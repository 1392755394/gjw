package com.gjw.common.constants;

/**
 * 任务管理相关常量定义
 * @author guojianbin
 *
 */
public class TaskConstant {

	//是否延期:延期
	public static final int DELAY_YES = 1;
	
	//是否延期:未延期
	public static final int DELAY_NO = 0;
	
	//验收状态:未验收
	public static final boolean CHECK_STATUS_NO = false;
	
	//验收状态:验收
	public static final boolean CHECK_STATUS_YES = true;
	
	//是否紧急:不紧急
	public static final boolean IS_URGENCY_NO = false;
	
	//是否紧急:紧急
	public static final boolean IS_URGENCY_YES = true;
	
	//任务类型:项目
	public static final int TASK_TYPE_PROJECT = 0;
	
	//任务类型:任务
	public static final int TASK_TYPE_TASK = 1;
	
	//参与人类型:参与人
	public static final int PARTICIPANT_TYPE_PARTICIPANT = 0;
	
	//参与人类型:负责人
	public static final int PARTICIPANT_TYPE_PRINCIPAL = 1;
	
	//是否已删除:未删除
	public static final boolean DEL_FLAG_NO = false;
	
	//是否已删除:已删除
	public static final boolean DEL_FLAG_YES = true;
	
	//文件类型:图片
	public static final int FILE_TYPE_PIC = 0;
	
	//文件类型:文件
	public static final int FILE_TYPE_FILE = 1;
	
	//施工项目:与g_task_type中设置一致
	public static final long TASK_TYPE_CONSTRUCTION = 5;
	
	//附件所属节点的类型:任务或者项目
	public static final int RELATION_TYPE_TASK = 0;
	
	//附件所属节点的类型:交流记录
	public static final int RELATION_TYPE_COMMUNICATION = 1;
	
	//客户类型:城运商
	public static final int CUSTOMER_TYPE_CITYOPERATOR = 0;
	
	//客户类型:4s店
	public static final int CUSTOMER_TYPE_SHOP = 1;
	
	//客户类型:业主
	public static final int CUSTOMER_TYPE_COMMON = 2;
	
	//员工类型:城运商
	public static final int USER_TYPE_CITYOPERATOR = 0;
	
	//员工类型:4s店
	public static final int USER_TYPE_SHOP = 1;
	
	//员工类型:构家网
	public static final int USER_TYPE_COMMON = 2;

    //消息类型:项目
    public static final int MESSAGE_TYPE_PROJECT= 0;

    //消息类型:任务
    public static final int MESSAGE_TYPE_TASK = 1;

    //消息类型:消息
    public static final int MESSAGE_TYPE_MESSAGE = 2;
}