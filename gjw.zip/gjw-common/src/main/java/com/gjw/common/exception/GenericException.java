/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.exception;

import com.gjw.common.error.ErrorMessage;

/**
 * 
 * @author Flouny.Caesar
 *
 */
public class GenericException extends ApplicationException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ErrorMessage errorMessage;
	
	public GenericException(String message){
	    super(message);
	    this.errorMessage=new ErrorMessage(message);
	}
	public GenericException(ErrorMessage errorMessage) {
		super(errorMessage.getMessage());
		this.errorMessage = errorMessage;
	}

	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(ErrorMessage errorMessage) {
		this.errorMessage = errorMessage;
	}
}