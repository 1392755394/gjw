package com.gjw.common.exception;

public class HTTP500Exception extends ApplicationException {

	private static final long serialVersionUID = 1L;

	public HTTP500Exception(String message) {
		super(message);
	}	
	
}
