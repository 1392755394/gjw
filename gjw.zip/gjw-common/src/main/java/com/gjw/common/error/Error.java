/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 自定义错误代码信息
 * 
 * @author Flouny.Caesar
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Error {
	String msg() default "";
}