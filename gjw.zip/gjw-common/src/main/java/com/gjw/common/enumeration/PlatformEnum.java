/**   
* @Title: PlatformEnum.java
* @Package com.gjw.common.enumeration
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 23, 2015 1:32:25 PM
* @version V1.0   
*/

package com.gjw.common.enumeration;

import com.gjw.entity.user.Platform;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoConsole;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.entity.user.UserInfoWebsite;


/**
 * @Description: 
 * @author  qingye
 * @date Dec 23, 2015 1:32:25 PM
 * 
 */

public enum PlatformEnum {
    Ges(2l,UserInfoGES.class),
    Website(1l,UserInfoWebsite.class),
    Console(3l,UserInfoConsole.class);
    private Platform obj;
    public Platform getObj() {
        return obj;
    }

    private Class<?> userInfoClazz;
    public Class<?> getUserInfoClazz() {
        return userInfoClazz;
    }

    PlatformEnum(Long id,Class<?> clazz){
        this.obj=new Platform();
        this.obj.setId(id);
        this.userInfoClazz=clazz;
    }
    
    public static PlatformEnum valueOfUserInfo(Class<? extends UserInfo> userInfoClazz){
        for(PlatformEnum platform:PlatformEnum.values()){
            if(platform.getUserInfoClazz()==userInfoClazz){
                return platform;
            }
        }
        return null;
    }
    
    public static PlatformEnum valueOfName(String platformName){
        platformName=platformName.toLowerCase();
        for(PlatformEnum platform:PlatformEnum.values()){
            if(platform.name().toLowerCase().equals(platformName)){
                return platform;
            }
        }
        return null;
    }

}
