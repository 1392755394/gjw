/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author jjw
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.helper;

/**
 * 读取configMap配置信息
 * 
 * @author jjw
 *
 */
public class Properties {
	
	protected static final String SERVER_WEB = "server.web";
	protected static final String SERVER_STATIC = "server.static";
	protected static final String SERVER_GOUJIA = "server.goujia";
	protected static final String SERVER_PARTNER = "server.partner";
	protected static final String SERVER_GUI = "server.gui";
	protected static final String SERVER_API = "server.api";
	protected static final String SERVER_DOWNLOAD = "server.download";
	protected static final String paymentResponse_file = "paymentResponse.file.path";
	protected static final String ignoreURLSurfixs = "ignoreURLSurfixs";
	
	protected static final String SERVER_GOUJIA_SUFFIX = "server.goujia.suffix";
	protected static final String SERVER_PARTNER_SUFFIX = "server.partner.suffix";
	
	public static String get(String key) {
		
		return ConfigInit.getConfigMap().get(key);
	}
}