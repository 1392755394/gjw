/**
 * Copyright 2014-2015 goujia.com
 * All rights reserved.
 * 
 * @project
 * @author guojianbin
 * @version 3.0
 * @date 2015-09-19
 */
package com.gjw.common.constants;

/**
 * 产品包DIY方案相关常量定义
 * @author guojianbin
 *
 */
public class GoodsDiyConstant {

	// 是否:是
	public static final String IS_YES = "y";

	// 是否:否
	public static final String IS_NO = "n";

	// 产品包状态:设计中
	//public static final String GOODS_STATUS_DESIGNING = "designing";

	// 产品包状态:已发布
	//public static final String GOODS_STATUS_PUBLISHED = "published";

	// 产品包状态:已删除
	//public static final String GOODS_STATUS_DELETED = "deleted";

    // 产品包状态:设计中
    public static final int GOODS_STATUS_DESIGNING = 1;

    // 产品包状态:已发布
    public static final int GOODS_STATUS_PUBLISHED = 2;

    // 产品包状态:已删除
    public static final int GOODS_STATUS_DELETED = 3;

    // 4S店产品包状态:已上架
    public static final int SHOP_GOODS_STATUS_ENABLE = 0;

    // 4S店产品包状态:已下架
    public static final int SHOP_GOODS_STATUS_DISABLE = 1;

    // 4S店产品包状态:已删除
    public static final int SHOP_GOODS_STATUS_DELETED = 2;

	// 物料一级类目:电气设备安装系统G
	public static final int CATEGORY_FIRST_DIANQISHEBEI = 12;

	// 物料一级类目:柜体收纳系统T
	public static final int CATEGORY_FIRST_GUITISHOUNA = 13;

	// 物料一级类目:三墙面造型系统M
	public static final int CATEGORY_FIRST_SANQIANGMIAN = 14;

	// 物料一级类目:五金链接系统H
	public static final int CATEGORY_FIRST_WUJINLIANJIE = 15;

	// 物料一级类目:灯光照明系统L
	public static final int CATEGORY_FIRST_DENGGUANG = 16;

	// 物料一级类目:厨卫阳台系统K
	public static final int CATEGORY_FIRST_CHUWEIYANGTAI = 17;

	// 物料一级类目:移动家具系统F
	public static final int CATEGORY_FIRST_YIDONGJIAJU = 18;

	// 物料一级类目:艺术陈设系统A
	public static final int CATEGORY_FIRST_YISHUCHENSHE = 19;

	// DIY方案创建者类型:业主
	public static final int DIY_CREATOR_TYPE_USER = 0;

	// DIY方案创建者类型:管理员
	public static final int DIY_CREATOR_TYPE_ADMIN = 1;

	// 物料类型:标配
	//public static final String GOODS_MATTER_TYPE_STANDARD = "standard";
    public static final long GOODS_MATTER_TYPE_STANDARD = 1030501;

	// 物料类型:选配
	//public static final String GOODS_MATTER_TYPE_OPTIONAL = "optional";
    public static final long GOODS_MATTER_TYPE_OPTIONAL = 1030502;

    // 产品包类型:整装产品包
    public static final long GOODS_TYPE_Z = 1030101;

    // 产品包类型:软装包
    public static final long GOODS_TYPE_R = 1030102;

    // 产品包类型:阳台景观包
    public static final long GOODS_TYPE_Y = 1030103;

    // 产品包类型:阳台私享定制
    public static final long GOODS_TYPE_CUSTOMIZATION = 1030104;

    // 产品包类型:阳台精品套餐
    public static final long GOODS_TYPE_SET = 1030105;

    // 产品包类型:家庭植物包
    public static final long GOODS_TYPE_PLANT = 1030106;

	// 是否DIY:产品包
	public static final long IS_DIY_GOODS = 1030201;

	// 是否DIY:标准DIY方案
	public static final long IS_DIY_STANDARD = 1030202;

	// 是否DIY:用户DIY方案
	public static final long IS_DIY_USER = 1030203;

	// DIY操作类型:增加
	public static final long DIY_OPRATE_TYPE_ADD = 1030601;

	// DIY操作类型:减少
	public static final long DIY_OPRATE_TYPE_REDUCE = 1030602;

	// DIY操作类型:更换
	public static final long DIY_OPRATE_TYPE_REPLACE = 1030603;

	// 物料分类:硬装
	public static final long MATTER_CLASSIFICATION_HARD = 1060902;

	// 物料分类:软装
	public static final long MATTER_CLASSIFICATION_SOFT = 1060903;

	// 物料分类:其他
	public static final long MATTER_CLASSIFICATION_OTHER = 1060901;

	// 物料位置分类:其他
	public static final long MATTER_POSITION_OTHER = 1061001;

	// 物料位置分类:顶部
	public static final long MATTER_POSITION_TOP = 1061002;

	// 物料位置分类:底部
	public static final long MATTER_POSITION_BOTTOM = 1061003;

	// 物料位置分类:左侧
	public static final long MATTER_POSITION_LEFT = 1061004;

	// 物料三级类目:MZ02 瓷砖
	public static final int CATEGORY_THIRD_CIZHUAN = 171;

	// 物料三级类目:MZ05 木地板
	public static final int CATEGORY_THIRD_MUDIBAN = 174;

	// 物料三级类目:MZ15壁纸
	public static final int CATEGORY_THIRD_BIZHI = 184;

	// 物料三级类目:MZ16  集成吊顶
	public static final int CATEGORY_THIRD_JICHENGDIAODING = 185;

	// 是否编辑:否
	public static final int IS_MODIFY_NO = 0;

	// 是否编辑:编辑标准DIY
	public static final int IS_MODIFY_STANDARD = 1;

	// 是否编辑:编辑普通DIY
	public static final int IS_MODIFY_NORMAL = 2;

    // 十大系统价格:艺术陈设系统
    public static final long BUDGET_CATEGORY_YISHUCHENSHE = 1030801;

    // 十大系统价格:移动家具系统
    public static final long BUDGET_CATEGORY_YIDONGJIAJU = 1030802;

    // 十大系统价格:给排水线系统
    public static final long BUDGET_CATEGORY_GEIPAISHUI = 1030803;

    // 十大系统价格:强弱电管线系统
    public static final long BUDGET_CATEGORY_QIANRUODIAN = 1030804;
	
    // 十大系统价格:电气设备安装系统
    public static final long BUDGET_CATEGORY_DIANQISHEBEI = 1030805;

    // 十大系统价格:五金链接系统
    public static final long BUDGET_CATEGORY_WUJINLIANJIE = 1030806;

    // 十大系统价格:三墙面造型系统
    public static final long BUDGET_CATEGORY_SANQIANGMIAN = 1030807;

    // 十大系统价格:灯光照明系统
    public static final long BUDGET_CATEGORY_DENGGUANG = 1030808;

    // 十大系统价格:厨卫阳台系统
    public static final long BUDGET_CATEGORY_CHUWEIYANGTAI = 1030809;

    // 十大系统价格:柜体收纳系统
    public static final long BUDGET_CATEGORY_GUITISHOUNA = 1030810;
}
