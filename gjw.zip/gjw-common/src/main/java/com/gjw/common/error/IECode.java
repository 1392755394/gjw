/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;

/**
 * 错误码接口
 * 
 * @author Flouny.Caesar
 *
 */
public interface IECode {
	
	public final static String SPLIT_CHAR = "|";

	public String toString();
	
	public String toDynamicString(Object...parameters);
}