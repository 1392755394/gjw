/**   
* @Title: UserConstants.java
* @Package com.gjw.common.constants
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 18, 2015 2:58:31 PM
* @version V1.0   
*/

package com.gjw.common.constants;

/**
 * @Description: 
 * @author  qingye
 * @date Dec 18, 2015 2:58:31 PM
 * 
 */

public class UserConstants {
    public static final String SESSION_USER="session_user";
    public static final String IGNORE_LOGIN_CHECK="ignoreLoginCheck";
    
}
