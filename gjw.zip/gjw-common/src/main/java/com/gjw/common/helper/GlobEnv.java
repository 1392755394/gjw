/**
 * Copyright 2014-2015 goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-05-12
 */
package com.gjw.common.helper;

import com.gjw.utils.StringUtil;


/**
 * 获取静态/动态资源
 * @author Flouny.Caesar
 *
 */
public class GlobEnv extends Properties {
	
	/**
	 * 获取静态根目录资源
	 * @return
	 */
	public static String getStaticRoot() {
		String rootPath = get(SERVER_STATIC);
		if (StringUtil.isBlank(rootPath)) return null;
		
		StringBuffer buffer = new StringBuffer();
		
		if(rootPath.startsWith("http://")) {
			buffer.append(rootPath.substring(0, rootPath.indexOf("//") + 2));
			String start = rootPath.substring(rootPath.indexOf("//") + 2);
			if (start.indexOf("/") != -1) {
				buffer.append(start.substring(0, start.indexOf("/")));
			} else {
				buffer.append(start + "/");
			}
		}
		
		return buffer.toString();
	}
	
	/**
	 * 获取静态资源
	 * @param path
	 * @return
	 */
	public static String getStaticURL(String path) {
		
		return getURL(get(SERVER_STATIC), path);
	}
	
	/**
	 * 获取组件GUI路径
	 * @param path
	 * @return
	 */
	public static String getStaticGUI(String path) {
		
		return getURL(get(SERVER_GUI), path);
	}
	
	/**
	 * 获取动态资源
	 * @param path
	 * @return
	 */
	public static String getWebURL(String path) {
		
		return getURL(get(SERVER_WEB), path);
	}
	
	/**
	 * 获取API资源
	 * @param path
	 * @return
	 */
	public static String getApiURL(String path) {
		
		return getURL(get(SERVER_API), path);
	}
	
	/**
	 * 获取资源路径
	 * @param prefixPath
	 * @return
	 */
	public static String getPath(String prefixPath) {
		if (StringUtil.isBlank(prefixPath)) return null;
		
		return get(prefixPath);
	}
	
	/**
	 * 获取下载路径
	 * @param path
	 * @return
	 */
	public static String getDownloadURL(String path) {
		
		return getURL(get(SERVER_DOWNLOAD), path);
	}
	
	private static String getURL(String base, String path) {
		if (StringUtil.isBlank(base)) return null;
		
		if (StringUtil.isNotBlank(base) && StringUtil.isBlank(path)) return base;
		
		String url = null;
		if (base.endsWith("/") && !path.startsWith("/")) {
			url = base + path;
		} else if (!base.endsWith("/") && path.startsWith("/")) {
			url = base + path;
		} else if (base.endsWith("/") && path.startsWith("/")) {
			base = base.substring(0, base.length() - 1);
			url = base + path;
		} else if (!base.endsWith("/") && !path.startsWith("/")) {
			url = base + "/" + path;
		}
		
		return url;
	}
	
	/**
	 * 获取server地址
	 * @param server
	 * @return
	 */
	public static String getServerURL(String server) {
		
		return getURL(get(server), "");
	}
	
	public static String getIgnoreURLSurfixs(){
		return get(ignoreURLSurfixs);
	}
	
	public static String getServerGouJiaSuffix(){
		return get(SERVER_GOUJIA_SUFFIX);
	}
	
	public static String getServerPartnerSuffix(){
		return get(SERVER_PARTNER_SUFFIX);
	}
}