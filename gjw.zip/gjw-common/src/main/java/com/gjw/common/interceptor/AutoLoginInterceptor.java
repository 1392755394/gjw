/**   
* @Title: LoginInterceptor.java
* @Package con.gjw.common.interceptor
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 18, 2015 2:40:38 PM
* @version V1.0   
*/

package com.gjw.common.interceptor;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.gjw.common.constants.UserConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.handler.LoginHandler;
import com.gjw.common.helper.sso.SSOHelper;
import com.gjw.entity.user.User;

/**
 * @Description: 
 * @author  qingye
 * @date Dec 18, 2015 2:40:38 PM
 * 
 */

public class AutoLoginInterceptor extends HandlerInterceptorAdapter{
    @Value("${platform.name}")
    private String platformName;
    
    @Value("${sso.url}")
    private String ssoUrl;
    
    @Autowired
    private SSOHelper ssoHelper;
    
    @Autowired
    private LoginHandler loginHandler;
    
    @Override
    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) throws Exception {
        if(request.getHeader("x-requested-with")==null){
            if(SSOHelper.hadTicket(request.getQueryString())){
                response.sendRedirect(SSOHelper.getNoTicketUrl(request.getRequestURL().toString(),request.getQueryString()));
                return false;
            }
            Boolean ignore=(Boolean)request.getAttribute(UserConstants.IGNORE_LOGIN_CHECK);
            if(ignore==null || !ignore){
                if(loginHandler.getUserFromSession(request.getSession())==null){
                    if(requireLogin(request.getCookies())){
                        String url=getSSOUrl(request.getRequestURL().toString());
                        response.sendRedirect(url);
                        return false;
                    }
                } 
            }
        }
        return super.preHandle(request, response, handler);
    }
    
    
    /** 
    * @Description  
    * @param requestURL
    * @return
    * @author qingye   
    * @date Dec 18, 2015 6:25:52 PM
    */
    
    private String getSSOUrl(String requestURL) {
        StringBuffer sb=new StringBuffer(ssoUrl);
        sb.append("/login");
        sb.append("?service=");
        try {
            sb.append(URLEncoder.encode(requestURL, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        sb.append("&isAuto=");
        sb.append(true);
        return sb.toString();
    }


    /**
     * 
    * @Description 判断cookie中是否包含hadLogin且值为true  
    * @param cookies
    * @return
    * @author qingye   
    * @date Dec 18, 2015 3:04:07 PM
     */
    private boolean requireLogin(Cookie[] cookies){
        int loginFlag=ssoHelper.getLoginFlagValue(cookies);
        if(loginFlag!=0)
            return ssoHelper.requireLogin(PlatformEnum.valueOfName(platformName), loginFlag);
        return false;
    }

}
