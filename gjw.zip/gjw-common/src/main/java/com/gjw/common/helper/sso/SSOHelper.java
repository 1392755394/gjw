/**   
* @Title: UserHelper.java
* @Package com.gjw.common.helper.user
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 18, 2015 5:18:04 PM
* @version V1.0   
*/

package com.gjw.common.helper.sso;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gjw.common.constants.UserConstants;
import com.gjw.common.enumeration.PlatformEnum;

/**
 * @Description: 
 * @author  qingye
 * @date Dec 18, 2015 5:18:04 PM
 * 
 */

public class SSOHelper {
    @Value("${login.flag.name}")
    private String loginFlagName;
    
    private Map<PlatformEnum,Integer> platformToBit=null;
    public SSOHelper(){
        platformToBit=new HashMap<PlatformEnum, Integer>();
        platformToBit.put(PlatformEnum.Website,1);
        platformToBit.put(PlatformEnum.Ges, 2);
        platformToBit.put(PlatformEnum.Console,4);
    }
    public boolean requireLogin(PlatformEnum platform,int loginFlag){
        int currentPlatformBit=platformToBit.get(platform);
        return (currentPlatformBit&loginFlag)==currentPlatformBit;
    }
    public int cancleLoginFlag(PlatformEnum platform,int loginFlag){
        int currentPlatformBit=platformToBit.get(platform);
        if((currentPlatformBit&loginFlag)==currentPlatformBit)
            return currentPlatformBit^loginFlag;
        return loginFlag;
    }
    
    /**
     * 
    * @Description 判断cookie中是否包含hadLogin且值为true  
    * @param cookies
    * @return
    * @author qingye   
    * @date Dec 18, 2015 3:04:07 PM
     */
    public int getLoginFlagValue(Cookie[] cookies){
        if(cookies==null)
            return 0;
        for(Cookie cookie:cookies){
            if(cookie.getName().equals(loginFlagName))
                return Integer.parseInt(cookie.getValue());
        }
        return 0;
    }
    
    public Cookie getCookie(int loginFlag){
        Cookie cookie=new Cookie(loginFlagName, String.valueOf(loginFlag));
        cookie.setDomain(".goujiawang.com");
        cookie.setPath("/");
        return cookie;
    }
    
    public static String getNoTicketUrl(String url,String question){
        StringBuilder t=new StringBuilder();
        t.append(url);
        t.append("?");
        t.append(question);
        url=t.toString();
        StringBuilder newUrl=new StringBuilder();
        int qpos=url.indexOf('?');
        if(qpos==-1)
            return url;
        newUrl.append(url.subSequence(0, qpos));
        int tposStart=url.indexOf("ticket=",qpos);
        if(tposStart==-1)
            return url;
        if(tposStart-qpos>1){
            if(url.charAt(tposStart-1)=='&')
                newUrl.append(url.substring(qpos,tposStart-1));
            else
                newUrl.append(url.substring(qpos,tposStart));
        }
        int tposEnd=url.indexOf("&",tposStart);
        if(tposEnd==-1)
            return newUrl.toString();
        if(tposStart-qpos==1){
            newUrl.append("?");
            tposEnd++;
        }
        newUrl.append(url.substring(tposEnd,url.length()));
        return newUrl.toString();
    }
    /** 
    * @Description  
    * @param string
    * @return
    * @author qingye   
    * @date Jan 14, 2016 3:36:51 PM
    */
    
    public static boolean hadTicket(String url) {
        if(url==null)
            return false;
        return url.contains("ticket=");
    }
}
