package com.gjw.common.constants;

/**
 * 
 * @Description: 基本静态类字段值
 * @author zhaoyonglian
 * @date 2015年12月15日 下午3:59:55
 * 
 */
public class DictionaryConstants {

    // 楼盘字典

    public static final Long DICTIONARY_BUILIDNG = 101l;
    /**
     * 物业类型
     */
    public static final Long DICTIONARY_BUILIDNG_PROPERTY = 10101l;
    /**
     * 建筑类型
     */
    public static final Long DICTIONARY_BUILIDNG_CONSTRUCTION = 10102l;
    /**
     * 相册类型
     */
    public static final Long DICTIONARY_BUILIDNG_ALBUM = 10103l;
    
    //轮播图
    public static final Long DICTIONARY_BUILIDNG_ALBUM_BANNER = 1010301l;
    //相册
    public static final Long DICTIONARY_BUILIDNG_ALBUM_PHOTO = 1010302l;
    
    // 城运商字典
    public static final Long DICTIONARY_CITYOPERATOR = 102l;

    // 产品包字典
    public static final Long DICTIONARY_GOODS = 103l;
    /**
     * 产品包类型
     */
    public static final Long DICTIONARY_GOODS_TYPE = 10301l;

    // 产品包类型:整装产品包
    public static final long DICTIONARY_GOODS_TYPE_Z = 1030101;

    // 产品包类型:软装包
    public static final long DICTIONARY_GOODS_TYPE_R = 1030102;

    // 产品包类型:阳台景观包
    public static final long DICTIONARY_GOODS_TYPE_Y = 1030103;

    // 产品包类型:阳台私享定制
    public static final long DICTIONARY_GOODS_TYPE_CUSTOMIZATION = 1030104;

    // 产品包类型:阳台精品套餐
    public static final long DICTIONARY_GOODS_TYPE_SET = 1030105;

    // 产品包类型:家庭植物包
    public static final long DICTIONARY_GOODS_TYPE_PLANT = 1030106;

    /**
     * DIY类型
     */
    public static final Long DICTIONARY_GOODS_DIY = 10302l;
    
    //产品包
    public static final Long DICTIONARY_GOODS_DIY_GOODS = 1030201l;
    //标准DIY方案
    public static final Long DICTIONARY_GOODS_DIY_STANDARD = 1030202l;
    //用户DIY方案
    public static final Long DICTIONARY_GOODS_DIY_USER = 1030203l;

    /**
     * 户型
     */
    public static final Long DICTIONARY_GOODS_HOUSE = 10303l;
    /**
     * 系列
     */
    public static final Long DICTIONARY_GOODS_STYLE = 10304l;
    /**
     * 物料类型（标配..）
     */
    public static final Long DICTIONARY_GOODS_MATTER = 10305l;
    // 是否为标配：是
    public static final Long DICTIONARY_GOODS_MATTER_Y = 1030501l;
    // 是否为标配：否
    public static final Long DICTIONARY_GOODS_MATTER_N = 1030502l;
    /**
     * DIY操作类型
     */
    public static final Long DICTIONARY_GOODS_OPERATION = 10306l;
    /**
     * 标记类型
     */
    public static final Long DICTIONARY_GOODS_MARK = 10307l;
    // 物料标记
    public static final Long DICTIONARY_GOODS_MARK_ONE = 1030701l;
    // 功能细节
    public static final Long DICTIONARY_GOODS_MARK_TWO = 1030702l;
    // 工艺标准
    public static final Long DICTIONARY_GOODS_MARK_THREE = 1030703l;

    /**
     * 价格类型（十大分类...）
     */
    public static final Long DICTIONARY_GOODS_PRICE = 10308l;
    /**
     * 房间属性
     */
    public static final Long DICTIONARY_GOODS_ROOM = 10309l;

    // 客户字典
    public static final Long DICTIONARY_CUSTOMER = 104l;
    /**
     * 账户类型
     */
    public static final Long DICTIONARY_CUSTOMER_ACCOUNT = 10401l;
    // 账户类型：承运商角色
    public static final Long DICIONARY_CUSTOMER_ACCOUNT_OPERATOR = 1040101l;
    /**
     * 职业类型
     */
    public static final Long DICTIONARY_CUSTOMER_JOB = 10402l;
    /**
     * 客户关注
     */
    public static final Long DICTIONARY_CUSTOMER_FOCUSE = 10403l;
    /**
     * 行业了解程度
     */
    public static final Long DICTIONARY_CUSTOMER_KNOWLEDGE = 10404l;
    /**
     * 居住情况
     */
    public static final Long DICTIONARY_CUSTOMER_LIVE = 10405l;
    /**
     * 问题类目
     */
    public static final Long DICTIONARY_CUSTOMER_QUESTION = 10406l;

    // 标签字典
    public static final Long DICTIONARY_LABEL = 105l;
    /**
     * 标签属性
     */
    public static final Long DICTIONARY_LABEL_PROPERTY = 10501l;

    // 分类标签
    public static final Long DICTIONARY_LABEL_PROPERTY_CATEGORY = 1050101l;
    // 建材百科
    public static final Long DICTIONARY_LABEL_PROPERTY_BUILD = 1050102l;
    // 装修百科
    public static final Long DICTIONARY_LABEL_PROPERTY_DECO = 1050103l;
    // 设计百科
    public static final Long DICTIONARY_LABEL_PROPERTY_DES = 1050104l;
    // 直播阶段
    public static final Long DICTIONARY_LABEL_PROPERTY_BORAD = 1050105l;

    // 物料字典
    public static final Long DICTIONARY_MATTER = 106l;
    /**
     * 使用性质
     */
    public static final Long DICTIONARY_MATTER_USE = 10601l;
    /**
     * 加工性质
     */
    public static final Long DICTIONARY_MATTER_PROCESS_NATURE = 10602l;
    /**
     * 配送阶段
     */
    public static final Long DICTIONARY_MATTER_PERIOD = 10603l;
    /**
     * 配送方式
     */
    public static final Long DICTIONARY_MATTER_SEND = 10604l;
    /**
     * 加工方式
     */
    public static final Long DICTIONARY_MATTER_PROCESS_MODE = 10605l;
    /**
     * 转化单位（no use）
     */
    public static final Long DICTIONARY_MATTER_UNIT = 10606l;
    /**
     * 安装工
     */
    public static final Long DICTIONARY_MATTER_INSTALLER = 10607l;
    /**
     * 收货地址类型
     */
    public static final Long DICTIONARY_MATTER_ADDRESS_TYPE = 10608l;
    /**
     * 分类（软，硬...）
     * 
     * 
     */
    public static final Long DICTIONARY_MATTER_CATEGORY = 10609l;
    /**
     * 位置分类（左，右..）
     */
    public static final Long DICTIONARY_MATTER_POSITION = 10610l;

    // 模型库字典
    public static final Long DICTIONARY_MODELLING = 107l;
    /**
     * 分类类目
     */
    public static final Long DICTIONARY_MODELLING_CATEGORY = 10701l;

    // OA字典
    public static final Long DICTIONARY_OA = 108l;
    /**
     * 任务类型
     */
    public static final Long DICTIONARY_OA_TASK = 10801l;

    // 订单字典
    public static final Long DICTIONARY_ORDER = 109l;
    /**
     * 采购状态
     */
    public static final Long DICTIONARY_ORDER_STATUS = 10901l;

    // 4S店字典
    public static final Long DICTIONARY_SHOP = 110l;
    /**
     * 4S店类型（直营...）
     */
    public static final Long DICTIONARY_SHOP_TYPE = 11001l;
    /**
     * 反馈类型
     */
    public static final Long DICTIONARY_SHOP_FEEDBACK = 11002l;

    // 库存字典
    public static final Long DICTIONARY_STOCK = 111l;
    /**
     * 仓库类型
     */
    public static final Long DICTIONARY_STOCK_TYPE = 11101l;

    // 用户字典
    public static final Long DICTIONARY_USER = 112l;
    /**
     * 收藏类型
     */
    public static final Long DICTIONARY_USER_COLLECT = 11201l;
    
    //产品包收藏
    public static final Long DICTIONARY_USER_COLLECT_GOODS = 1120101l;
    //话题收藏
    public static final Long DICTIONARY_USER_COLLECT_TOPIC = 1120102l;
    //文章收藏
    public static final Long DICTIONARY_USER_COLLECT_ARTICLE = 1120103l;
    //图片收藏
    public static final Long DICTIONARY_USER_COLLECT_IMAGE = 1120104l;
    
    /**
     * 评论类型
     */
    public static final Long DICTIONARY_USER_COMMET = 11202l;

    // 文章评论
    public static final Long DICTIONARY_USER_COMMET_ARTICLE = 1120201l;
    // 图片评论
    public static final Long DICTIONARY_USER_COMMET_IMAGE = 1120202l;
    // 直播家日志评论
    public static final Long DICTIONARY_USER_COMMET_HOME = 1120203l;
    // 产品包评论
    public static final Long DICTIONARY_USER_COMMET_GOODS = 1120204l;
    /**
     * 点赞类型
     */
    public static final Long DICTIONARY_USER_SUPPORT = 11203l;

    //产品包点赞
    public static final Long DICTIONARY_USER_SUPPORT_GOODS = 1120301l;
    //话题点赞
    public static final Long DICTIONARY_USER_SUPPORT_TOPIC = 1120302l;
    //文章点赞
    public static final Long DICTIONARY_USER_SUPPORT_ARTICLE = 1120303l;
    //图片点赞
    public static final Long DICTIONARY_USER_SUPPORT_IMAGE = 1120304l;
    
    
    // 其他字典
    public static final Long DICTIONARY_OTHER = 113l;
    /**
     * 数据同步
     */
    public static final Long DICTIONARY_OTHER_SYNC = 11301l;
    // 未同步（默认状态）
    public static final Long DICTIONARY_OTHER_SYNC_DEFAULT = 1130101l;
    // 同步成功
    public static final Long DICTIONARY_OTHER_SYNC_ONE = 1130102l;
    // 同步失败
    public static final Long DICTIONARY_OTHER_SYNC_TWO = 1130103l;
    // 同步后修改
    public static final Long DICTIONARY_OTHER_SYNC_THREE = 1130104l;
    // 同步失败数据已存在
    public static final Long DICTIONARY_OTHER_SYNC_FOUR = 1130105l;
    /**
     * 入驻类型
     */
    public static final Long DICTIONARY_OTHER_ENTER = 11302l;
    /**
     * 标签关联类型（百科）
     */
    public static final Long DICTIONARY_OTHER_LABEL = 11303l;

    /**
     * 问答标签百科类型
     */
    public static final Long DICTIONARY_OTHER_LABEL_QUESTION = 1130301l;

    /**
     * 文章标签百科类型
     */
    public static final Long DICTIONARY_OTHER_LABEL_ATICLE = 1130302l;

    /**
     * 话题标签百科类型
     */
    public static final Long DICTIONARY_OTHER_LABEL_TOPIC = 1130303l;
    /**
     * 接收者类型（验证码）
     */
    public static final Long DICTIONARY_OTHER_RECEPTOER = 11304l;
    /**
     * 推荐位类型
     */
    public static final Long DICTIONARY_OTHER_REC = 11305l;
    /**
     * 文件类型
     */
    public static final Long DICTIONARY_OTHER_FILE = 11306l;
    /**
     * 问题类型（官网）
     */
    public static final Long DICTIONARY_OTHER_QUESTION = 11307l;

    /**
     * 承运商分类
     */
    public static final Long DICTIONARY_CITYOPERATOR_TYPE = 10201l;
    // 合作承运商
    public static final Long DICTIONARY_CITYOPERATOR_SUCCESS = 1020101l;
    // 意向承运商
    public static final Long DICTIONARY_CITYOPERATOR_TARGET = 1020102l;
    // 已解约承运商
    public static final Long DICTIONARY_CITYOPERATOR_FAIL = 1020103l;

}
