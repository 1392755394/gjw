package com.gjw.common.enumeration;

import java.util.ArrayList;
import java.util.List;

import com.gjw.common.web.IState;

public enum OrderStatusCopy implements IState {
	booked{
		@Override
		public String getText() {
			return "已预定";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if(OrderAction.sign.equals(action)) {
				return OrderStatusCopy.auditing;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.sign);
			return list;
		}
		
	},
	sign{
        @Override
        public String getText() {
            return "已签约";
        }

        @Override
        public OrderStatusCopy doAction(OrderAction action) {
            if(OrderAction.sign.equals(action)) {
                return OrderStatusCopy.auditing;
            }
            return this;
        }

        @Override
        public List<OrderAction> getActionsForWeb() {
            return null;
        }

        @Override
        public List<OrderAction> getActionsForGes() {
            List<OrderAction> list = new ArrayList<OrderAction>();
            list.add(OrderAction.sign);
            return list;
        }
        
    },
	auditing{
		@Override
		public String getText() {
			return "待核对合同";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.audit.equals(action)) {
				return OrderStatusCopy.prepaying;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.audit);
			return list;
		}
		
	},
	prepaying{
		@Override
		public String getText() {
			return "待支付10%装修定金";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.prepay.equals(action)) {
				return OrderStatusCopy.arriving_earnest;
			}else if(OrderAction.pos.equals(action)){
				return OrderStatusCopy.arriving_earnest;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.prepay);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.pos);
			return list;
		}
		
	},
	arriving_earnest{
		@Override
		public String getText() {
			return "已扣款10%装修定金,待到账";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.check.equals(action)) {
				return OrderStatusCopy.starting_AZZC;
			} 
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	starting_AZZC{
		@Override
		public String getText() {
			return "已到账，安装总成阶段开工";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.start.equals(action)) {
				return OrderStatusCopy.started_AZZC;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.start);
			return list;
		}
		
	},
	started_AZZC{
		@Override
		public String getText() {
			return "安装总成阶段施工中";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.finish.equals(action)) {
				return OrderStatusCopy.accepting_AZZC;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.finish);
			return list;
		}
		
	},
	accepting_AZZC{
		@Override
		public String getText() {
			return "安装总成阶段等待验收中";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.accept.equals(action)) {
				return OrderStatusCopy.accepted_AZZC;
			}else if(OrderAction.unaccept.equals(action)){
			    return OrderStatusCopy.mediating_AZZC;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.accept);
			list.add(OrderAction.unaccept);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	mediating_AZZC{
		@Override
		public String getText() {
			return "安装总成阶段待调解";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if(OrderAction.agree.equals(action)) {
				return OrderStatusCopy.accepted_AZZC;
			}
			//目前没有不同意的，不同意一直调节为同意为止
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.agree);
			list.add(OrderAction.unagree);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	accepted_AZZC{
		@Override
		public String getText() {
			return "安装总成已验收，等待汇入余款至购家宝";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.freeze.equals(action)) {
				return OrderStatusCopy.arriving_credit;
			}else if(OrderAction.pos.equals(action)){
				return OrderStatusCopy.arriving_credit;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.freeze);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.pos);
			return list;
		}
		
	},
	arriving_credit{
		@Override
		public String getText() {
			return "已扣款90%余款,待到账";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.check.equals(action)) {
				return OrderStatusCopy.paying_AZZC;
			} 
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	paying_AZZC{
		@Override
		public String getText() {
			return "已到账，等待支付30%装修款";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.repay.equals(action)) {
				return OrderStatusCopy.starting_JZFZ;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.repay);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	starting_JZFZ{
		@Override
		public String getText() {
			return "已支付，等待建筑附着阶段施工";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.start.equals(action)) {
				return OrderStatusCopy.started_JZFZ;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.start);
			return list;
		}
		
	},
	started_JZFZ{
		@Override
		public String getText() {
			return "建筑附着阶段施工中";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.finish.equals(action)) {
				return OrderStatusCopy.accepting_JZFZ;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.finish);
			return list;
		}
		
	},
	accepting_JZFZ{
		@Override
		public String getText() {
			return "建筑附着阶段完工，等待验收";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.accept.equals(action)) {
				return OrderStatusCopy.accepted_JZFZ;
			}else if(OrderAction.unaccept.equals(action)){
			    return OrderStatusCopy.mediating_JZFZ;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.accept);
			list.add(OrderAction.unaccept);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	mediating_JZFZ{
		@Override
		public String getText() {
			return "建筑附着阶段待调解";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if(OrderAction.agree.equals(action)) {
				return OrderStatusCopy.accepted_JZFZ;
			}
			//目前没有不同意的，一直协商
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.agree);
			list.add(OrderAction.unagree);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
	},
	accepted_JZFZ{
		@Override
		public String getText() {
			return "建筑附着阶段验收，等待支付30%工程款";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.repay.equals(action)) {
				return OrderStatusCopy.starting_YSCS;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.repay);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	starting_YSCS{
		@Override
		public String getText() {
			return "已支付，等待艺术陈设阶段施工";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.start.equals(action)) {
				return OrderStatusCopy.started_YSCS;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.start);
			return list;
		}
		
	},
	started_YSCS{
		@Override
		public String getText() {
			return "艺术陈设阶段施工中";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.finish.equals(action)) {
				return OrderStatusCopy.accepting_YSCS;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.finish);
			return list;
		}
		
	},
	accepting_YSCS{
		@Override
		public String getText() {
			return "艺术陈设阶段完成，等待验收";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.accept.equals(action)) {
				return OrderStatusCopy.accepted_YSCS;
			}else if(OrderAction.unaccept.equals(action)){
			    return OrderStatusCopy.mediating_YSCS;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.accept);
			list.add(OrderAction.unaccept); 
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	mediating_YSCS{
		@Override
		public String getText() {
			return "艺术陈设阶段待调解";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if(OrderAction.agree.equals(action)) {
				return OrderStatusCopy.accepted_YSCS;
			}
			//目前没有不同意，一直协调至同意为止
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.agree);
			list.add(OrderAction.unagree);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	accepted_YSCS{
		@Override
		public String getText() {
			return "艺术陈设阶段验收，等待支付30%工程款";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			if (OrderAction.repay.equals(action)) {
				return OrderStatusCopy.completed;
			}
			return this;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			List<OrderAction> list = new ArrayList<OrderAction>();
			list.add(OrderAction.repay);
			return list;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	},
	completed{
		@Override
		public String getText() {
			return "完工（订单结束）";
		}

		@Override
		public OrderStatusCopy doAction(OrderAction action) {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForWeb() {
			return null;
		}

		@Override
		public List<OrderAction> getActionsForGes() {
			return null;
		}
		
	}
	
	;
	public boolean equals(String status){
		return this.name().equals(status);
	}
	
	public OrderStatusCopy getOrderStatus(String name){
		return valueOf(name);
	}

}
