package com.gjw.common.constants;

public class OrderConstant {
	
	public static final Integer QUERY_ORDER=0;
	
	public static final Integer QUERY_PROJECT=1;
	
	public static final String ORDER_PROJECT_STATUS="signed";

}
