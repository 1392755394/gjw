/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;
import com.gjw.common.error.IECode;
import com.gjw.common.error.Error;
import com.gjw.utils.StringUtil;

/**
 * 全局错误码 由：模块名+"_"+数字组成 业务模块名以模块名简写字母开头，数字300000-399999 例如：reg_300000 注册失败
 * login_300001 登录失败
 * 
 * @author Flouny.Caesar
 * 
 */
public enum BECode implements IECode {

	/**
	 * 楼盘错误码
	 */
	@Error(msg = "楼盘Id不正确！")
	building_300000(300000),

	@Error(msg = "楼盘新增失败！")
	building_300001(300001),

	/**
	 * 图片上传错误码
	 */
	@Error(msg = "图片格式错误或大小受限！")
	photo_300001(300001),

	/**
	 * 会员错误码
	 */
	@Error(msg = "会员Id不正确！")
	member_300000(300000),
	/**
	 * @时间错误
	 */
	@Error(msg = "填写正确的日期！")
	building_400001(400001),
	/**
	 * 上传错误码
	 */
	@Error(msg = "文件不能为null！")
	store_300000(300000),

	@Error(msg = "文件不能大于20M！")
	store_300001(300001),

	@Error(msg = "文件上传失败！")
	store_300002(300002),

	@Error(msg = "该用户不支持该操作！")
	shop_400001(400001),
	
	@Error(msg = "销售单不存在！")
	purchase_300002(30002),
	
	@Error(msg = "该订单已生成过采购单！")
	purchase_300001(300001),
	
	
	@Error(msg = "该订单不存在！")
	order_300001(300001),
	/**
	 * @DIY配置错误
	 */
	@Error(msg = "%s的物料(%s)未配置，请将标配物料全部配置！")
	diy_300001(300001);

	private int code;

	BECode(int code) {
		this.code = code;
	}

	public int getCode() {

		return code;
	}

	private String getName() {

		return this.name();
	}

	/**
	 * 返回错误信息
	 * 
	 * @return
	 */
	public String getMessage() {
		Error error = null;
		try {
			error = this.getClass().getField(getName())
					.getAnnotation(Error.class);
		} catch (Exception e) {

			return null;
		}

		return error.msg();
	}

	/**
	 * 
	 */
	public String toString() {
		String message = this.getMessage();

		return "errCode".concat(String.valueOf(this.getCode())).concat(SPLIT_CHAR)
				.concat((StringUtil.isBlank(message) ? "" : message));
		
		//return StringUtil.isBlank(message) ? "" : message;
	}

	/**
	 * 返回错误码+动态错误信息
	 * 
	 * @return
	 */
	public String toDynamicString(Object... parameters) {

		return String.format(this.toString(), parameters);
	}
}