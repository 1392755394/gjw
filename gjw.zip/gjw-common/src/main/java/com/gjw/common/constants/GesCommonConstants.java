package com.gjw.common.constants;

public class GesCommonConstants {
	
	public static final String ORG_TYPE_CITY_OPERATOR="city_operator";
	
	public static final String ORG_TYPE_SHOP="shop";
	
	public static final String ORG_TYPE_GJW="admin";
    
    public static final String ORG_TYPE_DEVELOPER="developer";

}
