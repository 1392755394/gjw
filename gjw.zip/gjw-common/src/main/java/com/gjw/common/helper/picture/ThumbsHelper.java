package com.gjw.common.helper.picture;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class ThumbsHelper {

    /**
     * 设置缩略图
     * @Description  
     * @param sourceImg
     * @return 缩略图尺寸列表
     * @author guojianbin   
     * @date 2015年12月19日
     */
    public List<Rectangle> getThumbs(BufferedImage sourceImg) {
        List<Resolution> res = getFilters(sourceImg.getWidth(), sourceImg.getHeight());
        List<Rectangle> sizeList=new ArrayList<Rectangle>();
        for (Resolution r : res) {
            Rectangle rectangle = new Rectangle(r.getWidth(), r.getHeight());
            sizeList.add(rectangle);
        }

        return sizeList;
    }

    /**
     * 根据给定尺寸返回可压缩的比例尺寸
     * @Description  
     * @param width
     * @param height
     * @return 比例尺寸列表
     * @author guojianbin   
     * @date 2015年12月19日
     */
    private List<Resolution> getFilters(int width, int height) {
        Resolution[] resolutions = Resolution.values();
        int iEqual = width + height;
        List<Resolution> tmpList = new ArrayList<Resolution>();
        for (int i = 0; i < resolutions.length; i++) {
            Resolution resolution = resolutions[i];
            int rEqual = resolution.getWidth() + resolution.getHeight();

            if (rEqual <= iEqual) {
                tmpList.add(resolution);
            }
        }

        List<Resolution> results = new ArrayList<Resolution>();
        for (int j = 0; j < tmpList.size(); j++) {
            Resolution resolution = tmpList.get(j);
            if (resolution.getWidth() <= width
                    && resolution.getHeight() <= height) {
                results.add(resolution);
            }
        }

        return results;
    }

}
