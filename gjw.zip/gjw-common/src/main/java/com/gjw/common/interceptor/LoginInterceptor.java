package com.gjw.common.interceptor;


import java.util.List;

import com.gjw.common.constants.UserConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.handler.LoginHandler;
import com.gjw.common.helper.sso.SSOHelper;
import com.gjw.company.service.user.IAuthenticationService;
import com.gjw.company.service.user.IUserService;
import com.gjw.entity.user.User;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.jasig.cas.client.util.AbstractCasFilter;
import org.jasig.cas.client.validation.Assertion;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gjw.shiro.GesUserIdToken;

/**
 *  ctx url拦截器
 *  
 * @author lijy
 *
 */
public class LoginInterceptor extends HandlerInterceptorAdapter{
    
    @Autowired
    private LoginHandler loginHandler;
    
    @Autowired
	private IUserService userService;
	
	@Autowired
	private IAuthenticationService authenticationService;
	Logger log=org.slf4j.LoggerFactory.getLogger(this.getClass());
	@Value("${platform.name}")
    private String platformName;
	
	@Autowired
	private SSOHelper ssoHelper;
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		User user=loginHandler.getUserFromSession(request.getSession());
		if(user==null){
			Assertion assertion = (Assertion) request.getSession().getAttribute(AbstractCasFilter.CONST_CAS_ASSERTION);
			if(assertion!=null){
				log.warn("UserInterceptor --------------------"+assertion.getPrincipal().getName());
				user=authenticationService.getByLogin(assertion.getPrincipal().getName()).getUser();
				user=userService.getWithAllInfo(user.getId());
				
				PlatformEnum platform=PlatformEnum.valueOfName(platformName);
				if(loginHandler.hadPermission(request, response, user)){
				    try{
				        user.setPlatformUserInfo(user.getUserInfo(platform));
				        loginHandler.setUserToSession(request.getSession(), user);
				        loginHandler.deal(request, response, user);
				    }
				    catch(Exception e){
				        loginFail(request,response,platform);
				        e.printStackTrace();
				    }

				} else{
				    loginFail(request,response,platform);
				}
			}
		}

        Subject currentUser = SecurityUtils.getSubject();
        if ((!currentUser.isAuthenticated()) && user != null) {
            // 实际上是已经知道了 user 的 id，不需要验证了，只不过走走 shiro 的流程而已，然后检查下是否具有相应的访问权限
//                        GesUserIdToken token = new GesUserIdToken(user.getId()); 只能是 UsernamePasswordToken 的实例
            UsernamePasswordToken token = new UsernamePasswordToken();
            token.setUsername(user.getId().toString());
            token.setPassword(user.getId().toString().toCharArray());
            currentUser.login(token);
            
            if (currentUser.getSession().getAttribute("allPermissionNames") == null){
                List<String> allPermissionNames = userService.loadAllPermissionNames(user.getId());
                currentUser.getSession().setAttribute("allPermissionNames", allPermissionNames);
            }
        }


		return true;
	}
	
    private void loginFail(HttpServletRequest request,
            HttpServletResponse response,PlatformEnum platform){
	    request.setAttribute(UserConstants.IGNORE_LOGIN_CHECK, true);
        int loginFlag=ssoHelper.getLoginFlagValue(request.getCookies());
        if(loginFlag==0)
            return ;
        loginFlag=ssoHelper.cancleLoginFlag(platform,loginFlag);
        response.addCookie(ssoHelper.getCookie(loginFlag));
	}


}
