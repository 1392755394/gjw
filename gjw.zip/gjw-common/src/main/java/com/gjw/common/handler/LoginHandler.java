/**   
* @Title: UserHandler.java
* @Package com.gjw.common.handler
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Jan 4, 2016 3:00:10 PM
* @version V1.0   
*/

package com.gjw.common.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gjw.entity.user.User;

/**
 * @Description: 
 * @author  qingye
 * @date Jan 4, 2016 3:00:10 PM
 * 
 */

public interface LoginHandler {
    boolean hadPermission(HttpServletRequest request, HttpServletResponse response,User user);
    String deal(HttpServletRequest request,HttpServletResponse response,User user);
    void setUserToSession(HttpSession session,User user);
    User getUserFromSession(HttpSession session);
}
