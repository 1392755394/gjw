package com.gjw.common.constants;
/**
 * 任务状态
 * 0：未开始
 * 1：进行中
 * 2：已延期
 * 3：已取消
 * 4：已完成
 * @author guojianbin
 *
 */
public enum TaskStatusEnums {
	NOTSTARTED(0), 
	GOING(1), 
	DELAYED(2), 
	CANCELLED(3),
	FINISHED(4);
	
	private int code;
	
	TaskStatusEnums(int code){
		this.code = code;
	}
	
	public int getCode() {
		return code;
	}
}
