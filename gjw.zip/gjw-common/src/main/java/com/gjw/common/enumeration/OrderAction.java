package com.gjw.common.enumeration;

public enum OrderAction {

	book("预定"),
	sign("签署合同"),
	audit("核对合同"),
	pos("POS机支付"),
	check_earnest("财务核算"), //核算定金到账
	check("财务核算"), //核算余款到账
	
	prepay("网银支付"), //支付定金
	start("开工"),
	finish("完工"),
	freeze("网银支付"), //支付余款
	
	repay("购家宝支付"),
	repay_final("立即付款"),//最后一期
	
	accept("确认验收"),
	unaccept("验收不通过"),
	
	accept_first("验收通过"),//第一期
	
	agree("处理满意"),
	agree_first("处理满意"),
	unagree("处理不满意"),
	
	;

	
	private String text;
	
	OrderAction(String text){
		this.text = text;
	}
	
	
	public String getText() {
		return text;
	}

	public boolean equals(String action){
		return this.name().equals(action);
	}
	
}	