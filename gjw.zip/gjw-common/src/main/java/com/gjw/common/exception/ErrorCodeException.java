/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.exception;

import com.gjw.common.error.IECode;
import com.gjw.utils.StringUtil;

/**
 * 错误码异常处理
 * @author Flouny.Caesar
 *
 */
public class ErrorCodeException extends ApplicationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 * @param errorCode
	 */
	public ErrorCodeException(IECode errorCode) {
		super(errorCode.toString());
	}
	
	/**
	 * 
	 * @param errorCode
	 * @param cause
	 */
	public ErrorCodeException(IECode errorCode, Throwable cause) {
		super(errorCode.toString(), cause);
	}
	
	/**
	 * 
	 * @param errorCode
	 * @param parameters
	 */
	public ErrorCodeException(IECode errorCode, Object...parameters) {
		super(errorCode.toDynamicString(parameters));
	}
	
	/**
	 * 
	 * @param errorCode
	 * @param cause
	 * @param parameters
	 */
	public ErrorCodeException(IECode errorCode, Throwable cause, Object...parameters) {
		 super(errorCode.toDynamicString(parameters), cause);
	}
	
	/**
	 * 返回错误码
	 * @return
	 */
	public String getErrorCode() {
		String message = this.getMessage();
		if(StringUtil.isBlank(message)) return null;
		
		return message.substring(0, message.indexOf(IECode.SPLIT_CHAR));
	}
	
	/**
	 * 返回错误信息
	 * @return
	 */
	public String getErrorMessage() {
		String message = this.getMessage();
		if(StringUtil.isBlank(message)) return null;
		
		return message.substring(message.indexOf(IECode.SPLIT_CHAR)+1);
	}
}