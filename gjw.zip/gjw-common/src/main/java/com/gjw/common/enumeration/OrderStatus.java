package com.gjw.common.enumeration;


public enum OrderStatus {
    sign(20,"已签约"),
	booked(1,"已预定"),
	auditing(2,"待核对合同"),
	prepaying(3,"待支付10%装修定金"),
	arriving_earnest(4,"已扣款10%装修定金,待到账"),  //待到账定金
	starting_AZZC(5,"已到账，安装总成阶段开工"),
	started_AZZC(6,"安装总成阶段施工中"),
	accepting_AZZC(7,"安装总成阶段等待验收中"),
	mediating_AZZC(701,"安装总成阶段待调解"),
	accepted_AZZC(8,"安装总成已验收，等待汇入余款至购家宝"),
	arriving_credit(9,"已扣款90%余款,待到账"),  //待到账保证金
	paying_AZZC(10,"已到账，等待支付30%装修款"),
	
	starting_JZFZ(11,"已支付，等待建筑附着阶段施工"),
	started_JZFZ(12,"建筑附着阶段施工中"),
	accepting_JZFZ(13,"建筑附着阶段完工，等待验收"),
	mediating_JZFZ(1301,"建筑附着阶段待调解"),
	accepted_JZFZ(14,"建筑附着阶段验收，等待支付30%工程款"),
	
	starting_YSCS(15,"已支付，等待艺术陈设阶段施工"),
	started_YSCS(16,"艺术陈设阶段施工中"),
	accepting_YSCS(17,"艺术陈设阶段完成，等待验收"),
	mediating_YSCS(1701,"艺术陈设阶段待调解"),
	accepted_YSCS(18,"艺术陈设阶段验收，等待支付30%工程款"),
	completed(19,"完工（订单结束）");
	
	private Integer intValue;
	private String text;
	
	OrderStatus(Integer intValue,String text){
		this.intValue = intValue;
		this.text = text;
	}
	
	public Integer getIntValue() {
		return intValue;
	}
	
	public String getText() {
		return text;
	}

	public boolean equals(String status){
		return this.name().equals(status);
	}
	
	public OrderStatus getOrderStatus(String name){
		return valueOf(name);
	}
	
	/**
	 * 测试
	 * @param ordinal
	 * @return
	 */
	public static OrderStatus valueOf(int ordinal){
		
		if(ordinal<0||ordinal>values().length){
			throw new IndexOutOfBoundsException();
		}
		
		return values()[ordinal+1];
	}

}
