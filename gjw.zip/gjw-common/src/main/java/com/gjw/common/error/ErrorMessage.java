/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;

/**
 * 
 * @author Flouny.Caesar
 *
 */
public class ErrorMessage {
	
	private String message;
	
	private Throwable cause;
	
	public ErrorMessage(String message) {
		this.message = message;
	}
	
	public ErrorMessage(Throwable cause) {
		this.cause = cause;
	}
	
	public ErrorMessage(String message, Throwable cause) {
		this.message = message;
		this.cause = cause;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Throwable getCause() {
		return cause;
	}

	public void setCause(Throwable cause) {
		this.cause = cause;
	}
}