package com.gjw.common.helper;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;


/**
 * 邮件发送器
 * 
 * @author xieshangzhen
 * @date 2015年9月28日
 * @version 1.0
 */
public class MailSender {

	private static final Logger logger = LoggerFactory
			.getLogger(MailSender.class);

	private JavaMailSender mailSender;

	private Executor executor = Executors.newFixedThreadPool(10);

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * 邮件发送同步
	 * @param to 接收方
	 * @param subject 主题
	 * @param content 内容
	 * @throws Exception 
	 */
	public void sendMail(final String to, final String subject,
			final String content) throws Exception {

			//SSLUtils.ignoreSsl();
		try {
		    // add handlers for main MIME types
		    MailcapCommandMap mc = (MailcapCommandMap)CommandMap.getDefaultCommandMap();
		    mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		    mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		    mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		    mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		    mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		    CommandMap.setDefaultCommandMap(mc);

			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true,
					"utf-8");
			helper.setTo(to);
			helper.setFrom("goujia@goujiawang.com");
			helper.setSubject(subject);
			helper.setText(content, true);
			mailSender.send(message);
			logger.info("mail already send");
		} catch (MessagingException e) {
			logger.error("generate mail fialure");
			e.printStackTrace();
		}
	}

	/**
	 * 邮件发送异步
	 * @param to 接收方
	 * @param subject 主题
	 * @param content 内容
	 */
	public void sendMailAsync(final String to, final String subject,
			final String content) {
	    
	    // 无接收方则终止发送
	    if(to == null) {
	        logger.info("no mail address");
	        return;
	    }
	    
		Runnable task = new Runnable() {

			@Override
			public void run() {
				try {
					sendMail(to, subject, content);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		executor.execute(task);
	}
}
