/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;

import com.gjw.common.web.JsonResult;

/**
 * 
 * @author Flouny.Caesar
 *
 */
public class ErrorResult extends JsonResult<Object> {
	
	private String version;

	public ErrorResult() {
		result =null;
	}

	public ErrorResult(String ret, String msg) {
		this.ret = ret;
		this.msg = msg;
		result =null;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
}