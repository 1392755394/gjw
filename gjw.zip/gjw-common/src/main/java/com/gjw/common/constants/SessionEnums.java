/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author guojianbin
 * @version 3.0
 * @date 2015-7-9
 */
package com.gjw.common.constants;

/**
 * 
 * @author guojianbin
 *
 */
public enum SessionEnums {
	_GOUJIA_GES_FORM_LOGIN_NAME("login_name"), 
	_GOUJIA_GES_FORM_REAL_NAME("real_name"), 
	_GOUJIA_GES_FORM_ORG_TYPE("org_type"), 
	_GOUJIA_GES_FORM_ORG_ID("org_id"),
	_GOUJIA_GES_FORM_CUID("cuid"),
	_GOUJIA_GES_FORM_PERMISSION("permission"),
    _GOUJIA_GES_FORM_ROLE_ID("role_id"),
    _GOUJIA_GES_FORM_ROLE_NAME("role_name");
	
	private String name;
	
	SessionEnums(String name){
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}