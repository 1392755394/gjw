package com.gjw.common.constants;

public class GoodsConstant {
	
	//产品包是爆款
	public static final String PROMOTION_YES="y";
		
	//产品包不是爆款
	public static final String PROMOTION_NO="n";

}
