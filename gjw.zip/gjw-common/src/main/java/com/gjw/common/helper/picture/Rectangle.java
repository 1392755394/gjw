/**   
* @Title: Rectangle.java
* @Package com.gjw.common.helper.picture
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 9, 2015 4:07:37 PM
* @version V1.0   
*/

package com.gjw.common.helper.picture;

/**
 * @Description: 
 * @author  qingye
 * @date Dec 9, 2015 4:07:37 PM
 * 
 */

public class Rectangle {
    
    public Rectangle(){
        
    }
    
    public Rectangle(int width,int height){
        this.width=width;
        this.height=height;
    }
    
    
    
    private int width;
    public int getWidth() {
        return width;
    }
    public void setWidth(int width) {
        this.width = width;
    }
    public int getHeight() {
        return height;
    }
    public void setHeight(int height) {
        this.height = height;
    }
    private int height;
}
