/**   
* @Title: PictureHelper.java
* @Package com.gjw.common.helper.picture
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Dec 9, 2015 4:09:21 PM
* @version V1.0   
*/

package com.gjw.common.helper.picture;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.Thumbnails.Builder;
import net.coobird.thumbnailator.geometry.Positions;

import org.apache.commons.io.FilenameUtils;
import org.springframework.context.ApplicationContextException;
import org.springframework.web.multipart.MultipartFile;

import com.gjw.entity.picture.Picture;
import com.gjw.utils.encrypt.SHA256;

/**
 * @Description: 
 * @author  qingye
 * @date Dec 9, 2015 4:09:21 PM
 * 
 */

public class PictureHelper {
    
    //水印地址
    private  String waterMarkPath="/uploaded/999999/watermark.png";
    //水印宽比例
    private double waterMarkWidthScale=0.2;
    //水印高比例
    private double waterMarkHeightScale=0.12;
    //是否添加水印
    private boolean addWater=true;
    
    
    public void setWaterMarkWidthScale(double waterMarkWidthScale) {
        this.waterMarkWidthScale = waterMarkWidthScale;
    }
    public void setWaterMarkHeightScale(double waterMarkHeightScale) {
        this.waterMarkHeightScale = waterMarkHeightScale;
    }
    public void setAddWater(boolean addWater) {
        this.addWater = addWater;
    }
    public void setWaterMarkPath(String waterMarkPath) {
        this.waterMarkPath = waterMarkPath;
    }

    /**
     * 
    * @Description  存储图片(不保存到数据库，需要调用者自己保存picture到数据库)
    * @param storePath 存储的实际路径
    * @param file 文件
    * @param sizeList 缩略图大小，如果不产生缩略如则为null
    * @return 完整的Picture对象，包含缩略图
    * @author qingye   
    * @date Dec 9, 2015 5:09:54 PM
     */
    public Picture store(String storePath,MultipartFile file,List<Rectangle> sizeList){
        if(sizeList==null)
            return store(storePath,file,new ArrayList<Rectangle>());
        BufferedImage bi=null;
        try {
            bi=ImageIO.read(file.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        Picture picture=new Picture();
        picture.setWidth(bi.getWidth());
        picture.setHeight(bi.getHeight());
        String ext = FilenameUtils.getExtension(file.getOriginalFilename());
        String folderPath=getRelativeFolderPath(storePath);
        String fileName=genPictureName();
        //设置值和缩略图
        initPicture(picture,folderPath,fileName,ext,sizeList);
        //存储到磁盘
        storePicture(storePath,picture,bi);
        //因为windows里路径分隔符号为\，网络路径应该都为/
        dealSeparator(picture);
        return picture;
    }
    
    /** 
    * @Description  
    * @param picture
    * @author qingye   
    * @date Dec 22, 2015 1:57:15 PM
    */
    
    private void dealSeparator(Picture picture) {
        if(!File.separator.equals("\\"))
            return;
        picture.setPath(replaceSeparator(picture.getPath()));
        for(Picture thum:picture.getThumbnailSet())
            thum.setPath(replaceSeparator(thum.getPath()));
    }
    
    
    /** 
    * @Description  
    * @param path
    * @author qingye   
    * @date Dec 22, 2015 1:59:37 PM
    */
    
    private String replaceSeparator(String path) {
        return path.replace('\\', '/');
    }
    /** 
    * @Description  
    * @param storePath
    * @param picture
    * @param bi
    * @author qingye   
    * @date Dec 9, 2015 5:45:28 PM
    */
    private void storePicture(String storePath, Picture picture,
            BufferedImage bi) {
        BufferedImage waterImage=getWaterImage(storePath);
        
        //保存原始图
        savePictureToFile(getFullPath(storePath, picture.getPath()),bi,picture.getWidth(),picture.getHeight(),waterImage);
        for(Picture thum:picture.getThumbnailSet()){
            savePictureToFile(getFullPath(storePath, thum.getPath()),bi,thum.getWidth(),thum.getHeight(),waterImage);
        }
        
    }
    
    /** 
    * @Description  
    * @return
    * @author qingye   
    * @date Dec 11, 2015 1:17:43 PM
    */
    
    private BufferedImage getWaterImage(String storePath) {
        if(!addWater)
            return null;
        File file=new File(waterMarkPath);
        if(!file.exists()){
            file=new File(storePath+waterMarkPath);
            if(!file.exists())
                return null;
        }
        try {
            return ImageIO.read(file);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 
    * @Description  保存图片
    * @param fullStorePath 图片的绝对路径
    * @param srcImage 原始图片
    * @param width 保存的宽
    * @param height 保存的高
    * @param waterImage 水印，可为null
    * @author qingye   
    * @date Dec 10, 2015 1:57:02 PM
     */
    private void savePictureToFile(String fullStorePath,BufferedImage srcImage,int width,int height,BufferedImage waterImage){
        try {
            Builder<BufferedImage> tmp = Thumbnails.of(srcImage).size(width, height);
            waterImage=getScaledWaterImage(waterImage,width,height);
            if(waterImage!=null)
                tmp=tmp.watermark(Positions.BOTTOM_RIGHT, waterImage, 0.8f);
            tmp.toFile(new File(fullStorePath));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    /** 
    * @Description  
    * @param waterImage
    * @param width
    * @param height
    * @return
    * @author qingye   
    * @date Dec 11, 2015 1:39:35 PM
    */
    
    private BufferedImage getScaledWaterImage(BufferedImage waterImage,
            int width, int height) {
        if(waterImage==null)
            return null;
        int waterWidth=(int)(width*waterMarkWidthScale);
        int waterHeight=(int)(height*waterMarkHeightScale);
        try {
            return Thumbnails.of(waterImage).size(waterWidth, waterHeight).asBufferedImage();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /** 
    * @Description  初始化picture参数
    * @param picture 图片实体
    * @param folderPath 目录路径
    * @param fileName 文件名
    * @param ext 文件扩展名
    * @param sizeList 缩略图大小
    * @author qingye   
    * @date Dec 9, 2015 5:07:03 PM
    */
    
    private void initPicture(Picture picture, String folderPath,
            String fileName, String ext, List<Rectangle> sizeList) {
        picture.setPath(getRelativePath(folderPath,fileName,ext));
        picture.setOriginal(0l);
        Set<Picture> thumbnailSet=new HashSet<Picture>();
        for(Rectangle size:sizeList){
            if(size.getWidth()>picture.getWidth() || size.getHeight()>picture.getHeight())
                throw new ApplicationContextException("缩略图尺寸大于原图");
            Picture thumbnail=new Picture();
            thumbnail.setWidth(size.getWidth());
            thumbnail.setHeight(size.getHeight());
            thumbnail.setPath(getRelativePath(folderPath,getThumbnailName(fileName,size.getWidth(),size.getHeight()),ext));
            thumbnailSet.add(thumbnail);
        }
        picture.setThumbnailSet(thumbnailSet);
    }

    /**
     * 
    * @Description 得到完整的存储路径  
    * @param storePath
    * @param relativePath
    * @return
    * @author qingye   
    * @date Dec 10, 2015 11:30:38 AM
     */
    private String getFullPath(String storePath,String relativePath){
        if(storePath.endsWith(File.separator))
            return storePath+relativePath;
        else
            return storePath+File.separator+relativePath;
    }

    /** 
    * @Description  用于拼接路径
    * @param folderPath
    * @param fileName
    * @param ext
    * @return
    * @author qingye   
    * @date Dec 9, 2015 5:15:40 PM
    */
    
    private String getRelativePath(String folderPath, String fileName,
            String ext) {
        StringBuffer sb=new StringBuffer();
        sb.append(folderPath);
        sb.append(File.separator);
        sb.append(fileName);
        sb.append(".");
        sb.append(ext);
        return sb.toString();
    }

    /**
     * 
    * @Description 得到相对文件夹的路径  
    * @return
    * @author qingye   
    * @date Dec 9, 2015 5:07:20 PM
     */
    private String getRelativeFolderPath(String prefixPath){
        StringBuffer sb=new StringBuffer();
        sb.append("uploaded");
        File folder=new File(getFullPath(prefixPath, sb.toString()));
        if(!folder.exists())
            folder.mkdir();
        sb.append(File.separator);
        String timestamp = String.valueOf(new Date().getTime()).substring(0, 6); // 二级目录
        sb.append(timestamp);
        folder=new File(getFullPath(prefixPath,sb.toString()));
        if(!folder.exists())
            folder.mkdir();
        return sb.toString();
    }
    
    
    
    /**
     * 
    * @Description 得到文件名  
    * @return
    * @author qingye   
    * @date Dec 9, 2015 5:08:10 PM
     */
    private String genPictureName(){
        return SHA256.encrypt(String.valueOf(new Date().getTime())).substring(0, 24);
    }
    
    /** 
     * @Description  得到缩略图文件名
     * @param fileName
     * @param width
     * @param height
     * @return
     * @author qingye   
     * @date Dec 9, 2015 5:38:38 PM
     */
     
     private String getThumbnailName(String fileName, int width, int height) {
         StringBuffer sb=new StringBuffer();
         sb.append(fileName);
         sb.append("_");
         sb.append(width);
         sb.append("x");
         sb.append(height);
         return sb.toString();
     }

     /**
      * 
     * @Description  存储图片(不保存到数据库，需要调用者自己保存picture到数据库)
     * @param storePath 存储的实际路径
     * @param file 文件
     * @param sizeList 缩略图大小，如果不产生缩略如则为null
     * @param rates 图片质量，范围：0.0~1.0，1为最高质量
     * @return 完整的Picture对象，包含缩略图
     * @author guojianbin   
     * @date 2016年04月19日
      */
     public Picture storeWithRates(String storePath,MultipartFile file,List<Rectangle> sizeList,float rates){
         if(sizeList==null)
             return storeWithRates(storePath,file,new ArrayList<Rectangle>(),rates);
         if(rates<0)
             rates = 1;
         BufferedImage bi=null;
         try {
             bi=ImageIO.read(file.getInputStream());
         } catch (IOException e) {
             e.printStackTrace();
         }
         Picture picture=new Picture();
         picture.setWidth(bi.getWidth());
         picture.setHeight(bi.getHeight());
         String folderPath=getRelativeFolderPath(storePath);
         String fileName=genPictureName();
         //设置值和缩略图
         initRatedPicture(picture,folderPath,fileName,sizeList);
         //存储到磁盘
         storeRatedPicture(storePath,picture,bi,rates);
         //因为windows里路径分隔符号为\，网络路径应该都为/
         dealSeparator(picture);
         return picture;
     }
     
     /** 
      * @Description  
      * @param storePath
      * @param picture
      * @param bi
      * @param rates 图片质量，范围：0.0~1.0，1为最高质量
      * @author guojianbin   
      * @date 2016年04月19日
      */
      private void storeRatedPicture(String storePath, Picture picture,
              BufferedImage bi,float rates) {
          BufferedImage waterImage=getWaterImage(storePath);
          
          //保存原始图
          saveRatedPictureToFile(getFullPath(storePath, picture.getPath()),bi,picture.getWidth(),picture.getHeight(),waterImage,rates);
          for(Picture thum:picture.getThumbnailSet()){
              saveRatedPictureToFile(getFullPath(storePath, thum.getPath()),bi,thum.getWidth(),thum.getHeight(),waterImage,rates);
          }
          
      }

      /**
       * 
      * @Description  保存图片
      * @param fullStorePath 图片的绝对路径
      * @param srcImage 原始图片
      * @param width 保存的宽
      * @param height 保存的高
      * @param waterImage 水印，可为null
      * @param rates 图片质量，范围：0.0~1.0，1为最高质量
      * @author guojianbin   
      * @date 2016年04月19日
       */
      private void saveRatedPictureToFile(String fullStorePath,BufferedImage srcImage,int width,int height,
              BufferedImage waterImage,float rates){
          try {
              Builder<BufferedImage> tmp = Thumbnails.of(srcImage).size(width, height);
              waterImage=getScaledWaterImage(waterImage,width,height);
              if(waterImage!=null)
                  tmp=tmp.watermark(Positions.BOTTOM_RIGHT, waterImage, 0.8f);
              tmp.outputQuality(rates).outputFormat("jpg").toFile(new File(fullStorePath));
          } catch (Exception e) {
              e.printStackTrace();
          }
          
      }
      
      /** 
      * @Description  初始化picture参数
      * @param picture 图片实体
      * @param folderPath 目录路径
      * @param fileName 文件名
      * @param ext 文件扩展名
      * @param sizeList 缩略图大小
      * @author guojianbin   
      * @date 2016年04月19日
      */
      private void initRatedPicture(Picture picture, String folderPath,
              String fileName, List<Rectangle> sizeList) {
          picture.setPath(getRatedRelativePath(folderPath,fileName));
          picture.setOriginal(0l);
          Set<Picture> thumbnailSet=new HashSet<Picture>();
          for(Rectangle size:sizeList){
              if(size.getWidth()>picture.getWidth() || size.getHeight()>picture.getHeight())
                  throw new ApplicationContextException("缩略图尺寸大于原图");
              Picture thumbnail=new Picture();
              thumbnail.setWidth(size.getWidth());
              thumbnail.setHeight(size.getHeight());
              thumbnail.setPath(getRatedRelativePath(folderPath,getThumbnailName(fileName,size.getWidth(),size.getHeight())));
              thumbnailSet.add(thumbnail);
          }
          picture.setThumbnailSet(thumbnailSet);
      }

      /** 
      * @Description  用于拼接路径
      * @param folderPath
      * @param fileName
      * @param ext
      * @return
      * @author guojianbin   
      * @date 2016年04月19日
      */
      private String getRatedRelativePath(String folderPath, String fileName) {
          StringBuffer sb=new StringBuffer();
          sb.append(folderPath);
          sb.append(File.separator);
          sb.append(fileName);
          return sb.toString();
      }

}