/**
 * Copyright 2014-2015 www.goujiawang.com
 * All rights reserved.
 * 
 * @project
 * @author Flouny.Caesar
 * @version 2.0
 * @date 2014-11-26
 */
package com.gjw.common.error;

import com.gjw.common.error.Error;
import com.gjw.utils.StringUtil;

/**
 * 系统错误码
 * 
 * @author Flouny.Caesar
 *
 */
public enum SECode implements IECode {
	
	@Error(msg="服务器繁忙!")
	s_100000(100000), 
	
	@Error(msg="当前的操作未被授权!")
	s_100001(100001), 

	@Error(msg="OpenKey为空!")
	s_100002(100002), 
	
	@Error(msg="OpenID为空!")
	s_100003(100003), 
	
	@Error(msg="OpenID或OpenKey为空!")
	s_100004(100004), 
	
	@Error(msg="OpenAPI未经用户授权!")
	s_100005(100005), 
	
	@Error(msg="OpenAPI超时!")
	s_100006(100006), 
	
	@Error(msg="OpenKey为空!")
	s_100007(100007), 
	
	@Error(msg="签名串为空!")
	s_100008(100008), 
	
	@Error(msg="签名串错误!")
	s_100009(100009), 
	
	@Error(msg="系统错误，请稍后再试!")
	s_100010(100010),
	
	
	@Error(msg="用户ID不为空")
	u_100001(100001),
	@Error(msg="密码错误")
	u_100002(100002),
	@Error(msg="用户不存在")
	u_100003(100003),
	@Error(msg="非法用户名")
	u_100004(100004),
	@Error(msg="用户名已经存在")
	u_100005(100005),
	@Error(msg="非法手机号")
	u_100006(100006),
	@Error(msg="手机号已注册")
	u_100007(100007),
	@Error(msg="非法邮箱")
	u_100008(100008),
	@Error(msg="邮箱已注册")
	u_100009(100009),
	
	@Error(msg="文章名不能为空")
	c_100001(100001),
	
	@Error(msg="父级字典不能为空")
	d_100001(100001)
	
	;
	private int code;
	
	SECode(int code) {
		this.code = code;
	}
	
	public int getCode() {
		
		return code;
	}
	
	private String getName() {
		
		return this.name();
	}

	/**
	 * 返回错误信息
	 * @return
	 */
	public String getMessage() {
		Error error = null;
		try {
			error = this.getClass().getField(getName()).getAnnotation(Error.class);
		} catch (Exception e) {
			
			return null;
		}
		
		return error.msg();
	}
	
	/**
	 * 
	 */
	public String toString() {
		String message = this.getMessage();

		return String.valueOf(this.getCode()).concat(SPLIT_CHAR).concat((StringUtil.isBlank(message)?"":message));
	}
	
	/**
	 * 返回错误码+动态错误信息
	 * @return
	 */
	public String toDynamicString(Object...parameters) {
		
		return String.format(this.toString(), parameters);
	}
}