package com.gjw.common.web;

import java.util.List;

import com.gjw.common.enumeration.OrderAction;
import com.gjw.common.enumeration.OrderStatusCopy;

public interface IState {
	
	public String getText();
	
	public OrderStatusCopy doAction(OrderAction action);
	
	public List<OrderAction> getActionsForWeb();
	
	public List<OrderAction> getActionsForGes();

}
