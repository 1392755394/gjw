package com.gjw.company.service.impl.user;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.user.IUserBuildingItemService;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;


@Service("userBuildingItemServiceImpl")
@Transactional
public class UserBuildingItemServiceImpl extends AbstractServiceImpl implements IUserBuildingItemService {

    @Override
    public UserBuildingItem queryByUser(User user) {
        return super.getUserBuildingItemDAO().queryByUser(user);
    }

}
