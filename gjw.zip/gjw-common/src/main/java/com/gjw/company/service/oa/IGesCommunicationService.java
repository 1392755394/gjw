package com.gjw.company.service.oa;

import java.util.List;
import java.util.Map;

import com.gjw.entity.oa.GesCommunication;
import com.gjw.entity.user.User;
import com.gjw.vo.oa.GesCommunicationVO;

public interface IGesCommunicationService {
	
	/**
	 * 获取任务的交流列表
	 * @param gesCommunication
	 * @return
	 */
	public Map<String, Object> listCommunication(GesCommunicationVO gesCommunication,User user, String mobileLogin);
	
	/**
	 * 发布交流
	 * @param communication
	 * @return
	 */
	public GesCommunicationVO creatCommunication(GesCommunicationVO communication);
	
	/**
	 * 根据交流的id删除交流信息
	 * @param communicationId
	 * @return
	 */
	public boolean deleteCommunicationById(GesCommunication communication);
	
	/**
	 * 根据任务的id获取交流的id
	 * @param taskId
	 * @return
	 */
	public List<Long> queryCommunicationIdByTaskId(Long taskId);
	

}
