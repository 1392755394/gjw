package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.vo.RdRecordsVO;
import com.gjw.vo.StoreInventoryVO;

/**
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 下午5:26:38
 * 
 */
public interface IGesStoreInventoryDAO extends IDAO {

    /**
     * 查询库存量
     * 
     * @Description
     * @param records
     * @return
     * @author gwb
     * @date 2015年12月21日 下午5:49:26
     */
    public Long sumInventory(RdRecordsVO records, List<GesStore> listStore);

    /**
     * 查询库存
     * 
     * @Description
     * @param condition
     * @return
     * @author gwb
     * @date 2015年12月24日 上午9:47:14
     */
    public GesStoreInventory getGesStoreInventoryByMatterIdAndStoreId(GesStoreInventory condition);

    /**
     * 修改库存数量
     * 
     * @Description
     * @param storeInventory
     * @author gwb
     * @date 2015年12月24日 上午9:58:02
     */
    public void updateInventoryAmountById(GesStoreInventory storeInventory);

    /**
     * 库存管理
     * <p>
     * 库存查询分页
     * 
     * @Description
     * @param gesStoreInventory
     * @return
     * @author gwb
     * @date 2016年1月7日 下午2:06:54
     */
    public List<GesStoreInventory> pageByGesStoreInventory(StoreInventoryVO gesStoreInventory);

    /**
     * 库存管理
     * <p>
     * 库存查询总数
     * 
     * @Description
     * @param gesStoreInventory
     * @return
     * @author gwb
     * @date 2016年1月7日 下午2:07:22
     */
    public Long count(StoreInventoryVO gesStoreInventory);

}
