package com.gjw.company.dao.impl.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.company.dao.user.IUserInfoDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.utils.StringUtil;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("userInfoDAOHibernateImpl")
public class UserInfoDAOHibernateImpl extends AbstractDAOHibernateImpl implements IUserInfoDAO {

    @Override
    protected Class<? extends AbstractEntity> getEntityClass() {
        return UserInfo.class;
    }

    @Override
    public UserInfo get(Long id){
        UserInfo userInfo=(UserInfo)super.get(id);
        return userInfo;
    }

    @Override
    public List<User> pageUserInfoByOwnerForGes(UserInfo owner) {
        StringBuilder hql=new StringBuilder("from User user, UserInfoGES info   where  user.id=info.user.id and user.invalid=0 ");
        List<Object> ls=new ArrayList<Object>();
        if(null!=owner.getUser() && null!=owner.getUser().getId()){
            hql.append("and info.owerId=? ");
            ls.add(owner.getUser().getId());
        }
        if(null!=owner.getOperatorId()){
            hql.append("and (info.operator.id=? ");
            ls.add(owner.getOperatorId());
            hql.append("and info.orgType=? ");
            ls.add(GesCommonConstants.ORG_TYPE_CITY_OPERATOR);
            hql.append("or info.orgType=? ");
            ls.add(GesCommonConstants.ORG_TYPE_SHOP);
            hql.append("and info.shop.id in (select s.id from GesShop s where s.operator.id =?))  ");
            ls.add(owner.getOperatorId());
        }
        if(null!=owner.getShopId()){
            hql.append("and info.shop.id=? ");
            ls.add(owner.getShopId());
        }
        if(owner.getRealName()!=null && !"".equals(owner.getRealName())){
            hql.append("and info.realName like ?");
            ls.add(this.getFuzzyCondition(owner.getRealName()));
        }
        if(owner.getUser().getEmail()!=null && !"".equals(owner.getUser().getEmail())){
            hql.append("and user.email like ?");
            ls.add(this.getFuzzyCondition(owner.getUser().getEmail()));
        }
        if(owner.getUser().getMobile()!=null && !"".equals(owner.getUser().getMobile())){
            hql.append("and user.mobile like ?");
            ls.add(this.getFuzzyCondition(owner.getUser().getMobile()));
        }
        List<Object[]> list = (List<Object[]>)super.findByPageCallBack(hql.toString(),"",ls,owner,null);
        List<User> userList=new ArrayList<User>();
        for(Object[] items:list){
            User user=(User)items[0];
            user.setPlatformUserInfo((UserInfo)items[1]);
            userList.add(user);
        }
        return userList;
    }
    
    
    @Override
    public long countUserInfoByOwnerForGes(UserInfo owner) {
        StringBuilder hql=new StringBuilder("from User user, UserInfoGES info   where  user.id=info.user.id and user.invalid=0 ");
        List<Object> ls=new ArrayList<Object>();
        if(null!=owner.getUser() && null!=owner.getUser().getId()){
            hql.append("and info.owerId=? ");
            ls.add(owner.getUser().getId());
        }
        if(null!=owner.getOperatorId()){
            hql.append("and (info.operator.id=? ");
            ls.add(owner.getOperatorId());
            hql.append("and info.orgType=? ");
            ls.add(GesCommonConstants.ORG_TYPE_CITY_OPERATOR);
            hql.append("or info.orgType=? ");
            ls.add(GesCommonConstants.ORG_TYPE_SHOP);
            hql.append("and info.shop.id in (select s.id from GesShop s where s.operator.id =?))  ");
            ls.add(owner.getOperatorId());
        }
        if(null!=owner.getShopId()){
            hql.append("and info.shop.id=? ");
            ls.add(owner.getShopId());
        }
        if(owner.getRealName()!=null && !"".equals(owner.getRealName())){
            hql.append("and info.realName like ?");
            ls.add(this.getFuzzyCondition(owner.getRealName()));
        }
        if(owner.getUser().getEmail()!=null && !"".equals(owner.getUser().getEmail())){
            hql.append("and user.email like ?");
            ls.add(this.getFuzzyCondition(owner.getUser().getEmail()));
        }
        if(owner.getUser().getMobile()!=null && !"".equals(owner.getUser().getMobile())){
            hql.append("and user.mobile like ?");
            ls.add(this.getFuzzyCondition(owner.getUser().getMobile()));
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public List<UserInfo> getByOrgIdAndTypeForGes(Long orgId, String orgType) {
        StringBuilder  hql=new StringBuilder("from UserInfoGES where invalid=0 ");
        if(orgType.equals(GesCommonConstants.ORG_TYPE_SHOP))
            hql.append("and shop.id=?");
        else
            hql.append("and operator.id=?");
        return (List<UserInfo>)this.getHibernateTemplate().find(hql.toString(), orgId);
    }

    @Override
    public Long countForGes(UserInfoGES userInfo) {
        StringBuilder hql=new StringBuilder("from UserInfoGES info inner join info.user user  where user.invalid=0  and info.invalid=0 ");
        List<Object> ls=new ArrayList<Object>();
        if(userInfo.getUser()!=null && userInfo.getUser().getUsername()!=null && !"".equals(userInfo.getUser().getUsername())){
            hql.append("and user.username like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getUsername()));
        }
        if(userInfo.getUser()!=null && userInfo.getUser().getEmail()!=null && !"".equals(userInfo.getUser().getEmail())){
            hql.append("and user.email like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getEmail()));
        }
        if(userInfo.getRealName()!=null &&  !"".equals(userInfo.getRealName())){
            hql.append("and info.realName like ?");
            ls.add(getFuzzyCondition(userInfo.getRealName()));
        }
        if(userInfo.getOrgType()!=null && !"".equals(userInfo.getOrgType())){
            hql.append("and info.orgType = ?");
            ls.add(userInfo.getOrgType());
        } else {
            hql.append("and info.orgType <> ?");
            ls.add(GesCommonConstants.ORG_TYPE_DEVELOPER);
        }
        if(userInfo.getUser()!=null && userInfo.getUser().getMobile()!=null && !"".equals(userInfo.getUser().getMobile())){
            hql.append("and user.mobile like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getMobile()));
        }
        if(userInfo.getOrgName()!=null && !"".equals(userInfo.getOrgName())){
            hql.append("and (info.shop.name like ? or info.operator.companyName like ?)");
            ls.add(getFuzzyCondition(userInfo.getOrgName()));
            ls.add(getFuzzyCondition(userInfo.getOrgName()));
        }
        if (StringUtil.isNotEmpty(userInfo.getRoles())){
            hql.append(" and info.user in (select uri.gesUser from UserRoleItem uri where uri.role.name like ? )");
            ls.add(this.getFuzzyCondition(userInfo.getRoles()));
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
        
        
    }

    @Override
    public List<User> pageForGes(UserInfoGES userInfo) {
        StringBuilder hql=new StringBuilder("from UserInfoGES info inner join info.user user left join info.shop left join info.operator where user.invalid=0 and info.invalid=0 ");
        List<Object> ls=new ArrayList<Object>();
        if(userInfo.getUser()!=null && userInfo.getUser().getUsername()!=null && !"".equals(userInfo.getUser().getUsername())){
            hql.append("and user.username like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getUsername()));
        }
        if(userInfo.getUser()!=null && userInfo.getUser().getEmail()!=null && !"".equals(userInfo.getUser().getEmail())){
            hql.append("and user.email like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getEmail()));
        }
        if(userInfo.getRealName()!=null &&  !"".equals(userInfo.getRealName())){
            hql.append("and info.realName like ?");
            ls.add(getFuzzyCondition(userInfo.getRealName()));
        }
        if(userInfo.getOrgType()!=null && !"".equals(userInfo.getOrgType())){
            hql.append("and info.orgType = ?");
            ls.add(userInfo.getOrgType());
        } else {
            hql.append("and info.orgType <> ?");
            ls.add(GesCommonConstants.ORG_TYPE_DEVELOPER);
        }
        if(userInfo.getContactMobile()!=null && !"".equals(userInfo.getContactMobile())){
            hql.append("and info.contactMobile like ?");
            ls.add(getFuzzyCondition(userInfo.getContactMobile()));
        }
        if(userInfo.getOrgName()!=null && !"".equals(userInfo.getOrgName())){
            hql.append("and ( (info.orgType='shop' and info.shop.name like ?) or (info.orgType='city_operator' and info.operator.companyName like ?))");
            ls.add(getFuzzyCondition(userInfo.getOrgName()));
            ls.add(getFuzzyCondition(userInfo.getOrgName()));
        }
        if (StringUtil.isNotEmpty(userInfo.getRoles())){
            hql.append(" and info.user in (select uri.gesUser from UserRoleItem uri where uri.role.invalid = false and  uri.role.name like ? )");
            ls.add(this.getFuzzyCondition(userInfo.getRoles()));
        }
        hql.append(" order by info.user.updatedDatetime desc");
        List<Object[]> list = (List<Object[]>)super.findByPageCallBack(hql.toString(),"",ls,userInfo,null);
        List<User> userList=new ArrayList<User>();
        for(Object[] items:list){
            User user=(User)items[1];
            UserInfoGES info=(UserInfoGES)items[0];
            info.setShop((GesShop)items[2]);
            info.setOperator((GesCityOperator)items[3]);
            user.setPlatformUserInfo(info);
            userList.add(user);
        }
        return userList;
    }

    @Override
    public UserInfoGES userInfoForGes(UserInfoGES userInfo) {
        // TODO Auto-generated method stub
        StringBuilder hql=new StringBuilder("from UserInfoGES info inner join info.user user  where user.invalid=0  and info.invalid=0 ");
        List<Object> ls=new ArrayList<Object>();
        if(userInfo.getUser()!=null && userInfo.getUser().getId()!=null){
            hql.append("and user.email like ?");
            ls.add(getFuzzyCondition(userInfo.getUser().getEmail()));
        }
        if(userInfo.getOrgType()!=null && !"".equals(userInfo.getOrgType())){
            hql.append("and info.orgType = ?");
            ls.add(userInfo.getOrgType());
        }
        List<UserInfoGES> list=(List<UserInfoGES>) super.findByPageCallBack(hql.toString(),"",ls,userInfo,null);
        if(null!=list && list.size()>0){
            return list.get(0);
        }
        return null;
    }
}
