package com.gjw.company.dao.oa;

import java.util.List;
import java.util.Map;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesAttachment;
import com.gjw.vo.oa.GesAttachmentVO;

public interface IGesAttachmentDAO extends IDAO {
	
	public int updateAttachmentRelation(Map<String,Object> attachment);
    
    /**
     * 根据关联的id获取相关的附件
     * @param attachment
     * @return
     */
    public List<GesAttachmentVO> listAttachmentByRelationId(GesAttachmentVO attachment);
    
    /**
     * 获取节点的附件列表
     * @param attachment 附件（附件所属节点的id与类型）
     * @return 附件列表
     */
    public List<GesAttachment> listAttachmentByRelationId(GesAttachment attachment);
    
    /**
     * 下载附件
     * @param attachmentID 附件ID
     * @return 下载成功与否
     */
    public boolean downloadAttachment(Long attachmentID);

    /**
     * 删除附件
     * @param attachmentID 附件ID
     * @return 删除成功与否
     */
    public boolean deleteAttachment(Long attachmentID);

}
