package com.gjw.company.dao.impl.matter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IMatterSpecDAO;
import com.gjw.entity.matter.MatterSpec;
import com.gjw.utils.StringUtil;

/**
 * 物料规格dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("matterSpecDAOHibernateImpl")
public class MatterSpecDAOHibernateImpl extends AbstractDAOHibernateImpl implements IMatterSpecDAO {

    @Override
    protected Class<?> getEntityClass() {
        return MatterSpec.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<MatterSpec> pageMatterSpec(MatterSpec matterSpecCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from MatterSpec m where m.invalid = false and m.matter.id= ?");
        hql.append("  order by m.updatedDatetime desc");
        ls.add(matterSpecCriteria.getMatter().getId());
        return (List<MatterSpec>) super.findByPageCallBack(hql.toString(), "", ls, matterSpecCriteria, null);
    }

    @Override
    public Long countMatterSpec(MatterSpec matterSpecCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from MatterSpec m where m.invalid = false and m.matter.id= ?");
        ls.add(matterSpecCriteria.getMatter().getId());
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public long create(MatterSpec matterSpec) {
        super.add(matterSpec);
        return matterSpec.getId();
    }

    @Override
    public boolean update(MatterSpec matterSpec) {
        MatterSpec old = (MatterSpec) super.get(matterSpec.getId());
        StringUtil.copyProperties(matterSpec, old);
        return super.update(old) == 1;
    }

    @Override
    public boolean deletedByID(long id) {
        return super.remove(id) == 1;
    }

}
