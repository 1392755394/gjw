package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesPoDetailDAO;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.utils.StringUtil;

/**
 * 采购管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月17日 下午1:31:06
 * 
 */
@Component("gesPoDetailDAOHibernateImpl")
public class GesPoDetailDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesPoDetailDAO {

    @Override
    protected Class getEntityClass() {
        return GesPoDetail.class;
    }

    @Override
    public List<GesPoDetail> pagePoDetailByPoCode(GesPoDetail poCode) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesPoDetail a    where a.invalid =0  ");

        List<Object> ls = new ArrayList<Object>();

        if (StringUtil.notEmpty(poCode.getPoCode())) {
            hql.append(" and a.poCode like ? ");
            ls.add(super.getFuzzyCondition(poCode.getPoCode()));
        }
        if (StringUtil.notEmpty(poCode.getRoom()) && poCode.getRoom().getId() != null && poCode.getRoom().getId() >= 0) {
            hql.append(" and a.room.id=? ");
            ls.add(poCode.getRoom().getId());
        }

        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getCode())) {
            hql.append(" and a.matter.code like ? ");
            ls.add(super.getFuzzyCondition(poCode.getMatter().getCode()));
        }
        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getName())) {
            hql.append(" and a.matter.name like ? ");
            ls.add(super.getFuzzyCondition(poCode.getMatter().getName()));
        }
        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getModel())) {
            hql.append(" and a.matter.model like ? ");
            ls.add(super.getFuzzyCondition(poCode.getMatter().getModel()));
        }
        if (poCode.getMatter() != null && poCode.getMatter().getIsDiy() != null) {
            hql.append(" and a.matter.isDiy = ? ");
            ls.add(poCode.getMatter().getIsDiy());
        }
        if (poCode.getMatter() != null && poCode.getMatter().getBrand() != null
                && StringUtil.notEmpty(poCode.getMatter().getBrand().getName())) {
            hql.append(" and a.matter.brand.name like ? ");
            ls.add(super.getFuzzyCondition(poCode.getMatter().getBrand().getName()));
        }
        return (List<GesPoDetail>) super.findByPageCallBack(hql.toString(), "", ls, poCode, null);
    }

    @Override
    public Long count(GesPoDetail poCode) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesPoDetail a    where a.invalid =0  ");

        List<Object> ls = new ArrayList<Object>();

        if (StringUtil.notEmpty(poCode.getPoCode())) {
            hql.append(" and a.poCode=? ");
            ls.add(poCode.getPoCode());
        }
        if (poCode.getRoom() != null && poCode.getRoom().getId() != null && poCode.getRoom().getId() >= 0) {
            hql.append(" and a.room.id=? ");
            ls.add(poCode.getRoom().getId());
        }

        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getCode())) {
            hql.append(" and a.matter.code=? ");
            ls.add(poCode.getMatter().getCode());
        }
        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getModel())) {
            hql.append(" and a.matter.model=? ");
            ls.add(poCode.getMatter().getModel());
        }
        if (poCode.getMatter() != null && StringUtil.notEmpty(poCode.getMatter().getName())) {
            hql.append(" and a.matter.name like ? ");
            ls.add(super.getFuzzyCondition(poCode.getMatter().getName()));
        }
        if (poCode.getMatter() != null && poCode.getMatter().getBrand() != null
                && StringUtil.notEmpty(poCode.getMatter().getBrand().getName())) {
            hql.append(" and a.matter.brand.name=? ");
            ls.add(poCode.getMatter().getBrand().getName());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public GesPoDetail getByPoCode(String poCode) {
        return null;
    }

    @Override
    public void create(GesPoDetail poDetail) {
        super.saveResultBoolean(poDetail);
    }

    @Override
    public boolean batchDel(String ids) {
        String[] idArray = ids.split(",");
        List<Long> list = new ArrayList<Long>();
        for (String id : idArray) {
            list.add(Long.parseLong(id));
        }
        String hql = " delete from GesPoDetail where id in(:ids)";
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql);
        query.setParameterList("ids", list);
        query.executeUpdate();
        return true;
    }

    @Override
    public boolean updateAmount(Long id, Double amount) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        String hql = " update GesPoDetail set quantity=:amount where id=:id ";
        Query query = session.createQuery(hql);
        query.setParameter("amount", amount);
        query.setParameter("id", id);
        query.executeUpdate();
        return true;
    }

    @Override
    public GesPoDetail getRoomIdById(Long iorderseq) {
        String hql = " from GesPoDetail a    where a.invalid =0 and id=:id)";
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql);
        query.setParameter("id", iorderseq);
        return (GesPoDetail) query.uniqueResult();
    }
}
