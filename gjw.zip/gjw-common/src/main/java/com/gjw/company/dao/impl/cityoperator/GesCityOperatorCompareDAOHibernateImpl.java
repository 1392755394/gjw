package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorCompareDAO;
import com.gjw.entity.cityoperator.GesCityOperatorCompare;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorCompareDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorCompareDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorCompareDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperatorCompare.class;
    }

    @Override
    public GesCityOperatorCompare listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperatorCompare) super.get(id);
    }

    @Override
    public boolean updateGesCityOperatorCompare(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCityOperatorCompare(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorCompare item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getConcept())){
            hql=hql+" and item.concept like ?";
            params.add(super.getFuzzyCondition(model.getConcept()));
        }
        if(StringUtil.notEmpty(model.getTeam())){
            hql=hql+" and item.team like ?";
            params.add(super.getFuzzyCondition(model.getTeam()));
        }
        if(StringUtil.notEmpty(model.getEconomic())){
            hql=hql+" and item.economic like ?";
            params.add(super.getFuzzyCondition(model.getEconomic()));
        }
        if(StringUtil.notEmpty(model.getResource())){
            hql=hql+" and item.resource like ?";
            params.add(super.getFuzzyCondition(model.getResource()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperatorCompare> listByGesCityOperatorCompare(
            GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorCompare item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getConcept())){
            hql=hql+" and item.concept like ?";
            params.add(super.getFuzzyCondition(model.getConcept()));
        }
        if(StringUtil.notEmpty(model.getTeam())){
            hql=hql+" and item.team like ?";
            params.add(super.getFuzzyCondition(model.getTeam()));
        }
        if(StringUtil.notEmpty(model.getEconomic())){
            hql=hql+" and item.economic like ?";
            params.add(super.getFuzzyCondition(model.getEconomic()));
        }
        if(StringUtil.notEmpty(model.getResource())){
            hql=hql+" and item.resource like ?";
            params.add(super.getFuzzyCondition(model.getResource()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCityOperatorCompare>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
