package com.gjw.company.service.impl.oa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.TaskConstant;
import com.gjw.company.dao.oa.IGesTaskPersonDAO;
import com.gjw.company.service.oa.IGesTaskPersonService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.utils.ComparatorUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesCityOperatorVO;
import com.gjw.vo.oa.TaskPersonVO;
import com.gjw.vo.oa.UserVO;

@Component("gesTaskPersonServiceImpl")
public class GesTaskPersonServiceImpl extends AbstractServiceImpl implements
		IGesTaskPersonService {
	
	@Resource(name="gesTaskPersonHibernateImpl")
	private IGesTaskPersonDAO gesTaskPersonDAO;
	
	public IGesTaskPersonDAO getGesTaskPersonDAO() {
		return gesTaskPersonDAO;
	}

	public void setGesTaskPersonDAO(IGesTaskPersonDAO gesTaskPersonDAO) {
		this.gesTaskPersonDAO = gesTaskPersonDAO;
	}

	/**
	 * 获取可选客户分类:
	 * 构家网显示: 城运商+4S店+业主;
	 * 城运商显示: 4S店+业主;
	 * 4S店显示: 业主;
	 * @return 客户分类
	 */
	@Override
	public List<TaskPersonVO> selectCustomer(String orgType) {
		
		List<TaskPersonVO> list = new ArrayList<TaskPersonVO>();
		
		//构家网：显示城运商   需要获取用户的组织类型---------------
		if ("admin".equals(orgType)) {
			TaskPersonVO taskPerson = new TaskPersonVO();
			taskPerson.setId(-1l);
			taskPerson.setName("城运商");
			taskPerson.setIsLeaf(false);
			taskPerson.setParentId(0l);
			taskPerson.setType(TaskConstant.CUSTOMER_TYPE_CITYOPERATOR);
			list.add(taskPerson);
		}
		
		//构家网、城运商：显示4S店
		if (!"shop".equals(orgType)) {
			TaskPersonVO taskPerson = new TaskPersonVO();
			taskPerson.setId(-2l);
			taskPerson.setName("4S店");
			taskPerson.setIsLeaf(false);
			taskPerson.setParentId(0l);
			taskPerson.setType(TaskConstant.CUSTOMER_TYPE_SHOP);
			list.add(taskPerson);
		}
		
		//任何情况下都显示业主
		TaskPersonVO taskPerson = new TaskPersonVO();
		taskPerson.setId(-3l);
		taskPerson.setName("业主");
		taskPerson.setIsLeaf(false);
		taskPerson.setParentId(0l);
		taskPerson.setType(TaskConstant.CUSTOMER_TYPE_COMMON);
		list.add(taskPerson);
		
		return list;
	}

	/**
	 * 获取常用客户列表
	 * @param taskPerson 客户(类型)
	 * @return 客户列表
	 */
	@Override
	@Transactional(readOnly=true)
	public List<TaskPersonVO> listCustomer(TaskPersonVO taskPerson) {
		//查询项目任务中涉及的客户
		List<TaskPersonVO> listProject=getGesTaskPersonDAO().listCustomerInProjectTask(taskPerson);
		//查询交流中涉及到的客户
		List<TaskPersonVO> listCommunication=getGesTaskPersonDAO().listCustomerInCommunication(taskPerson);
		//结果集去重合并
		listProject.removeAll(listCommunication);
		listProject.addAll(listCommunication);
		//对listProject中的实体排序，取前10条
		Collections.sort(listProject, new ComparatorUtil<TaskPersonVO>("createdDatetime", "desc"));
		if(listProject.size()>10){
			listProject.subList(0, 10);
		}
		for(TaskPersonVO p:listProject){
			p.setIsLeaf(true);
		}
		return listProject;
	}
	
	

	/**
	 * 获取下属部门及员工列表
	 * @param parentId 部门Id
	 * @return 下属部门及员工列表，员工在先，下属部门在后
	 */
	@Override
	@Transactional(readOnly=true)
	public List<TaskPersonVO> listUser(long parentId, Long taskId,UserVO userInfoGes) {
		List<TaskPersonVO> list = new ArrayList<TaskPersonVO>();
		//构家网------------------------------
		if ("admin".equals(userInfoGes.getOrgType())) {
			//根据部门查询下属员工
			UserVO uvo = new UserVO();
			uvo.setDeptId(parentId);
			uvo.setTaskId(taskId);
			List<UserVO> userList = getGesTaskPersonDAO().queryUserByDept(uvo);
			//先列员工列表
			for(UserVO user:userList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(user.getId());
				if (!StringUtil.isBlank(user.getRealName())) {
					taskPerson.setName(user.getRealName());
				} else {
					taskPerson.setName(user.getUserName());
				}
				taskPerson.setIsLeaf(true);
				taskPerson.setParentId(parentId);
				list.add(taskPerson);
			}
			
			//根据部门查询下属部门
			Dept tempDept=new Dept();
			tempDept.setId(parentId);
			tempDept.setParent(tempDept);
			
			List<Dept> deptList = getGesTaskPersonDAO().queryDeptByParentId(tempDept);
			//后列下属部门列表
			for(Dept dept:deptList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(dept.getId());
				taskPerson.setName(dept.getName());
				taskPerson.setIsLeaf(false);
				taskPerson.setParentId(parentId);
				list.add(taskPerson);
			}
		} else {
			//构家网以外的登录用户限定其选择范围为自己所属组织
			UserVO u = new UserVO();
			u.setOrgType(userInfoGes.getOrgType());
			u.setOrgId(userInfoGes.getOrgId());
			if ("city_operator".equals(userInfoGes.getOrgType())) {
				u.setSearchType(TaskConstant.USER_TYPE_CITYOPERATOR);
			} else if ("shop".equals(userInfoGes.getOrgType())) {
				u.setSearchType(TaskConstant.USER_TYPE_SHOP);
			} else {
				u.setSearchType(TaskConstant.USER_TYPE_COMMON);
			}
			u.setTaskId(taskId);
			//根据名称查询员工列表
			List<UserVO> userList = getGesTaskPersonDAO().queryUser(u);
			for(UserVO user:userList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(user.getId());
				taskPerson.setName(user.getRealName());
				taskPerson.setIsLeaf(true);
				taskPerson.setParentId(0l);
				list.add(taskPerson);
			}
		}
		
		return list;
	}

	/**
	 * 根据类型及名称查询客户列表
	 * @param type
	 * @param name
	 * @param user
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public List<TaskPersonVO> queryCustomer(int type, String name,
			UserVO user) {
		List<TaskPersonVO> list = new ArrayList<TaskPersonVO>();
		//查询城运商列表信息
		if (type == TaskConstant.CUSTOMER_TYPE_CITYOPERATOR) {
			GesCityOperatorVO cityOperator = new GesCityOperatorVO();
			cityOperator.setContactName(name);
			//4S店只能查询其所属城运商信息，构家网可查询全部,城运商查自己
			if("city_operator".equals(user.getOrgType())) {
				cityOperator.setId(user.getOrgId());
			}
			if("shop".equals(user.getOrgType())) {
				cityOperator.setShopId(user.getOrgId());
			}
			List<GesCityOperator> cityOperatorList = getGesTaskPersonDAO().queryCityOperator(cityOperator);
			for(GesCityOperator co:cityOperatorList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(co.getId());
				taskPerson.setName(co.getCompanyName());
				taskPerson.setIsLeaf(true);
				taskPerson.setParentId(-1l);
				taskPerson.setType(TaskConstant.CUSTOMER_TYPE_CITYOPERATOR);
				list.add(taskPerson);
			}
		}
		
		//查询4S店列表信息
		if (type == TaskConstant.CUSTOMER_TYPE_SHOP) {
			GesShop shop = new GesShop();
			shop.setName(name);
			//城运商只能查询其下属4S店列表信息，构家网可查询全部,4S店查自己
			if("city_operator".equals(user.getOrgType())) {
				GesCityOperator gco=new GesCityOperator();
				gco.setId(user.getOrgId());
				shop.setOperator(gco);
			}
			if("shop".equals(user.getOrgType())) {
				shop.setId(user.getOrgId());
			}
			List<GesShop> shopList = getGesTaskPersonDAO().queryShop(shop);
			for(GesShop s:shopList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(s.getId());
				taskPerson.setName(s.getName());
				taskPerson.setIsLeaf(true);
				taskPerson.setParentId(-2l);
				taskPerson.setType(TaskConstant.CUSTOMER_TYPE_SHOP);
				list.add(taskPerson);
			}
		}
		
		//查询客户列表
		if (type == TaskConstant.CUSTOMER_TYPE_COMMON) {
			GesCustomerVO cvo = new GesCustomerVO();
			cvo.setName(name);
			//根据组织类型及登录用户ID决定查询范围
			cvo.setOrgType(user.getOrgType());
			cvo.setId(user.getId());	
			List<GesCustomer> customerList = getGesTaskPersonDAO().queryCustomer(cvo);
			for(GesCustomer c:customerList){
				TaskPersonVO taskPerson = new TaskPersonVO();
				taskPerson.setId(c.getId());
				taskPerson.setName(c.getName());
				taskPerson.setIsLeaf(true);
				taskPerson.setParentId(-3l);
				taskPerson.setType(TaskConstant.CUSTOMER_TYPE_COMMON);
				list.add(taskPerson);
			}
		}
		
		return list;
	}

	/**
	 * 根据名称查询员工列表
	 * @param taskId 任务Id
	 * @param type 员工类型
	 * @param name 名称
	 * @return 员工列表
	 */
	@Override
	@Transactional(readOnly=true)
	public List<TaskPersonVO> queryUserByName(UserVO userVO) {
		//根据名称查询员工列表
		List<UserVO> userList = getGesTaskPersonDAO().queryUser(userVO);
		//转换成前端使用的数据类型
		List<TaskPersonVO> list = new ArrayList<TaskPersonVO>();
		for(UserVO u:userList){
			TaskPersonVO taskPerson = new TaskPersonVO();
			taskPerson.setId(u.getId());
			if(StringUtil.notEmpty(u.getRealName())){
				taskPerson.setName(u.getRealName());
			}else{
				taskPerson.setName(u.getUserName());
			}
			taskPerson.setIsLeaf(true);
			taskPerson.setParentId(0l);
			list.add(taskPerson);
		}
		return list;
	}
	
	

}
