package com.gjw.company.service.label;

import java.util.List;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.label.WebLabel;



public interface IWebLabelService {
    public void add(WebLabel label);
    public void remove(Long id);
    public void update(WebLabel label);
    /**
     * 
    * @Description  通过id得到
    * @param id
    * @return
    * @author qingye   
    * @date Dec 19, 2015 10:42:42 AM
     */
    WebLabel get(Long id);
   
    /**
     * 
    * @Description   通过属性得到所有的parent为0的一级标签
    * @param peroperty
    * @return
    * @author qingye
    * @date Dec 19, 2015 10:42:35 AM
     */
    List<WebLabel> listParentByPeroperty(Dictionary peroperty);
    
    /**
     * 
    * @Description  通过父id得到所有的子标签
    * @param parentId
    * @return
    * @author qingye   
    * @date Dec 19, 2015 11:02:50 AM
     */
    List<WebLabel> listChildByParent(Long parentId);
    
    
    
    /**
     * 
    * @Description  通过parent批量更新peropertyType
    * @param peroperty
    * @param parentId
    * @author qingye   
    * @date Dec 19, 2015 11:23:26 AM
     */
    void updatePeropertyByParent(Dictionary peroperty, Long parentId);
    /** 
    * @Description  
    * @param list
    * @return
    * @author qingye   
    * @date Dec 19, 2015 2:00:34 PM
    */
    
    public List<WebLabel> batchRemove(List<Long> list);
    /** 
    * @Description  
    * @param list
    * @return
    * @author qingye   
    * @date Dec 19, 2015 2:13:01 PM
    */
    
    public List<WebLabel> batchReuse(List<Long> list);
    
    public List<WebLabel> page(WebLabel label);
    public long count(WebLabel label);
    
    public List<WebLabel> baikeLabel(Long parentId);
}
