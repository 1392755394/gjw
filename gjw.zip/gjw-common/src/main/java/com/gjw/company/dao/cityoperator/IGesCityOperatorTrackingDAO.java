package com.gjw.company.dao.cityoperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperatorTracking;

public interface IGesCityOperatorTrackingDAO extends IDAO{
    public GesCityOperatorTracking listByID(Long id);

    public boolean updateGesCityOperatorTracking(GesCityOperatorTracking model);

    public boolean createGesCityOperatorTracking(GesCityOperatorTracking model);
    
    public long count(GesCityOperatorTracking model);
    
    public List<GesCityOperatorTracking> listByGesCityOperatorTracking(GesCityOperatorTracking model);
}
