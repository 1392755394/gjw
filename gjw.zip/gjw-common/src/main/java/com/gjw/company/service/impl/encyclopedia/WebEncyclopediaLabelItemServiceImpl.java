package com.gjw.company.service.impl.encyclopedia;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.encyclopedia.IWebEncyclopediaLabelItemDAO;
import com.gjw.company.dao.label.IWebLabelDAO;
import com.gjw.company.service.encyclopedia.IWebEncyclopediaLabelItemService;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;
import com.gjw.entity.label.WebLabel;
import com.gjw.utils.StringUtil;

@Component("webEncyclopediaLabelItemServiceImpl")
public class WebEncyclopediaLabelItemServiceImpl implements IWebEncyclopediaLabelItemService {
    @Autowired
    private IWebEncyclopediaLabelItemDAO dao;

    @Autowired
    private IWebLabelDAO labelDao;

    @Override
    @Transactional(readOnly = true)
    public List<WebEncyclopediaLabelItem> listByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        List<WebEncyclopediaLabelItem> items = dao.listByInfoAndDictionary(item);
        for(WebEncyclopediaLabelItem i:items){
            if(StringUtil.notEmpty(i)){
                Hibernate.initialize(i.getLabel());
            }
        }
        return items;
    }

    @Override
    @Transactional
    public boolean invalidByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        return dao.invalidByInfoAndDictionary(item);
    }

    @Override
    @Transactional
    public boolean addRelation(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        String labelIds = item.getLabelIds();
        if (StringUtil.notEmpty(labelIds)) {
            String[] labelLise = labelIds.split(",");
            for (String label : labelLise) {
                if(StringUtil.notEmpty(label)){
                    WebEncyclopediaLabelItem entity = new WebEncyclopediaLabelItem();
                    WebLabel la = new WebLabel();
                    la.setId(Long.valueOf(label));
                    entity.setLabel(la);
                    entity.setInfo(item.getInfo());
                    entity.setPropertyType(item.getPropertyType());
                    dao.add(entity);
                }
            }
        }
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public String getLabelNameByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        String labelName = "";
        List<WebEncyclopediaLabelItem> list = dao.listByInfoAndDictionary(item);
        if (null != list && list.size() > 0) {
            for (WebEncyclopediaLabelItem label : list) {
                labelName = label.getLabel().getName() + ";" + labelName;
            }
        }
        if ("" != labelName) {
            return labelName.substring(0, labelName.length() - 1);
        }
        return labelName;
    }

    @Override
    @Transactional(readOnly = true)
    public String getLabelNameByCondition(WebEncyclopediaLabelItem item, Long dictionary) {
        // TODO Auto-generated method stub
        String labelName = "";
        List<WebEncyclopediaLabelItem> list = dao.listByInfoAndDictionary(item);
        if (null != list && list.size() > 0) {
            for (WebEncyclopediaLabelItem label : list) {
                WebLabel la = labelDao.get(label.getLabel().getId());
                if (null != la && null != la.getPropertyType() && la.getPropertyType().getId().equals(dictionary)) {
                    labelName = label.getLabel().getName() + ";" + labelName;
                }
            }
        }
        if ("" != labelName) {
            return labelName.substring(0, labelName.length() - 1);
        }
        return labelName;
    }

    @Override
    @Transactional(readOnly = true)
    public String getLabelIdByCondition(WebEncyclopediaLabelItem item, Long dictionary) {
        // TODO Auto-generated method stub
        String labelId = "";
        List<WebEncyclopediaLabelItem> list = dao.listByInfoAndDictionary(item);
        if (null != list && list.size() > 0) {
            for (WebEncyclopediaLabelItem label : list) {
                WebLabel la = labelDao.get(label.getLabel().getId());
                if (null != la && null != la.getPropertyType() && la.getPropertyType().getId().equals(dictionary)) {
                    labelId = label.getLabel().getId() + "," + labelId;
                }
            }
        }
        if ("" != labelId) {
            return labelId.substring(0, labelId.length() - 1);
        }
        return labelId;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        return dao.countByInfoAndDictionary(item);
    }
}
