package com.gjw.company.dao.matter;

import java.util.List;
import java.util.Map;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.matter.MaterialsCategory;
import com.gjw.vo.MaterialsCategoryVO;

/**
 * 建材类目dao接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月14日
 * 
 */
public interface IMaterialsCategoryDAO extends IDAO {

    /**
     * 查询建材分类列表
     * 
     * @Description
     * @param parentId
     *            父分类ID
     * @return 子分类列表
     * @author guojianbin
     * @date 2015年12月14日
     */
    public List<MaterialsCategory> listCategoryByParentId(long parentId);

    /**
     * 查询建材分类总数
     * 
     * @Description
     * @param parentId
     *            父分类ID
     * @return 建材分类总数
     * @author guojianbin
     * @date 2015年12月17日
     */
    public Long countCategoryByParentId(long parentId);

    /**
     * 根据ID获取建材分类
     * 
     * @Description
     * @param id
     *            建材分类id
     * @return 建材分类
     * @author guojianbin
     * @date 2015年12月17日
     */
    public MaterialsCategory queryByID(Long id);

    /**
     * 建材库分类同步查询
     * 
     * @Description
     * @param materialsCategory
     * @return
     * @author gwb
     * @date 2015年12月19日 下午2:02:12
     */
    public List<Map<String, Object>> listMaterialsCategoryForSynch(MaterialsCategory materialsCategory);

    /**
     * 修改建材库分类同步结果
     * 
     * @Description
     * @param obj
     * @author gwb
     * @date 2015年12月19日 下午3:21:04
     */
    public void updateMaterialsCategory(MaterialsCategoryVO obj);
    
    /**
     * 
    * @Description  修改建材库类目信息
    * @param materialsCategory
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月8日 上午11:57:44
     */
    public boolean updateCategory(MaterialsCategory materialsCategory);

}
