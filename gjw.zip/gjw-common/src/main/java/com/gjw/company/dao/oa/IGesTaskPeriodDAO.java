package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesTaskPeriod;
import com.gjw.vo.oa.GesTaskPeriodVO;

public interface IGesTaskPeriodDAO extends IDAO {
	
	/**
	 * 根据任务的id查询任务的阶段及阶段下的任务个数
	 * @param taskId
	 * @return
	 */
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskId(Long taskId);
    
    /**
     * 通过任务的id查询任务阶段的列表信息
     * @param taskId
     * @return
     */
    public List<GesTaskPeriodVO> queryTaskPeriodByTaskId(Long taskId);
    
    /**
     * 添加一条记录
     * @param taskPeriod
     * @return
     */
    public long addTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 更新一条记录
     * @param taskPeriod
     * @return
     */
    public boolean updateTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 通过任务的id查询任务阶段的最大顺序
     * @param taskPeriod
     * @return
     */
    public int queryMaxOrder(Long taskId);
    
    /**
     * 删除一条记录
     * @param taskPeriod
     * @return
     */
    public boolean delTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 查询当前阶段的下一个阶段
     * @param taskPeriod
     * @return
     */
    public GesTaskPeriod queryNextPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 查询当前阶段的上一个阶段
     * @param taskPeriod
     * @return
     */
    public GesTaskPeriod queryPrevPeriod(GesTaskPeriod taskPeriod);
    
    /**
	 * 根据施工管理项目的id查询任务的阶段及阶段下的任务个数
	 * @param taskId
	 * @return
	 */
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskIdForPM(Long taskId);

}
