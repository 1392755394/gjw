package com.gjw.company.service.impl.matter;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.matter.IBrandService;
import com.gjw.entity.matter.Brand;

/**
 * 品牌service实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月14日 
 *
 */
@Component("brandServiceImpl")
public class BrandServiceImpl extends AbstractServiceImpl implements IBrandService {

    @Override
    @Transactional(readOnly = true)
    public List<Brand> pageBrandByNameAndType(Brand brandCriteria) {
        return super.getBrandDAO().pageBrandByNameAndType(brandCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countBrandByNameAndType(Brand brandCriteria) {
        return super.getBrandDAO().countBrandByNameAndType(brandCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Brand queryByID(Long id) {
        return super.getBrandDAO().queryByID(id);
    }

    @Override
    @Transactional
    public void saveOrUpdate(Brand brand) {
        if (brand.getId() == null || brand.getId() == 0) {
            // 根据分类查询品牌总数
            long maxId = super.getBrandDAO().countMaxByType(brand);
            String c = String.valueOf(maxId+1);
            // 前面补0凑成3位
            brand.setCode(c.length()==2 ? "0"+c : c.length()==1 ? "00"+c : c);
        }
        super.getBrandDAO().saveOrUpdate(brand);
    }

}
