package com.gjw.company.service.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.cityoperator.IGesCityOperatorService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.cityoperator.GesCityOperatorCompare;
import com.gjw.entity.cityoperator.GesCityOperatorCompareConclusion;
import com.gjw.entity.cityoperator.GesCityOperatorContract;
import com.gjw.entity.cityoperator.GesCityOperatorPartner;
import com.gjw.entity.cityoperator.GesCityOperatorTracking;
import com.gjw.entity.cityoperator.GesGuide;
import com.gjw.utils.StringUtil;
import com.gjw.vo.oa.GesCityOperatorVO;

@Service("gesCityOperatorServiceImpl")
public class GesCityOperatorServiceImpl extends AbstractServiceImpl implements IGesCityOperatorService {
    /**
     * 通过ID查找城运商
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperator listByID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperator model = super.getGesCityOperatorDAO().listByID(id);
        Hibernate.initialize(model.getDictionary());
        Hibernate.initialize(model.getProvince());
        Hibernate.initialize(model.getCity());
        Hibernate.initialize(model.getCountry());
        Hibernate.initialize(model.getDictionary());
        return model;
    }

    /**
     * 更新城运商
     */
    @Override
    @Transactional
    public boolean updateGesCityOperator(GesCityOperator model) {
        // TODO Auto-generated method stub
        GesCityOperator item = super.getGesCityOperatorDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        if(null==model.getCompanyName() || "".equals(model.getCompanyName())){
            item.setCompanyName("");
        }
        return super.getGesCityOperatorDAO().update(item) == 1;
    }

    /**
     * 创建一个新的城运商
     */
    @Override
    @Transactional
    public boolean createGesCityOperator(GesCityOperator model) {
        // TODO Auto-generated method stub
        if(null==model.getCity() || null==model.getCity().getId()){
            model.setCity(null);
        }
        if(null==model.getCountry() || null==model.getCountry().getId()){
            model.setCountry(null);
        }
        model.setUfCode("03"+String.valueOf(System.currentTimeMillis()).substring(9));
        return super.getGesCityOperatorDAO().createGesCityOperator(model);
    }
    /**
     * 统计城运商总数
     */
    @Override
    @Transactional(readOnly = true)
    public long count(GesCityOperator model, Integer... stars) {
        // TODO Auto-generated method stub
        if (null != stars && stars.length > 0) {
            return super.getGesCityOperatorDAO().count(model, stars);
        }
        return super.getGesCityOperatorDAO().count(model);
    }

    /**
     * 城运商列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperator> listByGesCityOperator(GesCityOperator model, Integer... stars) {
        // TODO Auto-generated method stub
        List<GesCityOperator> list = new ArrayList<GesCityOperator>();
        if (null != stars && stars.length > 0) {
            list = super.getGesCityOperatorDAO().listByGesCityOperator(model, stars);
            for (GesCityOperator gesCityOperator : list) {
                Hibernate.initialize(gesCityOperator.getProvince());
                Hibernate.initialize(gesCityOperator.getCity());
                Hibernate.initialize(gesCityOperator.getDictionary());
            }
        } else {
            list = super.getGesCityOperatorDAO().listByGesCityOperator(model);
            for (GesCityOperator gesCityOperator : list) {
                Hibernate.initialize(gesCityOperator.getProvince());
                Hibernate.initialize(gesCityOperator.getCity());
                Hibernate.initialize(gesCityOperator.getDictionary());
                if(null!=gesCityOperator.getSynchType()){
                    Hibernate.initialize(gesCityOperator.getSynchType().getText());
                }
            }
        }
        return list;
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorVO> listByGesCityOperator4Export(GesCityOperator model, Integer... stars) {
        model.setPageSize(Integer.MAX_VALUE);
        List<GesCityOperator> list = listByGesCityOperator(model, stars);
        List<GesCityOperatorVO> resultList = new ArrayList<GesCityOperatorVO>();
        for (GesCityOperator item : list) {
            GesCityOperatorVO vo = new GesCityOperatorVO();
            vo.setContactName(item.getContactName());
            switch (item.getStar() != null? item.getStar().intValue():0) {
            case 1: 
                vo.setStarStr("一星");
                break;
            case 2: 
                vo.setStarStr("二星");
                break;
            case 3: 
                vo.setStarStr("三星");
                break;
            case 4: 
                vo.setStarStr("四星");
                break;
            case 5: 
                vo.setStarStr("五星减");
                break;
            case 6: 
                vo.setStarStr("五星");
                break;
            case 7: 
                vo.setStarStr("五星加");
                break;
            default:
                vo.setStarStr("未设置星级");
                break;
            }
            vo.setProvinceName(item.getProvince()!=null?item.getProvince().getName():"");
            vo.setCityName(item.getCity()!=null?item.getCity().getName():"");
            vo.setCompanyName(item.getCompanyName());
            vo.setPhone(item.getPhone());
            vo.setAddDatetime(item.getCreatedDatetime());
            resultList.add(vo);
        }
        return resultList;
    }

    /**
     * 通过ID查找城运商4维度对比总结
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperatorCompareConclusion listByGesCityOperatorCompareConclusionID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperatorCompareConclusion model = super.getGesCityOperatorCompareConclusionDAO().listByID(id);
        return model;
    }

    /**
     * 更新城运商4维度对比总结
     */
    @Override
    @Transactional()
    public boolean updateGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        GesCityOperatorCompareConclusion item = super.getGesCityOperatorCompareConclusionDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCityOperatorCompareConclusionDAO().updateGesCityOperatorCompareConclusion(item);
    }

    /**
     * 创建城运商4维度对比总结
     */
    @Override
    @Transactional()
    public boolean createGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorCompareConclusionDAO().createGesCityOperatorCompareConclusion(model);
    }

    /**
     * 统计城运商4维度对比总结总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesCityOperatorCompareConclusionCount(GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorCompareConclusionDAO().count(model);
    }

    /**
     * 城运商4维度对比总结列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorCompareConclusion> listByGesCityOperatorCompareConclusion(
            GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        List<GesCityOperatorCompareConclusion> list = super.getGesCityOperatorCompareConclusionDAO()
                .listByGesCityOperatorCompareConclusion(model);
        for (GesCityOperatorCompareConclusion gesCityOperatorCompareConclusion : list) {

        }
        return list;
    }

    /**
     * 通过ID查询城运商4对比
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperatorCompare listByGesCityOperatorCompareID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperatorCompare model = super.getGesCityOperatorCompareDAO().listByID(id);
        return model;
    }

    /**
     * 更新城运商4对比
     */
    @Override
    @Transactional()
    public boolean updateGesCityOperatorCompare(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        GesCityOperatorCompare item = super.getGesCityOperatorCompareDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCityOperatorCompareDAO().updateGesCityOperatorCompare(item);
    }

    /**
     * 创建城运商4对比
     */
    @Override
    @Transactional()
    public boolean createGesCityOperatorCompare(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorCompareDAO().createGesCityOperatorCompare(model);
    }

    /**
     * 统计城运商4对比
     */
    @Override
    @Transactional(readOnly = true)
    public long gesCityOperatorCompareCount(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorCompareDAO().count(model);
    }

    /**
     * 列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorCompare> listByGesCityOperatorCompare(GesCityOperatorCompare model) {
        // TODO Auto-generated method stub
        List<GesCityOperatorCompare> list = super.getGesCityOperatorCompareDAO().listByGesCityOperatorCompare(model);
        for (GesCityOperatorCompare gesCityOperatorCompare : list) {
            Hibernate.initialize(gesCityOperatorCompare.getCityOperator());
            if (null != gesCityOperatorCompare.getCityOperator()) {
                Hibernate.initialize(gesCityOperatorCompare.getCityOperator().getProvince());
                Hibernate.initialize(gesCityOperatorCompare.getCityOperator().getCity());
                Hibernate.initialize(gesCityOperatorCompare.getCityOperator().getCountry());
            }
        }
        return list;
    }

    /**
     * 通过ID查询城运商合同信息
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperatorContract listByGesCityOperatorContractID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperatorContract model = super.getGesCityOperatorContractDAO().listByID(id);
        return model;
    }

    /**
     * 更新城运商合同信息
     */
    @Override
    @Transactional()
    public boolean updateGesCityOperatorContract(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        GesCityOperatorContract item = super.getGesCityOperatorContractDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCityOperatorContractDAO().updateGesCityOperatorContract(item);
    }

    /**
     * 创建城运商合同信息
     */
    @Override
    @Transactional()
    public boolean createGesCityOperatorContract(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorContractDAO().createGesCityOperatorContract(model);
    }

    /**
     * 统计城运商合同信息总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesCityOperatorContractCount(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorContractDAO().count(model);
    }

    /**
     * 城运商合同信息列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorContract> listByGesCityOperatorContract(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        List<GesCityOperatorContract> list = super.getGesCityOperatorContractDAO().listByGesCityOperatorContract(model);
        for (GesCityOperatorContract gesCityOperatorContract : list) {
            Hibernate.initialize(gesCityOperatorContract.getCityOperator());
        }
        return list;
    }

    /**
     * 通过ID查询城运商合伙人
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperatorPartner listByGesCityOperatorPartnerID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperatorPartner model = super.getGesCityOperatorPartnerDAO().listByID(id);
        return model;
    }

    /**
     * 更新城运商合伙人
     */
    @Override
    @Transactional()
    public boolean updateGesCityOperatorPartner(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        GesCityOperatorPartner item = super.getGesCityOperatorPartnerDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCityOperatorPartnerDAO().updateGesCityOperatorPartner(item);
    }

    /**
     * 创建城运商合伙人
     */
    @Override
    @Transactional()
    public boolean createGesCityOperatorPartner(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorPartnerDAO().createGesCityOperatorPartner(model);
    }

    /**
     * 统计城运商合伙人总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesCityOperatorPartnerCount(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorPartnerDAO().count(model);
    }

    /**
     * 城运商合伙人列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorPartner> listByGesCityOperatorPartner(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        List<GesCityOperatorPartner> list = super.getGesCityOperatorPartnerDAO().listByGesCityOperatorPartner(model);
        return list;
    }

    /**
     * 软删除城运商合伙人
     */
    @Override
    @Transactional()
    public boolean deleteGesCityOperatorPartner(GesCityOperatorPartner model) {
        GesCityOperatorPartner item = super.getGesCityOperatorPartnerDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        item.setInvalid(true);
        return super.getGesCityOperatorPartnerDAO().updateGesCityOperatorPartner(item);
    }

    /**
     * 通过ID查询城运商跟踪信息
     */
    @Override
    @Transactional(readOnly = true)
    public GesCityOperatorTracking listByGesCityOperatorTrackingID(Long id) {
        // TODO Auto-generated method stub
        GesCityOperatorTracking model = super.getGesCityOperatorTrackingDAO().listByID(id);
        Hibernate.initialize(model.getCityOperator());
        return model;
    }

    /**
     * 更新城运商跟踪信息
     */
    @Override
    @Transactional()
    public boolean updateGesCityOperatorTracking(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        GesCityOperatorTracking item = super.getGesCityOperatorTrackingDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCityOperatorTrackingDAO().updateGesCityOperatorTracking(item);
    }

    /**
     * 创建城运商跟踪信息
     */
    @Override
    @Transactional()
    public boolean createGesCityOperatorTracking(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorTrackingDAO().createGesCityOperatorTracking(model);
    }

    /**
     * 统计城运商跟踪信息总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesCityOperatorTrackingCount(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        return super.getGesCityOperatorTrackingDAO().count(model);
    }

    /**
     * 城运商跟踪信息列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperatorTracking> listByGesCityOperatorTracking(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        List<GesCityOperatorTracking> list = super.getGesCityOperatorTrackingDAO().listByGesCityOperatorTracking(model);
        for (GesCityOperatorTracking gesCityOperatorTracking : list) {
            Hibernate.initialize(gesCityOperatorTracking.getCityOperator());
        }
        return list;
    }

    /**
     * 根据ID查询接引表单
     */
    @Override
    @Transactional(readOnly = true)
    public GesGuide listByGesGuideID(Long id) {
        // TODO Auto-generated method stub
        GesGuide model = super.getGesGuideDAO().listByID(id);
        Hibernate.initialize(model.getOperator());
        Hibernate.initialize(model.getCommitOperator());
        Hibernate.initialize(model.getDictionary());
        return model;
    }

    /**
     * 更新一条接引表单信息
     */
    @Override
    @Transactional()
    public boolean updateGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        GesGuide item = super.getGesGuideDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesGuideDAO().updateGesGuide(item);
    }

    /**
     * 创建一条接引表单
     */
    @Override
    @Transactional()
    public boolean createGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        return super.getGesGuideDAO().createGesGuide(model);
    }

    /**
     * 统计接引表单总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesGuideCount(GesGuide model) {
        // TODO Auto-generated method stub
        return super.getGesGuideDAO().count(model);
    }

    /**
     * 接引表单列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesGuide> listByGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        List<GesGuide> list = super.getGesGuideDAO().listByGesGuide(model);
        for (GesGuide item : list) {
            Hibernate.initialize(item.getOperator());
            Hibernate.initialize(item.getCommitOperator());
            Hibernate.initialize(item.getDictionary());
        }
        return list;
    }

    /**
     * 批量删除接引表单
     */
    @Override
    @Transactional()
    public boolean deleteGuide(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesGuide model = super.getGesGuideDAO().listByID(Long.valueOf(id));
            model.setInvalid(true);
            super.getGesGuideDAO().updateGesGuide(model);
        }
        return true;
    }


}
