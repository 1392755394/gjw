package com.gjw.company.service.impl.article;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.encyclopedia.IWebEncyclopediaLabelItemDAO;
import com.gjw.company.dao.topic.IWebTopicArticleItemDAO;
import com.gjw.company.service.article.IWebArticleService;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.entity.comment.WebCommentItem;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;
import com.gjw.entity.label.WebLabel;
import com.gjw.entity.topic.WebTopic;
import com.gjw.entity.topic.WebTopicArticleItem;
import com.gjw.entity.user.User;
import com.gjw.utils.StringUtil;
import com.gjw.utils.TagUtil;

@Service("webArticleServiceImpl")
@Transactional
public class WebArticleServiceImpl extends AbstractServiceImpl implements IWebArticleService {
    @Autowired
    private IWebEncyclopediaLabelItemDAO encyclopediaLabelDao;
    @Autowired
    private IWebTopicArticleItemDAO tipicArticleDao;

    @Override
    public WebArticle get(Long id) {
        WebArticle article = this.getWebArticleDAO().get(id);
        if (article != null) {
            Hibernate.initialize(article.getImage());
        }
        return article;
    }

    @Override
    public List<WebArticle> pageByName(WebArticle article) {

        List<WebArticle> list = this.getWebArticleDAO().pageByName(article);
        for (WebArticle item : list) {
            Hibernate.initialize(item.getUser());
        }
        return list;
    }

    @Override
    public long countByName(WebArticle article) {
        return this.getWebArticleDAO().countByName(article);
    }

    @Override
    public void batchDelete(List<Long> idList) {
        this.getWebArticleDAO().batchDelete(idList);
    }

    @Override
    public void batchReuse(List<Long> idList) {
        this.getWebArticleDAO().batchReuse(idList);
    }

    @Override
    public void add(WebArticle article, List<WebLabel> labelList, List<WebTopic> topicList) {
        this.getWebArticleDAO().add(article);
        for (WebLabel label : labelList)
            this.encyclopediaLabelDao.add(new WebEncyclopediaLabelItem(label, new Dictionary(
                    DictionaryConstants.DICTIONARY_OTHER_LABEL_ATICLE), article.getId()));
        for (WebTopic topic : topicList)
            this.tipicArticleDao.add(new WebTopicArticleItem(topic, article));
    }

    @Override
    public void update(WebArticle article, List<WebLabel> labelList, List<WebTopic> topicList) {
        WebArticle tmp = this.getWebArticleDAO().get(article.getId());
        StringUtil.copyPropertiesAllowEmpty(article, tmp);
        this.getWebArticleDAO().update(tmp);
        encyclopediaLabelDao.deleteByPropertyAndInfo(new Dictionary(DictionaryConstants.DICTIONARY_OTHER_LABEL_ATICLE),
                article.getId());
        tipicArticleDao.deleteByArticle(article);
        for (WebLabel label : labelList)
            this.encyclopediaLabelDao.add(new WebEncyclopediaLabelItem(label, new Dictionary(
                    DictionaryConstants.DICTIONARY_OTHER_LABEL_ATICLE), article.getId()));
        for (WebTopic topic : topicList)
            this.tipicArticleDao.add(new WebTopicArticleItem(topic, article));
    }

    @Override
    public List<WebArticle> listByArticle(WebArticle model) {
        // TODO Auto-generated method stub
        List<WebArticle> list = super.getWebArticleDAO().listByArticle(model);
        for (WebArticle webArticle : list) {
            Hibernate.initialize(webArticle.getImage());
            Hibernate.initialize(webArticle.getUser());
            if (null != webArticle.getUser() && null != webArticle.getUser().getPlatformUserInfo()) {
                Hibernate.initialize(webArticle.getUser().getPlatformUserInfo());
                if (null != webArticle.getUser().getPlatformUserInfo().getAvatar()) {
                    Hibernate.initialize(webArticle.getUser().getPlatformUserInfo().getAvatar());
                }
            }
        }
        return list;
    }

    @Override
    public long count(WebArticle model) {
        // TODO Auto-generated method stub
        return super.getWebArticleDAO().count(model);
    }

    @Override
    public List<WebArticle> listByWebEncyclopediaLabelItem(List<WebEncyclopediaLabelItem> items, Long userId) {
        // TODO Auto-generated method stub
        List<WebArticle> list = new ArrayList<WebArticle>();
        for (WebEncyclopediaLabelItem item : items) {
            WebArticle article = super.getWebArticleDAO().get(item.getInfo());
            if (!article.getInvalid()) {
                List<WebEncyclopediaLabelItem> labels = encyclopediaLabelDao.listByInfoAndDictionary(item);
                for (WebEncyclopediaLabelItem webEncyclopediaLabelItem : labels) {
                    Hibernate.initialize(webEncyclopediaLabelItem.getLabel());
                }
                // 文章标签
                article.setLabels(labels);
                // 文章评论
                WebCommentItem param = new WebCommentItem();
                param.setInfo(article.getId());
                Dictionary articleReview = new Dictionary();
                articleReview.setId(1120201l);
                article.setCommentCount(super.getWebCommentItemDAO().countByCondition(param));
                // 文章图片
                List<String> images = TagUtil.getSrc(article.getContent(), "<img", "/>", "src=\"");
                if (null != images && images.size() > 4) {
                    images = images.subList(0, 4);
                }
                article.setImages(images);
                // 是否收藏
                if (null != userId) {
                    WebCollectionItem collection = new WebCollectionItem();
                    User user = new User();
                    user.setId(userId);
                    collection.setUser(user);
                    collection.setInfo(article.getId());
                    Dictionary d = new Dictionary();
                    d.setId(1120103l);
                    collection.setPropertyType(d);
                    Long flag = super.getWebCollectionItemDAO().countByContent(collection);
                    if (0 < flag) {
                        article.setHadCollection(true);
                    }
                }
                Hibernate.initialize(article.getUser());
                if (null != article.getUser()) {
                    if (null != article.getUser().initPlatformUserInfo(PlatformEnum.Website)) {
                        if (null != article.getUser().initPlatformUserInfo(PlatformEnum.Website).getAvatar()) {
                            article.getUser().initPlatformUserInfo(PlatformEnum.Website).getAvatar().getPath();
                        }
                    }
                }
                list.add(article);
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebArticle> listArticleBy(List<WebCollectionItem> list) {
        // TODO Auto-generated method stub 根据用户收藏文章id查询文章列表
        List<WebArticle> li = super.getWebArticleDAO().listArticleBy(list);
        for (WebArticle article : li) {
            Hibernate.initialize(article.getImage());
            Hibernate.initialize(article.getUser().getPlatformUserInfo());
            if (article.getImage() != null) {
                Hibernate.initialize(article.getImage());
            }
        }

        return li;
    }
}
