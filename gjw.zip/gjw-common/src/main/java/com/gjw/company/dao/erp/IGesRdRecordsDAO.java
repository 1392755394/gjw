package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.vo.RdRecordsVO;

/**
 * 出入库单明细实体
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月18日 上午10:59:22
 * 
 */
public interface IGesRdRecordsDAO extends IDAO {

    /**
     * 新增出库单明细
     * 
     * @Description
     * @param rdRecords
     * @author gwb
     * @date 2015年12月18日 下午1:13:51
     */
    public void create(GesRdRecords rdRecords);

    /**
     * 根据code查询
     * 
     * @Description
     * @param rCodes
     * @return
     * @author gwb
     * @date 2015年12月18日 下午1:14:15
     */

    public Long countByCode(GesRdRecords rCodes);

    /**
     * 销售出库单房间与物料分页查询
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月21日 下午4:48:42
     */
    public List<GesRdRecords> pageByRdRecord(RdRecordsVO rdRecords);

    /**
     * 销售出库单房间与物料分页总数
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 上午9:24:29
     */
    public Long countByRdRecords(RdRecordsVO rdRecords);

    /**
     * 
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 下午4:17:41
     */
    public List<GesRdRecords> listArrivalByRdRecords(RdRecordsVO rdRecords);

    /**
     * 分页查询到货单明细(查询已入库数量不等于到货数量的到货单（销售出库单）)
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 下午4:17:47
     */
    public Long countArrivalByRecords(RdRecordsVO rdRecords, List<GesRdRecords> list);

    public List<GesRdRecords> pageArrivalByRdRecords(RdRecordsVO rdRecords, List<GesRdRecords> list);

    /**
     * 获取采购入库单明细
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月24日 上午9:23:40
     */
    public List<GesRdRecords> listGesRdRecord(GesRdRecord rdRecord);

    /**
     * * 采购到货单---到货
     * <p>
     * 修改删除关联入库数量
     * 
     * @Description
     * @param id
     * @param amount
     * @return
     * @author gwb
     * @date 2015年12月24日 下午5:36:26
     */
    public boolean updateAmountById(Long id, Long amount);

    /**
     * 更新已入库数量
     * 
     * @Description
     * @param rdRecords
     * @author gwb
     * @date 2015年12月25日 上午9:51:08
     */
    public void updateStockIn(GesRdRecords rdRecords);

}