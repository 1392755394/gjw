package com.gjw.company.service.impl.comment;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.common.constants.DictionaryConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.article.IWebArticleDAO;
import com.gjw.company.dao.comment.IWebCommentItemDAO;
import com.gjw.company.dao.goods.IGoodsDAO;
import com.gjw.company.dao.order.IWebOrderLogDAO;
import com.gjw.company.dao.picture.IPictureDAO;
import com.gjw.company.service.comment.IWebCommentItemService;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.comment.WebCommentItem;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.WebOrderLog;
import com.gjw.entity.picture.Picture;
import com.gjw.entity.user.UserInfo;

@Component("webCommentItemServiceImpl")
public class WebCommentItemServiceImpl implements IWebCommentItemService {

    @Autowired
    private IWebCommentItemDAO dao;
    @Autowired
    private IPictureDAO pictureDao;
    @Autowired
    private IWebOrderLogDAO logDao;
    @Autowired
    private IGoodsDAO goodsDao;
    @Autowired
    private IWebArticleDAO articleDao;

    @Override
    @Transactional(readOnly = true)
    public List<WebCommentItem> pageByCondition(WebCommentItem item) {
        // TODO Auto-generated method stub
        List<WebCommentItem> list = dao.pageByCondition(item);
        if (null != list && list.size() > 0) {
            // 文章评论
            if (item.getPropertyType().getId().equals(DictionaryConstants.DICTIONARY_USER_COMMET_ARTICLE)) {
                // 等青叶写好，写
                for (WebCommentItem comment : list) {
                    WebArticle article = articleDao.get(comment.getInfo());
                    if(null!=comment.getUser() && null!=comment.getUser().getId()){
                        UserInfo userInfo = comment.getUser().initPlatformUserInfo(PlatformEnum.Website);
                        if (userInfo == null) {
                            comment.getUser().initPlatformUserInfo(PlatformEnum.Ges);
                        }
                        userInfo.getRealName();
                        if(null!=comment.getUser().getPlatformUserInfo()){
                            Picture picture = comment.getUser().getPlatformUserInfo().getAvatar();
                            if (picture != null) {
                                comment.getUser().getPlatformUserInfo().getAvatar().getPath();
                            }
                        }
                        Hibernate.initialize(comment.getUser());
                    }
                    if (null != article) {
                        comment.setTitle(article.getName());
                    }
                }
            }
            // 图片评论
            if (item.getPropertyType().getId().equals(DictionaryConstants.DICTIONARY_USER_COMMET_IMAGE)) {
                for (WebCommentItem comment : list) {
                    Picture pic = pictureDao.get(comment.getInfo());
                    Hibernate.initialize(comment.getUser());
                    // comment.getUser().getUsername();
                    if (null != pic) {
                        comment.setTitle(pic.getPath());
                    }
                }
            }
            // 直播家日志评论
            if (item.getPropertyType().getId().equals(DictionaryConstants.DICTIONARY_USER_COMMET_HOME)) {
                for (WebCommentItem comment : list) {
//                    Hibernate.initialize(comment.getUser().getPlatformUserInfo().getAvatar().getPath());
                    comment.getUser().getUsername();
                    UserInfo userInfo = comment.getUser().initPlatformUserInfo(PlatformEnum.Website);
                    if (userInfo == null) {
                        comment.getUser().initPlatformUserInfo(PlatformEnum.Ges);
                    }
                    Picture picture = comment.getUser().getPlatformUserInfo().getAvatar();
                    if (picture != null) {
                        comment.getUser().getPlatformUserInfo().getAvatar().getPath();
                    }
                    WebOrderLog log = logDao.getById(comment.getInfo());
                    if (null != log) {
                        String title = log.getContent();
                        if (title.length() > 20) {
                            comment.setTitle(title.substring(0, 20));
                        } else {
                            comment.setTitle(title);
                        }
                    }
                }
            }
            // 产品包评论
            if (item.getPropertyType().getId().equals(DictionaryConstants.DICTIONARY_USER_COMMET_GOODS)) {
                for (WebCommentItem comment : list) {
                    Goods goods = goodsDao.queryById(comment.getInfo());
                    if (null != goods) {
                        comment.setTitle(goods.getName());
                    }
                    comment.getUser().initPlatformUserInfo(PlatformEnum.Website);
                    UserInfo userInfo = comment.getUser().getPlatformUserInfo();
                    if (userInfo == null) 
                        comment.getUser().initPlatformUserInfo(PlatformEnum.Ges);
                    Hibernate.initialize(comment.getUser().getPlatformUserInfo().getAvatar());
                }
            }
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByCondition(WebCommentItem item) {
        // TODO Auto-generated method stub
        return dao.countByCondition(item);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = this.invalid(Long.valueOf(id));
                    if (row > 0) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                row = this.invalid(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        if (0 == success && 0 != error) {
            return "失败废弃" + error + "条评论！";
        } else if (0 == error && 0 != success) {
            return "成功废弃" + success + "条评论！";
        } else if (0 == success && 0 == error) {
            return "请选择废弃的评论！";
        } else {
            return "成功废弃" + success + "条评论,失败废弃" + error + "条评论！";
        }
    }

    @Override
    @Transactional
    public boolean insert(WebCommentItem item) {
        return dao.saveResultBoolean(item);
    }

}
