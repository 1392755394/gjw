package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.UserRoleItem;

public interface IUserRoleDAO extends IDAO {
    
    List<UserRoleItem> listRolesOfUser(long userId);
}
