package com.gjw.company.dao.modelling;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.modelling.Modelling;

/**
 * 
* @Description: 造型库dao接口类
* @author  zhaoyonglian
* @date 2016年1月9日 下午2:52:37
*
 */
public interface IModellingDAO extends IDAO {

    /**
     * 
    * @Description  造型库列表
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:54:07
     */
    public List<Modelling> pageByCondition(Modelling modelling);

    /**
     * 
    * @Description  总数
    * @param matterCriteria
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:54:33
     */
    public Long countByCondition(Modelling modelling);

    /**
     * 
    * @Description  获取详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:55:17
     */
    public Modelling queryByID(Long id);

    /**
     * 
    * @Description  更新
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:13
     */
    public boolean updateModelling(Modelling modelling);

    /**
     * 
    * @Description  批量删除
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:29
     */
    public boolean delBatchByID(String ids);
    
}
