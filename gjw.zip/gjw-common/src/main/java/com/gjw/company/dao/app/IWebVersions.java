package com.gjw.company.dao.app;

import com.gjw.base.dao.IDAO;

public interface IWebVersions extends IDAO{
    
}
