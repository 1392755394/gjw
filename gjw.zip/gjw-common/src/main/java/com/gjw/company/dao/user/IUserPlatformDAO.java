package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserPlatformItem;

/**
 * 
* @Description: 
* @author  qingye
* @date Dec 23, 2015 3:27:20 PM
*
 */
public interface IUserPlatformDAO extends IDAO {
    void add(UserPlatformItem item);
}
