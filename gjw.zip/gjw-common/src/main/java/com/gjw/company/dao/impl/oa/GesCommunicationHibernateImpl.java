package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesCommunicationDAO;
import com.gjw.entity.oa.GesCommunication;
import com.gjw.vo.oa.GesCommunicationVO;

@Component("gesCommunicationHibernateImpl")
public class GesCommunicationHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesCommunicationDAO {

	@Override
	protected Class<?> getEntityClass() {
		return GesCommunication.class;
	}

	@Override
	public void createCommunication(GesCommunication communication) {
		super.add(communication);
	}

	/**
	 * 统计任务的交流数目
	 * @param gesCommunicationVO
	 * @return
	 */
	@Override
	public Long countCommunicationByTaskId(GesCommunicationVO gesCommunicationVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" from GesCommunication c where c.invalid=? and c.task.id=? ");
		param.add(false);
		param.add(gesCommunicationVO.getTaskId());
		return super.countHql(hql.toString(), param);
	}

	/**
	 * 根据订单id查询交流
	 * @param gesCommunicationVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesCommunicationVO> queryCommunicationByTaskId(
			GesCommunicationVO gesCommunicationVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select a.id as id,m.realName as commitUser,a.content as content,a.createdDatetime as gmtCreate,"
				+ "a.customerId as customerId,a.customerType as customerType,m.avatar.path as headPortrait,"
				+ "a.parent.id as parentId,a.root.id as rootId,a.updatedDatetime as updateTime,a.user.id as userId ");		
		hql.append(" from GesCommunication a,UserInfo m left join m.avatar t where 1=1 and a.invalid=? and m.type=? and a.user.id=m.user.id ");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		hql.append(" and a.task.id=? ");
		param.add(gesCommunicationVO.getTaskId());
		hql.append(" order by a.createdDatetime desc ");
		return (List<GesCommunicationVO>) super.findByPageCallBack(hql.toString(), null, param, gesCommunicationVO, Transformers.aliasToBean(GesCommunicationVO.class));
	}

	/**
	 * 根据任务的id更新任务的交流id
	 */
	@Override
	public int updateTaskCommunicationIdById(GesCommunication communication) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" update GesProjectTask p set p.communication.id=? where p.id=? ");
		param.add(communication.getId());
		param.add(communication.getTask().getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

	/**
	 * 根据交流的id删除交流信息
	 */
	@Override
	public int deleteCommunicationById(GesCommunication communication) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesCommunication c ");
		hql.append(" set c.updatedDatetime=? , c.invalid=?,c.user.id=? ");
		hql.append(" where c.id=? ");
		param.add(new Date());
		param.add(true);
		param.add(communication.getUser().getId());
		param.add(communication.getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

    @Override
    public GesCommunication queryById(Long communicationId) {
        return (GesCommunication) super.get(communicationId);
    }
    
    /**
	 * 根据任务的id更新任务的交流id为当前任务交流的最大交流ID
	 */
	@Override
	public int updateTaskCommunicationIdToMax(GesCommunication communication) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" update GesProjectTask p set p.updatedDatetime=? , p.communication.id=(select max(c.id) from GesCommunication c where c.invalid=? and c.task.id=? ) where p.id=? ");
		param.add(new Date());
		param.add(false);
		param.add(communication.getTask().getId());
		param.add(communication.getTask().getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

	@Override
	public List<Long> queryCommunicationIdByTaskId(Long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select id from GesCommunication where invalid=? and task.id=? ");
		param.add(false);
		param.add(taskId);
		return (List<Long>) super.findByListCallBack(hql.toString(), null, param, null);
	}

}
