package com.gjw.company.service.impl.salestool;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.error.BusinessErrorCode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.common.exception.GenericException;
import com.gjw.company.service.salestool.IBuildingSaleConfigService;
import com.gjw.entity.salestool.BuildingInfo;
import com.gjw.entity.salestool.BuildingSaleConfig;

@Component("buildingSaleConfigServiceImpl")
public class BuildingSaleConfigServiceImpl extends AbstractServiceImpl implements IBuildingSaleConfigService {

    @Override
    @Transactional(readOnly = true)
    public List<BuildingSaleConfig> pageBuildingSaleConfig(BuildingSaleConfig buildingSaleConfig) {
        List<BuildingSaleConfig> list = super.getBuildingSaleConfigDAO().pageBuildingSaleConfig(buildingSaleConfig);
        for (BuildingSaleConfig item : list) {
            Hibernate.initialize(item.getAerialView());
            Hibernate.initialize(item.getBuilding());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(BuildingSaleConfig buildingSaleConfig) {
        return super.getBuildingSaleConfigDAO().count(buildingSaleConfig);
    }

    @Override
    @Transactional
    public long create(BuildingSaleConfig buildingSaleConfig) {
        return super.getBuildingSaleConfigDAO().create(buildingSaleConfig);
    }

    @Override
    @Transactional
    public boolean update(BuildingSaleConfig buildingSaleConfig) {
        BuildingSaleConfig oldObj = queryByID(buildingSaleConfig.getId());
        BuildingInfo buildingInfo = new BuildingInfo();
        buildingInfo.setBuildingSaleConfig(buildingSaleConfig);
        long count = super.getBuildingInfoDAO().count(buildingInfo);
        if (oldObj.getBuilding().getId().longValue() != buildingSaleConfig.getBuilding().getId().longValue() && count > 0){
            throw new ErrorCodeException(BusinessErrorCode.BuildingSaleConfig_100, "修改楼盘前请删除楼号信息");
        }
        oldObj.setAerialView(buildingSaleConfig.getAerialView());
        oldObj.setBuilding(buildingSaleConfig.getBuilding());
        if (buildingSaleConfig.getInvalid() != null){
            oldObj.setInvalid(buildingSaleConfig.getInvalid());
        }
        if (buildingSaleConfig.getStatus() != null){
            oldObj.setStatus(buildingSaleConfig.getStatus());
        }
        return super.getBuildingSaleConfigDAO().update(oldObj);
    }
	
	@Override
    @Transactional(readOnly = true)
    public BuildingSaleConfig queryByID(long id) {
        BuildingSaleConfig buildingSaleConfig = super.getBuildingSaleConfigDAO().queryByID(id);
        Hibernate.initialize(buildingSaleConfig.getBuilding());
        Hibernate.initialize(buildingSaleConfig.getAerialView());
        return buildingSaleConfig;
    }
    
    @Override
    @Transactional
    public boolean deletes(String ids) {
        return super.getBuildingSaleConfigDAO().deletes(ids);
    }
}

