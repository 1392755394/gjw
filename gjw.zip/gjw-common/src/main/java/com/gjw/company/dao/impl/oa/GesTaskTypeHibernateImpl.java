package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.oa.IGesTaskTypeDAO;
import com.gjw.entity.oa.GesTaskType;

@Component("gesTaskTypeHibernateImpl")
public class GesTaskTypeHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesTaskTypeDAO {

	@Override
	protected Class<?> getEntityClass() {
		return GesTaskType.class;
	}

	/**
	 * 根据任务项目类别查询任务项目类型
	 * @param type
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskType> listTaskTypeByType(GesTaskType taskType) {
		String hql="from GesTaskType where invalid=? and type=? AND id != 5 order by id asc";
		List<Object> param=new ArrayList<Object>();
		param.add(taskType.getInvalid());
		param.add(taskType.getType());
		return (List<GesTaskType>) super.findByListCallBack(hql, null, param, null);
	}

	/**
	 * 根据任务类别和父节点id 查询任务项目类型
	 * @param taskType
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskType> listTaskTypeByTypeAndParentId(GesTaskType taskType) {
		String hql="from GesTaskType t where t.invalid=? and t.taskType.id=? and type=? and id!=5 order by id asc";
		List<Object> param=new ArrayList<Object>();
		param.add(taskType.getInvalid());
		param.add(taskType.getTaskType().getId());
		param.add(taskType.getType());
		return (List<GesTaskType>) super.findByListCallBack(hql, null, param, null);
	}

    @Override
    public GesTaskType getTaskTypeById(long id) {
        return (GesTaskType) super.get(id);
    }
	
	

}
