package com.gjw.company.service.modelling;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.modelling.Modelling;

/**
 * 
* @Description: 造型库service接口
* @author  zhaoyonglian
* @date 2016年1月9日 下午3:25:04
*
 */
public interface IModellingService extends IService {


    /**
     * 
    * @Description  造型库列表
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:54:07
     */
    public List<Modelling> pageByCondition(Modelling modelling);

    /**
     * 
    * @Description  总数
    * @param matterCriteria
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:54:33
     */
    public Long countByCondition(Modelling modelling);

    /**
     * 
    * @Description  获取详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:55:17
     */
    public Modelling queryByID(Long id);
    
    /**
     * 
    * @Description  增加造型库
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月12日 下午3:57:11
     */
    public boolean create(Modelling modelling);

    /**
     * 
    * @Description  更新
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:13
     */
    public boolean update(Modelling modelling);

    /**
     * 
    * @Description  批量删除
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:29
     */
    public boolean delBatchByID(String ids);
}
