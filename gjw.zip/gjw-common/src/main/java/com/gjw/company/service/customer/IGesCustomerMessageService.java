package com.gjw.company.service.customer;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.customer.GesCustomerMessage;

public interface IGesCustomerMessageService extends IService{
    public GesCustomerMessage listByID(Long id);

    public boolean updateGesCustomerMessage(GesCustomerMessage model);

    public boolean createGesCustomerMessage(GesCustomerMessage model);
    
    public List<GesCustomerMessage> listByGesCustomerMessage(GesCustomerMessage model);
    
    public long count(GesCustomerMessage model);
}
