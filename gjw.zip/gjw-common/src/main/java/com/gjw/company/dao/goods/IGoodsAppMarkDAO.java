package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.GoodsAppMark;
import com.gjw.entity.goods.GoodsMark;

/**
 * 
 * @Description: 产品包APP锚点
 * @author guojianbin   
 * @date 2016年04月20日 
 *
 */
public interface IGoodsAppMarkDAO extends IDAO {
    
    /**
     * 
    * @Description  修改关系
    * @param mark
    * @return
    * @author guojianbin   
    * @date 2016年04月20日 
     */
    public boolean update(GoodsAppMark mark);
    
    /**
     * 
    * @Description  新增产品包物料关系
    * @param goodsMatter
    * @return
    * @author guojianbin   
    * @date 2016年04月20日 
     */
    public long create(GoodsAppMark mark);


}
