package com.gjw.company.service.impl.salestool;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.IBuildingInfoGoodsService;
import com.gjw.entity.salestool.BuildingInfo;
import com.gjw.entity.salestool.BuildingInfoGoods;

@Component("buildingInfoGoodsServiceImpl")
public class BuildingInfoGoodsServiceImpl extends AbstractServiceImpl implements IBuildingInfoGoodsService {

    @Override
    @Transactional(readOnly = true)
    public List<BuildingInfoGoods> pageBuildingInfoGoods(BuildingInfoGoods buildingInfoGoods) {
        List<BuildingInfoGoods> list = super.getBuildingInfoGoodsDAO().pageBuildingInfoGoods(buildingInfoGoods);
        for (BuildingInfoGoods item : list) {
            Hibernate.initialize(item.getGoods().getStyle());
            Hibernate.initialize(item.getGoods().getHouse());
            if (null != item.getGoods().getHouse()) {
                Hibernate.initialize(item.getGoods().getHouse().getBuilding());
            }
            Hibernate.initialize(item.getGoods().getHouseType());
            Hibernate.initialize(item.getGoods().getPhoto());
            Hibernate.initialize(item.getGoods().getFloorPlanImage());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(BuildingInfoGoods buildingInfoGoods) {
        return super.getBuildingInfoGoodsDAO().count(buildingInfoGoods);
    }

    @Override
    @Transactional
    public long create(BuildingInfoGoods buildingInfoGoods) {
        long id =  super.getBuildingInfoGoodsDAO().create(buildingInfoGoods);
        buildingInfoGoods.setId(id);
        updateBuildingInfo(buildingInfoGoods);
        return id;
    }

    @Override
    @Transactional
    public boolean update(BuildingInfoGoods buildingInfoGoods) {
        boolean result = super.getBuildingInfoGoodsDAO().update(buildingInfoGoods);
        updateBuildingInfo(buildingInfoGoods);
        return result;
    }
	
	@Override
    @Transactional(readOnly = true)
    public BuildingInfoGoods queryByID(Long id) {
        BuildingInfoGoods buildingInfoGoods = super.getBuildingInfoGoodsDAO().queryByID(id);
        return buildingInfoGoods;
    }
	
	private void updateBuildingInfo(BuildingInfoGoods buildingInfoGoods){
	    long count = count(buildingInfoGoods);
	    long id = buildingInfoGoods.getBuildingInfo().getId();
        BuildingInfo  buildingInfo = super.getBuildingInfoDAO().queryByID(id);
	    if (count > 0){
	        buildingInfo.setContainsGoods(true);
	        
	    } else if (count == 0){
	        buildingInfo.setContainsGoods(false);
	    }
	    super.getBuildingInfoDAO().update(buildingInfo);
	}
    
    @Override
    @Transactional
    public boolean deletes(String ids) {
        boolean bool =  super.getBuildingInfoGoodsDAO().deletes(ids);
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            BuildingInfoGoods buildingInfoGoods = super.getBuildingInfoGoodsDAO().queryByID(Long.parseLong(id));
            Hibernate.initialize(buildingInfoGoods.getBuildingInfo());
            BuildingInfoGoods buildingInfoGoodsObj = new BuildingInfoGoods();
            buildingInfoGoodsObj.setBuildingInfo(buildingInfoGoods.getBuildingInfo());
            updateBuildingInfo(buildingInfoGoodsObj);
        }
        return bool;
    }
    
}

