package com.gjw.company.dao.cityoperator;


import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperatorContract;

public interface IGesCityOperatorContractDAO extends IDAO{
    public GesCityOperatorContract listByID(Long id);

    public boolean updateGesCityOperatorContract(GesCityOperatorContract model);

    public boolean createGesCityOperatorContract(GesCityOperatorContract model);
    
    public long count(GesCityOperatorContract model);
    
    public List<GesCityOperatorContract> listByGesCityOperatorContract(GesCityOperatorContract model);
}
