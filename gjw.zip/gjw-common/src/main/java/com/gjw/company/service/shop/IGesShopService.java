package com.gjw.company.service.shop;

import java.util.List;

import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.entity.shop.GesShopOrderFeedback;
import com.gjw.entity.shop.GesShopPhotoItem;
import com.gjw.entity.shop.GesShopWorker;
import com.gjw.vo.GesShopVO;

public interface IGesShopService {
    // 4S店
    public GesShop listByID(Long id);

    public boolean updateGesShop(GesShop model);

    public boolean createGesShop(GesShop model);

    public long count(GesShop model);

    public List<GesShop> listByGesShop(GesShop model);
    
    public List<GesShopVO> listByGesShop4Export(GesShop model);

    // 4S店与产品包
    public GesShopGoodsItem listByGesShopGoodsItemID(Long id);

    public boolean updateGesShopGoodsItem(GesShopGoodsItem model);

    public boolean deleteGesShopGoodsItem(String ids);

    public boolean createGesShopGoodsItem(String ids, Long shopId);

    public long gesShopGoodsItemCount(GesShopGoodsItem model);

    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model);

    public GesShopGoodsItem listByShopAndGood(GesShopGoodsItem model);

    public String getShopGoodsIds(GesShopGoodsItem model);

    // 4S店与订单
    public GesShopOrderFeedback listByGesShopOrderFeedbackID(Long id);

    public boolean updateGesShopOrderFeedback(GesShopOrderFeedback model);

    public boolean createGesShopOrderFeedback(GesShopOrderFeedback model);

    public long gesShopOrderFeedbackCount(GesShopOrderFeedback model);

    public List<GesShopOrderFeedback> listByGesShopOrderFeedback(GesShopOrderFeedback model);

    // 4S店与照片
    public GesShopPhotoItem listByGesShopPhotoItemID(Long id);

    public boolean updateGesShopPhotoItem(GesShopPhotoItem model);

    public boolean deleteGesShopPhotoItem(GesShopPhotoItem model);

    public boolean createGesShopPhotoItem(GesShopPhotoItem model);

    public long GesShopPhotoItemCount(GesShopPhotoItem model);

    public List<GesShopPhotoItem> listByGesShopPhotoItem(GesShopPhotoItem model);

    // 4S店与员工
    public GesShopWorker listByGesShopWorkerID(Long id);

    public boolean updateGesShopWorker(GesShopWorker model);

    public boolean delelteGesShopWorker(String ids);

    public boolean createGesShopWorker(GesShopWorker model);

    public long gesShopWorkerCount(GesShopWorker model);

    public List<GesShopWorker> listByGesShopWorker(GesShopWorker model);

    /**
     * 查看产品4s店列表
     * 
     * @Description
     * @param goods
     *            产品
     * @return 4s店列表
     * @author guojianbin
     * @date 2016年1月30日
     */
    public List<GesShop> listShopByGoods(Goods goods);

    /**
     * 根据用户id获取shop city id
     * 
     * @Description
     * @param id
     * @author gwb
     * @date 2016年4月7日 上午11:44:41
     */
    public GesShop getShopCityIdByUserId(Long id);

}
