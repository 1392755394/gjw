package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.vo.GesSoMatterVO;

/**
 * <P>
 * 构家网---- 产品包销售订单关联的物料(采购清单)实体
 * <P>
 * 城运商，4s店发起采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月30日 下午2:17:38
 * 
 */
public interface IGesSoMatterItemDAO extends IDAO {

    /**
     * 分页查询总数
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2015年12月30日 下午2:32:42
     */
    public Long count(GesSoMatterVO soMatter, List<GesSoMatterItem> listSoMatter);

    /**
     * 分页查询
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2015年12月30日 下午2:32:57
     */
    public List<GesSoMatterItem> pageSoMatter(GesSoMatterVO soMatter, List<GesSoMatterItem> listSoMatter,
            Integer start, Integer pageSize);

    public List<GesSoMatterItem> ListSoMatter(GesSoMatterVO soMatter);

    /**
     * 修改采购清单数量
     * 
     * @Description
     * @param poDetail
     * @author gwb
     * @date 2015年12月31日 下午2:26:29
     */
    public void updateGesSoMatterItem(GesPoDetail poDetail);

    /**
     * 库存管理---发货清单---发货---分步查询
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2016年1月5日 下午3:08:20
     */
    public List<GesSoMatterItem> ListSoMatterByGesGesRdRecords(GesSoMatterVO soMatter);

    /**
     * 根据rdRecords 修改 STOCK_OUT_QUANTITY
     * 
     * @Description
     * @param rdRecords
     * @author gwb
     * @date 2016年1月6日 上午10:06:50
     */
    public void updateGesSoMatterItemByrdRecords(GesRdRecords rdRecords);

}
