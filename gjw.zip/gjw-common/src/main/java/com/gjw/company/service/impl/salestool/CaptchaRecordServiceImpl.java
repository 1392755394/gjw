package com.gjw.company.service.impl.salestool;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.ICaptchRecoredService;
import com.gjw.entity.salestool.CaptchaRecord;
import com.gjw.utils.StringUtil;

@Service("captchaRecordServiceImpl")
public class CaptchaRecordServiceImpl extends AbstractServiceImpl implements ICaptchRecoredService{

    @Override
    @Transactional(readOnly=true)
    public CaptchaRecord listByID(Long id) {
        // TODO Auto-generated method stub
        CaptchaRecord model=super.getCaptchaRecordDAOHibernateImpl().listByID(id);
        return model;
    }

    @Override
    @Transactional()
    public boolean updateCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        CaptchaRecord modelFlag=super.getCaptchaRecordDAOHibernateImpl().listByID(model.getId());
        StringUtil.copyProperties(model, modelFlag);
        return super.getCaptchaRecordDAOHibernateImpl().updateCaptchaRecord(modelFlag);
    }

    @Override
    @Transactional()
    public boolean createCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return super.getCaptchaRecordDAOHibernateImpl().createCaptchaRecord(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long count(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    @Transactional(readOnly=true)
    public List<CaptchaRecord> listByCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return null;
    }

}
