package com.gjw.company.service.impl.oa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.constants.TaskConstant;
import com.gjw.common.constants.TaskStatusEnums;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesAttachmentDAO;
import com.gjw.company.dao.oa.IGesCommunicationDAO;
import com.gjw.company.dao.oa.IGesProjectTaskDAO;
import com.gjw.company.dao.oa.IGesTaskParticipantDAO;
import com.gjw.company.service.oa.IGesProjectTaskService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.oa.GesCommunication;
import com.gjw.entity.oa.GesPmModel;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.entity.oa.GesTaskType;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.event.base.BaseEventPublisher;
import com.gjw.event.oa.GesTaskParticipantEvent;
import com.gjw.utils.DateOperation;
import com.gjw.utils.StringUtil;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesCommunicationVO;
import com.gjw.vo.oa.GesProjectTaskQueryVO;
import com.gjw.vo.oa.GesProjectTaskVO;
import com.gjw.vo.oa.UserVO;

@Component("gesProjectTaskServiceImpl")
public class GesProjectTaskServiceImpl extends AbstractServiceImpl implements IGesProjectTaskService {
	
	private static final Logger log=LoggerFactory.getLogger(GesProjectTaskServiceImpl.class);
	
	@Resource(name="gesProjectTaskHibernateImpl")
	private IGesProjectTaskDAO gesProjectTaskDAO;
	
	@Resource(name="gesTaskParticipantHibernateImpl")
	private IGesTaskParticipantDAO gesTaskParticipantDAO;
	
	@Resource(name="gesAttachmentHibernateImpl")
	private IGesAttachmentDAO gesAttachmentDAO;
	
	@Resource(name="gesCommunicationHibernateImpl")
	private IGesCommunicationDAO gesCommunicationDAO;

    @Resource(name="baseEventPublisher")
    private BaseEventPublisher baseEventPublisher;
	
	public IGesProjectTaskDAO getGesProjectTaskDAO() {
		return gesProjectTaskDAO;
	}

	public void setGesProjectTaskDAO(IGesProjectTaskDAO gesProjectTaskDAO) {
		this.gesProjectTaskDAO = gesProjectTaskDAO;
	}

	public IGesTaskParticipantDAO getGesTaskParticipantDAO() {
		return gesTaskParticipantDAO;
	}

	public void setGesTaskParticipantDAO(
			IGesTaskParticipantDAO gesTaskParticipantDAO) {
		this.gesTaskParticipantDAO = gesTaskParticipantDAO;
	}

	public IGesAttachmentDAO getGesAttachmentDAO() {
		return gesAttachmentDAO;
	}

	public void setGesAttachmentDAO(IGesAttachmentDAO gesAttachmentDAO) {
		this.gesAttachmentDAO = gesAttachmentDAO;
	}

	public IGesCommunicationDAO getGesCommunicationDAO() {
		return gesCommunicationDAO;
	}

	public void setGesCommunicationDAO(IGesCommunicationDAO gesCommunicationDAO) {
		this.gesCommunicationDAO = gesCommunicationDAO;
	}

	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> queryAllProjectTaskCommunicationByUserId(
			GesProjectTaskQueryVO gesProjectTaskVO,UserInfoGES gesUser) {
		Map<String, Object> map=new HashMap<String, Object>();
		User user=new User();
		user.setId(gesUser.getId());
		gesProjectTaskVO.setUser(user);
		//计算从哪一条数组开始分页查询数据
		gesProjectTaskVO.setStart(gesProjectTaskVO.getNumber()/gesProjectTaskVO.getPageSize()+1);
		//获取多少条数据
		gesProjectTaskVO.setPageSize(gesProjectTaskVO.getPageSize());
		
		List<GesProjectTaskQueryVO> list=getGesProjectTaskDAO().queryAllProjectTaskCommunicationByUserId(gesProjectTaskVO);
		Long total=getGesProjectTaskDAO().countAllProjectTaskCommunicationByUserId(gesProjectTaskVO);
		map.put("total", total);
		map.put("rows", list);
		return map;
	}

	@Override
	@Transactional(readOnly=true)
	public Long countAllProjectTaskCommunicationByUserId(
			GesProjectTaskQueryVO gesProjectTaskVO) {
		User user=new User();
		user.setId(1l);
		gesProjectTaskVO.setUser(user);
		return getGesProjectTaskDAO().countAllProjectTaskCommunicationByUserId(gesProjectTaskVO);
	}

	/**
	 * 添加任务和项目
	 */
	@Override
	@Transactional
	public void createProjectTask(GesProjectTaskVO gesProjectTaskVO,UserVO gesUser,GesProjectTask gesProjectTask) {
		User tempUser=new User();
		tempUser.setId(gesUser.getId());
		gesProjectTask.setFounder(tempUser);
		//设置城运商和4S店
		if(GesCommonConstants.ORG_TYPE_CITY_OPERATOR.equals(gesUser.getOrgType())){
			GesCityOperator tempOperator=new GesCityOperator();
			tempOperator.setId(gesUser.getOrgId());
			gesProjectTask.setOperator(tempOperator);
		}else if(GesCommonConstants.ORG_TYPE_SHOP.equals(gesUser.getOrgType())){
			GesShop tempShop=new GesShop();
			tempShop.setId(gesUser.getOrgId());
			gesProjectTask.setShop(tempShop);
			//查询4s店所属的城运商的id
			GesShop shop=getGesShopDAO().listByID(gesUser.getOrgId());
			GesCityOperator tempOperator=new GesCityOperator();
			tempOperator.setId(shop.getOperator().getId());
			gesProjectTask.setOperator(tempOperator);
		}
		//未延期
		gesProjectTask.setPostpone(TaskConstant.DELAY_NO);
		//项目是否验收，设为否，未验收
		gesProjectTask.setCheckStatus(TaskConstant.CHECK_STATUS_NO);
		//设置项目或者任务的状态 未开始
		gesProjectTask.setTaskStatus(TaskStatusEnums.NOTSTARTED.getCode());
		gesProjectTask.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
		//保存任务
		getGesProjectTaskDAO().addGesProjectTask(gesProjectTask);
		log.info("任务项目添加成功："+gesProjectTask.getId());
		gesProjectTaskVO.setId(gesProjectTask.getId());
		gesProjectTaskVO.setDifference(gesProjectTask.getDifference());
		//生成参与人list
		List<GesTaskParticipant> list=generateParticipantList(gesProjectTaskVO,gesUser);
		//批量插入任务的参与成员信息
		int num=getGesTaskParticipantDAO().createGesTaskParticipant(list);
		log.info("需要插入的条数为："+list.size()+",实际插入的条数为："+num);
		if(StringUtil.notEmpty(gesProjectTaskVO.getAttachmentIds())&&gesProjectTaskVO.getAttachmentIds().split(",").length>0){
			String[] ids=gesProjectTaskVO.getAttachmentIds().split(",");
			List<Long> idList=new ArrayList<Long>();
			for(String id:ids){
				idList.add(Long.parseLong(id));
			}
			//更新附件表，修改附件关联的节点id
			Map<String,Object> attachment = new HashMap<String,Object>();
			//附件所属节点的id设置为交流ID
			attachment.put("relationId", gesProjectTask.getId());
			//附件所属节点的类型:任务记录
			attachment.put("relationType", TaskConstant.RELATION_TYPE_TASK);
			//附件ID列表，用于批量更新附件所属节点的id
			attachment.put("attachmentIds",idList );
			//批量更新附件所属节点的id
			getGesAttachmentDAO().updateAttachmentRelation(attachment);		
		}
		//添加一条交流信息
		GesCommunication communication=new GesCommunication();
		communication.setUser(tempUser);
		if(gesProjectTask.getDifference()==0){
			communication.setContent("项目已创建");	
		}else{
			communication.setContent("任务已创建");			
		}
		communication.setTask(gesProjectTask);
		GesCommunication tempGc=new GesCommunication();
		tempGc.setId(0l);
		communication.setParent(tempGc);
		communication.setRoot(tempGc);
		getGesCommunicationDAO().createCommunication(communication);
		//此处更新任务表中的交流id
		gesProjectTask.setCommunication(communication);
		getGesProjectTaskDAO().updateGesProjectTaskCommunicationId(gesProjectTask);
		//更新用户的最新交流id
		GesTaskParticipant taskParticipant=new GesTaskParticipant();
		taskParticipant.setCommunication(communication);
		taskParticipant.setParticipant(gesProjectTask.getFounder());
		taskParticipant.setTask(gesProjectTask);
		getGesTaskParticipantDAO().updateParticipantCommunicationId(taskParticipant);
		
		//参与人中去除创建者
		for(GesTaskParticipant tp:list){
			if(tp.getParticipant().getId().longValue()==gesUser.getId().longValue()){
				list.remove(tp);
				break;
			}
		}
		
		//处理任务
		dealReturnTaskInfo(gesProjectTaskVO, gesUser, gesProjectTask);
		
        // 发布添加成员事件
        for (GesTaskParticipant p : list) {
            GesTaskParticipantEvent event = new GesTaskParticipantEvent(p);
            event.setOprateName(gesUser.getRealName());
            event.setProjectTask(gesProjectTask);
            event.setTaskNum(0l);
            baseEventPublisher.publishEvent(event);
        }
		
	}
		
	public void dealReturnTaskInfo(GesProjectTaskVO gesProjectTaskVO,UserVO gesUser,GesProjectTask gesProjectTask){
		long day=1000*60*60*24;
		gesProjectTaskVO.setPlanStartDate(gesProjectTask.getPlanStartDate());
		gesProjectTaskVO.setPlanEndDate(gesProjectTask.getPlanEndDate());
		gesProjectTaskVO.setChatContent(gesProjectTask.getCommunication().getContent());
		gesProjectTaskVO.setContent(gesProjectTask.getContent());
		gesProjectTaskVO.setLatestTime(gesProjectTask.getCommunication().getCreatedDatetime());
		gesProjectTaskVO.setIsUrgency(gesProjectTask.getIsUrgency());
		//查询交流人的真实姓名和头像
		UserVO user=getGesProjectTaskDAO().queryUserInfoByUserId(gesUser.getId());
		if(user!=null){
			gesProjectTaskVO.setUserName(user.getRealName());
			gesProjectTaskVO.setHeadPortrait(user.getHeadPortrait());
		}
		dealTaskTime(gesUser.getRealName(), day, gesProjectTaskVO);
	}
	
	/**
	 * 任务参与人处理、去重、创建人识别、组装list
	 * @param projectTaskVO
	 * @return
	 */
	public List<GesTaskParticipant> generateParticipantList(GesProjectTaskVO projectTaskVO,UserVO gesUser){
		//创建成员list，参与人容器
		List<GesTaskParticipant> list=new ArrayList<GesTaskParticipant>();
		//Map,参与人id容器
		Map<Long, Integer> map=new HashMap<Long,Integer>();
		//判断负责人id字符串是否为空
		if(projectTaskVO.getLeader()!=null&&projectTaskVO.getLeader().length()>0){
			//分割负责人字符串
			String[] ids=projectTaskVO.getLeader().split(",");
			//循环负责人id
			for(String id:ids){
				log.info("负责人的id+"+id);
				//填充负责人属性，加入list容器
				list=assembleEntity(list,map,projectTaskVO,Long.parseLong(id),TaskConstant.PARTICIPANT_TYPE_PRINCIPAL,gesUser);
			}
		}
		//判断参与人id字符串是否为空
		if(projectTaskVO.getParticipant()!=null&&projectTaskVO.getParticipant().length()>0){
			//分割参与人字符串
			String[] ids=projectTaskVO.getParticipant().split(",");
			//循环参与人id
			for(String id:ids){
				log.info("参与人的+"+id);
				//判断参与人是否已在负责人中存在，若存在则跳过，继续下一个
				if(map.containsKey(Long.parseLong(id))){
					log.info("已添加过此id+"+id);
					continue;
				}
				//填充参与人属性，加入list容器                             
				list=assembleEntity(list,map,projectTaskVO,Long.parseLong(id),TaskConstant.PARTICIPANT_TYPE_PARTICIPANT,gesUser);
			}
		}
		//判断创建人是否已经存在，不存在，加入到list中，存在，结束
		//用户id修改
		if(!map.containsKey(gesUser.getId())){
			//用户id修改
			list=assembleEntity(list,map,projectTaskVO,gesUser.getId(),TaskConstant.PARTICIPANT_TYPE_PARTICIPANT,gesUser);
		}
		return list;
	}

	/**
	 * 组装参与人的信息，加入到容器中，并记录参与人的id
	 * @param list
	 * @param map
	 * @param projectTaskVO
	 * @param userId
	 * @param userType
	 * @return
	 */
	public List<GesTaskParticipant> assembleEntity(List<GesTaskParticipant> list,Map<Long, Integer> map,
			GesProjectTaskVO projectTaskVO,Long userId,Integer userType,UserVO gesUser){
		//创建实体
		GesTaskParticipant taskParticipant=new GesTaskParticipant();
		//填充属性值
		GesProjectTask gesProjectTask=new GesProjectTask();
		gesProjectTask.setId(projectTaskVO.getId());
		taskParticipant.setTask(gesProjectTask);
		User user=new User();
		user.setId(userId);
		taskParticipant.setParticipant(user);
		taskParticipant.setUser(user);
		taskParticipant.setParticipantType(userType);
		//判断当前成员的id是否是创建人
		//用户id修改
		if(gesUser.getId().longValue()==userId){
			taskParticipant.setIsCreator(true);	
			map.put(userId, 1);
		}else{
			taskParticipant.setIsCreator(false);
			map.put(userId, 0);
		}
		taskParticipant.setDifference(projectTaskVO.getDifference());
		taskParticipant.setIsHandle(0);
		//设置交流的id
		GesCommunication gesCommunication=new GesCommunication();
		gesCommunication.setId(0l);
		taskParticipant.setCommunication(gesCommunication);
		taskParticipant.setInvalid(TaskConstant.DEL_FLAG_NO);
		//加入容器中
		list.add(taskParticipant);
		return list;
	}

	/**
	 * 根据条件查询任务的列表（两种情况）
	 * 1、权限permission 为1的能够看到他所属组织(构家网、城运商、4S店)的所有任务
	 * 2、普通登录用户只能看到他是参与者的任务
	 * @param projectTask 查询条件
	 * @return 
	 */
	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> queryTaskByFeature(
			GesProjectTaskQueryVO gesProjectTaskVO, UserVO gesUser) {
		//返回的map
		Map<String, Object> map=new HashMap<String, Object>();
		//返回的数据
		List<GesProjectTaskQueryVO> list=null;
		//数据总数
		long total=0;
		//登录用户的id
		User tempUser=new User();
		tempUser.setId(gesUser.getId());
		gesProjectTaskVO.setUser(tempUser);
		//设置登录人所属的组织类型
		gesProjectTaskVO.setOrgType(gesUser.getOrgType());
		//判断登录人所属的组织类型
		if(GesCommonConstants.ORG_TYPE_CITY_OPERATOR.equals(gesUser.getOrgType())){
			gesProjectTaskVO.setOperatorId(gesUser.getOrgId());
			log.info("组织id"+gesUser.getOrgId());
		}else if(GesCommonConstants.ORG_TYPE_SHOP.equals(gesUser.getOrgType())){
			gesProjectTaskVO.setShopId(gesUser.getOrgId());
			log.info("组织id"+gesUser.getOrgId());
		}
		//计算从哪一条数组开始分页查询数据
		gesProjectTaskVO.setStart(gesProjectTaskVO.getNumber()/gesProjectTaskVO.getPageSize()+1);
		//获取多少条数据
		gesProjectTaskVO.setPageSize(gesProjectTaskVO.getPageSize());
		//获取登录用户的permission
		int permission=gesUser.getPermission();
		log.info("权限permission"+permission);
		//判断当前登录的用户的权限，即判断permission字段是否为1，为1，则能看到所属组织(构家网、城运商、4S店)的所有任务，否则只显示所参与的任务
		if(permission==1){ //领导或者构家网
			//判断查询的是项目还是任务
			if(gesProjectTaskVO.getDifference()==0){
				if(gesProjectTaskVO.getMemberType()!=0 &&gesProjectTaskVO.getMemberType()!=1){
					log.info("permission为1，查询全部项目信息"+gesProjectTaskVO.getMemberType());
					//是项目，根据条件分页查询所属组织的所有的项目
					list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO, 1);
					//任务项目总数
					total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 1);
				}else{
					//是项目，根据条件分页查询所参与的所有的项目
					list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO,2);
					//任务项目总数
					total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 2);
				}
			}else{
				if(gesProjectTaskVO.getIsDeal()!=0&&gesProjectTaskVO.getIsDeal()!=1){
					log.info("permission为1，查询全部任务信息"+gesProjectTaskVO.getIsDeal());
					//是任务，根据条件分页查询所属组织的所有的任务
					list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO, 3);
					//任务项目总数
					total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO,3);
				}else{
					//是任务，根据条件分页查询所参与的所有的任务
					list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO, 4);
					//任务项目总数
					total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 4);
				}
			}			
		}else{ //普通用户
			//判断查询的是项目还是任务
			if(gesProjectTaskVO.getDifference()==0){
				//是项目，根据条件分页查询所参与的所有的项目
				list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO,2);
				//任务项目总数
				total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 2);
			}else{
				//是任务，根据条件分页查询所参与的所有的任务
				list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO,4);
				//任务项目总数
				total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 4);
			}				
		}
		map.put("rows", list);
		map.put("total", total);
		
		return map;
	}

	/**
	 * 根据任务id获取任务的详情
	 */
	@Override
	@Transactional(readOnly=true)
	public GesProjectTaskVO queryTaskById(Long taskId) {
		log.info("------------"+taskId);
		GesProjectTaskVO gesProjectTaskVO=getGesProjectTaskDAO().queryTaskById(taskId);
		log.info("++++++++++++++++++++gesProjectTaskVO="+gesProjectTaskVO+",-----taskId="+taskId);
		if(gesProjectTaskVO.getParentId()!=null && gesProjectTaskVO.getParentId()>0){
			//查询父任务
			GesProjectTaskVO tempProjectTask=getGesProjectTaskDAO().queryTaskById(gesProjectTaskVO.getParentId());
			gesProjectTaskVO.setChatContent(tempProjectTask.getContent());
		}
		
		return gesProjectTaskVO;
	}

    @Override
    @Transactional
    public void createConstructionProject(GesProjectTaskVO gesProjectTaskVO, UserVO gesUser) {
        // 项目模版ID
        long pmModeID = 0;
        // 项目
        GesProjectTask project = null;

        // 获取项目模版
        List<GesPmModel> pmModeList = super.getGesPmModelDAO().listAll();
        // 项目启动时间
        Date startDate = gesProjectTaskVO.getProjectStartDate();
        DateOperation dt = new DateOperation();

        // 获取登录用户，即创建人
        User tempUser=new User();
        tempUser.setId(gesUser.getId());
        // 获取订单信息:订单编号、产品包名、运营商ID、4S店ID
        GesOrder order = super.getGesOrderDAO().queryOrderByOrderId(gesProjectTaskVO.getOrderId());

        // 任务列表
        List<GesProjectTask> taskList = new ArrayList<GesProjectTask>();
        // 参与人列表
        List<GesTaskParticipant> peopleList = new ArrayList<GesTaskParticipant>();

        for (int i = 0; i < pmModeList.size(); i++) {
            GesProjectTask pm = new GesProjectTask();

            // 项目模版ID＝1时为项目，任务内容:订单编号+产品包名
            // 否则为任务,任务内容:项目模版的关键节点
            pmModeID = pmModeList.get(i).getId();
            if (pmModeID == 1) {
                pm.setContent(order.getCode() + order.getGoods().getName());
            } else {
                pm.setContent(pmModeList.get(i).getKeypoint());
            }
            
            // 获取登录用户，即创建人
            pm.setFounder(tempUser);
            // 从订单信息获取的运营商、4S店
            pm.setOperator(order.getOperator());
            pm.setShop(order.getShop());
            pm.setGesOrder(order);

            // 根据项目模版计算进度计划
            pm.setPlanEndDate(dt.dateOperation(startDate, pmModeList.get(i).getNum()));
            pm.setPlanStartDate(dt.dateOperation(startDate, pmModeList.get(i).getTimelimit()));

            // 是否延期:未延期
            pm.setPostpone(TaskConstant.DELAY_NO);
            // 项目启动时间
            pm.setProjectStartDate(startDate);
            // 项目是否验收，设为否，未验收
            pm.setCheckStatus(TaskConstant.CHECK_STATUS_NO);
            pm.setPmModel(pmModeList.get(i));
            // 任务类型固定为施工项目
            GesTaskType  taskType=new GesTaskType();
            taskType.setId(TaskConstant.TASK_TYPE_CONSTRUCTION);
            pm.setTaskType(taskType);
            // 是否紧急:不紧急
            pm.setIsUrgency(TaskConstant.IS_URGENCY_NO);
            // 任务状态：进行中
            pm.setTaskStatus(TaskStatusEnums.GOING.getCode());
            // 项目、任务区分：
            // 项目模版ID＝1时为项目，创建项目及交流信息
            // 否则为任务,后面批量创建
            if (pmModeID == 1) {
                pm.setDifference(TaskConstant.TASK_TYPE_PROJECT);
                pm.setParent(null);
                // 创建项目
                getGesProjectTaskDAO().addGesProjectTask(pm);
                // 记录项目，用于关联子任务、参与人、交流
                project = pm;
            } else {
                pm.setDifference(TaskConstant.TASK_TYPE_TASK);
                // 父任务ID
                pm.setParent(project);
                // 任务列表
                taskList.add(pm);
            }

            pm = null;
        }

        // 批量创建任务
        getGesProjectTaskDAO().batchAddProjectTask(taskList);

        // 生成参与人list
        gesProjectTaskVO.setId(project.getId());
        gesProjectTaskVO.setDifference(TaskConstant.TASK_TYPE_PROJECT);
        peopleList = generateParticipantList(gesProjectTaskVO, gesUser);

        // 以下保存参与人数据
        for (int i = 0; i < taskList.size(); i++) {
            List<GesTaskParticipant> list = new ArrayList<GesTaskParticipant>();
            gesProjectTaskVO.setId(taskList.get(i).getId());
            gesProjectTaskVO.setDifference(TaskConstant.TASK_TYPE_TASK);
            list = generateParticipantList(gesProjectTaskVO, gesUser);
            peopleList.addAll(list);
            list = null;
        }
        // 批量插入任务的参与成员信息
        getGesTaskParticipantDAO().createGesTaskParticipant(peopleList);

        // 以下添加交流信息
        GesCommunication communication = new GesCommunication();
        // 获取登录用户，即发言人
        communication.setUser(tempUser);
        communication.setContent("项目已创建");
        communication.setTask(project);
        // 父交流记录的id、根交流记录的id暂不使用，设为0
        communication.setParent(null);
        communication.setRoot(null);
        getGesCommunicationDAO().createCommunication(communication);
        //此处更新任务表中的交流id
        project.setCommunication(communication);
        getGesProjectTaskDAO().updateGesProjectTaskCommunicationId(project);
        for (int i = 0; i < taskList.size(); i++) {
            GesCommunication comm = new GesCommunication();
            // 获取登录用户，即发言人
            comm.setUser(tempUser);
            comm.setContent("任务已创建");
            comm.setTask(taskList.get(i));
            // 父交流记录的id、根交流记录的id暂不使用，设为0
            comm.setParent(null);
            comm.setRoot(null);
            getGesCommunicationDAO().createCommunication(comm);
            //此处更新任务表中的交流id
            taskList.get(i).setCommunication(comm);
            getGesProjectTaskDAO().updateGesProjectTaskCommunicationId(taskList.get(i));
            comm = null;
        }

        // 参与人中去除创建者
        List<GesTaskParticipant> list = new ArrayList<GesTaskParticipant>();
        for (GesTaskParticipant tp : peopleList) {
            if (tp.getParticipant().getId() != gesUser.getId()) {
                list.add(tp);
            }
        }
        
        // 更新订单的项目状态、项目启动时间
        order.setProjectStatus("started");
        order.setProjectStartup(gesProjectTaskVO.getProjectStartDate());
        super.getGesOrderDAO().updateProjectStatusByOrderId(order);
        
        // 发布添加成员事件
        for (GesTaskParticipant p : list) {
            if (p.getDifference() == 0) {
                GesTaskParticipantEvent event = new GesTaskParticipantEvent(p);
                event.setOprateName(gesUser.getRealName());
                event.setProjectTask(project);
                event.setTaskNum(getGesProjectTaskDAO().countGesProjectTaskByParentId(project.getId()));
                baseEventPublisher.publishEvent(event);
            }
        }
    }

    /**
     * 根据任务id查询该任务的阶段和子任务
     * @param taskId
     * @return
     */
	@Override
	@Transactional(readOnly=true)
	public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId) {
		List<GesProjectTaskVO> list=getGesProjectTaskDAO().queryTaskPeriodAndSubTaskByTaskId(taskId);
		long day=1000*60*60*24;
		dealTaskForTableAndGatte(list, day,0);
		return list;
	}
	
    @Override
    @Transactional(readOnly=true)
    public List<GesProjectTask> queryByOrderId(Long orderId) {
        return getGesProjectTaskDAO().queryByOrderId(orderId);
    }

    /**
     * 根据任务的id修改任务的状态
     */
	@Override
	@Transactional
	public boolean updateTaskStatusByTaskId(GesProjectTask projectTask) {
		//判断当前任务状态，若是进行中，则设置实际开工时间为当前时间，若为已完成，则设置实际完成时间为当前时间
		if(projectTask.getTaskStatus()==TaskStatusEnums.GOING.getCode()){
			projectTask.setActualStartDate(new Date());
		}
		if(projectTask.getTaskStatus()==TaskStatusEnums.FINISHED.getCode()){
			projectTask.setActualEndDate(new Date());
		}
		//获取修改前的状态
		GesProjectTask p=getGesProjectTaskDAO().queryAllTaskInfoByTaskId(projectTask.getId());
		String preStatus=taskStatusName(p.getTaskStatus());
		//添加一条交流信息
		GesCommunication communication=new GesCommunication();
		communication.setUser(projectTask.getUser());
		String nowStatus=taskStatusName(projectTask.getTaskStatus());
		if(p.getDifference()==0){
			communication.setContent("项目状态从\""+preStatus+"\"变更为\""+nowStatus+"\"");
		}else{
			communication.setContent("任务状态从\""+preStatus+"\"变更为\""+nowStatus+"\"");
		}
		GesProjectTask tempTask=new GesProjectTask();
		tempTask.setId(projectTask.getId());
		communication.setTask(tempTask);
		GesCommunication tempCommunication=new GesCommunication();
		tempCommunication.setId(0l);
		communication.setParent(tempCommunication);
		communication.setRoot(tempCommunication);
		getGesCommunicationDAO().createCommunication(communication);
		//此处更新任务表中的交流id
		projectTask.setCommunication(communication);
		getGesProjectTaskDAO().updateGesProjectTaskCommunicationId(projectTask);
		//更新用户的最新交流id
		GesTaskParticipant taskParticipant=new GesTaskParticipant();
		taskParticipant.setCommunication(communication);
		taskParticipant.setParticipant(projectTask.getUser());
		taskParticipant.setTask(projectTask);
		getGesTaskParticipantDAO().updateParticipantCommunicationId(taskParticipant);
		//更新任务的状态
		getGesProjectTaskDAO().updateTaskStatusByTaskId(projectTask);
		
		return true;
	}
	
	public String taskStatusName(int taskStatus){
		if(taskStatus==TaskStatusEnums.FINISHED.getCode()){	
			return "已完成";
		}else if(taskStatus==TaskStatusEnums.CANCELLED.getCode()){
			return "已取消";
		}else if(taskStatus==TaskStatusEnums.DELAYED.getCode()){
			return "已延期";
		}else if(taskStatus==TaskStatusEnums.GOING.getCode()){
			return "进行中";
		}else if(taskStatus==TaskStatusEnums.NOTSTARTED.getCode()){
			return "未开始";
		}
		return null;
	}

	/**
	 * 根据阶段的id查询该阶段下的任务列表
	 * @param periodId
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public List<GesProjectTaskVO> queryTaskByTaskPeriod(Long periodId,String realName,Long cuid) {
		List<GesProjectTaskVO> list=getGesProjectTaskDAO().queryTaskByTaskPeriod(periodId);
		//循环
		long day=1000*60*60*24;
		for(GesProjectTaskVO p:list){
			dealTaskTime(realName, day, p);
		}
		return list;
	}

	protected void dealTaskTime(String realName, long day, GesProjectTaskVO p) {
		p.setCheckUserName(realName);
		log.info("验收人真实姓名为："+p.getCheckUserName());
		log.info("任务计划开始时间："+p.getPlanStartDate()+",计划结束时间："+p.getPlanEndDate());
		if(p.getPlanEndDate()!=null&&p.getPlanEndDate()!=null){
			p.setTimeLimit((int)((p.getPlanEndDate().getTime()-p.getPlanStartDate().getTime())/day)+1);
		}
		if(p.getActualEndDate()!=null&&p.getPlanEndDate()!=null){
			long actual=p.getActualEndDate().getTime();
			long plan=p.getPlanEndDate().getTime();
			if(actual>plan){
				p.setActDelay((int)((actual-plan)/day));
			}else{
				p.setActDelay(0);
			}
		}
		if(p.getPlanEndDate()!=null){
			long plan=p.getPlanEndDate().getTime();
			long now=new Date().getTime();
			if(now>plan){
				p.setPostpone((int)((now-plan)/day));
			}else{
				p.setPostpone(0);
			}
		}
		if(p.getPlanStartDate()!=null&&p.getActualStartDate()!=null){
			long planStart=p.getPlanStartDate().getTime();
			long actualStart=p.getActualStartDate().getTime();
			p.setSetBack((int)((actualStart-planStart)/day));
		}
		if(p.getPlanStartDate()!=null){
			long planStart=p.getPlanStartDate().getTime();
			long now=new Date().getTime();
			p.setOffsetTime((int)((now-planStart)/day));
		}
	}

	/**
	 * 根据任务的id查询任务的基本信息及最新交流信息
	 */
	@Override
	public GesProjectTaskVO queryNewTaskByTaskId(Long taskId) {
		return getGesProjectTaskDAO().queryNewTaskByTaskId(taskId);
	}

	/**
	 * 施工管理项目
	 */
	@Override
	@Transactional(readOnly=true)
	public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskIdForPM(Long taskId) {
		List<GesProjectTaskVO> list=getGesPmModelDAO().queryTaskPeriodAndSubTaskByTaskId(taskId);
		long day=1000*60*60*24;
		dealTaskForTableAndGatte(list, day,1);
		return list;
	}

	/**
	 * 可以和上面的合并，目前没合并，后期合并
	 * @param list
	 * @param day
	 */
	protected void dealTaskForTableAndGatte(List<GesProjectTaskVO> list,long day,int type) {
		for(GesProjectTaskVO p:list){
			if(p.getCheckUser()!=null){
				p.setCheckUserName(p.getCheckUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
				log.info("验收人真实姓名为："+p.getCheckUserName());
			}
			log.info("任务计划开始时间："+p.getPlanStartDate()+",计划结束时间："+p.getPlanEndDate());
			if(p.getPlanEndDate()!=null&&p.getPlanEndDate()!=null&&type==0){
				p.setTimeLimit((int)((p.getPlanEndDate().getTime()-p.getPlanStartDate().getTime())/day)+1);
			}
			if(p.getActualEndDate()!=null&&p.getPlanEndDate()!=null){
				long actual=p.getActualEndDate().getTime();
				long plan=p.getPlanEndDate().getTime();
				if(actual>plan){
					p.setActDelay((int)((actual-plan)/day));
				}else{
					p.setActDelay(0);
				}
			}
			if(p.getPlanEndDate()!=null){
				long plan=p.getPlanEndDate().getTime();
				long now=new Date().getTime();
				if(now>plan){
					p.setPostpone((int)((now-plan)/day));
				}else{
					p.setPostpone(0);
				}
			}
			if(p.getPlanStartDate()!=null&&p.getActualStartDate()!=null){
				long planStart=p.getPlanStartDate().getTime();
				long actualStart=p.getActualStartDate().getTime();
				p.setSetBack((int)((actualStart-planStart)/day));
			}
			
		}
	}

	/**
	 * 施工管理项目
	 */
	@Override
	public List<GesProjectTaskVO> queryTaskByTaskPeriodForPM(Long taskId,
			String periodName, String realName, long cuid) {
		List<GesProjectTaskVO> list=getGesProjectTaskDAO().queryTaskByTaskPeriodForPM(taskId,periodName);
		//循环
		long day=1000*60*60*24;
		for(GesProjectTaskVO p:list){
			dealTaskTime(realName, day, p);
		}
		return list;
	}
	
	/**
     * 根据施工管理项目id查询该任务的阶段和子任务
     * @param taskId
     * @return
     */
	@Override
	@Transactional(readOnly=true)
	public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskIdForPM(long taskId) {
		List<GesProjectTaskVO> list=getGesPmModelDAO().queryTaskPeriodAndSubTaskByTaskId(taskId);
		long day=1000*60*60*24;
		dealTaskForTableAndGatte(list, day,1);
		return list;
	}

	/**
	 * 更新任务的验收状态
	 */
	@Override
	@Transactional
	public boolean updateTaskCheckInfo(GesCommunicationVO communication,long cuid,String realName) {
		User tempUser=new User();
		tempUser.setId(cuid);
		communication.setUser(tempUser);
		//新建任务实体
		GesProjectTask projectTask = new GesProjectTask();
		//设置属性
		projectTask.setId(communication.getTaskId());
		projectTask.setCheckUser(tempUser);
		projectTask.setCheckDate(communication.getCheckDate());
		projectTask.setCheckStatus(TaskConstant.CHECK_STATUS_YES);
		projectTask.setActualStartDate(communication.getActualStartDate());
		projectTask.setActualEndDate(communication.getActualEndDate());
		getGesProjectTaskDAO().updateTaskCheckInfo(projectTask);
		return true;
	}

    @Override
    public GesProjectTask projectTaskByCustomer(GesCustomerVO customer) {
        // TODO Auto-generated method stub
        return getGesProjectTaskDAO().projectTaskByCustomer(customer);
    }

    /**
     * APP用 根据条件查询任务的列表（两种情况）
     * 普通登录用户只能看到他是参与者的任务
     * @param projectTask 查询条件
     * @return 
     */
    @Override
    @Transactional(readOnly=true)
    public Map<String, Object> taskList(
            GesProjectTaskQueryVO gesProjectTaskVO, UserVO gesUser) {
        //返回的map
        Map<String, Object> map=new HashMap<String, Object>();
        //返回的数据
        List<GesProjectTaskQueryVO> list=null;
        //数据总数
        long total=0;
        //任务总数 包括待办和已办
        long totalAll = 0;
        //登录用户的id
        User tempUser=new User();
        tempUser.setId(gesUser.getId());
        gesProjectTaskVO.setUser(tempUser);
        //设置登录人所属的组织类型
        gesProjectTaskVO.setOrgType(gesUser.getOrgType());
        //判断登录人所属的组织类型
        if(GesCommonConstants.ORG_TYPE_CITY_OPERATOR.equals(gesUser.getOrgType())){
            gesProjectTaskVO.setOperatorId(gesUser.getOrgId());
            log.info("组织id"+gesUser.getOrgId());
        }else if(GesCommonConstants.ORG_TYPE_SHOP.equals(gesUser.getOrgType())){
            gesProjectTaskVO.setShopId(gesUser.getOrgId());
            log.info("组织id"+gesUser.getOrgId());
        }
        //计算从哪一条数组开始分页查询数据
        gesProjectTaskVO.setStart(gesProjectTaskVO.getNumber()/gesProjectTaskVO.getPageSize()+1);
        //获取多少条数据
        gesProjectTaskVO.setPageSize(gesProjectTaskVO.getPageSize());

        //判断查询的是项目还是任务
        if(gesProjectTaskVO.getDifference()==0){
            //是项目，根据条件分页查询所参与的所有的项目
            list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO,2);
            //任务项目总数
            total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 2);
        }else{
            //是任务，根据条件分页查询所参与的所有的任务
            list=getGesProjectTaskDAO().queryTaskByFeature(gesProjectTaskVO,4);
            // 待办任务项目总数
            gesProjectTaskVO.setIsDeal(0);
            total=getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 4);
            //任务总数，包括待办和已办
            gesProjectTaskVO.setIsDeal(2);
            totalAll = getGesProjectTaskDAO().countTaskByFeature(gesProjectTaskVO, 4);
        }  
        
        List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
        
        for (GesProjectTaskQueryVO projectTaskVO : list) { 
            Map<String,Object> dto = new HashMap<String, Object>();
            String content = HtmlUtils.htmlEscape(projectTaskVO.getContent());
            projectTaskVO.setContent(content);
            dto.put("id", projectTaskVO.getId());
            dto.put("content", projectTaskVO.getContent());
            dto.put("userName", projectTaskVO.getUserName());
            dto.put("chatContent", projectTaskVO.getChatContent());
            dto.put("createTime", projectTaskVO.getCreateTime());
            dto.put("latestTime", projectTaskVO.getLatestTime());
            dto.put("picPath", projectTaskVO.getPicPath());
            dto.put("taskStatus", projectTaskVO.getTaskStatus());
            dto.put("planStartDate", projectTaskVO.getPlanStartDate());
            dto.put("planEndDate", projectTaskVO.getPlanEndDate());
            dto.put("parentId", projectTaskVO.getParentId());
            GesProjectTaskVO p = queryTaskById(projectTaskVO.getId());
            dto.put("parentContent", p.getChatContent());
            dto.put("isDeal", projectTaskVO.getIsDeal());
            dto.put("isUrgency", projectTaskVO.getIsUrgency());
            result.add(dto);
        }
        
        map.put("rows", result);
        map.put("total", total);
        map.put("totalAll", totalAll);
        return map;
    }
}
