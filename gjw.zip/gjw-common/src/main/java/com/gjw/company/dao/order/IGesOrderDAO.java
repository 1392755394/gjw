package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.GesOrder;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.order.GesOrderVO;

public interface IGesOrderDAO extends IDAO {

    /**
     * 官网 根据购买者ID分页获取订单信息
     * 
     * @param buyerId
     * @return
     */
    public List<GesOrderVO> pageOrderByBuyerIdForWeb(GesOrder gesOrder);

    /**
     * Ges 构家网用户 分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByGjwIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 城运商用户 根据城运商ID分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByOperatorIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 4S店用户 根据4s店的ID分页查询订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByShopIdForGes(GesOrderVO gesOrderVO);

    /**
     * 官网 根据购买者id统计订单的总数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByBuyerIdForWeb(GesOrder gesOrder);

    /**
     * Ges 构家网用户 统计订单数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByGjwIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 城运商用户 根据城运商ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByOperatorIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 4S店用户 根据4s店的ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByShopIdForGes(GesOrderVO gesOrderVO);

    /**
     * 根据订单的id更行订单的状态
     * 
     * @param gesOrder
     * @return
     */
    public Boolean updateOrderStatusByOrderId(GesOrder gesOrder);

    /**
     * 官网后台 分页查询订单信息
     * 
     * @param gesOrderVO
     * @return
     */
    public List<GesOrderVO> pageOrderForWebConsole(GesOrderVO gesOrderVO);

    /**
     * 官网后台 统计订单数量
     * 
     * @param gesOrderVO
     * @return
     */
    public Long countOrderForWebConsole(GesOrderVO gesOrderVO);

    /**
     * 根据订单id 查询订单信息
     * 
     * @param orderId
     * @return
     */
    public GesOrder queryOrderByOrderId(Long orderId);

    /**
     * Ges 根据4S店ID分页查询该店已完成的订单
     * 
     * @param gesOrderVO
     * @return
     */
    public List<GesOrderVO> pageOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO);

    /**
     * Ges 根据4S店ID统计已完成订单的数量
     * 
     * @param gesOrderVO
     * @return
     */
    public Long countOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO);

    /**
     * 采购清单查询
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2016年1月5日 上午9:19:21
     */
    public List<GesOrder> pageByOrder(GesOrderVO model);

    /**
     * 采购清单总数查询
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2016年1月5日 上午9:19:30
     */
    public Long countByOrder(GesOrderVO model);

    /**
     * 根据订单的id更行订单的项目状态
     * 
     * @Description
     * @param gesOrder
     *            Description
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月6日
     */
    public boolean updateProjectStatusByOrderId(GesOrder gesOrder);
    
    /**
     * 更新订单信息
     * @param order
     * @return
     */
    public int updateOrder(GesOrder order);

    /**
     * 基础数据同步项目同步
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2016年1月16日 上午9:51:12
     */
    public List<GesOrder> baseProjectListPage(GesOrder order);

    /**
     * 基础数据同步---修改同步结果
     * 
     * @Description
     * @param order
     * @author gwb
     * @date 2016年1月16日 上午10:13:28
     */
    public void updateProjectSynch(GesOrder order);
    
    /**
     * 统计订单关联产品包的物料
     * @param soMatter
     * @return
     */
    public Long countStandardMatter(GesSoMatterVO soMatter);
    
    /**
     * 分页获取订单关联的物料
     * @param soMatter
     * @return
     */
    public List<GesSoMatterVO> pageStandardMatter(GesSoMatterVO soMatter);

    /**
     * 根据订单id更新订单信息 Ges中修改订单的价格、面积、备注等信息
     * 
     * @Description
     * @param gesOrder
     * @return
     * @author gwb
     * @date 2016年1月18日 上午10:51:41
     */
    public Boolean updateOrderInfoByOrderId(GesOrder gesOrder);

    /**
     * 官网前台 统计该产品包的订单总数
     * 
     * @param goods
     * @return
     */
    public Long countOrderByGoodsForWeb(Goods goods);
    
    /**
     * 直播家 查询订单信息
     * @param orderId
     * @return
     */
    public GesOrderVO queryOrderInfoForLiveHome(Long orderId);
    
    /**
     * 根据客户查询订单信息
     * @param order
     * @return
     */
//    public GesOrder queryOrderInfoForCustomer(GesOrder order);
    
    /**
     * 修改订单状态
     * @param order
     * @return
     */
    public int updateOrderStatusBySystem(GesOrder order);
    
    /**
     * 根据订单id 查询订单信息
     * @param orderId
     * @return
     */
    public GesOrderVO queryOrderByIdForGjb(Long orderId);
    
    /**
     * 根据支付的流水号查询订单信息
     * @param tradeId
     * @return
     */
    public GesOrderVO queryOrderByTradeId(String tradeId);
    public List<GesOrder> queryOrderInfoForCustomer(GesOrder order);
    
    /**
     * 订单删除
     * @param orderId
     * @return
     */
    public int deleteGesOrder(GesOrder order);
    
    public List<GesOrderVO> queryOrderInfoForExcel(GesOrderVO gesOrderVO);

}
