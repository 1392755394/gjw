package com.gjw.company.dao.impl.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IDeptUserDAO;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;

/**
 * 部门dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2016年1月9日 
 *
 */
@Component("deptUserDAOHibernateImpl")
public class DeptUserDAOHibernateImpl extends AbstractDAOHibernateImpl implements IDeptUserDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return DeptUser.class;
    }

    @Override
    public DeptUser get(long id) {
        return (DeptUser)super.get(id);
    }
    
    
    @Override
    public List<DeptUser> pageByDept(DeptUser deptUser) {
        StringBuilder hql=new StringBuilder("from UserInfoGES info inner join info.user user,DeptUser deptUser where deptUser.dept.id=? and user.id=deptUser.user.id and info.invalid=0 and deptUser.invalid=0");
        List<Object> ls=new ArrayList<Object>();
        ls.add(deptUser.getDept().getId());
        if(deptUser.getUser()!=null && deptUser.getUser().getUsername()!=null && !"".equals(deptUser.getUser().getUsername())){
            hql.append("and info.user.username like ?");
            ls.add(getFuzzyCondition(deptUser.getUser().getUsername()));
        }
        List<Object[]> list = (List<Object[]>)super.findByPageCallBack(hql.toString(),"",ls,deptUser,null);
        List<DeptUser> userList=new ArrayList<DeptUser>();
        for(Object[] items:list){
            DeptUser du=(DeptUser)items[2];
            User user=(User)items[1];
            user.setPlatformUserInfo((UserInfo)items[0]);
            du.setUser(user);
            userList.add(du);
        }
        return userList;
    }

    @Override
    public Long countByDept(DeptUser deptUser) {
        StringBuilder hql=new StringBuilder("from UserInfoGES info inner join info.user user,DeptUser deptUser where deptUser.dept.id=? and user.id=deptUser.user.id and info.invalid=0 and deptUser.invalid=0");
        List<Object> ls=new ArrayList<Object>();
        ls.add(deptUser.getDept().getId());
        if(deptUser.getUser()!=null && deptUser.getUser().getUsername()!=null && !"".equals(deptUser.getUser().getUsername())){
            hql.append("and info.user.username like ?");
            ls.add(getFuzzyCondition(deptUser.getUser().getUsername()));
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public List<User> pageUncheckByDept(DeptUser deptUser) {
        StringBuilder hql=new StringBuilder("from DeptUser du right join du.user user inner join user.userInfoMap info with info.type=2 where du.id is null and info.invalid=0 and du.invalid is null and user.invalid=0");
        List<Object> ls=new ArrayList<Object>();
        if(deptUser.getUser()!=null && deptUser.getUser().getUsername()!=null && !"".equals(deptUser.getUser().getUsername())){
            hql.append("and info.user.username like ?");
            ls.add(getFuzzyCondition(deptUser.getUser().getUsername()));
        }
        List<Object[]> list = (List<Object[]>)super.findByPageCallBack(hql.toString(),"",ls,deptUser,null);
        List<User> userList=new ArrayList<User>();
        for(Object[] items:list){
            User user=(User)items[1];
            user.setPlatformUserInfo((UserInfo)items[2]);
            userList.add(user);
        }
        return userList;
    }

    @Override
    public Long countUncheckByDept(DeptUser deptUser) {
        StringBuilder hql=new StringBuilder("from DeptUser du right join du.user user inner join user.userInfoMap info with info.type=2 where du.id is null and info.invalid=0 and du.invalid is null and user.invalid=0");
        List<Object> ls=new ArrayList<Object>();
        if(deptUser.getUser()!=null && deptUser.getUser().getUsername()!=null && !"".equals(deptUser.getUser().getUsername())){
            hql.append("and info.user.username like ?");
            ls.add(getFuzzyCondition(deptUser.getUser().getUsername()));
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public DeptUser getByDeptAndUser(DeptUser deptUser) {
        String hql="from DeptUser where user.id=? and dept.id=?";
        return ((List<DeptUser>)this.getHibernateTemplate().find(hql, deptUser.getUser().getId(),deptUser.getDept().getId())).get(0);
    }

}
