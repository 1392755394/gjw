package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesErpCodeDAO;
import com.gjw.entity.erp.GesErpCode;

/**
 * 基础数据同步
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月16日 下午3:53:08
 * 
 */
@Component("gesErpCodeDAOHibernateImpl")
public class GesErpCodeDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesErpCodeDAO {

    @Override
    protected Class getEntityClass() {
        return GesErpCode.class;
    }

    @Override
    public List<GesErpCode> pageByGesErpCode(GesErpCode gesErpCode) {
        String hql = " from GesErpCode where invalid =?";
        List<Object> list = new ArrayList<Object>();
        list.add(false);
        return (List<GesErpCode>) super.findByPageCallBack(hql, "", list, gesErpCode, null);
    }

    @Override
    public Long count(GesErpCode gesErpCode) {
        String hql = " from GesErpCode where invalid =?";
        List<Object> list = new ArrayList<Object>();
        list.add(false);
        return super.findByPageCallBackCount(hql, list);
    }

    /**
     * 根据 ProcjectCode修改---GesErpCode
     */
    @Override
    public void updateByProcjectCode(GesErpCode gesErpCode) {
        String hql = " update GesErpCode set updatedDatetime=? where procjectCode=?";
        // + ",lastOperater.id=?";
        List<Object> list = new ArrayList<Object>();
        list.add(gesErpCode.getUpdatedDatetime());
        list.add(gesErpCode.getProcjectCode());
        // list.add(gesErpCode.getLastOperater().getId());
        super.updateByParam(hql, list);
    }
}
