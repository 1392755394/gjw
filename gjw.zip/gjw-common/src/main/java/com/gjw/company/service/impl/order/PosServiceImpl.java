package com.gjw.company.service.impl.order;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.common.error.ErrorMessage;
import com.gjw.common.exception.GenericException;
import com.gjw.company.service.order.IMultiplePaymentService;
import com.gjw.company.service.order.IPosService;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.User;
import com.gjw.gjb.enumeration.EPaymentRecordMode;
import com.gjw.gjb.enumeration.EPaymentRecordStatus;
import com.gjw.utils.StringUtil;
import com.gjw.vo.order.GesOrderVO;

@Component("posServiceImpl")
public class PosServiceImpl extends AbstractServiceImpl implements IPosService {
	
	private final static Logger LOG=LoggerFactory.getLogger(PosServiceImpl.class);

	private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    public final static String CREDIT_CODE_PREFIX ="CRET"; // 保证金支付  银行要求支付流水号是纯数字，所以用11代替CRET的前面的字符
	public final static String EARNEST_CODE_PREFIX ="EART";//定金支付        
	
	@Resource(name="multiplePaymentServiceImpl")
	private IMultiplePaymentService multiplePaymentService;
	
	/**
	 * 刷卡准备
	 */
	@Override
	@Transactional
	public Map<String, Object> ready(Long orderId, Long userId,Integer action) {
		//查询订单信息
        GesOrder order =getGesOrderDAO().queryOrderByOrderId(orderId);
        LOG.info("订单id为："+orderId+",订单状态："+order.getOrderStatus());		
        
        GesShop shop =  order.getShop();
        
        MultiplePayment mp=new MultiplePayment();
        
        User tempUser=new User();
        tempUser.setId(userId);
        
        GesPaymentRecord paymentRecord = new GesPaymentRecord();
        paymentRecord.setGmtSuccess(new Timestamp(System.currentTimeMillis()));
        paymentRecord.setGesOrder(order);
        paymentRecord.setMode(EPaymentRecordMode.POS.getValue());
        paymentRecord.setAction(action);
        paymentRecord.setUser(tempUser);
        paymentRecord.setOrderStatus(order.getOrderStatus());
        paymentRecord.setPayStatus(EPaymentRecordStatus.PAYING.getValue());

        String orderType="";
        /* TODO 这里需要确认一个好的 code 的生成规则 */
        //支付流水号
        String payCode=simpleDateFormat.format(new Date())  + (int)(Math.random() * 1000000000);
        //传给银行的支付流水号
        String paymentRecordCode="";
        /* 这里要确认状态，以确认是支付 10% 还是 90% */
        if (order.getOrderStatus().equals(OrderStatus.prepaying.name()) || order.getOrderStatus().equals(OrderStatus.booked.name())) {
        	orderType="0";//0 预付款
            paymentRecord.setTargetAccount("购家网账号");
            paymentRecordCode=  EARNEST_CODE_PREFIX+payCode;
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
        } else if (order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())) {
        	orderType="1";//0 预付款  1 保证金
            paymentRecord.setTargetAccount("保证金账号");
            paymentRecordCode=CREDIT_CODE_PREFIX+payCode;
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
        } else {
            throw new UnsupportedOperationException();
        }

        paymentRecord.setPosSN(shop.getPosSN());
        //要支付的金额
        BigDecimal payMoney=multiplePaymentService.queryNeedPayMoneyForGes(orderId,userId).getResult();
        long money=payMoney.multiply(new BigDecimal(100)).longValue();
        LOG.info("要支付的金额为："+payMoney+"元，转为分为:"+money);
        if(money==0){
            throw new GenericException(new ErrorMessage("获取支付金额有误！")); 
        }
        paymentRecord.setMoney(money);
        paymentRecord.setCode(payCode);
        paymentRecord.setInvalid(false);
        getGesPaymentRecordDAO().createPaymentRecord(paymentRecord);
        
        //更新支付记录中的支付流水号
        mp.setGesOrder(order);
        mp.setSerialPayNo(payCode);
        getMultiplePaymentDAO().updateSerialPayNo(mp);
        
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", true);
        result.put("paymentRecordId", paymentRecord.getId());
        result.put("orderStatus", paymentRecord.getOrderStatus());
        result.put("orderCode", addSpace(order.getId()+"",20));
        result.put("posSN", shop.getPosSN());
        result.put("shopId", shop.getId());
        BigDecimal rate = BigDecimal.ONE.subtract(new BigDecimal(0.9));
        result.put("money",paymentRecord.getMoney());
        result.put("paymentRecordCode",addSpace(paymentRecordCode,32));
        result.put("name", order.getBuyer().getUsername());
        result.put("IDCard", order.getIDCard());
        if(order.getMobile()==null||order.getMobile().length()==0){
            order.setMobile("18668083807");
        }
        result.put("mobile", addSpace(order.getMobile(),11));
        result.put("paid", order.getPayedAmount());
        result.put("paidNum", order.getPayedNum());
       // result.put("payCode", addSpace(payCode,32));
        result.put("orderType", orderType);
        LOG.info("订单总金额："+order.getTotalAmount());
        String totalAmount=new BigDecimal(order.getTotalAmount()).divide(new BigDecimal(100)) +"";
        if(totalAmount.length()>10){
            LOG.info("订单金额字符串："+totalAmount+"截取字符串后为："+totalAmount.substring(0, 10));
            result.put("totalAmount", addSpace(totalAmount.substring(0, 10),10));
        }else{
            result.put("totalAmount", addSpace(totalAmount,10));
        }
        if (order.getOrderStatus().equals(OrderStatus.prepaying.name())) {
        	 result.put("operatorId", addSpace("gjw",32));
        } else if (order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())) {
        	 result.put("operatorId", addSpace(shop.getCode()+"",32));
        }else if(order.getOrderStatus().equals(OrderStatus.booked.name())){
            result.put("operatorId", addSpace("gjw",32));
        } else {
            throw new UnsupportedOperationException();
        }
       
        LOG.info("传送给银行的信息："+result.get("operatorId")+result.get("orderCode")+result.get("mobile")+
                result.get("totalAmount")+result.get("orderType")+result.get("paymentRecordCode"));
        return result;
	}
	
	/**
     * 不足补空格
     * @param str
     * @param countSpace
     * @return
     */
	public String addSpace(String str, int countSpace){
		if(StringUtil.isEmpty(str)){
			LOG.error("-------------------"+str+"="+countSpace+"数据补空格报错");
			return "";
			}
		
		String resultStr = str;
		for (int i = 0; i < countSpace - str.length(); i++) {
			resultStr = resultStr + " ";
		}
		return resultStr;
	}

	/**
	 * 刷卡成功后银行返回信息处理
	 */
	@Override
	@Transactional
	public Map<String, Object> complete(GesPaymentRecord paymentRecord,Long userId) {
		//根据record的id查出订单id
		GesPaymentRecord record=getGesPaymentRecordDAO().queryPaymentRecordById(paymentRecord.getId());
		//查询订单信息
		GesOrder order = record.getGesOrder();
		User tempUser=new User();
		tempUser.setId(userId);
		order.setUser(tempUser);
		// 更新记录状态
		updateMultiplePaymentStatus(order, record);
		// 判断已支付的金额是否等于需要支付的金额，如果是，则更新订单的状态 否则只更新支付记录为已收到银行反馈信息
		updateOrderStatusAndRecordStatus(order, record);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("paid", order.getPayedAmount());
		map.put("paidNum", order.getPayedNum());
		return map;
	}
	
	/**
	 * 更新多次支付记录的支付状态和支付方式
	 * @param order
	 * @param paymentRecord
	 */
	public void updateMultiplePaymentStatus(GesOrder order,GesPaymentRecord paymentRecord){
	    MultiplePayment mp=new MultiplePayment();
	    GesOrderPayMoney orderPay=new GesOrderPayMoney();
	    mp.setGesOrder(order);
	    mp.setMoney(paymentRecord.getMoney().longValue());
	    mp.setPayStatus(PaymentConstant.PAY_STATUS_TWO);
	    mp.setSerialPayNo(paymentRecord.getCode());
	    LOG.info("待修改状态的记录的金额为（分）:"+mp.getMoney());
	    mp.setPayWay(PaymentConstant.PayWay.POS.ordinal());
	    //阶段
	    if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus()) || PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())){//10%
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            orderPay.setEarnestPay(mp.getMoney());
            orderPay.setEarnestPayNum(1);
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            orderPay.setDepositPay(mp.getMoney());
            orderPay.setDepositPayNum(1);
        }else{
            LOG.error("订单状态异常，请查看！"+order.getOrderStatus());
        }
	    int flag=getMultiplePaymentDAO().updateMultiplePay(mp);
	    LOG.info("更新支付的状态结果："+flag);
	    //
        orderPay.setGesOrder(order);
        orderPay.setInvalid(false);
	    int payFlag=getGesOrderPayMoney().updateOrderPay(orderPay);
        LOG.info("更新订单金额统计记录状态："+payFlag);
        if(payFlag<1){
            //flag为false说明没有该条记录，需要插入一条数据
            getGesOrderPayMoney().addGesOrderPayMoney(orderPay);
            LOG.info("添加订单金额统计记录的id："+orderPay.getId());
        }
	}
	
	/**
	 * 判断已支付的金额是否等于需要支付的金额，如果是，则更新订单的状态和支付记录状态 否则只更新支付记录为已收到银行反馈信息
	 * @param order
	 * @param paymentRecord
	 */
	public void updateOrderStatusAndRecordStatus(GesOrder order,GesPaymentRecord paymentRecord){
	    long totalAmount=0l;
	    MultiplePayment mp=new MultiplePayment();
	    if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus()) || PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())){
	        mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
	        totalAmount=order.getTotalAmount().longValue()/10;
	    }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
	        mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }
	    mp.setGesOrder(order);
	    //判断已付的金额是否等于总金额
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        LOG.info("支付阶段为："+mp.getPeriod()+",已支付金额为："+payedMoney+",要支付的金额为："+totalAmount);
        if(payedMoney==totalAmount){
        	getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
        	if(order.getOrderStatus().equals(OrderStatus.booked.name())){
        		order.setOrderStatus(OrderStatus.booked.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.prepaying.name())){
        		order.setOrderStatus(OrderStatus.arriving_earnest.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())){
        		order.setOrderStatus(OrderStatus.arriving_credit.name());
        	}
        	getGesOrderDAO().updateOrderStatusByOrderId(order);
        }else{
        	getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
        }
	    
	}
	

}
