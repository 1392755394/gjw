package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesStoreInventoryService;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.vo.StoreInventoryVO;

/**
 * 库位管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 下午5:25:20
 * 
 */
@Service("gesStoreInventoryServiceImpl")
public class GesStoreInventoryServiceImpl extends AbstractServiceImpl implements IGesStoreInventoryService {

    @Override
    @Transactional(readOnly = true)
    public List<GesStoreInventory> pageByGesStoreInventory(StoreInventoryVO gesStoreInventory) {
        List<GesStoreInventory> list = super.getGesStoreInventoryDAO().pageByGesStoreInventory(gesStoreInventory);
        for (GesStoreInventory model : list) {
            if (model.getStore() != null && model.getStore().getStoreType() != null) {
                model.getStore().getStoreType().getText();
            }
            if (model.getStoreLocation() != null) {
                model.getStoreLocation().getName();
            }
            model.getMatter().getName();
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(StoreInventoryVO gesStoreInventory) {
        return super.getGesStoreInventoryDAO().count(gesStoreInventory);
    }

}
