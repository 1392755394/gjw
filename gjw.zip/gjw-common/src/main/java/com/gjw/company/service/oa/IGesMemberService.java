package com.gjw.company.service.oa;

import com.gjw.vo.oa.UserVO;

public interface IGesMemberService {
	
	/**
     * 后期移动
     * @param id
     * @return
     */
    public UserVO queryUserInfo(long id);
    
    /**
	 * 会员详细(官网用户)
	 * @param id
	 * @return
	 */
	public UserVO queryMember(long id);

}
