package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.matter.MatterUnit;

/**
 * 物料单位
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月21日 上午9:16:48
 * 
 */
public interface IMatterUnitService extends IService {
    /**
     * 物料单位列表查询
     * 
     * @Description
     * @param matterUnit
     * @return
     * @author gwb
     * @date 2015年12月21日 上午9:19:40
     */
    public List<MatterUnit> listByMatterUnitSynch(MatterUnit matterUnit);

    /**
     * 修改物料单位同步结果
     * 
     * @Description
     * @param matterUnit
     * @return
     * @author gwb
     * @date 2015年12月21日 上午9:19:53
     */
    public boolean updateMatterUnitSynch(MatterUnit matterUnit);

}
