package com.gjw.company.service.app;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.app.WebDesigner;

public interface IWebDesignerService extends IService{
    public WebDesigner get(Long id);

    public List<WebDesigner> getList(WebDesigner model);
    
    public boolean addWebDesigner(WebDesigner model);
    
    public void updateWebDesigner(WebDesigner model);
    
    public WebDesigner getTopic(Long topicId);
}
