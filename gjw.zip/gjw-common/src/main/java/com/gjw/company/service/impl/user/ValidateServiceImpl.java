package com.gjw.company.service.impl.user;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.service.user.IValidateService;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.AuthenticationEmail;
import com.gjw.entity.user.AuthenticationMobile;
import com.gjw.entity.user.AuthenticationUsername;
import com.gjw.entity.user.User;
import com.gjw.utils.ValidateUtil;

@Service("validateServiceImpl")
@Transactional
public class ValidateServiceImpl extends AbstractServiceImpl implements IValidateService {
    
    
    @Override
    public void validateUsername(String username){
            if(!ValidateUtil.validateUsername(username))
                throw new ErrorCodeException(SECode.u_100004);
            Authentication tmp = this.getAuthenticationDAO().getByLogin(username, AuthenticationUsername.class.getSimpleName());
            if(tmp!=null)
                throw new ErrorCodeException(SECode.u_100005);
    }
    @Override
    public void validateMobile(String mobile){
        if(mobile!=null && !mobile.equals("")){
            if(!ValidateUtil.validatePhone(mobile))
                throw new  ErrorCodeException(SECode.u_100006);
            Authentication tmp = this.getAuthenticationDAO().getByLogin(mobile, AuthenticationMobile.class.getSimpleName());
            if(tmp!=null)
                throw new  ErrorCodeException(SECode.u_100007);
        }
    }
    @Override
    public void validateEmail(String email){
        if(email!=null  && !email.equals("")){
            if(!ValidateUtil.validateMail(email))
                throw new  ErrorCodeException(SECode.u_100008);
            Authentication tmp = this.getAuthenticationDAO().getByLogin(email, AuthenticationEmail.class.getSimpleName());
            if(tmp!=null)
                throw new  ErrorCodeException(SECode.u_100009);
        }
    }
    
    @Override
    public void validate(User user){
        validateUsername(user.getUsername());
        if(user.getMobile()!=null && !user.getMobile().equals("")){
            validateMobile(user.getMobile());
        }
        if(user.getEmail()!=null  && !user.getEmail().equals("")){
            validateEmail(user.getEmail());
        }
    }
   

}
