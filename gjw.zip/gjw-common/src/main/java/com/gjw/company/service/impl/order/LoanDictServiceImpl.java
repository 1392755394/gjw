package com.gjw.company.service.impl.order;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.order.ILoanDictDAO;
import com.gjw.company.service.order.ILoanDictService;
import com.gjw.entity.order.LoanDict;

@Component("loanDictServiceImpl")
public class LoanDictServiceImpl implements ILoanDictService {
	
	@Resource(name="loanDictDAOHibernate")
	private ILoanDictDAO loanDictDAO;

	@Override
	@Transactional(readOnly=true)
	public List<LoanDict> queryByCIP(LoanDict dict) {
		
		return loanDictDAO.queryByCIP(dict);
	}
	
	

}
