package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesRdRecordDAO;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.utils.StringUtil;
import com.gjw.vo.RdRecordVO;

/**
 * 销售出库单管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月15日 下午3:35:56
 * 
 */
@Component("gesRdRecordDAOHibernateImpl")
public class GesRdRecordDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesRdRecordDAO {

    @Override
    protected Class<GesRdRecord> getEntityClass() {
        return GesRdRecord.class;
    }

    public Map<String, Object> getHql(RdRecordVO rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesRdRecord  where invalid=0 and type.id=?");
        ls.add(rdRecord.getRdRecordType());
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            ls.add(rdRecord.getRecordCode());
            hql.append(" and recordCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getSoCode())) {
            ls.add(rdRecord.getSoCode());
            hql.append(" and sourceCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getSourceCode())) {
            ls.add(rdRecord.getSourceCode());
            hql.append(" and sourceCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getShopName())) {
            ls.add(rdRecord.getShopName());
            hql.append(" and gesOrder.shop.name=?");
        }
        if (rdRecord.getReceiverShop() != null && rdRecord.getReceiverShop().getId() != null) {
            ls.add(rdRecord.getReceiverShop().getId());
            hql.append(" and receiverShop.id=?");
        }

        if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
            ls.add(rdRecord.getOperatorName());
            hql.append(" and gesOrder.operator.companyName=?");
        }
        if (rdRecord.getReceiverOperator() != null && rdRecord.getReceiverOperator().getId() != null) {
            ls.add(rdRecord.getReceiverOperator().getId());
            hql.append(" and receiverOperator.id=?");
        }

        if (StringUtil.notEmpty(rdRecord.getBuyer())) {
            ls.add(rdRecord.getBuyer());
            hql.append(" and gesOrder.buyer.username=?");
        }

        if (rdRecord.getStatus() != null && rdRecord.getStatus() != -1) {
            ls.add(rdRecord.getStatus());
            hql.append(" and status=?");
        }
        hql.append(" and shipperOperator.id is null and  shipperShop.id is null ");
        // hql.append(" and shipperOperator.id is not null or  shipperShop.id is not null ");
        hql.append(" order by createdDatetime desc");
        map.put("list", ls);
        map.put("hql", hql.toString());
        // hql.append(" from GesRdRecord  where invalid=0 and type.id=?");
        // ls.add(rdRecord.getRdRecordType());
        // if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
        // ls.add(rdRecord.getRecordCode());
        // hql.append(" and recordCode=?");
        // }
        // if (StringUtil.notEmpty(rdRecord.getSoCode())) {
        // ls.add(rdRecord.getSoCode());
        // hql.append(" and sourceCode=?");
        // }
        // if (StringUtil.notEmpty(rdRecord.getShopName())) {
        // ls.add(rdRecord.getShopName());
        // hql.append(" and shop.name=?");
        // }
        // if (rdRecord.getReceiverShop() != null &&
        // rdRecord.getReceiverShop().getId() != null) {
        // ls.add(rdRecord.getReceiverShop().getId());
        // hql.append(" and receiverShop.id=?");
        // }
        //
        // if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
        // ls.add(rdRecord.getOperatorName());
        // hql.append(" and cityOperator.companyName=?");
        // }
        // if (rdRecord.getReceiverOperator() != null &&
        // rdRecord.getReceiverOperator().getId() != null) {
        // ls.add(rdRecord.getReceiverOperator().getId());
        // hql.append(" and receiverOperator.id=?");
        // }
        // /* if (rdRecord.getBuyer()!=null) {
        // ls.add(rdRecord.getBuyer());
        // hql.append(" and ");
        // }*/
        // if (rdRecord.getStatus() != null && rdRecord.getStatus() != -1) {
        // ls.add(rdRecord.getStatus());
        // hql.append(" and status=?");
        // }
        // hql.append(" and shipperOperator.id is null and  shipperShop.id is null ");
        // //
        // hql.append(" and shipperOperator.id is not null or  shipperShop.id is not null ");
        // hql.append(" order by createdDatetime desc");
        // map.put("list", ls);
        // map.put("hql", hql.toString());
        return map;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesRdRecord> pageByRdRecord(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHql(rdRecord);
        return (List<GesRdRecord>) super.findByPageCallBack(map.get("hql").toString(), "", (List) map.get("list"),
                rdRecord, null);
    }

    @Override
    public Long count(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHql(rdRecord);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List) map.get("list"));

    }

    /**
     * 根据 单据编号 修改销售出库单状态
     */
    @Override
    public boolean updateByRecordCode(GesRdRecord rdRecord) {

        String hql = " update GesRdRecord set status=?,updatedDatetime=? where recordCode=?";
        List<Object> ls = new ArrayList<Object>();
        ls.add(rdRecord.getStatus());
        ls.add(rdRecord.getUpdatedDatetime());
        ls.add(rdRecord.getRecordCode());
        return super.updateByParam(hql, ls);
    }

    @Override
    public GesRdRecord getByGesRdRecord(GesRdRecord rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecord where invalid=0 ");
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            hql.append(" and recordCode=?");
            list.add(rdRecord.getRecordCode());
        }
        return (GesRdRecord) super.queryByParam(hql.toString(), list);
    }

    @Override
    public void create(GesRdRecord rdRecord) {
        super.add(rdRecord);
    }

    /**
     * 采购入库单sql
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年3月23日 上午10:10:56
     */
    private Map<String, Object> getStockMap(RdRecordVO rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();

        hql.append("  SELECT ");
        hql.append(" pm.po_code poCode,o.id,r.record_code recordCode, r.source_code sourceCode, r.receiver_address receiverAddress,r.wh_destination_id, ");
        hql.append(" r.storage_location_destination,r.remark, r.status, g.name, sp.name AS shopName,o.total_amount AS totalAmout,");
        hql.append(" co.company_name AS operatorName, u.username, s.name AS warehouseName,s1.name AS localtionName  ");
        hql.append(" FROM ges_rd_record r LEFT JOIN  ");
        hql.append("    (SELECT  gesrdrecor1_.record_code, gesrdrecor1_.po_main_id, gesrdrecor1_.ges_order_id  ");
        hql.append("   FROM  ges_rd_record gesrdrecor1_   WHERE gesrdrecor1_.invalid = 0    AND gesrdrecor1_.type = 1130601) rp  ");
        hql.append("  ON r.source_code = rp.record_code  LEFT JOIN ges_po_main pm    ON rp.po_main_id = pm.id  ");
        hql.append("   LEFT JOIN b_order o ON pm.order_id =o.id LEFT JOIN p_goods g ON o.goods_id=g.id ");
        hql.append("  LEFT JOIN u_user u ON o.buyer_id=u.id  LEFT JOIN base_shop sp ON sp.id=r.receiver_shop_id ");
        hql.append("  LEFT JOIN base_city_operator co ON co.id=r.receiver_operator_id LEFT JOIN ges_store s ON r.wh_destination_id=s.id ");
        hql.append(" LEFT JOIN ges_store_location s1 ON r.storage_location_destination=s1.id ");
        hql.append(" WHERE r.invalid = 0  AND r.type = 1130602  ");

        if (rdRecord.getReceiverOperator() != null && rdRecord.getReceiverOperator().getId() != null) {
            hql.append(" and  r.receiver_operator_id=?  ");
            list.add(rdRecord.getReceiverOperator().getId());
        }
        if (rdRecord.getReceiverShop() != null && rdRecord.getReceiverShop().getId() != null) {
            hql.append(" and r.receiver_shop_id=?  ");
            list.add(rdRecord.getReceiverShop().getId());
        }
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            hql.append(" and r.record_code=?");
            list.add(rdRecord.getRecordCode());
        }
        if (StringUtil.notEmpty(rdRecord.getPoCode())) {
            hql.append(" and pm.po_code=?");
            list.add(rdRecord.getPoCode());
        }
        if (StringUtil.notEmpty(rdRecord.getBuyer())) {
            hql.append(" and u.username=?");
            list.add(rdRecord.getBuyer());
        }
        if (StringUtil.notEmpty(rdRecord.getShopName())) {
            hql.append(" and sp.name=?");
            list.add(rdRecord.getShopName());
        }
        if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
            hql.append(" and co.company_name=?");
            list.add(rdRecord.getOperatorName());
        }
        map.put("hql", hql);
        map.put("list", list);
        return map;

    }

    /**
     * 采购入库单分页查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Map> pageStockByRdRecord(RdRecordVO rdRecord) {

        Map<String, Object> map = this.getStockMap(rdRecord);
        // hql.append("  from GesRdRecord rda where invalid=0 and rda.sourceCode in (select recordCode from GesRdRecord where invalid=0 and  type=1130601");
        // if (rdRecord.getReceiverOperator() != null &&
        // rdRecord.getReceiverOperator().getId() != null) {
        // hql.append(" and receiverOperator.id=?");
        // list.add(rdRecord.getReceiverOperator().getId());
        // }
        // if (rdRecord.getReceiverShop() != null &&
        // rdRecord.getReceiverShop().getId() != null) {
        // hql.append(" and receiverShop.id=?");
        // list.add(rdRecord.getReceiverShop().getId());
        // }
        // hql.append(" and rda.type=1130602 )");
        // if (rdRecord.getReceiverOperator() != null &&
        // rdRecord.getReceiverOperator().getId() != null) {
        // hql.append(" and rda.receiverOperator.id=?");
        // list.add(rdRecord.getReceiverOperator().getId());
        // }
        // if (rdRecord.getReceiverShop() != null &&
        // rdRecord.getReceiverShop().getId() != null) {
        // hql.append(" and rda.receiverShop.id=?");
        // list.add(rdRecord.getReceiverShop().getId());
        // }
        // if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
        // hql.append(" and rda.recordCode=?");
        // list.add(rdRecord.getRecordCode());
        // }
        // if (StringUtil.notEmpty(rdRecord.getSourceCode())) {
        // hql.append(" and rda.sourceCode=?");
        // list.add(rdRecord.getSourceCode());
        // }
        // if (StringUtil.notEmpty(rdRecord.getShopName())) {
        // hql.append(" and rda.shop.name=?");
        // list.add(rdRecord.getShopName());
        // }
        // if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
        // hql.append(" and rda.cityOperator.companyName=?");
        // list.add(rdRecord.getOperatorName());
        // }
        // if (StringUtil.notEmpty(rdRecord.getBuyer())) {
        // hql.append(" and rda.gesPoMain.gesOrder.user.platformUserInfo.realName=?");
        // list.add(rdRecord.getBuyer());
        // }
        return (List<Map>) super.findByPageSql(map.get("hql").toString() + "  order by r.created_Datetime desc", null,
                (List) map.get("list"), rdRecord, true);
    }

    /**
     * 采购入库单分页总数查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public Long countStock(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getStockMap(rdRecord);
        return super.countSql("select count(1) from (" + map.get("hql").toString() + ") b", (List) map.get("list"));
    }

    /**
     * 构家网销售出库单
     */
    @Override
    public List<GesRdRecord> ListByRdRecord(RdRecordVO rdRecord) {
        StringBuffer hql = new StringBuffer();
        hql.append("  from GesRdRecord where invalid=0 and  type=1130601  ");
        List<Object> list = new ArrayList<Object>();
        return (List<GesRdRecord>) super.findByListCallBack(hql.toString(), null, list, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesRdRecord> pageStockOutByRdRecord(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHqlStockOut(rdRecord);
        return (List<GesRdRecord>) super.findByPageCallBack(map.get("hql").toString(), "", (List) map.get("list"),
                rdRecord, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long countStockOut(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHqlStockOut(rdRecord);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List) map.get("list"));
    }

    public Map<String, Object> getHqlStockOut(RdRecordVO rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesRdRecord  where invalid=0 and type.id=?");
        ls.add(rdRecord.getRdRecordType());
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            ls.add(rdRecord.getRecordCode());
            hql.append(" and recordCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getSoCode())) {
            ls.add(rdRecord.getSoCode());
            hql.append(" and gesPoMain.soCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getSourceCode())) {
            ls.add(rdRecord.getSourceCode());
            hql.append(" and sourceCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getShopName())) {
            ls.add(rdRecord.getShopName());
            hql.append(" and shop.name=?");
        }
        if (rdRecord.getShipperShop() != null && rdRecord.getShipperShop().getId() != null) {
            ls.add(rdRecord.getShipperShop().getId());
            hql.append(" and shipperShop.id=?");
        }

        if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
            ls.add(rdRecord.getOperatorName());
            hql.append(" and gesOrder.operator.companyName=?");
        }
        if (rdRecord.getShipperOperator() != null && rdRecord.getShipperOperator().getId() != null) {
            ls.add(rdRecord.getShipperOperator().getId());
            hql.append(" and shipperOperator.id=?");
        }
        if (StringUtil.notEmpty(rdRecord.getBuyer())) {
            ls.add(rdRecord.getBuyer());
            hql.append(" and gesOrder.buyer.username=?");
        }

        // if (StringUtil.notEmpty(rdRecord.getBuyer())) {
        // ls.add(rdRecord.getOperatorName());
        // hql.append(" and shipperOperator.companyName=?");
        // }
        if (rdRecord.getStatus() != null && rdRecord.getStatus() != -1) {
            ls.add(rdRecord.getStatus());
            hql.append(" and status=?");
        }
        hql.append(" and ( shipperOperator.id is not null or  shipperShop.id is not null ) ");
        hql.append(" order by createdDatetime desc ");
        map.put("list", ls);
        map.put("hql", hql.toString());
        return map;
    }

    @Override
    public void deleteGesRdRecord(String ids) {
        String[] idArray = ids.split(",");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        for (String id : idArray) {
            String hql = " delete from  GesRdRecords where id=:ids";
            Query query = session.createQuery(hql);
            query.setParameter("ids", Long.parseLong(id));
            query.executeUpdate();
        }

    }

    @Override
    public void updateAmount(Long id, Integer amount) {
        String hql = " update GesRdRecords set quantity=? where id=?";
        List<Object> ls = new ArrayList<Object>();
        ls.add(Double.valueOf(amount.toString()));
        ls.add(id);
        super.updateByParam(hql, ls);

    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesRdRecord> pageByRdRecordOpMat(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHqlStockOutOpMat(rdRecord);
        return (List<GesRdRecord>) super.findByPageCallBack(map.get("hql").toString(), null,
                (List<Object>) map.get("list"), rdRecord, null);
    }

    @Override
    public Long countOpMat(RdRecordVO rdRecord) {
        Map<String, Object> map = this.getHqlStockOutOpMat(rdRecord);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    public Map<String, Object> getHqlStockOutOpMat(RdRecordVO rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesRdRecord  where invalid=0 and type.id=?");
        ls.add(rdRecord.getRdRecordType());
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            ls.add(rdRecord.getRecordCode());
            hql.append(" and recordCode=?");
        }
        if (StringUtil.notEmpty(rdRecord.getSoCode())) {
            ls.add(rdRecord.getSoCode());
            hql.append(" and gesOrder.code=?");
        }
        if (StringUtil.notEmpty(rdRecord.getShopName())) {
            ls.add(rdRecord.getShopName());
            hql.append(" and shop.name=?");
        }
        if (rdRecord.getShipperShop() != null && rdRecord.getShipperShop().getId() != null) {
            ls.add(rdRecord.getShipperShop().getId());
            hql.append(" and shipperShop.id=?");
        }

        if (StringUtil.notEmpty(rdRecord.getOperatorName())) {
            ls.add(rdRecord.getOperatorName());
            hql.append(" and cityOperator.companyName=?");
        }
        if (rdRecord.getShipperOperator() != null && rdRecord.getShipperOperator().getId() != null) {
            ls.add(rdRecord.getShipperOperator().getId());
            hql.append(" and shipperOperator.id=?");
        }

        if (StringUtil.notEmpty(rdRecord.getBuyer())) {
            ls.add(rdRecord.getOperatorName());
            hql.append(" and shop.companyName=?");
        }
        if (rdRecord.getStatus() != null && rdRecord.getStatus() != -1) {
            ls.add(rdRecord.getStatus());
            hql.append(" and status=?");
        }
        hql.append(" and ( shipperOperator.id is not null or  shipperShop.id is not null ) ");
        hql.append(" order by createdDatetime desc ");
        map.put("list", ls);
        map.put("hql", hql.toString());
        return map;
    }
}
