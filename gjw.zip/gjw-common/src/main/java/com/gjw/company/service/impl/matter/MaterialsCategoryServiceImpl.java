package com.gjw.company.service.impl.matter;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.service.matter.IMaterialsCategoryService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.matter.MaterialsCategory;

/**
 * 建材类目service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月14日
 * 
 */
@Component("materialsCategoryServiceImpl")
public class MaterialsCategoryServiceImpl extends AbstractServiceImpl implements IMaterialsCategoryService {

    @Override
    @Transactional(readOnly = true)
    public List<MaterialsCategory> listCategoryByParentId(long parentId) {
        return super.getMaterialsCategoryDAO().listCategoryByParentId(parentId);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countCategoryByParentId(long parentId) {
        return super.getMaterialsCategoryDAO().countCategoryByParentId(parentId);
    }

    /**
     * 建材库分类同步查询
     */
    @Override
    @Transactional(readOnly = true)
    public List<Map<String, Object>> listMaterialsCategoryForSynch(MaterialsCategory materialsCategory) {
        return super.getMaterialsCategoryDAO().listMaterialsCategoryForSynch(materialsCategory);
    }

    @Override
    @Transactional(readOnly = true)
    public MaterialsCategory queryCategoryByID(Long id) {
        // TODO Auto-generated method stub
        return super.getMaterialsCategoryDAO().queryByID(id);
    }

    @Override
    @Transactional
    public boolean updateCategory(MaterialsCategory materialsCategory) {
        // TODO Auto-generated method stub
        return super.getMaterialsCategoryDAO().updateCategory(materialsCategory);
    }

    @Override
    @Transactional
    public boolean createCategory(MaterialsCategory materialsCategory) {
        // TODO Auto-generated method stub
        Dictionary synchType = new Dictionary();
        synchType.setId(DictionaryConstants.DICTIONARY_OTHER_SYNC_DEFAULT);
        materialsCategory.setSynchType(synchType);
        return super.getMaterialsCategoryDAO().saveResultBoolean(materialsCategory);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isChildNode(Long id) {
        // TODO Auto-generated method stub
        return super.getMaterialsCategoryDAO().countCategoryByParentId(id)>0;
    }

    @Override
    @Transactional
    public boolean deleteCategory(Long id) {
        // TODO Auto-generated method stub
        return super.getMaterialsCategoryDAO().remove(id)>0;
    }
}
