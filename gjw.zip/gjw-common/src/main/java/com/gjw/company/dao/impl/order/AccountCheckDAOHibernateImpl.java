package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IAccountCheckDAO;
import com.gjw.utils.StringUtil;
import com.gjw.vo.order.PaymentRecordResponseVO;

@Component("accountCheckDAOHibernateImpl")
public class AccountCheckDAOHibernateImpl extends AbstractDAOHibernateImpl
		implements IAccountCheckDAO {

	@Override
	protected Class getEntityClass() {
		return null;
	}

	/**
	 * 统计支付的总额
	 */
	@Override
	public Long sumFinance(PaymentRecordResponseVO record) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select coalesce(sum(r.payAmt),0) ");
		assembleQuery(record, hql, param);
		
		return (Long) super.queryByParam(hql.toString(), param);
	}

	protected void assembleQuery(PaymentRecordResponseVO record,
			StringBuffer hql, List<Object> param) {
		hql.append("from User u,GesCityOperator c,GesShop s,Goods g,MultiplePayment m,GesOrder o,GesPaymentRecordResponse r ");
		hql.append("where u.id=o.buyer.id and c.id=o.operator.id and s.id=o.shop.id and g.id=o.goods.id and o.id=m.gesOrder.id and r.cmpySequenceId=m.serialPayNo "
				+ "and o.id=r.gesOrder.id ");
		if(StringUtil.notEmpty(record.getHadSettled())&&!record.getHadSettled().equals("a")){
			hql.append(" and r.hadSettled=? ");
			param.add(record.getHadSettled());
		}
		if(StringUtil.notEmpty(record.getOrderCode())){
			hql.append(" and o.code=? ");
			param.add(record.getOrderCode());
		}
		if(StringUtil.notEmpty(record.getPayType())){
			hql.append(" and r.payType=? ");
			param.add(record.getPayType());
		}
		if(record.getOperateList().size()>0){
			hql.append(" and r.operateType in (? ");
			param.add(record.getOperateList().get(0));
			for(int i=1;i<record.getOperateList().size();i++){
				hql.append(",?");
				param.add(record.getOperateList().get(i));
			}
			hql.append(") ");
		}
		if(StringUtil.notEmpty(record.getStartDate())){
			hql.append(" and DATE_FORMAT(r.settleDate,'%Y-%m-%d')>=?");
			param.add(record.getStartDate());
		}
		if(StringUtil.notEmpty(record.getEndDate())){
			hql.append(" and DATE_FORMAT(r.settleDate,'%Y-%m-%d')<? ");
			param.add(record.getEndDate());
		}
	}

	/**
	 * 统计符合条件的记录总数
	 */
	@Override
	public Long countFinance(PaymentRecordResponseVO record) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select count(1) ");
		assembleQuery(record, hql, param);
		return (Long) super.queryByParam(hql.toString(), param);
	}

	/**
	 * 分页获取支付记录信息
	 */
	@Override
	public List<PaymentRecordResponseVO> pageFinance(
			PaymentRecordResponseVO record) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select o.id as orderId,o.code as orderCode,g.name as goodsName,CONCAT(o.totalAmount,'') as totalAmount,"
				+ "o.orderStatus as nowStatus,m.orderStatus as orderStatus,m.paySuccessTime as createdDatetime,m.money as payMoney,"
				+ "r.payAmt as payAmt,r.cmpySequenceId as cmpySequenceId,r.payType as payType,r.operateType as operateType,"
				+ "s.name as shopName,c.companyName as operatorName,s.accountNo as bankNum,o.mobile as customerMobile,"
				+ "r.hadSettled as hadSettled,r.settleDate as settleDate,u.username as buyerName ");
		assembleQuery(record, hql, param);
		hql.append(" order by m.paySuccessTime desc ");
		return (List<PaymentRecordResponseVO>) super.findByPageCallBack(hql.toString(), null, param, record, Transformers.aliasToBean(PaymentRecordResponseVO.class));
	}
	
	

}
