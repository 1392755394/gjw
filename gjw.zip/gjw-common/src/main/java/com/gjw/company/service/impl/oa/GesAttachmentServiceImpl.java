package com.gjw.company.service.impl.oa;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.TaskConstant;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.error.BECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.common.helper.GlobEnv;
import com.gjw.company.dao.oa.IGesAttachmentDAO;
import com.gjw.company.service.oa.IGesAttachmentService;
import com.gjw.entity.oa.GesAttachment;
import com.gjw.entity.user.User;
import com.gjw.utils.DateUtil;

/**
 * 附件处理
 * 
 * @author User
 * 
 */
@Component("gesAttachmentServiceImpl")
public class GesAttachmentServiceImpl extends AbstractServiceImpl implements
		IGesAttachmentService {
	
	@Resource(name="gesAttachmentHibernateImpl")
	private IGesAttachmentDAO gesAttachmentDAO;
	
	public IGesAttachmentDAO getGesAttachmentDAO() {
		return gesAttachmentDAO;
	}

	public void setGesAttachmentDAO(IGesAttachmentDAO gesAttachmentDAO) {
		this.gesAttachmentDAO = gesAttachmentDAO;
	}

	/**
	 * 上传附件
	 */
	@Override
	@Transactional
	public GesAttachment uploadAttachment(Long taskId, User user,
			MultipartFile file) {
		
		// 判断文件是否是图片
		int fileType = TaskConstant.FILE_TYPE_FILE;
		BufferedImage bi;
		try {
			bi = javax.imageio.ImageIO.read(file.getInputStream());
			if (bi != null) {
				// 文件是图片
				fileType = TaskConstant.FILE_TYPE_PIC;
			}
		} catch (IOException e) {
		}

		// 获取相对目录路径
		String relaDirPath = getRelaDirPath("files");

		// 获取绝对目录路径
		String _dirPath = GlobEnv.get("store.file") + "/" + relaDirPath;

		// 获取新文件名(时间+上传文件名)
		String _fileName = new Date().getTime() + (int) (Math.random() * 900)
				+ 100 + "."
				+ FilenameUtils.getExtension(file.getOriginalFilename());

		try {

			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(
					_dirPath + "/" + _fileName));
		} catch (IOException e) {

			throw new ErrorCodeException(BECode.store_300002, e.getMessage(), e);
		}

		// 以下保存文件上传记录
		GesAttachment attachment = new GesAttachment();
		// 附件所属节点的id
		if (taskId != null && taskId != 0) {
			// 在任务的文件管理中上传时有节点id
			attachment.setRelationId(taskId);
			// 附件所属节点的类型:任务或者项目
			attachment.setRelationType(TaskConstant.RELATION_TYPE_TASK);
		} else {
			// 任务发布、交流时未有节点id
			attachment.setRelationId(0l);
		}
		// 文件名称
		attachment.setFileName(file.getOriginalFilename());
		// 文件存储路径
		attachment.setFilePath(relaDirPath + "/" + _fileName);
		// 获取登录用户id，即上传人id
		attachment.setUser(user);
		// 文件大小
		attachment.setFileSize((int) file.getSize() / 1024);
		// 文件类型
		attachment.setFileType(fileType);
		// 是否已删除:未删除
		attachment.setInvalid(TaskConstant.DEL_FLAG_NO);
		// 下载次数
		attachment.setDownloadNum(0);
		// 保存文件上传记录，并取得文件ID
		getGesAttachmentDAO().add(attachment);

		return attachment;
	}
	
	/**
	 * 返回相对目录路径 如 2014/06
	 * 
	 * @param rDir
	 * @return
	 */
	private String getRelaDirPath(String rDir) {
		
		//从StoreController拷贝而来
		
		String fDir = DateUtil.formatDateTime(new Date(), "yyyy");
		String sDir = DateUtil.formatDateTime(new Date(), "MM");

		File rDirPath = new File(GlobEnv.get("store.file") + "/" + rDir);
		if (!rDirPath.exists()) {
			rDirPath.mkdir();
		}

		File fDirPath = new File(rDirPath.getPath() + "/" + fDir);
		if (!fDirPath.exists()) {
			fDirPath.mkdir();
		}

		File sDirPath = new File(fDirPath.getPath() + "/" + sDir);
		if (!sDirPath.exists()) {
			sDirPath.mkdir();
		}

		return rDir + "/" + fDir + "/" + sDir;
	}

    @Override
    @Transactional(readOnly=true)
    public List<GesAttachment> listAttachmentByRelationId(GesAttachment attachment) {
        List<GesAttachment> list = getGesAttachmentDAO().listAttachmentByRelationId(attachment);
        for (GesAttachment r: list) {
            Hibernate.initialize(r.getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
        }
        
        return list;
    }

    @Override
    @Transactional
    public boolean downloadAttachment(Long attachmentID) {
        return getGesAttachmentDAO().downloadAttachment(attachmentID);
    }

    @Override
    @Transactional
    public boolean deleteAttachment(Long attachmentID) {
        return getGesAttachmentDAO().deleteAttachment(attachmentID);
    }

}
