package com.gjw.company.service.collection;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.collection.WebCollectionItem;

/**
 * 收藏管理
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月25日 下午2:06:21
 * 
 */
public interface IWebCollectionItemService extends IService {

    /**
     * 方法描述：收藏
     * 
     * @param record
     *            收藏对象
     * @return 是否成功
     * @author zhaoyonglian 15-6-19
     */
    boolean delete(Long id);

    /**
     * 方法描述：收藏
     * 
     * @param record
     *            收藏对象
     * @return 是否成功
     * @author zhaoyonglian 15-6-19
     */
    boolean insert(WebCollectionItem record);

    /**
     * 方法描述：查看收藏详情
     * 
     * @param id
     *            收藏id
     * @return 收藏对象
     * @author zhaoyonglian 15-6-19
     */
    // WebCollectionItem get(Long id);

    WebCollectionItem selectTopic(WebCollectionItem collection);

    /**
     * 方法描述：修改收藏信息
     * 
     * @param record
     *            收藏对象
     * @return 是否成功
     * @author zhaoyonglian 15-6-19
     */
    boolean update(WebCollectionItem record);

    /**
     * 方法描述：查看收藏列表
     * 
     * @param collection
     *            收藏条件
     * @return 收藏列表
     * @author zhaoyonglian 15-6-19
     */
    List<WebCollectionItem> collectList(WebCollectionItem collection);

    boolean deleteByContent(WebCollectionItem collection);

    // void deleteByMember(WebCollectionItem men);

    Long countByContent(WebCollectionItem collection);

    /**
     * @Description
     * @param collection
     * @param param
     * @return
     * @author chenghao
     * @date Sep 14, 2015 6:11:32 PM
     */
    List<WebCollectionItem> collectListWithPage(WebCollectionItem collection);
}
