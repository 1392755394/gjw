package com.gjw.company.dao.user;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Permission;

import java.util.List;

/**
 * Created by Epee on 2016/3/3.
 */
public interface IPermissionDAO extends IDAO {

    List<String> loadAllPermissionNames(Long userId);
    
    Permission getByName(String name);

}
