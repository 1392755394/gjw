package com.gjw.company.dao.label;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.label.WebLabel;


public interface IWebLabelDAO extends IDAO{
    
    /**
     * 
    * @Description  通过id得到
    * @param id
    * @return
    * @author qingye   
    * @date Dec 19, 2015 10:42:42 AM
     */
    WebLabel get(Long id);
   
    /**
     * 
    * @Description   通过属性得到所有的parent为0的一级标签
    * @param peroperty
    * @return
    * @author qingye
    * @date Dec 19, 2015 10:42:35 AM
     */
    List<WebLabel> listParentByPeroperty(Dictionary peroperty);
    
    /**
     * 
    * @Description  通过父id得到所有的子标签
    * @param parentId
    * @return
    * @author qingye   
    * @date Dec 19, 2015 11:02:50 AM
     */
    List<WebLabel> listChildByParent(Long parentId);
    
    
    
    /**
     * 
    * @Description  通过parent批量更新peropertyType
    * @param peroperty
    * @param parentId
    * @author qingye   
    * @date Dec 19, 2015 11:23:26 AM
     */
    void updatePeropertyByParent(Dictionary peroperty, Long parentId);

    /** 
    * @Description  
    * @param label
    * @author qingye   
    * @date Dec 19, 2015 4:11:49 PM
    */
    
    List<WebLabel> page(WebLabel label);

    /** 
    * @Description  
    * @param label
    * @author qingye   
    * @date Dec 19, 2015 4:11:58 PM
    */
    
    long count(WebLabel label);
    
    /**
     * 
    * @Description  重新使用该标签
    * @param id
    * @author qingye   
    * @date Dec 22, 2015 3:40:00 PM
     */
    void reuse(Long id);
    
}
