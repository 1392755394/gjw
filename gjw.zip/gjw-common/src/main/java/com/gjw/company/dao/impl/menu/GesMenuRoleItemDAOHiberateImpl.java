package com.gjw.company.dao.impl.menu;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.menu.IGesMenuRoleItemDAO;
import com.gjw.entity.menu.GesMenuRoleItem;

@Component("gesMenuRoleItemDAOHiberateImpl")
public class GesMenuRoleItemDAOHiberateImpl extends AbstractDAOHibernateImpl
        implements IGesMenuRoleItemDAO {
    
    @Override
    protected Class getEntityClass() {
         return GesMenuRoleItem.class;
    }

    @Override
    public long create(GesMenuRoleItem menuRoleItem) {
        super.add(menuRoleItem);
        return menuRoleItem.getId();
    }
    
    @Override
    public boolean update(GesMenuRoleItem menuRoleItem) {
        return false;
    }
    
    @Override
    public boolean delete(GesMenuRoleItem menuRoleItem) {
        super.getHibernateTemplate().delete(menuRoleItem);
        return true;
    }

    @Override
    public GesMenuRoleItem getItemByMenuIdAndRoleID(GesMenuRoleItem menuRoleItem) {
        List<GesMenuRoleItem >  list = (List<GesMenuRoleItem>)super.getHibernateTemplate().find(" from GesMenuRoleItem where role.id = ? and menu.id = ?" ,menuRoleItem.getRole().getId(), menuRoleItem.getMenu().getId());
        if (list != null && list.size() > 0){
            return list.get(0);
        }else {
            return null;
        }
    }

}
