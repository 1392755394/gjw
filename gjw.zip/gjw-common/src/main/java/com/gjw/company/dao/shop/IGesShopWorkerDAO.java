package com.gjw.company.dao.shop;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.shop.GesShopWorker;

public interface IGesShopWorkerDAO extends IDAO{
    public GesShopWorker listByID(Long id);

    public boolean updateGesShopWorker(GesShopWorker model);

    public boolean createGesShopWorker(GesShopWorker model);
    
    public long count(GesShopWorker model);
    
    public List<GesShopWorker> listByGesShopWorker(GesShopWorker model);
}
