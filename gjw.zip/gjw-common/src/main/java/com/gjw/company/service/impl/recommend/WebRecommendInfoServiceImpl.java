package com.gjw.company.service.impl.recommend;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.recommend.IWebRecommendInfoDAO;
import com.gjw.company.dao.recommend.IWebRecommendPositionDAO;
import com.gjw.company.service.recommend.IWebRecommendInfoService;
import com.gjw.entity.recommend.WebRecommendInfo;

@Component("webRecommendInfoServiceImpl")
public class WebRecommendInfoServiceImpl implements IWebRecommendInfoService {

    @Autowired
    private IWebRecommendInfoDAO dao;
    
    @Autowired
    private IWebRecommendPositionDAO positonDao;

    @Override
    @Transactional(readOnly = true)
    public WebRecommendInfo getById(Long id) {
        // TODO Auto-generated method stub
        WebRecommendInfo info = dao.getById(id);
        if(null != info){
            info.getImage().getPath();
        }
        return info;
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebRecommendInfo> pageByNameAndCode(WebRecommendInfo info) {
        // TODO Auto-generated method stub
        List<WebRecommendInfo> list = dao.pageByNameAndCode(info);
        if(null != list && list.size()>0){
            for (WebRecommendInfo webRecommendInfo : list) {
                Hibernate.initialize(webRecommendInfo.getImage());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByNameAndCode(WebRecommendInfo info) {
        // TODO Auto-generated method stub
        return dao.countByNameAndCode(info);
    }

    @Override
    @Transactional
    public boolean insert(WebRecommendInfo entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public boolean update(WebRecommendInfo entity) {
        // TODO Auto-generated method stub
        return dao.updateInfo(entity);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

}
