package com.gjw.company.dao.recommend;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.recommend.WebRecommendPosition;

/**
 * 
* @Description: 问题dao接口类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:28:30
*
 */
public interface IWebRecommendPositionDAO extends IDAO {

	/**
	 * 
	* @Description  推荐位详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:13:28
	 */
	public WebRecommendPosition getById(Long id);
	
	/**
	 * 
	* @Description  分页查询，推荐位名字或者代码
	* @param position
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:13:44
	 */
	public List<WebRecommendPosition> pageByNameAndCode(WebRecommendPosition position);
	
	/**
	 * 
	* @Description  总数
	* @param position
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:14:06
	 */
	public Long countByNameAndCode(WebRecommendPosition position);
	
	/**
	 * 
	* @Description  修改
	* @param position
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:14:18
	 */
	public boolean updatePosition(WebRecommendPosition position);
	
	/**
	 * 
	* @Description  有效推荐位列表
	* @param invalid
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月18日 下午1:32:45
	 */
	public List<WebRecommendPosition> listByInvalid(Integer invalid);
}
