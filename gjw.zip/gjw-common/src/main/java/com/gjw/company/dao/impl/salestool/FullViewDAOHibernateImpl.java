package com.gjw.company.dao.impl.salestool;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.IFullViewDAO;
import com.gjw.entity.salestool.FullView;
import com.gjw.utils.StringUtil;

@Component("fullViewDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class FullViewDAOHibernateImpl extends AbstractDAOHibernateImpl implements IFullViewDAO{

    @Override
    public FullView listByID(Long id) {
        // TODO Auto-generated method stub
        return (FullView) super.get(id);
    }

    @Override
    public boolean updateFullView(FullView model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createFullView(FullView model) {
        if (model.getBuilding() != null && model.getBuilding().getId() == null){
            model.setBuilding(null);
        }
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(FullView model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from FullView item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and item.status=?";
            params.add(model.getStatus());
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql = hql + " and item.name=?";
            params.add(model.getName());
        }
        hql = hql + " order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<FullView> listByFullView(FullView model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from FullView item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and item.status=?";
            params.add(model.getStatus());
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql = hql + " and item.name like ?";
            params.add(super.getFuzzyCondition(model.getName()));
        }
        hql = hql + " order by item.createdDatetime desc";
        return (List<FullView>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return FullView.class;
    }

    @Override
    public List<FullView> listByCaptcha(String captcha) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from FullView item where item.invalid=0 ");
        hql.append(" and item.building.id in ( select ca.building.id from Captcha as ca where ca.invalid = 0 and ca.captcha ='"+captcha+"' )");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        return query.list();
    }

}
