package com.gjw.company.dao.impl.salestool;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.IIpadAdvertDAO;
import com.gjw.entity.salestool.Captcha;
import com.gjw.entity.salestool.IpadAdvert;
import com.gjw.utils.StringUtil;

@Component("ipadAdvertDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class IpadAdvertDAOHibernateImpl extends AbstractDAOHibernateImpl implements IIpadAdvertDAO{

    @Override
    public IpadAdvert listByID(Long id) {
        // TODO Auto-generated method stub
        return (IpadAdvert) super.get(id);
    }

    @Override
    public boolean updateIpadAdvert(IpadAdvert model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createIpadAdvert(IpadAdvert model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(IpadAdvert model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public List<IpadAdvert> listByIPadAdvert() {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from IpadAdvert where invalid = 0");
        hql.append("order by id desc");
         return (List<IpadAdvert>) super.findByPageCallBack(hql.toString(), "", null, new IpadAdvert(), null);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return IpadAdvert.class;
    }

}
