package com.gjw.company.dao.comment;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.comment.WebCommentItem;

/**
 * 
* @Description: 评论dao接口类
* @author  zhaoyonglian
* @date 2015年12月26日 下午3:47:51
*
 */
public interface IWebCommentItemDAO extends IDAO {
	/**
	 * 
	* @Description  分页列表，搜索条件：字典，内容，废弃，创建者
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月26日 下午3:49:56
	 */
	public List<WebCommentItem> pageByCondition(WebCommentItem item);
	
	/**
	 * 
	* @Description  总数
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月26日 下午3:50:34
	 */
	public Long countByCondition(WebCommentItem item);
	
}
