package com.gjw.company.dao.impl.collection;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.collection.IWebCollectionItemDAO;
import com.gjw.entity.collection.WebCollectionItem;

/**
 * 收藏管理
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月25日 下午1:36:25
 * 
 */
@Component("webCollectionItemDAOHiberanteImpl")
public class WebCollectionItemDAOHiberanteImpl extends AbstractDAOHibernateImpl implements IWebCollectionItemDAO {
    @Override
    protected Class<WebCollectionItem> getEntityClass() {
        return WebCollectionItem.class;
    }

    @Override
    public boolean insert(WebCollectionItem record) {
        return super.saveResultBoolean(record);
    }

    @Override
    public WebCollectionItem selectTopic(WebCollectionItem collection) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from  WebCollectionItem where invalid=0 ");
        if (collection.getInfo() != null) {
            hql.append(" and info=?");
            list.add(collection.getInfo());
        }
        if (collection.getUser() != null && collection.getUser().getId() > 0) {
            hql.append(" and user.id=?");
            list.add(collection.getUser().getId());
        }
        if (collection.getPropertyType() != null && collection.getPropertyType().getId() > 0) {
            hql.append(" and propertyType.id=?");
            list.add(collection.getPropertyType().getId());
        }
        if (collection.getId() != null) {
            hql.append(" and id=?");
            list.add(collection.getId());
        }
        return (WebCollectionItem) super.queryByParam(hql.toString(), list);
    }

    @Override
    public boolean update(WebCollectionItem record) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update WebCollectionItem set invalid=1 where invalid=0");
        if (record.getUser() != null && record.getUser().getId() != null) {
            hql.append(" and user.id=?");
            list.add(record.getUser().getId());
        }
        if (record.getPropertyType() != null && record.getPropertyType().getId() != null) {
            hql.append(" and propertyType.id=?");
            list.add(record.getPropertyType().getId());
        }
        if (record.getInfo() != null) {
            hql.append(" and info=?");
            list.add(record.getInfo());
        }
        if (record.getId() != null) {
            hql.append(" and id=?");
            list.add(record.getId());
        }
        return super.updateByParam(hql.toString(), list);
    }

    @Override
    public List<WebCollectionItem> collectList(WebCollectionItem collection) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean deleteByContent(WebCollectionItem collection) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update  WebCollectionItem set invalid=1 where 1=1");
        if (collection.getInvalid() != null ) {
            hql.append(" and invalid=? ");
            list.add(collection.getInvalid());
        }
        if (collection.getUser() != null && collection.getUser().getId() != null) {
            hql.append(" and user.id=? ");
            list.add(collection.getUser().getId());
        }
        if (collection.getPropertyType() != null && collection.getPropertyType().getId() != null) {
            hql.append(" and propertyType.id=? ");
            list.add(collection.getPropertyType().getId());
        }
        if (collection.getId() != null) {
            hql.append(" and id=? ");
            list.add(collection.getId());
        }
        if (collection.getInfo() != null) {
            hql.append(" and info=? ");
            list.add(collection.getInfo());
        }
        return super.updateByParam(hql.toString(), list);
    }

    @Override
    public Long countByContent(WebCollectionItem collection) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from  WebCollectionItem where invalid=0  ");
        if (collection.getUser() != null && collection.getUser().getId() != null) {
            hql.append(" and user.id=? ");
            list.add(collection.getUser().getId());
        }
        if (collection.getPropertyType() != null && collection.getPropertyType().getId() != null) {
            hql.append(" and propertyType.id=? ");
            list.add(collection.getPropertyType().getId());
        }
        if (collection.getInfo() != null) {
            hql.append(" and info=? ");
            list.add(collection.getInfo());
        }
        return super.findByPageCallBackCount(hql.toString(), list);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebCollectionItem> collectListWithPage(WebCollectionItem collection) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from  WebCollectionItem where invalid=0  ");
        if (collection.getUser() != null && collection.getUser().getId() != null) {
            hql.append(" and user.id=? ");
            list.add(collection.getUser().getId());
        }
        if (collection.getPropertyType() != null && collection.getPropertyType().getId() != null) {
            hql.append(" and propertyType.id=? ");
            list.add(collection.getPropertyType().getId());
        }
        if (collection.getInfo() != null) {
            hql.append(" and info=? ");
            list.add(collection.getInfo());
        }
        hql.append(" order by createdDatetime desc");
        return (List<WebCollectionItem>) super.findByPageCallBack(hql.toString(), null, list, collection, null);
    }

}
