package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.erp.IGesErpCodeService;
import com.gjw.entity.erp.GesErpCode;

/**
 * 基础数据同步
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月16日 下午3:52:54
 * 
 */
@Service("gesErpCodeServiceImpl")
public class GesErpCodeServiceImpl extends AbstractServiceImpl implements IGesErpCodeService {

    /**
     * 基础数据分页---总数
     */
    @Override
    @Transactional(readOnly = true)
    public Long count(GesErpCode gesErpCode) {
        return super.getGesErpCodeDAO().count(gesErpCode);
    }

    /**
     * 基础数据分页
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesErpCode> pageByGesErpCode(GesErpCode gesErpCode) {
        List<GesErpCode> list = super.getGesErpCodeDAO().pageByGesErpCode(gesErpCode);
        for (GesErpCode erpCode : list) {
            erpCode.getLastOperater().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
        }
        return list;
    }

}
