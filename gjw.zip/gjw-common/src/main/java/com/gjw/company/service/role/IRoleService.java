package com.gjw.company.service.role;

import java.util.List;

import com.gjw.entity.user.Role;

public interface IRoleService {
    
    public List<Role> listRoles();
    
    public List<Role> listChildRoles(long parentID);
    
    public List<Role> listAvailableParents(long id);
    
    public Role getRoleById(long id);
    
    public boolean delete(Role role);
    
    public long create(Role role);
    
    public boolean update(Role role);

}
