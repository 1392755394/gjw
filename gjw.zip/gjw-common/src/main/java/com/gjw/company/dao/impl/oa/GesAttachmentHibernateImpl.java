package com.gjw.company.dao.impl.oa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesAttachmentDAO;
import com.gjw.entity.oa.GesAttachment;
import com.gjw.utils.StringUtil;
import com.gjw.vo.oa.GesAttachmentVO;

@Component("gesAttachmentHibernateImpl")
public class GesAttachmentHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesAttachmentDAO {

	@Override
	protected Class<?> getEntityClass() {
		return GesAttachment.class;
	}

	@SuppressWarnings("rawtypes")
    @Override
	public int updateAttachmentRelation(Map<String, Object> attachment) {
		// 生成更新的语句
        StringBuffer hql = new StringBuffer();
        hql.append("update GesAttachment ");
        hql.append(" set updatedDatetime = :updatedDatetime,relationId=:relationId,"
        		+ "relationType=:relationType where id in (:id_list) ");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        //修改时间
        query.setParameter("updatedDatetime", new Timestamp(System.currentTimeMillis()));
        query.setParameter("relationId", attachment.get("relationId"));
        query.setParameter("relationType", attachment.get("relationType"));
        // ID列表
        query.setParameterList("id_list", (Collection) attachment.get("attachmentIds"));

        return query.executeUpdate();
	}

	/**
	 * 根据关联的id获取相关的附件
	 * @param attachment
	 * @return
	 */
    @SuppressWarnings("unchecked")
    @Override
	public List<GesAttachmentVO> listAttachmentByRelationId(GesAttachmentVO attachment) {
		StringBuffer hql = new StringBuffer();
		List<Object> param=new ArrayList<Object>();
        hql.append("select a.id as id,a.relationId as relationId,a.fileName as fileName,a.filePath as filePath,");
        hql.append("m.realName as uploadPersonName,a.downloadNum as downloadNum,a.fileSize as fileSize,"
        		+ "a.fileType as fileType,a.createdDatetime as createdDatetime ");
        hql.append(" from GesAttachment a ,UserInfo m ");
        hql.append(" where a.invalid=? and m.type=? and m.user.id=a.user.id and a.relationType=? and a.relationId=? ");
        param.add(false);
        param.add(PlatformEnum.Ges.getObj().getId().intValue());
        param.add(attachment.getRelationType());
        param.add(attachment.getRelationId());
        if(StringUtil.notEmpty(attachment.getSortField())){
        }
        return (List<GesAttachmentVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesAttachmentVO.class));
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<GesAttachment> listAttachmentByRelationId(GesAttachment attachment) {
        String hql = "from GesAttachment a where a.invalid=false and a.relationType=? and a.relationId=? order by a.updatedDatetime desc ";
        return (List<GesAttachment>) super.getHibernateTemplate().find(hql, attachment.getRelationType(),
                attachment.getRelationId());
    }

    @Override
    public boolean downloadAttachment(Long attachmentID) {
        GesAttachment attachment = (GesAttachment) super.get(attachmentID);
        attachment.setDownloadNum(attachment.getDownloadNum() + 1);
        return super.update(attachment) == 1;
    }

    @Override
    public boolean deleteAttachment(Long attachmentID) {
        return super.remove(attachmentID) > 0;
    }
	
	

}
