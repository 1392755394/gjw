package com.gjw.company.service.impl.customer;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.customer.IGesAppointmentService;
import com.gjw.entity.customer.GesAppointment;
import com.gjw.utils.DateUtil;
import com.gjw.utils.StringUtil;

@Component("gesAppointmentServiceImpl")
public class GesAppointmentServiceImpl extends AbstractServiceImpl implements IGesAppointmentService {
    @Override
    @Transactional(readOnly = true)
    public GesAppointment getById(Long id) {
        // TODO Auto-generated method stub
        GesAppointment appointment = super.getGesAppointmentDAO().getById(id);
        if (StringUtil.notEmpty(appointment)) {
            appointment.setAppointTimeStr(DateUtil.format(appointment.getAppointmentTime()));
        }
        return appointment;
    }

    @Override
    @Transactional
    public boolean updateAppointment(GesAppointment record) {
        // TODO Auto-generated method stub
        return super.getGesAppointmentDAO().updateAppointment(record) > 0;
    }

    @Override
    @Transactional
    public boolean createAppointment(GesAppointment record) {
        // TODO Auto-generated method stub
        return super.getGesAppointmentDAO().saveAppoint(record);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesAppointment> listByBuildingId(Long buildingId) {
        // TODO Auto-generated method stub
        List<GesAppointment> list = super.getGesAppointmentDAO().listByBuildingId(buildingId);
        if (null != list && list.size() > 0) {
            for (GesAppointment gesAppointment : list) {
                gesAppointment.setAppointTimeStr(DateUtil.format(gesAppointment.getAppointmentTime()));
            }
        }
        return list;
    }

}
