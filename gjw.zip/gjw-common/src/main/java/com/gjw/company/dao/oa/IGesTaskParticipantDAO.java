package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.vo.oa.GesTaskParticipantVO;
import com.gjw.vo.oa.UserVO;

/**
 * 任务项目参与人操作DAO
 * @author jjw
 *
 */
public interface IGesTaskParticipantDAO extends IDAO {
	
	/**
	 * 插入多条参与人记录
	 * @param list
	 */
	public int createGesTaskParticipant(List<GesTaskParticipant> list);
	
	/**
	 * 查询用户的真实姓名
	 */
	public UserVO queryUserByUserId(Long id);
	
	public List<GesTaskParticipantVO> queryMemberInfoByTaskId(Long taskId);
	
	/**
	 * 跟新参与人任务的待办状态
	 * @param taskParticipant
	 * @return
	 */
	public int updateGesTaskParticipantByIsHandle(GesTaskParticipant taskParticipant);
	
	/**
	 * 更新登录用户的交流id
	 * @param taskParticipant
	 * @return
	 */
	public int updateParticipantCommunicationId(GesTaskParticipant taskParticipant);
    
    /**
     * 任务成员删除
     * @param taskParticipant
     * @return
     */
    public boolean delMember(GesTaskParticipant taskParticipant);
    
    /**
     * 批量插入参与成员信息
     * @param nameSpace
     * @param sqlId
     * @param list
     * @return
     */
    public int batchSaveTaskParticipant(List<GesTaskParticipant> list);
    
    /**
     * 查询登录用户是否是某一个任务的创建人或者负责人
     * @param taskId
     * @param userId
     * @return
     */
    public List<GesTaskParticipantVO> getMemberInfo(long taskId, long userId);
    
    /**
     * 通过任务id和用户id查询成员信息
     * @param taskId
     * @param userId
     * @return
     */
    public List<GesTaskParticipantVO> getMemberByIdAndUserid(long taskId,long userId);
    
    /**
     * 根据id查询参与人信息
     * @param id
     * @return
     */
    public GesTaskParticipant getTaskParticipant(Long id);

    /**
     * 根据用户id 任务id 更新 已办 or 未办
     * @param taskId
     * @param isDeal
     * @param userId
     * @return
     */
    public boolean updateTaskDeal(Long taskId,Integer isDeal,Long userId);

}
