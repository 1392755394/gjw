package com.gjw.company.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.role.IRoleService;
import com.gjw.entity.user.Role;
import com.gjw.utils.StringUtil;

@Service("roleServiceImpl")
@Transactional
public class RoleServiceImpl extends AbstractServiceImpl implements IRoleService {

    @Override
    public List<Role> listRoles() {
        return this.getRoleDAO().listRoles();
    }

    @Override
    public List<Role> listChildRoles(long parentID) {
        return this.getRoleDAO().listChildRoles(parentID);
    }

    @Override
    public List<Role> listAvailableParents(long id) {
        List<Role> allRoles = listRoles();
        List<Role> allChildRoles = new ArrayList<Role>();
        listAllchildRoles(id, allChildRoles);
        Set<Long> notAvilableIds = new HashSet<Long>();
        for (Role role : allChildRoles) {
            notAvilableIds.add(role.getId());
        }
        notAvilableIds.add(id);
        List<Role> availableParentslist = new ArrayList<Role>();
        for (Role role : allRoles) {
            if (!notAvilableIds.contains(role.getId())){
                availableParentslist.add(role);
            }
        }
        return availableParentslist;
        
    }
    
    private void listAllchildRoles(long parentID, List<Role> roleList){
        List<Role> list =  listChildRoles(parentID);
        roleList.addAll(list);
        for (Role role : list) {
            listAllchildRoles(role.getId(), roleList);
        }
    }

    @Override
    public Role getRoleById(long id) {
        return this.getRoleDAO().getRoleById(id);
    }

    @Override
    public boolean delete(Role role) {
        Role roleObj = getRoleById(role.getId());
        roleObj.setInvalid(true);
        return this.getRoleDAO().update(roleObj);
    }

    @Override
    public long create(Role role) {
        return this.getRoleDAO().create(role);
    }

    @Override
    public boolean update(Role role) {
        Role roleObj = getRoleById(role.getId());
        long previousParentId = roleObj.getParentId();
        if(StringUtil.isNotEmpty(role.getName())){
            roleObj.setName(role.getName());
        }
        if(StringUtil.isNotEmpty(role.getType())){
            roleObj.setType(role.getType());
        }
        if (role.getPermission() != null){
            roleObj.setPermission(role.getPermission());
        }
        if (role.getParentId() != null){
            roleObj.setParentId(role.getParentId());
        }
        boolean result = this.getRoleDAO().update(roleObj);
        if (previousParentId != roleObj.getParentId().longValue()){
            Role previousParentRole = getRoleById(previousParentId);
            List<Role> childRoles = listChildRoles(previousParentId);
            if (childRoles != null && childRoles.size() == 0){
                previousParentRole.setIsLeaf(true);
                this.getRoleDAO().update(previousParentRole);
            }
            Role currentParentRole = getRoleById(role.getParentId());
            if (currentParentRole.getIsLeaf()){
                currentParentRole.setIsLeaf(false);
                this.getRoleDAO().update(currentParentRole);
            }
        }
        return result;
    }

}
