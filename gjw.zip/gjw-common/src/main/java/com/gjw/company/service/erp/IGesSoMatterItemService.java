package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.vo.GesSoMatterVO;

/**
 * <P>
 * 构家网---- 产品包销售订单关联的物料(采购清单)实体
 * <P>
 * 城运商，4s店发起采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月30日 下午2:21:03
 * 
 */
public interface IGesSoMatterItemService extends IService {

    /**
     * 分页查询总数
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2015年12月30日 下午2:32:42
     */
    public Long count(GesSoMatterVO soMatter);

    /**
     * 分页查询
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2015年12月30日 下午2:32:57
     */
    public List<GesSoMatterItem> pageSoMatter(GesSoMatterVO soMatter);

    /**
     * 库存管理
     * <p>
     * 发货清单
     * <p>
     * 发货管理产品总数查询
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2016年1月5日 下午2:59:27
     */
    public Long countRds(GesSoMatterVO soMatter);

    /**
     * 库存管理
     * <p>
     * 发货清单
     * <p>
     * 发货管理产品分页查询
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2016年1月5日 下午2:59:27
     */
    public List<GesSoMatterItem> pageSoMatterRds(GesSoMatterVO soMatter);

    /**
     * 新增销售订单关联物料
     * 
     * @Description
     * @param orderId
     * @param goodsId
     * @return
     * @author gwb
     * @date 2016年1月19日 下午1:25:12
     */
    public boolean saveGesSoMatterItem(Long orderId, Long goodsId, Long cuid);

}
