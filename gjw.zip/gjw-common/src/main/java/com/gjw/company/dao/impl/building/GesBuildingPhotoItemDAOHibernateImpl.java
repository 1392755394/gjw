package com.gjw.company.dao.impl.building;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.building.IGesBuildingPhotoItemDAO;
import com.gjw.entity.building.GesBuildingPhotoItem;

@Component("gesBuildingPhotoItemDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesBuildingPhotoItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesBuildingPhotoItemDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesBuildingPhotoItem.class;
    }

    @Override
    public GesBuildingPhotoItem listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesBuildingPhotoItem) super.get(id);
    }

    @Override
    public boolean updateGesBuildingPhotoItem(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesBuildingPhotoItem(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" form GesBuildingPhotoItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getUser() && null!=model.getUser().getId()){
            hql=hql+" and item.user.id=?";
            params.add(model.getUser().getId());
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesBuildingPhotoItem> listByGesBuildingPhotoItem(
            GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesBuildingPhotoItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getUser() && null!=model.getUser().getId()){
            hql=hql+" and item.user.id=?";
            params.add(model.getUser().getId());
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesBuildingPhotoItem>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
