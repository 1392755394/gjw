package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesPmModel;
import com.gjw.vo.oa.GesProjectTaskVO;

/**
 * 施工项目模板dao接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月6日 
 * 
 */
public interface IGesPmModelDAO extends IDAO {

    /**
     * 查询施工项目模板列表
     * 
     * @Description
     * @return 施工项目模板列表
     * @author guojianbin
     * @date 2016年1月6日 
     */
    public List<GesPmModel> listAll();
    
    /**
     * 根据施工管理项目的id查询任务的阶段和子任务
     * @param taskId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId);
    
    
}
