package com.gjw.company.dao.impl.user;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.dao.user.IAuthenticationDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.User;

/**
 * created by 重剑 on 2015/9/18 0018
 */
@Component("authenticationDAOHibernateImpl")
@Transactional
public class AuthenticationDAOHibernateImpl extends AbstractDAOHibernateImpl implements IAuthenticationDAO {

    @Override
    public Authentication getByLogin(String login, String className) {
        List<?> list = this.getHibernateTemplate().find("from " + className + " where login=?", login.toLowerCase());
        if (list != null && list.size() > 0) {
            Authentication auth = (Authentication) list.get(0);
            return auth;
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Authentication> findByUser(User user) {
        return (List<Authentication>) this.getHibernateTemplate().find("from Authentication where user.id=?",
                user.getId());
    }

    @Override
    public void updateByUser(Authentication auth) {
        this.getHibernateTemplate().bulkUpdate(
                "update " + auth.getClass().getSimpleName() + " set login=? where user.id=?", auth.getLogin(),
                auth.getUser().getId());
    }

    @Override
    protected Class<?> getEntityClass() {
        return Authentication.class;
    }

    @Override
    public void add(AbstractEntity entity) {
        Authentication auth = (Authentication) entity;
        if (this.getByLogin(auth.getLogin(), Authentication.class.getSimpleName()) == null) {
            super.add(entity);
        } else {
            throw new ErrorCodeException(SECode.u_100005);
        }
    }

    @Override
    public Authentication getByLoginTypeAndUser(User user, String className) {
        List<?> list = this.getHibernateTemplate().find("from " + className + " where user.id=?", user.getId());
        if (list.size() > 0) {
            Authentication auth = (Authentication) list.get(0);
            return auth;
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Authentication> listAllForPassword() {
        return (List<Authentication>) this.getHibernateTemplate()
                .find("from Authentication where password is not null");
    }

}
