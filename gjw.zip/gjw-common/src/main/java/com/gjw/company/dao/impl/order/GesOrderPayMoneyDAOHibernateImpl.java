package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IGesOrderPayMoneyDAO;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.vo.order.GesOrderVO;

/**
 * 订单金额统计数据库操作实现类
 * 
 * @author jjw
 * 
 */
@Component("gesOrderPayMoneyDAOHibernateImpl")
public class GesOrderPayMoneyDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesOrderPayMoneyDAO {

    private static final Logger log = LoggerFactory.getLogger(GesOrderPayMoneyDAOHibernateImpl.class);

    @SuppressWarnings("rawtypes")
    @Override
    protected Class getEntityClass() {
        return GesOrderPayMoney.class;
    }

    /**
     * 更新订单支付的金额和次数
     * 
     * @param gesOrderPayMoney
     * @return
     */
    @Override
    public int updateGesOrderPayMoney(GesOrderPayMoney gesOrderPayMoney) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("update GesOrderPayMoney o set o.updatedDatetime=? ");
        param.add(new Date());
        if (gesOrderPayMoney.getEarnestPay() != null && gesOrderPayMoney.getEarnestPay() > 0) {
            hql.append(",o.earnestPay=? ");
            param.add(gesOrderPayMoney.getEarnestPay());
        }
        if (gesOrderPayMoney.getEarnestPayNum() != null && gesOrderPayMoney.getEarnestPayNum() > 0) {
            hql.append(",o.earnestPayNum=? ");
            param.add(gesOrderPayMoney.getEarnestPayNum());
        }
        if (gesOrderPayMoney.getDepositPay() != null && gesOrderPayMoney.getDepositPay() > 0) {
            hql.append(",o.depositPay=? ");
            param.add(gesOrderPayMoney.getDepositPay());
        }
        if (gesOrderPayMoney.getDepositPayNum() != null && gesOrderPayMoney.getDepositPayNum() > 0) {
            hql.append(",o.depositPayNum=? ");
            param.add(gesOrderPayMoney.getDepositPayNum());
        }
        if (gesOrderPayMoney.getBatchPay() != null && gesOrderPayMoney.getBatchPay() > 0) {
            hql.append(",o.batchPay=? ");
            param.add(gesOrderPayMoney.getBatchPay());
        }
        if (gesOrderPayMoney.getBatchPayNum() != null && gesOrderPayMoney.getBatchPayNum() > 0) {
            hql.append(",o.batchPayNum=? ");
            param.add(gesOrderPayMoney.getBatchPayNum());
        }
        hql.append(" where o.gesOrder.id=? ");
        param.add(gesOrderPayMoney.getGesOrder().getId());
        // 改成返回整数值，结果自己判断
        super.updateByParam(hql.toString(), param);
        // 返回上面方法的返回值
        return 0;
    }

    /**
     * <p>
     * 采购管理
     * <p>
     * 采购清单分页查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<GesOrderPayMoney> pageByGesOrderPayMoney(GesOrderVO order) {
        Map<String, Object> map = this.hql(order);
        return (List<GesOrderPayMoney>) super.findByPageCallBack(map.get("hql").toString(), "",
                (List<Object>) map.get("list"), order, null);
    }

    /**
     * 采购管理
     * <p>
     * 采购清单分页查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public Long count(GesOrderVO order) {
        Map<String, Object> map = this.hql(order);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));

    }

    /**
     * 采购管理
     * <p>
     * 采购清单分页查询---hql
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2015年12月26日 下午4:16:50
     */
    private Map<String, Object> hql(GesOrderVO order) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesOrderPayMoney where invalid=0 ");
        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }

    @Override
    public GesOrderPayMoney getGesOrderPayMoneyByOrderId(Long id) {

        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesOrderPayMoney where invalid=0  and gesOrder.id=?");
        list.add(id);
        return (GesOrderPayMoney) super.queryByParam(hql.toString(), list);
    }

	@Override
	public void addGesOrderPayMoney(GesOrderPayMoney orderPay) {
		super.add(orderPay);
	}

	@Override
	public int updateOrderPay(GesOrderPayMoney gesOrderPayMoney) {
		StringBuffer hql = new StringBuffer();
		List<Object> param = new ArrayList<Object>();
        hql.append("update GesOrderPayMoney o set o.updatedDatetime=? ");
        param.add(new Date());
        if (gesOrderPayMoney.getEarnestPay() != null && gesOrderPayMoney.getEarnestPay() > 0) {
            hql.append(",o.earnestPay=o.earnestPay+? ");
            param.add(gesOrderPayMoney.getEarnestPay());
        }
        if (gesOrderPayMoney.getEarnestPayNum() != null && gesOrderPayMoney.getEarnestPayNum() > 0) {
            hql.append(",o.earnestPayNum=o.earnestPayNum+? ");
            param.add(gesOrderPayMoney.getEarnestPayNum());
        }
        if (gesOrderPayMoney.getDepositPay() != null && gesOrderPayMoney.getDepositPay() > 0) {
            hql.append(",o.depositPay=o.depositPay+? ");
            param.add(gesOrderPayMoney.getDepositPay());
        }
        if (gesOrderPayMoney.getDepositPayNum() != null && gesOrderPayMoney.getDepositPayNum() > 0) {
            hql.append(",o.depositPayNum=o.depositPayNum+? ");
            param.add(gesOrderPayMoney.getDepositPayNum());
        }
        if (gesOrderPayMoney.getBatchPay() != null && gesOrderPayMoney.getBatchPay() > 0) {
            hql.append(",o.batchPay=o.batchPay+? ");
            param.add(gesOrderPayMoney.getBatchPay());
        }
        if (gesOrderPayMoney.getBatchPayNum() != null && gesOrderPayMoney.getBatchPayNum() > 0) {
            hql.append(",o.batchPayNum=o.batchPayNum+? ");
            param.add(gesOrderPayMoney.getBatchPayNum());
        }
        hql.append(" where o.gesOrder.id=? ");
        param.add(gesOrderPayMoney.getGesOrder().getId());
		
		return updateByHql(hql.toString(), param);
	}
    
	public int updateByHql(String hql, List<Object> list) {
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql);
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.executeUpdate();
    }

	/**
	 * 根据订单id查询支付的金额信息
	 */
	@Override
	public GesOrderPayMoney queryOrderPayMoneyByOrderId(Long orderId) {
		StringBuffer hql = new StringBuffer();
		List<Object> param = new ArrayList<Object>();
		hql.append("from GesOrderPayMoney m where m.invalid=? and m.gesOrder.id=? ");
		param.add(false);
		param.add(orderId);
		return (GesOrderPayMoney) queryByParam(hql.toString(), param);
	}
    
	public Object queryByParam(String hql, List<Object> list) {
        List<Object> result=(List<Object>) super.findByListCallBack(hql, null, list, null);
        if(result!=null && result.size()>0){
        	return result.get(0);
        }else{
        	return null;
        }
    }
    
}
