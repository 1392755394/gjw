package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesPoMain;
import com.gjw.vo.GesPoMainVO;

/**
 * 采购----销售
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 下午2:35:31
 * 
 */
public interface IGesPoMainService extends IService {
    /**
     * 销售订单查询
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月10日 下午2:49:47
     */
    public List pageByPoMain(GesPoMainVO poMain);

    /**
     * 分页总数
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月12日 下午2:51:04
     */
    public Long count(GesPoMainVO poMain);

    /**
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月14日 下午3:13:20
     */
    public boolean updateByPoCode(GesPoMain poMain);

    /**
     * 根据采购订单编号 查询采购订单实体
     * 
     * @Description
     * @param poCode
     * @return
     * @author gwb
     * @date 2015年12月16日 下午1:27:28
     */
    public GesPoMain getByGesPoMain(GesPoMain poMain);

    /**
     * 保存采购订单
     * 
     * @Description
     * @param poMain
     * @author gwb
     * @date 2015年12月31日 下午2:21:04
     */
    public void create(GesPoMain poMain);

    /**
     * 销售出库同步
     * 
     * @Description
     * @param po
     * @return
     * @author gwb
     * @date 2016年1月12日 下午3:24:15
     */
    public GesPoMain getByGesPoMainBySynch(GesPoMain po);

}
