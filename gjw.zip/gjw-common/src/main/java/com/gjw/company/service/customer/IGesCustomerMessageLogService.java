package com.gjw.company.service.customer;

import java.util.List;
import com.gjw.base.service.IService;
import com.gjw.entity.customer.GesCustomerMessageLog;

public interface IGesCustomerMessageLogService extends IService{
    public GesCustomerMessageLog listByID(Long id);

    public boolean updateGesCustomerMessageLog(GesCustomerMessageLog model);

    public boolean createGesCustomerMessageLog(GesCustomerMessageLog model);
    
    public List<GesCustomerMessageLog> listByGesCustomerMessageLog(GesCustomerMessageLog model);
    
    public long count(GesCustomerMessageLog model);

    List<GesCustomerMessageLog> listByGesCustomerMessageLogItem(
            GesCustomerMessageLog model);
}
