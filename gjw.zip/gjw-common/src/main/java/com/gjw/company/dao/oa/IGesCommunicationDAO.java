package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesCommunication;
import com.gjw.vo.oa.GesCommunicationVO;

public interface IGesCommunicationDAO extends IDAO {
	
	public void createCommunication(GesCommunication communication);
	
	/**
	 * 统计任务的交流数目
	 * @param gesCommunicationVO
	 * @return
	 */
	public Long countCommunicationByTaskId(GesCommunicationVO gesCommunicationVO);
	
	/**
	 * 根据订单id查询交流
	 * @param gesCommunicationVO
	 * @return
	 */
	public List<GesCommunicationVO> queryCommunicationByTaskId(GesCommunicationVO gesCommunicationVO);
	
	/**
	 * 根据任务的id更新任务的交流id
	 * @param communication
	 * @return
	 */
	public int updateTaskCommunicationIdById(GesCommunication communication);
	
	/**
	 * 根据交流的id删除交流信息
	 * @param communicationId
	 * @return
	 */
	public int deleteCommunicationById(GesCommunication communication);
    
    /**
     * 根据交流的id查询交流
     * @param communicationId
     * @return
     */
    public GesCommunication queryById(Long communicationId);
    
    public int updateTaskCommunicationIdToMax(GesCommunication communication);
    
    /**
     * 根据任务id查询交流id
     * @param taskId
     * @return
     */
    public List<Long> queryCommunicationIdByTaskId(Long taskId);

}
