package com.gjw.company.service.impl.user;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.user.IDeptService;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;
import com.gjw.utils.StringUtil;

/**
 * 部门service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月9日
 * 
 */
@Component("deptServiceImpl")
public class DeptServiceImpl extends AbstractServiceImpl implements IDeptService {

    @Override
    @Transactional(readOnly = true)
    public List<Dept> listDeptByParentId(long parentId) {
        return super.getDeptDAO().listDeptByParentId(parentId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Dept> listDepts() {
        return super.getDeptDAO().listDepts();
    }

    @Override
    @Transactional
    public long create(Dept dept) {
        return super.getDeptDAO().create(dept);
    }

    @Override
    @Transactional
    public boolean update(Dept dept) {
        return super.getDeptDAO().update(dept);
    }

    @Override
    @Transactional
    public boolean delete(Dept dept) {
        return super.getDeptDAO().delete(dept);
    }

    @Override
    @Transactional
    public void createDeptUser(DeptUser dept) {
        this.getDeptUserDAO().add(dept);
    }

    @Override
    @Transactional
    public void updateDeptUser(DeptUser dept) {
        DeptUser tmp = this.getDeptUserDAO().get(dept.getId());
        StringUtil.copyProperties(dept, tmp);
        this.getDeptUserDAO().update(tmp);
    }

    @Override
    @Transactional
    public void deleteDeptUser(DeptUser dept) {
        this.getDeptUserDAO().delete(dept.getId());
    }

    /**
     * 基础数据同步--部门同步
     */
    @Override
    @Transactional(readOnly = true)
    public List<Dept> listDeptForSynch() {
        List<Dept> list = super.getDeptDAO().listDeptForSynch();
        for (Dept obj : list) {
            if (obj.getPropertyType() != null && obj.getPropertyType().getId() > 0) {
                obj.getPropertyType().getText();
            }
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DeptUser> listDeptUserForSynch() {
        List<DeptUser> list = super.getDeptDAO().listDeptUserForSynch();
        for (DeptUser deptUser : list) {
            deptUser.getUser().initPlatformUserInfo(PlatformEnum.Ges);
            deptUser.getDept().getCode();
            if (deptUser.getSynchType() != null) {
                deptUser.getSynchType().getText();
            }
        }
        return list;
    }
}
