package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesPoMain;
import com.gjw.vo.GesPoMainVO;

/**
 * 销售--------采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 下午2:40:55
 * 
 */
public interface IGesPoMainDAO extends IDAO {

    /**
     * 销售订单分页查询
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月10日 下午3:27:30
     */
    public List pageByPoMain(GesPoMainVO poMain);

    /**
     * 分页总数
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月12日 下午2:53:10
     */
    public Long count(GesPoMainVO poMain);

    /**
     * 销售订单 确认订单状态
     * 
     * @Description
     * @param poMain
     * @return
     * @author gwb
     * @date 2015年12月14日 下午3:15:51
     */
    public boolean updateByPoCode(GesPoMain poMain);

    /**
     * 根据poCode 查询GesPoMain
     * 
     * @Description
     * @param poCode
     * @return
     * @author gwb
     * @date 2015年12月17日 下午3:13:06
     */
    public GesPoMain getByGesPoMain(GesPoMain poMain);

    /**
     * 销售同步查询
     * 
     * @Description
     * @param po
     * @return
     * @author gwb
     * @date 2016年1月12日 下午3:25:09
     */
    public GesPoMain getByGesPoMainBySynch(GesPoMain po);

}
