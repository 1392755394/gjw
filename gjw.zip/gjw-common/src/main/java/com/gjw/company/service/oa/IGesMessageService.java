package com.gjw.company.service.oa;

import com.gjw.base.service.IService;
import com.gjw.entity.oa.GesMessage;

/**
 * OA消息service接口
 * @Description: 
 * @author  guojianbin
 * @date 2016年1月16日 
 *
 */
public interface IGesMessageService extends IService {
    
    /**
     * 查询消息提醒
     * @Description  
     * @param userId 用户id
     * @return 消息
     * @author guojianbin   
     * @date 2016年1月16日 
     */
    public GesMessage queryNewMessage(Long userId);
    
    /**
     * 重置消息提醒
     * @Description  
     * @param type 消息类型
     * @param userId 用户id
     * @return 消息
     * @author guojianbin   
     * @date 2016年1月18日 
     */
    public boolean resetNewMessage(int type, Long userId);
    
    /**
     * 增加消息提醒
     * @Description  
     * @param type 消息类型
     * @param userId 用户id
     * @param num 消息条数
     * @return 消息
     * @author guojianbin   
     * @date 2016年1月18日 
     */
    public boolean addNewMessage(int type, Long userId, int num);
}
