/*
 *  - 2016
 */

package com.gjw.company.dao.salestool;
/**
 * @author dabai email:qp(a)goujiawang.com
 */

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.salestool.BuildingSaleConfig;

public interface IBuildingSaleConfigDAO extends IDAO{
	public List<BuildingSaleConfig> pageBuildingSaleConfig(BuildingSaleConfig buildingsaleconfig);
	
	public Long count(BuildingSaleConfig buildingsaleconfig);

	public long create(BuildingSaleConfig buildingsaleconfig);
	
	public boolean update(BuildingSaleConfig buildingsaleconfig);
			
	public BuildingSaleConfig queryByID(long id);
	
	public boolean deletes(String ids);
}

