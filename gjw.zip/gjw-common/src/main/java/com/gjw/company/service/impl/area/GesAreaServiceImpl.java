package com.gjw.company.service.impl.area;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.hibernate.transform.Transformers;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.area.IGesAreaService;
import com.gjw.entity.area.GesArea;
import com.gjw.entity.area.GesCityDredge;
import com.gjw.utils.StringUtil;
import com.gjw.utils.search.AreaTernaryTree;
import com.gjw.vo.GesAreaVO;

@Component("gesAreaServiceImpl")
public class GesAreaServiceImpl extends AbstractServiceImpl implements IGesAreaService{

    @Override
    @Transactional(readOnly=true)
    public GesArea getById(Long id) {
        GesArea area=super.getGesAreaDAO().getById(id);
        Hibernate.initialize(area.getParentArea());
        return area;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesArea> listByParentId(Long parentId) {
        
        if(parentId < 0) return null;
        if(parentId>0){
            List<GesArea>  list =  (List<GesArea>) super.getGesAreaDAO().listByParentId(parentId);
            GesArea model = new GesArea();
            model.setName("不选");
            list.add(0, model);
            return list;
        }else{
            return (List<GesArea>)super.getGesAreaDAO().listByParentId(parentId);
        }
    }

    @Override
    @Transactional(readOnly=true)
    public Map<Object, Object> pageByParentId(GesArea gesArea) {
        
        return getGesAreaDAO().pageByParentId(gesArea);
    }
    
    @Override
    @Transactional(readOnly=true)
    public Map<Object, Object> pageCityByParentId(GesAreaVO area) {
        
        return getGesAreaDAO().pageCityByParentId(area);
    }

    @Override
    @Transactional(readOnly=true)
    public Map<Object, Object> pageCityDredgeByParentId(GesArea area) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    @SuppressWarnings("unchecked")
    @Transactional(readOnly=true)
    public Map<Object, Object> pageCityByAreaVO(GesAreaVO areaVO) {
        
        Map<Object, Object> map = new HashMap<Object, Object>();
        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();  //本函数按照已开通城市排序
     
        selectSb.append("select a.id as provinceId, a.name as provinceName,b.id as cityId, b.name as cityName  ");
        fromSb.append("FROM GesArea a, GesArea b  ");
        whereSb.append(" where a.parentArea.id = 0 and  a.id = b.parentArea.id and b.isCity = 'y'");
        fromSb.append(whereSb);
        
        List<Object> paramList = new ArrayList<Object>();
        if(StringUtil.notEmpty(areaVO.getCityName())){
            fromSb.append(" and b.name = ? ");
            paramList.add(areaVO.getCityName());
        }
        if(StringUtil.notEmpty(String.valueOf(areaVO.getProvinceId()))&&areaVO.getProvinceId()>0){
            fromSb.append(" and a.id = ?");
            paramList.add(areaVO.getProvinceId());
        } 
        List<GesAreaVO> areaVOList = (List<GesAreaVO>) getGesAreaDAO().pageByHql(fromSb.toString(), selectSb.toString(), paramList, areaVO, Transformers.aliasToBean(GesAreaVO.class));
      //fetch count
        long count = getGesAreaDAO().count(areaVO, fromSb.toString(), paramList);
        
        List<GesAreaVO> tem = areaVOList;
        //areaVolist 加入 citydredge
        List<GesCityDredge> cityDredgeList = (List<GesCityDredge>) getGesAreaDAO().ListAllByClass(GesCityDredge.class);
        for (GesAreaVO areaVo : areaVOList) {
            for(GesCityDredge cityDredge : cityDredgeList){
                if((long)areaVo.getCityId()== cityDredge.getCity().getId()){
                    areaVo.setCreatedDatetime(cityDredge.getCreatedDatetime());
                    areaVo.setDredgeId(cityDredge.getId());
                    areaVo.setIsAdd(null==cityDredge.getId()?"n":"y");
                }
            }
        }
        
        map.put("areaList", tem);
        map.put("totalCount", count);
        return map;

    }

    @Override
    @SuppressWarnings("unchecked")
    @Transactional(readOnly=true)
    public Map<Object, Object> pageCountyByAreaVO(GesAreaVO areaVO) {
        
        Map<Object, Object> map = new HashMap<Object, Object>();
        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
//        StringBuffer orderSb = new StringBuffer();  //本函数按照已开通城市排序
        
        selectSb.append("select a.id as provinceId, a.name as provinceName,b.id as cityId, b.name as cityName, c.name as cuntroyName,c.id as cuntroyId  ");
        fromSb.append("FROM GesArea a, GesArea b, GesArea c  ");
        whereSb.append(" where a.parentArea.id = 0 and  a.id = b.parentArea.id and c.parentArea.id = b.id and c.isCity ='n' and b.isCity = 'y' and c.parentArea.id >0 ");
        fromSb.append(whereSb);
                
        List<Object> paramList = new ArrayList<Object>();
        if(StringUtil.notEmpty(areaVO.getCuntroyName())){
            fromSb.append(" and c.name =? ");
            paramList.add(areaVO.getCuntroyName());
        }
        if(StringUtil.notEmpty(String.valueOf(areaVO.getProvinceId()))&&areaVO.getProvinceId()>0){
            fromSb.append(" and a.id = ?");
            paramList.add(areaVO.getProvinceId());
        } 
        if(StringUtil.notEmpty(String.valueOf(areaVO.getCityId()))&&areaVO.getCityId()>0){
            fromSb.append(" and b.id = ?");
            paramList.add(areaVO.getCityId());
        }
        
        List<GesAreaVO> areaVOList = (List<GesAreaVO>) getGesAreaDAO().pageByHql(fromSb.toString(), selectSb.toString(), paramList, areaVO, Transformers.aliasToBean(GesAreaVO.class));
      //fetch count
        long count = getGesAreaDAO().count(areaVO, fromSb.toString(), paramList);
        
        List<GesAreaVO> tem = areaVOList;
        //areaVolist 加入 citydredge
        List<GesCityDredge> cityDredgeList = (List<GesCityDredge>) getGesAreaDAO().ListAllByClass(GesCityDredge.class);
        for (GesAreaVO areaVo : areaVOList) {
            for(GesCityDredge cityDredge : cityDredgeList){
                if((long)areaVo.getCuntroyId()== cityDredge.getCity().getId()){
                    areaVo.setCreatedDatetime(cityDredge.getCreatedDatetime());
                    areaVo.setDredgeId(cityDredge.getId());
                    areaVo.setIsAdd(null==cityDredge.getId()?"n":"y");
                }
            }
        }
        
        map.put("areaList", tem);
        map.put("totalCount", count);
        return map;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesArea> listGesAreaByIsAdded() {
        List<GesArea> list=getGesAreaDAO().listGesAreaByIsAdded();
        for (GesArea gesArea : list) {
            Hibernate.initialize(gesArea.getParentArea());
        }
        return list;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesArea> listByParentAndBuilding(Long parentId) {
        return super.getGesAreaDAO().listByParentAndBuilding(parentId);
    }

    @Override
    @Transactional(readOnly=true)
    @Cacheable(value="cityCache",key="#root.targetClass + #root.methodName")
    public Map<Character, List<GesArea>> listGroupBySpell() {
        Map<Character, List<GesArea>> map=new HashMap<Character, List<GesArea>>();
        List<GesArea> list=super.getGesAreaDAO().getAll("y",null);
        for(GesArea area:list){
            char key=(char)(area.getSpell().charAt(0)-32);
            if(map.containsKey(key)){
                map.get(key).add(area);
            }
            else{
                List<GesArea> tmp=new ArrayList<GesArea>();
                tmp.add(area);
                map.put(key, tmp);
            }
        }
        return map;
    }

    @Override
    @Transactional(readOnly=true)
    @Cacheable(value="cityCache",key="#root.targetClass + #root.methodName")
    public Map<String, List<GesArea>> listGroupByProvince() {
        Map<String, List<GesArea>> map=new HashMap<String, List<GesArea>>();
        List<GesArea> provincelist=super.getGesAreaDAO().listByParentId(0l);
        Map<Long,String> provinceIdMap=new HashMap<Long, String>();
        for(GesArea area:provincelist)
            provinceIdMap.put(area.getId(), area.getName());
        Map<Long,Long> cityToProvince=new HashMap<Long, Long>();
        List<GesArea> cityList=super.getGesAreaDAO().getAll(null,"y");
        //添加省级下的城市
        for(GesArea area:cityList){
            //用于添加县区时得到省的名字
            cityToProvince.put(area.getId(), area.getParentArea().getId());
            
            if(area.getIsAdd().equals("y")){
                String provinceName=provinceIdMap.get(area.getParentArea().getId());
                if(map.containsKey(provinceName)){
                    map.get(provinceName).add(area);
                }
                else{
                    List<GesArea> tmp=new ArrayList<GesArea>();
                    tmp.add(area);
                    map.put(provinceName, tmp);
                }
            }
        }
        //添加省级下的县区
        List<GesArea> countyList=super.getGesAreaDAO().getAll("y","n");
        for(GesArea area:countyList){
            String provinceName=provinceIdMap.get(cityToProvince.get(area.getParentArea().getId()));
            if(map.containsKey(provinceName)){
                map.get(provinceName).add(area);
            }
            else{
                List<GesArea> tmp=new ArrayList<GesArea>();
                tmp.add(area);
                map.put(provinceName, tmp);
            }
        }
        return map;
    }

    @Override
    @Transactional(readOnly=true)
    @Cacheable(value="cityCache",key="#root.targetClass + #root.methodName")
    public AreaTernaryTree getSearchTree() {
        // TODO Auto-generated method stub
        return new AreaTernaryTree(super.getGesAreaDAO().getAll("y",null));
    }

    public List<GesArea> listByParentArea() {
        // TODO Auto-generated method stub
        return super.getGesAreaDAO().listByParentArea();
    }

    @Override
    @Transactional(readOnly=true)
    public GesArea getByName(String name) {
        // TODO Auto-generated method stub
        return super.getGesAreaDAO().getByName(name);
    }

    public List<GesArea> listByChildingArea(Long parentId) {
        // TODO Auto-generated method stub
        return super.getGesAreaDAO().listByChildingArea(parentId);

    }

}
