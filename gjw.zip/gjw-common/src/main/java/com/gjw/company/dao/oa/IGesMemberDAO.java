package com.gjw.company.dao.oa;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.User;
import com.gjw.vo.oa.UserVO;

public interface IGesMemberDAO extends IDAO {
	
	/**
     * 人员名片（后期移动到user中）
     * @return
     */
    public UserVO queryUserInfo(long id);
    
    /**
	 * 会员详细(官网用户)
	 * @param id
	 * @return
	 */
	public User queryMember(long id);

}
