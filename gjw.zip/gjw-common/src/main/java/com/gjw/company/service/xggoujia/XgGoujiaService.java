package com.gjw.company.service.xggoujia;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.xggoujia.XgGoujia;

public interface XgGoujiaService extends IService {
	// 查询
	public List<XgGoujia> getListXgGoujia(XgGoujia xgGoujia);

	// 添加
	public Long saveXgGoujia(XgGoujia xgGoujia);

	// 修改
	public Long updateXgGoujia(XgGoujia xgGoujia);

	// 删除
	public Long deleteXgGoujia(XgGoujia xgGoujia);

	// 根据id查询
	public XgGoujia getByIdXgGoujia(Long id);
	
	//查询总记录数
	public Long count(XgGoujia xgGoujia);
	
	//分页查询
	public List<XgGoujia> pageListXgGoujia(XgGoujia xgGoujia);
	
	// 模糊查询
	public List<XgGoujia>  pageListByName(XgGoujia xgGoujia);

}
