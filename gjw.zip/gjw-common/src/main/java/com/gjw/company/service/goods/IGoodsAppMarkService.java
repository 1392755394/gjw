package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsAppMark;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.vo.GoodsAppMarkVO;
import com.gjw.vo.GoodsMarkVO;

/**
 * 
 * @Description: 产品包APP锚点service接口
 * @author guojianbin   
 * @date 2016年04月20日 
 * 
 */
public interface IGoodsAppMarkService extends IService {

    /**
     * 
     * @Description 删除APP锚点，并把goods_matter关联的APP锚点置空
     * @param markId
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public boolean deleteById(Long markId);
    
    /**
     * 
    * @Description  修改关系
    * @param mark
    * @return
    * @author guojianbin   
    * @date 2016年04月20日 
     */
    public boolean update(GoodsAppMark mark);
    
    /**
     * 
    * @Description  新增产品包物料关系
    * @param goodsMatter
    * @return
    * @author guojianbin   
    * @date 2016年04月20日 
     */
    public long create(GoodsAppMark mark);

    /**
     * 
     * @Description 新增APP锚点及标配选配物料信息
     * @param mark
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public boolean createAppMarkAndMatter(GoodsAppMarkVO mark);

    /**
     * 
     * @Description 修改APP锚点及标配选配物料信息
     * @param mark
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public boolean updateAppMarkAndMatter(GoodsAppMarkVO markVO);

}
