package com.gjw.company.service.order;

import java.util.List;

import com.gjw.entity.order.GesPaymentRecordResponse;

public interface IPaymentRecordResponseService {
	
	/**
	 * 插入银行返回的支付记录信息
	 * @param list
	 */
	public void addPaymentRecordResponse(List<GesPaymentRecordResponse> list);

}
