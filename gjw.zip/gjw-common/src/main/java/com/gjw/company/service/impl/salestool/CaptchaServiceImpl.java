package com.gjw.company.service.impl.salestool;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.ICaptchaService;
import com.gjw.entity.salestool.Captcha;
import com.gjw.utils.StringUtil;

@Service("captchaServiceImpl")
public class CaptchaServiceImpl extends AbstractServiceImpl implements ICaptchaService{

    @Override
    @Transactional(readOnly=true)
    public Captcha listByID(Long id) {
        // TODO Auto-generated method stub
        Captcha model=super.getCaptchaDAOHibernateImpl().listByID(id);
        if(StringUtil.notEmpty(model)){
            Hibernate.initialize(model.getBuilding());
        }
        return model;
    }

    @Override
    @Transactional
    public boolean updateCaptcha(Captcha model) {
        // TODO Auto-generated method stub
        Captcha modelFlag=super.getCaptchaDAOHibernateImpl().listByID(model.getId());
        StringUtil.copyProperties(model, modelFlag);
        return super.getCaptchaDAOHibernateImpl().updateCaptcha(modelFlag);
    }

    @Override
    @Transactional
    public boolean createCaptcha(Captcha model) {
        // TODO Auto-generated method stub
        boolean ret = super.getCaptchaDAOHibernateImpl().createCaptcha(model);
        return ret;
    }

    @Override
    @Transactional(readOnly=true)
    public long count(Captcha model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    @Transactional(readOnly=true)
    public List<Captcha> pageBycaptchaAndBuilding(Captcha cap) {
        // TODO Auto-generated method stub
        List<Captcha> list = super.getCaptchaDAOHibernateImpl().pageBycaptchaAndBuilding(cap);
        if(null != list && list.size()>0){
            for (Captcha captcha : list) {
                Hibernate.initialize(captcha.getBuilding());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly=true)
    public Long countBycaptchaAndBuilding(Captcha cap) {
        // TODO Auto-generated method stub
        return super.getCaptchaDAOHibernateImpl().countBycaptchaAndBuilding(cap);
    }

    @Override
    @Transactional
    public boolean batchDel(String ids) {
        // TODO Auto-generated method stub
        return super.getCaptchaDAOHibernateImpl().batchDel(ids);
    }

    @Override
    @Transactional(readOnly=true)
    public List<Captcha> listByCaptcha(String captcha) {
        // TODO Auto-generated method stub
        return super.getCaptchaDAOHibernateImpl().listByCaptcha(captcha);
    }



}
