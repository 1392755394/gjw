package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorCompareConclusionDAO;
import com.gjw.entity.cityoperator.GesCityOperatorCompareConclusion;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorCompareConclusionDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorCompareConclusionDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorCompareConclusionDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperatorCompareConclusion.class;
    }

    @Override
    public GesCityOperatorCompareConclusion listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperatorCompareConclusion) super.get(id);
    }

    @Override
    public boolean updateGesCityOperatorCompareConclusion(
            GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCityOperatorCompareConclusion(
            GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorCompareConclusion item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperatorCompareConclusion> listByGesCityOperatorCompareConclusion(
            GesCityOperatorCompareConclusion model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorCompareConclusion item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCityOperatorCompareConclusion>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
