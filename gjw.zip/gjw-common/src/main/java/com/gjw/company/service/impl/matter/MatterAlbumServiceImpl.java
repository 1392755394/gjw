package com.gjw.company.service.impl.matter;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.matter.IMatterAlbumService;
import com.gjw.entity.matter.MatterAlbum;

/**
 * 物料相册service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月22日
 * 
 */
@Component("matterAlbumServiceImpl")
public class MatterAlbumServiceImpl extends AbstractServiceImpl implements IMatterAlbumService {

    @Override
    @Transactional
    public Long create(MatterAlbum matterAlbum) {
        return super.getMatterAlbumDAO().create(matterAlbum);
    }

    @Override
    @Transactional
    public boolean deleteById(long id) {
        return super.getMatterAlbumDAO().deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MatterAlbum> listAlbumByMatterID(long matterId) {
        return super.getMatterAlbumDAO().listAlbumByMatterID(matterId);
    }

}
