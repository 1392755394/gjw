package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.User;

/**
 * 部门dao接口
 * @Description: 
 * @author  qingye
 * @date 2016年1月9日 
 *
 */
public interface IDeptUserDAO extends IDAO {
    public DeptUser get(long id);
    
    public DeptUser getByDeptAndUser(DeptUser deptUser);
    
    /** 
     * @Description  
     * @param deptUser
     * @return
     * @author qingye   
     * @date Jan 15, 2016 11:49:13 AM
     */
     
     public List<DeptUser> pageByDept(DeptUser deptUser);

     /** 
     * @Description  
     * @param deptUser
     * @return
     * @author qingye   
     * @date Jan 15, 2016 11:49:40 AM
     */
     
     public Long countByDept(DeptUser deptUser);

     /** 
     * @Description  
     * @param deptUser
     * @return
     * @author qingye   
     * @date Jan 15, 2016 2:47:11 PM
     */
     
     public List<User> pageUncheckByDept(DeptUser deptUser);

     /** 
     * @Description  
     * @param deptUser
     * @return
     * @author qingye   
     * @date Jan 15, 2016 2:47:18 PM
     */
     
     public Long countUncheckByDept(DeptUser deptUser);

}
