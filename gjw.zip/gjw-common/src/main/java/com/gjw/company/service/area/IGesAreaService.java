package com.gjw.company.service.area;

import java.util.List;
import java.util.Map;

import com.gjw.entity.area.GesArea;
import com.gjw.utils.search.AreaTernaryTree;
import com.gjw.vo.GesAreaVO;

public interface IGesAreaService {
    
    /**
    * @Description  获得城市详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月3日 下午4:00:30
     */
    public GesArea getById(Long id);
    
    /**
    * @Description 根据父级Id获取地区列表  
    * @param parentId
    * @return
    * @author yanghaiyang   
    * @date 2015年12月10日 下午4:36:33
     */
    public List<GesArea> listByParentId(Long parentId);
    
    /**
    * @Description 根据父级Id获取地区分页列表数据  
    * @param gesArea
    * @return
    * @author yanghaiyang   
    * @date 2015年12月11日 上午10:17:41
     */
    public Map<Object, Object> pageByParentId(GesArea area);
    
    /**
    * @Description 根据parentId获取城市分页列表  
    * @param area
    * @return
    * @author haiyang   
    * @date 2015年12月12日 下午2:39:27
     */
    public Map<Object, Object> pageCityByParentId(GesAreaVO area);
    
    /**
    * @Description  查询已开通的城市  
    * @param area
    * @return
    * @author haiyang   
    * @date 2015年12月12日 上午9:56:15
     */
    public Map<Object, Object> pageCityDredgeByParentId(GesArea area);

    /**
    * @Description  获取地市分页列表数据
    * @param areaVO
    * @return
    * @author haiyang   
    * @date 2015年12月15日 上午11:33:50
     */
    public Map<Object, Object> pageCityByAreaVO(GesAreaVO areaVO);
    
    /**
    * @Description  获取县区分页列表
    * @param areaVO
    * @return
    * @author xiaoyang   
    * @date 2015年12月21日 上午11:15:21
     */
    public Map<Object, Object> pageCountyByAreaVO(GesAreaVO areaVO);
    
    public List<GesArea> listGesAreaByIsAdded();
    
    /**
    * @Description 根据父级Id获取有楼盘的地区列表  
    * @param parentId 父级Id
    * @return
    * @author guojianbin   
    * @date 2016年1月26日
     */
    public List<GesArea> listByParentAndBuilding(Long parentId);
    

    //官网城市切换
    
    public Map<Character, List<GesArea>> listGroupBySpell();
    
    public Map<String, List<GesArea>> listGroupByProvince();
    
    public AreaTernaryTree getSearchTree();
    
    public GesArea getByName(String name);

    public List<GesArea> listByParentArea();
    
    public List<GesArea> listByChildingArea(Long parentId);

}
