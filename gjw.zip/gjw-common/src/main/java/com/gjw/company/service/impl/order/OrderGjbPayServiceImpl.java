package com.gjw.company.service.impl.order;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.common.enumeration.PayWay;
import com.gjw.common.error.BusinessErrorCode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.common.exception.HTTP500Exception;
import com.gjw.common.helper.Properties;
import com.gjw.company.dao.order.IGesOrderPayMoneyDAO;
import com.gjw.company.service.order.IMultiplePaymentService;
import com.gjw.company.service.order.IOrderGjbPayService;
import com.gjw.dto.order.CommitOrderPayDTO;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.gjb.constants.Confirm;
import com.gjw.gjb.constants.Constants;
import com.gjw.gjb.enumeration.EPaymentRecordAction;
import com.gjw.gjb.enumeration.EPaymentRecordMode;
import com.gjw.gjb.enumeration.EPaymentRecordStatus;
import com.gjw.gjb.enumeration.GYJTradeCode;
import com.gjw.gjb.model.GJBBankVerify;
import com.gjw.gjb.model.GJWAnsAffirm;
import com.gjw.gjb.model.GJWCashDeposit;
import com.gjw.gjb.model.GYJNewPay;
import com.gjw.gjb.model.GYJNoticeOrderRequest;
import com.gjw.gjb.model.GYJQueryOrder;
import com.gjw.gjb.utils.Base64;
import com.gjw.gjb.utils.RASUtil;
import com.gjw.gjb.utils.Tool;
import com.gjw.gjb.utils.XMLUtil;
import com.gjw.utils.DateUtil;
import com.gjw.vo.order.GesOrderVO;

@Component("orderGjbPayServiceImpl")
public class OrderGjbPayServiceImpl extends AbstractServiceImpl implements
		IOrderGjbPayService {
	
	private final static Logger LOG=LoggerFactory.getLogger(OrderGjbPayServiceImpl.class);
	
	@Resource(name="multiplePaymentServiceImpl")
	private IMultiplePaymentService multiplePaymentService;
	
	@Resource(name="gesOrderPayMoneyDAOHibernateImpl")
	private IGesOrderPayMoneyDAO gesOrderPayMoneyDAO;

	public IGesOrderPayMoneyDAO getGesOrderPayMoneyDAO() {
		return gesOrderPayMoneyDAO;
	}

	public void setGesOrderPayMoneyDAO(IGesOrderPayMoneyDAO gesOrderPayMoneyDAO) {
		this.gesOrderPayMoneyDAO = gesOrderPayMoneyDAO;
	}


	/**
	 * 网银10%支付
	 */
	@Override
	@Transactional
	public CommitOrderPayDTO dealOrderEarnestEbankPay(long orderId, long userId,Map<String, String> map) {
		//查询订单信息
		GesOrderVO order = getGesOrderDAO().queryOrderByIdForGjb(orderId);
    	if (order == null
    			|| !order.getOrderStatus().equals(OrderStatus.prepaying.name()))
    		throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
    	
        //查询需要支付的金额
        Long money=multiplePaymentService.queryNeedPayMoney(order, userId);
        if(money.longValue()<=0){
            LOG.error("获取金额错误！");
            throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
        }
        //组装支付记录的信息
        GesPaymentRecord paymentRd=assemblePaymentRecord(order, money,EPaymentRecordAction.PREPAY.getIntValue().intValue());
        // 新增订单支付
        getGesPaymentRecordDAO().createPaymentRecord(paymentRd);
        LOG.info("######10% 添加payment record result："+paymentRd.getId());
        if (paymentRd.getId()==null) {
        	throw new ErrorCodeException(BusinessErrorCode.goujiabao_114);
        }
        //更新多次支付记录
        updateMultiplePayRecordSerialNo(order, paymentRd,PaymentConstant.PAY_PERIOD_TEN.intValue());
        /************************************* 新增订单支付信息结束 ********************************************/
        GYJNewPay gyjorder=assembleGYJEarnestPayInfo(order, paymentRd,map);
        
        return assembleReturnValue(gyjorder,map);
	}


	protected GesPaymentRecord assemblePaymentRecord(GesOrderVO order,Long money,int type){
		//支付流水号
        String code=DateUtil.formatTime(new Date()) + (int) (Math.random() * 1000000000);
        
		GesPaymentRecord paymentRd = new GesPaymentRecord();
		GesOrder gesOrder=new GesOrder();
		gesOrder.setId(order.getId());
        paymentRd.setGesOrder(gesOrder);
        paymentRd.setOrderStatus(order.getOrderStatus());
        paymentRd.setGmtSuccess(new Timestamp(System.currentTimeMillis()));
        // 支付金额 单位分
        paymentRd.setMoney(money.longValue());
        LOG.error("支付金额为"+money.intValue());
        // 支付方式
        paymentRd.setMode(EPaymentRecordMode.IDBC.getValue());
        // 支付类型
        if(type==EPaymentRecordAction.PREPAY.getIntValue().intValue()){
        	paymentRd.setAction(EPaymentRecordAction.PREPAY.getIntValue());
        }else if(type==EPaymentRecordAction.DEPOSIT.getIntValue().intValue()){
        	// 支付类型 5：保证金
        	paymentRd.setAction(EPaymentRecordAction.DEPOSIT.getIntValue());
        }else if(type==EPaymentRecordAction.CONFIRM.getIntValue().intValue()){
        	// 支付类型 5：确认付款
			paymentRd.setAction(EPaymentRecordAction.CONFIRM.getIntValue());
        }
        
        // 支付状态，1：准备支付
        paymentRd.setPayStatus(EPaymentRecordStatus.PAYING.getValue());
        // 支付号，有java代码生成
        paymentRd.setCode(code);
		return paymentRd;
	}
	
	protected void updateMultiplePayRecordSerialNo(GesOrderVO order,GesPaymentRecord paymentRd,int type){
		MultiplePayment mp=new MultiplePayment();
		if(type==PaymentConstant.PAY_PERIOD_TEN.intValue()){
			mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
		}else if(type==PaymentConstant.PAY_PERIOD_NINETY.intValue()){
			mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
		}else if(type==PaymentConstant.PAY_PERIOD_THIRTY.intValue()){
			mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
		}
        GesOrder gesOrder=new GesOrder();
		gesOrder.setId(order.getId());
        mp.setGesOrder(gesOrder);
        mp.setSerialPayNo(paymentRd.getCode());
        //更新支付记录中的支付流水号
        getMultiplePaymentDAO().updateSerialPayNo(mp);
	}
	
	/**
	 * 工银聚10%支付，组装支付信息
	 * @param order
	 * @param paymentRd
	 * @return
	 */
	protected GYJNewPay assembleGYJEarnestPayInfo(GesOrderVO order,GesPaymentRecord paymentRd,Map<String, String> map){
		GYJNewPay gyjorder = new GYJNewPay();
        // 测试 二级商户名称
        gyjorder.setSellername(map.get("merid"));// 对公账号  
        // 清算商户代码<!--长度不超过10位,必输，购家网定金支付送购家网代码“gjw”，保证金支付送装修公司代码，二级商户按此代码清算>
        gyjorder.setSelleracct("");
        gyjorder.setTranstime(Tool.formatTime(new Date()));
        // 公司方流水号 对应工银聚的订单编号
        gyjorder.setOrderid(Constants.EARNEST_CODE_PREFIX + paymentRd.getCode());
        LOG.info("#####################################订单号=" + Constants.EARNEST_CODE_PREFIX + paymentRd.getCode());
        // 测试 商户简称构家网简称（gjw）
        gyjorder.setMername(map.get("mername"));
        gyjorder.setUserid(order.getBuyerId() + "");
        gyjorder.setUsername(order.getBuyerName());
        // 二级商户默认为merid，选输，购家网该字段不输
        gyjorder.setSellerid(map.get("merid"));
        // <!--长度不超过20位,没有二级商户默认为merid，选输，购家网该字段不输-->
        gyjorder.setPayamount(new BigDecimal(paymentRd.getMoney()).divide(new BigDecimal(100))+"");
        LOG.error("gyorder设置的金额为:"+gyjorder.getPayamount());
        gyjorder.setNoticeurl(map.get("noticeURL"));
        gyjorder.setAmtinfo(PayWay.getNameByIndex(0) + "-总金额的"
                + (PayWay.getRateByIndex(0).multiply(new BigDecimal(100)).longValue()) + "%");
        LOG.info("产品包的长度为："+order.getGoodsName().length());
        if(order.getGoodsName().length()>18){
        	LOG.info("截取产品包长度："+order.getGoodsName().substring(0, 18));
            gyjorder.setGoodsinfo(order.getGoodsName().substring(0, 18));
        }else{
        	LOG.info("产品包长度："+order.getGoodsName());
            gyjorder.setGoodsinfo(order.getGoodsName());
        }
        gyjorder.setJumpurl(map.get("jumpUrl"));
        gyjorder.setB2bdate(DateUtil.formatDate(order.getCreatedDatetime()));
        gyjorder.setMervar(order.getId() + "");
        gyjorder.setEnabledpmd(Confirm.Enabledpmd);
        gyjorder.setInstallment("0");
        // 构家网合同编号 对应工银聚的合同号
        gyjorder.setGoodsid(order.getId() + "");
        // 清算商户代码  gjw
        gyjorder.setSettleacct("gjw");
        // <!--长度不超过255位，对构家网来说，该字段为：手机号（11位）|支付类型（0为定金支付，1为保证金支付）|合同号|合同总金额|门店号|，以“|”分隔-->
        gyjorder.setRemark1("0|" + order.getId() + "|" + new BigDecimal(order.getTotalAmount()).divide(new BigDecimal(100)) + "|" + order.getShopId()+"|"+order.getMobile());
        
		return gyjorder;
	}
	
	/**
	 * 网银90%支付 可以跟10%合并，为了清晰，此处未合并
	 */
	@Override
	@Transactional
	public CommitOrderPayDTO dealOrderDepositEbankPay(long orderId, long userId,Map<String, String> map) {
		//查询订单信息
		GesOrderVO order = getGesOrderDAO().queryOrderByIdForGjb(orderId);
		if (order == null || !order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())) {
			LOG.error(BusinessErrorCode.goujiabao_107.getMessage() + ";1::orderId=" + orderId);
			throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
		}
		//查询需要支付的金额
		Long money=multiplePaymentService.queryNeedPayMoney(order, userId);
		if(money.longValue()<=0){
			LOG.error("获取金额错误！");
			throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
		}
		//组装支付记录的信息
		GesPaymentRecord paymentRd=assemblePaymentRecord(order, money,EPaymentRecordAction.DEPOSIT.getIntValue().intValue());
		// 新增订单支付
		getGesPaymentRecordDAO().createPaymentRecord(paymentRd);
        LOG.info("######10% 添加payment record result："+paymentRd.getId());
        if (paymentRd.getId()==null) {
        	LOG.info("支付90%保证金登新增登记簿信息失败" + orderId);
        	throw new ErrorCodeException(BusinessErrorCode.goujiabao_114);
        }
        //更新多次支付记录
        updateMultiplePayRecordSerialNo(order, paymentRd,PaymentConstant.PAY_PERIOD_NINETY.intValue());
        /************************************* 新增订单支付信息结束 ********************************************/
        GYJNewPay gyjorder=assembleGYJDepositPayInfo(order, paymentRd,map);
        
        return assembleReturnValue(gyjorder,map);
	}
	
	/**
	 * 组装返回值
	 * @param gyjorder
	 * @return
	 */
	protected CommitOrderPayDTO assembleReturnValue(GYJNewPay gyjorder,Map<String, String> map) {
		CommitOrderPayDTO vo = new CommitOrderPayDTO();
		vo.setMerid(map.get("merid"));
		vo.setTrancode(GYJTradeCode.GYJPAY.name());
		vo.setCommitURL(GYJTradeCode.GYJPAY.getTradeURL(map.get("tradePath")));
		String reqdata = gyjorder.toXMLString();
		LOG.info("Ready to GYJPAY!reqdata:" + reqdata);
		vo.setReqdata(reqdata);
		vo.signature(reqdata, map.get("password"), gyjorder.getTranstime());
		LOG.info("Ready to GYJPAY!password_time:" + map.get("password") +","+ gyjorder.getTranstime());
		LOG.info("Ready to GYJPAY!signature:" + vo.getSignature());
		return vo;
	}
	
	/**
	 * 工银聚90%支付，组装支付信息
	 * @param order
	 * @param paymentRd
	 * @return
	 */
	protected GYJNewPay assembleGYJDepositPayInfo(GesOrderVO order,GesPaymentRecord paymentRd,Map<String, String> map){
		GYJNewPay gyjorder = new GYJNewPay();
        BigDecimal rate = BigDecimal.ONE.subtract(PayWay.getRateByIndex(0));
        // 测试
        gyjorder.setSellerid(map.get("merid"));
        gyjorder.setSellername(order.getShopName());// 二级商户名称
        // 清算商户代码<!--长度不超过10位,必输，购家网定金支付送购家网代码“gjw”，保证金支付送装修公司代码，二级商户按此代码清算>
        gyjorder.setTranstime(Tool.formatTime(new Date()));
        // 订单编号 工行要求在支付10%和90%的时候合同编号相同，订单编号不同
        gyjorder.setOrderid(Constants.CREDIT_CODE_PREFIX + paymentRd.getCode());
        // 测试 构家网（gjw）
        gyjorder.setMername(map.get("mername"));
        gyjorder.setUserid(order.getBuyerId() + "");
        gyjorder.setUsername(order.getBuyerName());
        // 二级商户编号
        LOG.info("#####################################二级商户编号=" + map.get("merid"));
        
        gyjorder.setPayamount(new BigDecimal(paymentRd.getMoney()).divide(new BigDecimal(100))+"");
        LOG.error("gyorder设置的金额为:"+gyjorder.getPayamount());
        gyjorder.setNoticeurl(map.get("noticeURL"));
        gyjorder.setAmtinfo("担保交易金-总金额的" + (rate.multiply(new BigDecimal(100))) + "%");
        if(order.getGoodsName().length()>18){
        	LOG.info("截取产品包长度："+order.getGoodsName().substring(0, 18));
            gyjorder.setGoodsinfo(order.getGoodsName().substring(0, 18));
        }else{
            LOG.info("产品包长度："+order.getGoodsName());
            gyjorder.setGoodsinfo(order.getGoodsName());
        }
        gyjorder.setJumpurl(map.get("jumpUrl"));
        gyjorder.setB2bdate(DateUtil.formatDate(order.getCreatedDatetime()));
        gyjorder.setMervar(order.getId() + "");
        gyjorder.setEnabledpmd(Confirm.Enabledpmd);
        gyjorder.setInstallment("1");
        //合同编号
        gyjorder.setGoodsid(order.getId() + "");
        gyjorder.setSettleacct(order.getShopCode());
        // <!--长度不超过255位，对构家网来说，该字段为：手机号（11位）|支付类型（0为定金支付，1为保证金支付）|合同号|合同总金额|门店号|，以“|”分隔-->
        gyjorder.setRemark1("1|" + order.getId() + "|" + new BigDecimal(order.getTotalAmount()).divide(new BigDecimal(100)) + "|" + order.getShopId()+"|"+order.getMobile());//
        
		return gyjorder;
	}

	/**
	 * 30%确认支付  目前是拷贝之前的代码，后期要修改整理，目前太乱
	 */
	@Override
	@Transactional
	public String dealOrderConfirmPay(long orderId, long userId,Map<String, String> map) {
	    JSONObject json = new JSONObject();
        // 判断两次点击是否相差300秒
        GesPaymentRecord pr = getGesPaymentRecordDAO().judgeTimeInterval(orderId);
        if (pr != null) {
            // 判断时间差是否超过300秒
            long intervalTime = new Date().getTime()
                    - pr.getGmtSuccess().getTime();
            if (intervalTime / 1000 >= 300) {
                LOG.info("支付的间隔时间为："+intervalTime);
            } else {
                json.put("result", false);
                json.put("type", 1);
                return json.toString();
            }
        }
		//查询订单信息
		GesOrderVO order = getGesOrderDAO().queryOrderByIdForGjb(orderId);
		if (order == null) {
		    LOG.info(BusinessErrorCode.goujiabao_107.getMessage()
					+ ";1::orderId=" + orderId);
			throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
		}
		
		LOG.info("########################################购家网向银行发起  开始测试######################################"	+ order.getId());

		if (order.getOrderStatus().equals(OrderStatus.paying_AZZC.name())
				|| order.getOrderStatus().equals(OrderStatus.accepted_JZFZ.name())
				|| order.getOrderStatus().equals(OrderStatus.accepted_YSCS.name())) {

			// 查询出原支付原保证金交易支付流水号
			List<MultiplePayment> multipleList = queryDepositPayRecord(order);
			if(multipleList==null||multipleList.size()<1){
				LOG.info("订单id为：" + order.getId() + "商品名为："	+ order.getGoodsName() + "的订单支付登陆簿数据不存在");
			    json.put("result", false);
			    json.put("type", 2);
			    return json.toString();
			}
			//查询需要确认支付的金额
			long money=multiplePaymentService.queryConfirmPayMoneyForThirty(order);
			//组装支付记录
			GesPaymentRecord paymentRd = assemblePaymentRecord(order, money, EPaymentRecordAction.CONFIRM.getIntValue());
			// 新增订单支付
	        getGesPaymentRecordDAO().createPaymentRecord(paymentRd);
	        LOG.info("######30% 添加payment record result："+paymentRd.getId());
	        if (paymentRd.getId()==null) {
	        	json.put("result", false);
				json.put("type", 2);
				return json.toString();
	        }
	        //更新支付流水号
	        updateMultiplePayRecordSerialNo(order, paymentRd, PaymentConstant.PAY_PERIOD_THIRTY);
			//组装发送给银行的信息
			GJWCashDeposit gd = assembleConfirmInfo(order, multipleList,paymentRd);
			String strXml = gd.toStringXml(gd);
			LOG.info("---------------------------strXml-----------" + strXml);
			String signature = RASUtil.sign(strXml.getBytes());
			LOG.info("---------------------------signature-----------"+ signature);
			if ("".equals(signature)) {
				LOG.info("订单id为：" + order.getId() + "商品名为："
						+ order.getGoodsName() + "，签名失败！");
			    json.put("result", false);
			    json.put("type", 2);
			    return json.toString();
			}
			// gd.setSignature(signature);
			String base64Xml = null;
			base64Xml = Base64.encode(gd.toStringXmlEncode(strXml));
			LOG.info("+++++++++++++++++++++++++base64Xml=" + base64Xml);
			GJWAnsAffirm ans = new GJWAnsAffirm();
			String ansStr = "";
			try {
				ansStr = verifyCashDeposit(base64Xml, signature,map);
				LOG.info("verifyBackAns+++++++++++++++++++++++++ansStr="+ ansStr);
				ans = (GJWAnsAffirm) XMLUtil.parseXML(Base64.decode(ansStr, Confirm.charset_gbk),new GJWAnsAffirm());
				LOG.info("+++++++++++++++++++++++++ans=" + ans.getRetcode());
				if (ans == null || ans.getRetcode() == null) {
					LOG.info("订单id为：" + order.getId() + "商品名为："	+ order.getGoodsName() + "响应银行信息失败！");
				    json.put("result", false);
				    json.put("type", 0);
				    return json.toString();
				}
			} catch (Exception e) {
				LOG.info("+++++++++++++++++++++++++银行响应信息失败"+e);
				json.put("result", false);
				json.put("type", 0);
				return json.toString();
			}
			LOG.info("+++++++++++++++++++++++++验证银行响应信息 开始=");
			// 验签 验证银行响应信息
			String verifyBackAns = "";
			String asnsXml = Base64.decode(ansStr, Confirm.charset_gbk);
			try {
				verifyBackAns = asnsXml.substring(asnsXml.indexOf("<pub>"),
						asnsXml.indexOf("<signature>"));
				LOG.info("+++++++++++++++++++++++++验证银行响应信息 开始=verifyBackAns:"+ verifyBackAns);
			} catch (Exception e1) {
				LOG.error("+++++++++++++++++++++++++验证银行响应信息 开始=verifyBackAns:"+ e1);
				json.put("result", false);
				json.put("type", 0);
				return json.toString();
			}
			// ans.verifyBackAns(ans);
			LOG.info("+++++++++++++++++++++++++验证银行应信息=verifyBackAns"+ verifyBackAns);
			LOG.info("+++++++++++++++++++++++++验证银行应信息=ans.getSignature()"+ ans.getSignature());
		} else {
			LOG.info(BusinessErrorCode.goujiabao_107.getMessage()+ ";2::orderId=" + orderId);
			throw new ErrorCodeException(BusinessErrorCode.goujiabao_107);
		}
		json.put("result", true);
		json.put("type", 0);
		return json.toString();
	}

	/**
	 * 组装确认支付的信息
	 * @param order
	 * @param multipleList
	 * @param paymentRd
	 * @return
	 */
	protected GJWCashDeposit assembleConfirmInfo(GesOrderVO order,
			List<MultiplePayment> multipleList, GesPaymentRecord paymentRd) {
		/************************* 确认支付开始 **************************/
		String date = Tool.formatTime(new Date());
		GJWCashDeposit gd = new GJWCashDeposit();
		gd.setOrgcode("GJW");
		gd.setTxcode(Confirm.txcode);
		gd.setCmpdate(date.substring(0, 8));
		gd.setCmptime(date.substring(8));
		// TODO 支付流水号
		gd.setCmptxsno(Constants.STAGES_CODE_PREFIX + paymentRd.getCode());
		gd.setPaytype("0");
		// 合同号订单编号
		gd.setContractno(order.getId() + "");
		// 二级商户order.getOperatorId() zb
		gd.setSubsellerid(order.getShopCode());
		// 原保证金交易支付流水号
		gd.setOrderno(Constants.CREDIT_CODE_PREFIX + multipleList.get(0).getSerialPayNo());
		gd.setAmount(new BigDecimal(paymentRd.getMoney()).divide(new BigDecimal(100))+"");
		LOG.error("支付的金额为："+gd.getAmount());
		gd.setMobile(order.getMobile());
		gd.setOrderstatus(order.getOrderStatus());
		return gd;
	}

	/**
	 * 查询90%支付记录
	 * @param order
	 * @return
	 */
	protected List<MultiplePayment> queryDepositPayRecord(GesOrderVO order) {
		MultiplePayment multiplePayment=new MultiplePayment();
		multiplePayment.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
		GesOrder gesOrder=new GesOrder();
		gesOrder.setId(order.getId());
		multiplePayment.setGesOrder(gesOrder);
		multiplePayment.setPayStatus(PaymentConstant.PAY_STATUS_THREE);
		return getMultiplePaymentDAO().queryDepositMultiplePayRecord(multiplePayment);
	}
	
	/**
	 * 确认支付调用的方法
	 * 
	 * @param orderId
	 * @param repayId
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws ParseException
	 * @throws IOException
	 * @throws HttpException
	 * @throws Exception
	 */
	@SuppressWarnings("finally")
	public String verifyCashDeposit(String xmlStr, String signature,Map<String, String> map) {
		LOG.info("1向银行发起请求开始########################################");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		List<BasicNameValuePair> pairs = new ArrayList<BasicNameValuePair>();
		pairs.add(new BasicNameValuePair("reqdata", xmlStr));
		pairs.add(new BasicNameValuePair("signature", signature));
		pairs.add(new BasicNameValuePair("charset", Constants.CHARSET));
		UrlEncodedFormEntity entity = null;
		try {
			entity = new UrlEncodedFormEntity(pairs, Constants.CHARSET);
		} catch (UnsupportedEncodingException e2) {
		    LOG.info("--------------------UrlEncodedFormEntity=" + e2);
		}
		HttpPost httppost = new HttpPost(map.get("confirmUrl"));//
		httppost.setEntity(entity);
		httppost.setHeader("Content-Type",
				"application/x-www-form-urlencoded;charset=utf-8");
		RequestConfig requestConfig = RequestConfig.custom()
				.setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
		httppost.setConfig(requestConfig);
		CloseableHttpResponse responseBody = null;
		String stringXml = "";
		LOG.info("4##############################responseBody请求开始###############");
		try {
			responseBody = httpclient.execute(httppost);
			LOG.info("--------------------向银行发起请求响应信息=" + responseBody);
			stringXml = EntityUtils.toString(responseBody.getEntity(),
					Constants.CHARSET);
			LOG.info("#######################################################="
					+ Base64.decode(stringXml, Confirm.charset_gbk));
		} catch (ClientProtocolException e1) {
			LOG.error("-------------------httpclient.execute请求失败=" + e1);
		} catch (IOException e1) {
			LOG.error("--------------------httpclient.executet请求出现异常=" + e1);
		} finally {
			try {
				httpclient.close();
				LOG.info("-------------------------------httpclient关闭成功-------------------");
			} catch (IOException e) {
				LOG.error("-------------------------------httpclient关闭失败-------------------"+e);
			}
		}
		return stringXml;
	}

	/**
	 * 处理10%和90%支付银行的通知   目前照搬，后期整理修改
	 */
	@Override
	@Transactional
	public boolean bankNoticeForTenAndNinety(String reqdata, String signature,String transtype,Map<String, String> map) {
		if ("ORDER".equals(transtype)) {
			boolean isTrue = false;
			try {
				GYJNoticeOrderRequest notice = new GYJNoticeOrderRequest(reqdata, signature);
				GYJQueryOrder queryOrder = notice.getData(map.get("merid"), map.get("password"));
				if (queryOrder == null || !"2".equals(queryOrder.getOrderstatus())) {
					throwHTTP500Exception(BusinessErrorCode.goujiabao_103,"reqdata=" + reqdata);
				}
				String orderId = queryOrder.getOrderid();
				long money=new BigDecimal(queryOrder.getPayamount()).multiply(new BigDecimal(100)).longValue();
				LOG.info("-------------------------3=="	+ orderId+".money="+money);
				if (Tool.isEmpty(orderId))
					throwHTTP500Exception(BusinessErrorCode.goujiabao_103,"GYJ_orderId=" + orderId);
				// 支付90%保证金
				if (orderId.startsWith(Constants.CREDIT_CODE_PREFIX)) {
					// 支付流水号
					String realOrderId = orderId.substring(Constants.CREDIT_CODE_PREFIX.length());
					if (Tool.isEmpty(realOrderId))
						throwHTTP500Exception(BusinessErrorCode.goujiabao_103,"orderCode=" + realOrderId);
					//根据订单的交易流水号查询订单的信息
					GesOrderVO orderPay=getGesOrderDAO().queryOrderByTradeId(realOrderId);
					//更新支付记录中的支付状态
					GesPaymentRecord paymentRecord=new GesPaymentRecord();
					paymentRecord.setCode(realOrderId);
					paymentRecord.setPayStatus(EPaymentRecordStatus.GET_RES.getValue());
					paymentRecord.setMoney(money);
					getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
					//修改订单状态、多次支付记录表的支付状态、支付金额表
					multiplePaymentService.updateMultiplePaymentStatus(orderPay, paymentRecord);
					isTrue =multiplePaymentService.updateOrderStatusWeb(orderPay, paymentRecord, OrderStatus.arriving_credit.name());
					if (!isTrue) {
					    LOG.error(BusinessErrorCode.goujiabao_104+ "  支付90%保证金，响应银行信息失败，支付流水号是：" + realOrderId);
						throwHTTP500Exception(BusinessErrorCode.goujiabao_104,"orderCode=" + realOrderId);
					}
					
				} else if (orderId.startsWith(Constants.EARNEST_CODE_PREFIX)) {// 支付10%定金
				    LOG.info("-----GYJ 10%-------------------");
					String realOrderId = orderId.substring(Constants.EARNEST_CODE_PREFIX.length());
					LOG.info("realOrderId：" + realOrderId);
					if (Tool.isEmpty(realOrderId))
						throwHTTP500Exception(BusinessErrorCode.goujiabao_103,"earnestCode=" + realOrderId);
					//根据订单的交易流水号查询订单的信息
					GesOrderVO orderPay=getGesOrderDAO().queryOrderByTradeId(realOrderId);
					//更新支付记录中的支付状态
					GesPaymentRecord paymentRecord=new GesPaymentRecord();
					paymentRecord.setCode(realOrderId);
					paymentRecord.setPayStatus(EPaymentRecordStatus.GET_RES.getValue());
					paymentRecord.setMoney(money);
					getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
					//修改订单状态、多次支付记录表的支付状态、支付金额表
					multiplePaymentService.updateMultiplePaymentStatus(orderPay, paymentRecord);
					LOG.info("修改订单状态!");
					isTrue =multiplePaymentService.updateOrderStatusWeb(orderPay, paymentRecord, OrderStatus.arriving_earnest.name());
					if (!isTrue) {
					    System.out.println(BusinessErrorCode.goujiabao_104+ "  支付10%定金，响应银行信息失败，订单支付流水号是：" + realOrderId);
						throwHTTP500Exception(BusinessErrorCode.goujiabao_104,"earnestCode=" + realOrderId);
					}

				} else {
					throwHTTP500Exception(BusinessErrorCode.goujiabao_103,"GYJ_orderId=" + orderId);
				}

			} catch (Exception e) {
				if (e instanceof HTTP500Exception) {
					throw e;
				} else {
				    LOG.error("---BusinessErrorCode.goujiabao_104----"+ e);
					throwHTTP500Exception(BusinessErrorCode.goujiabao_104,e.getMessage());
				}
			}
			return isTrue;

		} else {
			return false;
		}
	}
	
	private void throwHTTP500Exception(BusinessErrorCode code, String info) {
		LOG.error(code.getCode() + ";" + info);
		throw new HTTP500Exception(code.getCode());
	}

	/**
	 * 30%支付银行通知接口
	 */
	@Override
	@Transactional
	public String bankNoticeForThirty(String reqdata, String signature) {
		// return "post请求成功";
		GJBBankVerify gJBBankVerify = new GJBBankVerify();
		GJWAnsAffirm ans = new GJWAnsAffirm();
		String reqdatadecode = null;
		reqdatadecode = Base64.decode(reqdata, Confirm.charset_gbk);
		LOG.info("reqdatadecode："+ reqdatadecode);
		try {
			gJBBankVerify = (GJBBankVerify) XMLUtil.parseXML(reqdatadecode,
					gJBBankVerify);
		} catch (UnsupportedEncodingException e) {
			ans.setRetcode("11111");
			ans.setRetmsg("xml解析失败！");
			LOG.error("UnsupportedEncodingException=" + e);
		} catch (DocumentException e) {
			ans.setRetcode("11111");
			ans.setRetmsg("xml解析失败！");
			LOG.error("DocumentException=" + e);
		}

		// 响应银行信息
		String xmlSring = "";
		String signXml = reqdatadecode.substring(reqdatadecode.indexOf("<pub>"),reqdatadecode.indexOf("</package>"));
		LOG.info("signXml="	+ signXml);

		boolean verifyFlag = false;
		try {
			verifyFlag = RASUtil.verify(signature,signXml.getBytes(Confirm.charset_gbk));
		} catch (UnsupportedEncodingException e) {
			LOG.error("验签异常：" + e);
		}

		LOG.info("回传的订单状态为："+gJBBankVerify.getOrderstatus()+",状态代码："+gJBBankVerify.getRetcode().endsWith(Confirm.retcode));
		// 验签
		if (verifyFlag) {
			if ((gJBBankVerify.getOrderstatus().equals(
					OrderStatus.paying_AZZC.name())
					|| gJBBankVerify.getOrderstatus().equals(
							OrderStatus.accepted_JZFZ.name()) || gJBBankVerify
					.getOrderstatus().equals(OrderStatus.accepted_YSCS.name()))
					&& gJBBankVerify.getRetcode().endsWith(Confirm.retcode)) {
				
				GesOrderPayMoney orderPayMoney=new GesOrderPayMoney();
				GesOrder order = new GesOrder();
				if (gJBBankVerify.getOrderstatus().equals(
						OrderStatus.paying_AZZC.name())) {
					orderPayMoney.setBatchPayNum(1);
					order.setOrderStatus(OrderStatus.starting_JZFZ.name());
				} else if (gJBBankVerify.getOrderstatus().equals(
						OrderStatus.accepted_JZFZ.name())) {
					order.setOrderStatus(OrderStatus.starting_YSCS.name());
					orderPayMoney.setBatchPayNum(2);
				} else if (gJBBankVerify.getOrderstatus().equals(
						OrderStatus.accepted_YSCS.name())) {
					order.setOrderStatus(OrderStatus.completed.name());
					orderPayMoney.setBatchPayNum(3);
				}
				//查询订单信息
				GesOrderVO queryOrderInfo = getGesOrderDAO().queryOrderByIdForGjb(Long.parseLong(gJBBankVerify.getContractno()));
				//阳台包直接结束订单
				if(queryOrderInfo.getGoodsType().longValue()==PaymentConstant.GOODS_TYPE_BALCONY.longValue()){
					order.setOrderStatus(OrderStatus.completed.name());
					orderPayMoney.setBatchPayNum(1);
				}
				// 合同编号 即订单id
				order.setId(Long.parseLong(gJBBankVerify.getContractno()));
				orderPayMoney.setBatchPay(new BigDecimal(gJBBankVerify.getAmount()).multiply(new BigDecimal(100)).longValue());
				orderPayMoney.setGesOrder(order);
				//根据交易流水号查询订单支付是否存在
				String code = gJBBankVerify.getCmptxsno().substring(Constants.STAGES_CODE_PREFIX.length());
				MultiplePayment multiplePayment=new MultiplePayment();
				multiplePayment.setSerialPayNo(code);
//				multiplePayment.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
				GesOrder gesOrder=new GesOrder();
				gesOrder.setId(order.getId());
				multiplePayment.setGesOrder(gesOrder);
//				multiplePayment.setPayStatus(PaymentConstant.PAY_STATUS_THREE);
				List<MultiplePayment> list=getMultiplePaymentDAO().queryMultiplePaymentByCodeOrId(multiplePayment);
				if(list!=null&&list.size()>0){
					//更新订单状态
					getGesOrderDAO().updateOrderStatusBySystem(order);
					//更新支付金额表的分期支付金额
					getGesOrderPayMoneyDAO().updateOrderPay(orderPayMoney);
					//更新记录状态
					GesPaymentRecord paymentRecord=new GesPaymentRecord();
					paymentRecord.setCode(code);
					paymentRecord.setPayStatus(EPaymentRecordStatus.GET_RES.getValue());
					getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
					//更新多次支付记录中的支付状态
					int num=multiplePaymentService.updateRecordStatusAndOrderStatus(queryOrderInfo, paymentRecord);
					if (num>0) {
						ans.setRetcode(Confirm.retcode);
						ans.setRetmsg("响应成功");
					} else {
						ans.setRetcode(Confirm.retcodeFail);
						ans.setRetmsg("响应失败");
					}
				}else {
					ans.setRetcode(Confirm.retcodeFail);
					ans.setRetmsg("登记簿中信息不存在");
				}
				
			} else {
				ans.setRetcode(Confirm.retcodeFail);
				ans.setRetmsg("该订单不存在状态不存在，请核对");
			}
		} else {
			ans.setRetcode(Confirm.retcodeFail);
			ans.setRetmsg("验签失败！");
		}
		String sign = ans.verifyBackAns(ans);
		ans.setSignature(RASUtil.sign(sign.getBytes()));
		xmlSring = ans.toStringXml(ans);
		LOG.info("xmlSring:"+ xmlSring);
		return Base64.encode(xmlSring);
	}
	
	
	
}
