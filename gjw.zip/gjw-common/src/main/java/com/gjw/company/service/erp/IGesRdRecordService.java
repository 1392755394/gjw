package com.gjw.company.service.erp;

import java.util.List;
import java.util.Map;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.vo.RdRecordVO;

/**
 * 销售出库单管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月15日 下午3:29:29
 * 
 */
public interface IGesRdRecordService extends IService {
    /**
     * 销售出库单分页查询
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月15日 下午4:00:47
     */
    public List<GesRdRecord> pageByRdRecord(RdRecordVO rdRecord);

    /**
     * 销售出库单分页总数
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月15日 下午4:00:59
     */
    public Long count(RdRecordVO rdRecord);

    /**
     * 根据 单据编号 修改销售出库单状态
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月16日 上午10:16:31
     */
    public boolean updateByRecordCode(GesRdRecord rdRecord);

    /**
     * 根据recordCode 查询销售出库单
     * 
     * @Description
     * @param recordCode
     * @return
     * @author gwb
     * @date 2015年12月18日 上午9:38:42
     */
    public GesRdRecord getByGesRdRecord(GesRdRecord rdCode);

    /**
     * 新增销售出库单
     * 
     * @Description
     * @param rdRecord
     * @author gwb
     * @date 2015年12月18日 上午9:56:16
     */
    public void create(GesRdRecord rdRecord);

    /**
     * 采购入库单分页查询
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年1月4日 上午9:59:30
     */
    public List<Map> pageStockByRdRecord(RdRecordVO rdRecord);

    /**
     * 采购入库单分页查询总数
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年1月4日 上午9:59:30
     */
    public Long countStock(RdRecordVO rdRecord);

    /**
     * 保存发货清单
     * 
     * @Description
     * @param rdRecord
     * @author gwb
     * @date 2016年1月6日 上午10:09:24
     */
    public void saveGesRdRecord(GesRdRecord rdRecord);

    public List<GesRdRecord> pageStockOutByRdRecord(RdRecordVO rdRecord);

    public Long countStockOut(RdRecordVO rdRecord);

    public boolean batchDel(String ids);

    public boolean updateAmount(Long id, Integer amount);

    /**
     * 运营管理---销售出库单page
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年3月8日 下午1:46:36
     */
    public List<GesRdRecord> pageByRdRecordOpMat(RdRecordVO rdRecord);

    /**
     * 运营管理---销售出库单count
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年3月8日 下午1:46:52
     */
    public Long countOpMat(RdRecordVO rdRecord);

}
