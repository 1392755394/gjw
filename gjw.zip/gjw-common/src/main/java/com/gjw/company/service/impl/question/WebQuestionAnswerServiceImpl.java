package com.gjw.company.service.impl.question;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.question.IWebQuestionAnswerDAO;
import com.gjw.company.dao.question.IWebQuestionDAO;
import com.gjw.company.service.question.IWebQuestionAnswerService;
import com.gjw.entity.question.WebQuestion;
import com.gjw.entity.question.WebQuestionAnswer;
import com.gjw.vo.WebQuestionAnswerVO;

/**
 * 
* @Description: 问题答案service实现类
* @author  zhaoyonglian
* @date 2015年12月15日 上午11:19:09
*
 */
@Component("webQuestionAnswerServiceImpl")
public class WebQuestionAnswerServiceImpl implements
		IWebQuestionAnswerService {

	@Autowired
	private IWebQuestionAnswerDAO dao;
	
	@Autowired
	private IWebQuestionDAO questionDao;

    @Override
    @Transactional(readOnly=true)
    public WebQuestionAnswer getById(Long id) {
        // TODO Auto-generated method stub
        WebQuestionAnswer ans = dao.getById(id);
        if(null != ans){
            Hibernate.initialize(ans.getQuestion());
        }
        return ans;
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebQuestionAnswer> pageBySubjectAndInvalid(WebQuestionAnswerVO answer) {
        // TODO Auto-generated method stub
        List<WebQuestionAnswer> list = dao.pageBySubjectAndInvalid(answer);
        if(null != list && list.size()>0){
            for (WebQuestionAnswer webQuestionAnswer : list) {
                Hibernate.initialize(webQuestionAnswer.getQuestion());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly=true)
    public Long countBySubjectAndInvalid(WebQuestionAnswerVO answer) {
        // TODO Auto-generated method stub
        return dao.countBySubjectAndInvalid(answer);
    }

    @Override
    @Transactional
    public boolean insert(WebQuestionAnswer entity) {
        // TODO Auto-generated method stub
        boolean ret = dao.saveResultBoolean(entity);
        if(ret){
            //修改问题答案数量
            WebQuestion question = questionDao.getById(entity.getQuestion().getId());
            if(null != question){
                if (null == question.getAnwserAmount()) {
                    question.setAnwserAmount(1);
                } else {
                    int amount = question.getAnwserAmount();
                    question.setAnwserAmount(++amount);
                }
                questionDao.updateQuestion(question);
            }
        }
        return ret;
    }

    @Override
    @Transactional
    public boolean update(WebQuestionAnswer entity) {
        // TODO Auto-generated method stub
        return dao.updateAnswer(entity);
    }

    @Override
    public int delete(Long id) {
        // TODO Auto-generated method stub
        return dao.delete(id);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = dao.remove(Long.valueOf(id));
                    if (row > 0) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                row = dao.remove(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        if (0 == success && 0 != error) {
            return "失败删除" + error + "条问题答案！";
        } else if (0 == error && 0 != success) {
            return "成功删除" + success + "条问题答案！";
        } else {
            return "成功删除" + success + "条问题答案,失败删除" + error + "条问题答案！";
        }
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebQuestionAnswer> listByQuestion(Long questionId) {
        // TODO Auto-generated method stub
        List<WebQuestionAnswer> list = dao.listByQuestion(questionId);
        if(null != list && list.size()>0){
            for (WebQuestionAnswer webQuestionAnswer : list) {
                Hibernate.initialize(webQuestionAnswer.getUser());
            }
        }
        return list;
    }
	
}
