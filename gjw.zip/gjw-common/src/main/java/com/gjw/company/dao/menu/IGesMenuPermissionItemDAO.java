package com.gjw.company.dao.menu;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.menu.GesMenu;
import com.gjw.entity.menu.GesMenuPermissionItem;

public interface IGesMenuPermissionItemDAO extends IDAO {
    
    boolean delete(GesMenuPermissionItem menuPermissionItem);
    
    long create(GesMenuPermissionItem menuPermissionItem);
    
    List<GesMenuPermissionItem> listMenuPermissionItemsByMenus(List<GesMenu> menuList);
    
    void deleteAll();
   
}
