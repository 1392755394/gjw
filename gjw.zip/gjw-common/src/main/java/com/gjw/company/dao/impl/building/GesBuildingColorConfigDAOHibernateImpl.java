package com.gjw.company.dao.impl.building;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.building.IGesBuildingColorConfigDAO;
import com.gjw.entity.building.GesBuildingColorConfig;
@Component("gesBuildingColorConfigDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesBuildingColorConfigDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesBuildingColorConfigDAO{

    @Override
    public GesBuildingColorConfig listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesBuildingColorConfig) super.get(id);
    }

    @Override
    public boolean updateGesBuildingColorConfig(GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesBuildingColorConfig(
            GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesBuildingColorConfig item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesBuildingColorConfig> listByGesBuildingColorConfig(
            GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesBuildingColorConfig item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesBuildingColorConfig>) super.findByPageCallBack(hql,"",params,model,null);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesBuildingColorConfig.class;
    }

}
