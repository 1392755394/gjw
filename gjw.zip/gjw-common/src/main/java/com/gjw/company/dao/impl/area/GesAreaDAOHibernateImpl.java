package com.gjw.company.dao.impl.area;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.ResultTransformer;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.area.IGesAreaDAO;
import com.gjw.entity.area.GesArea;
import com.gjw.entity.area.GesCityDredge;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.goods.Goods;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesAreaVO;

@Component("gesAreaDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesAreaDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesAreaDAO{
    @Override
    public GesArea getById(Long id) {
        
        return (GesArea) super.get(id);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesArea.class;
    }

    @Override
    public List<GesArea> listByParentId(Long parentId) {
        
        GesArea ga = new GesArea();
        ga.setId(parentId);
        String hql = "from GesArea a where a.parentArea = ? order by orderTag asc";
        List<GesArea> areaList = (List<GesArea>) this.getHibernateTemplate().find(hql, ga);
        return areaList;
    }
    
    @Override
    public Map<Object, Object>  pageByParentId(GesArea gesArea) {

        Map<Object, Object> map = new HashMap<Object, Object>();
        StringBuffer selectSb = new StringBuffer();
        selectSb.append("select a.id,a.name,a.orderTag,a.parentArea,a.isAdd, a.createdDatetime ");
        
        StringBuffer fromSb = new StringBuffer();
        fromSb.append("from GesArea a where a.isCity = 'y'");
         
        List<Object> paramList = new ArrayList<Object>();
        if(StringUtil.notEmpty(gesArea.getName())){
            fromSb.append(" and a.name =?");
            paramList.add(gesArea.getName());
        }
        if(StringUtil.notEmpty(gesArea.getIsAdd())){
            fromSb.append("and a.isAdd = ?");
            paramList.add(gesArea.getIsAdd());
        }
        if(StringUtil.notEmpty(String.valueOf(gesArea.getParentArea().getId()))){
            fromSb.append("and a.parentArea.id = ?");
            paramList.add(gesArea.getParentArea().getId());
        }        
        fromSb.append("order by a.isAdd desc , a.orderTag desc , a.id desc");
       System.out.println("##############"+paramList);
        //totalCount
        long totalCount = super.countHql(fromSb.toString(), paramList);
        List<GesArea> areaPageList =  (List<GesArea>) super.findByPageCallBack(fromSb.toString(), selectSb.toString(), paramList, gesArea, null);
        map.put("totalCount", totalCount);
        map.put("areaList", areaPageList);
        System.out.println("@@@@@@@@@@@@@@@@@"+selectSb.append(fromSb));
        return map;
    }

    @Override
    public Map<Object, Object> pageCityDredgeByParentId(GesArea area) {
//        SELECT b.`NAME` provinceName,c.`NAME`
//        cityName,a.gmtAdd,a.provinceId,a.cityId,a.id FROM g_city_dredge
//        a,g_area b,g_area c
//        WHERE a.provinceId=b.id AND a.cityId=c.id
//        <if test="provinceId !=null and provinceId>0 ">
//            and provinceId=#{provinceId}
//        </if>
        // TODO Auto-generated method stub
        String hql = "select CityDredge cd, GesArea ga, GesArea gas where cd.province.id = ga.id and ga.city.id = gas.id ";  //if....
        return null;
    }

    @Override
    public Map<Object, Object> pageCityByParentId(GesAreaVO gesArea) {

       return null;
    }

    @Override
    public Map<Object, Object> pageCityByAreaVO(GesAreaVO gesArea) {
        
        Map<Object, Object> map = new HashMap<Object, Object>();
        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();  //本函数按照已开通城市排序
        
        if(null==gesArea.getCityId()&&null==gesArea.getCuntroyId()){

            selectSb.append("select a.id as provinceId, a.name as provinceName,b.id as cityId, b.name as cityName  ");
            fromSb.append("FROM GesArea a, GesArea b  ");
            whereSb.append(" where a.parentArea.id = 0 and  a.id = b.parentArea.id and b.isCity = 'y'");
            fromSb.append(whereSb);
            
            List<Object> paramList = new ArrayList<Object>();
            if(StringUtil.notEmpty(gesArea.getName())){
                fromSb.append(" and b.name =?");
                paramList.add(gesArea.getName());
            }
            if(StringUtil.notEmpty(String.valueOf(gesArea.getId()))&&gesArea.getId()>0){
                fromSb.append(" and a.id = ?");
                paramList.add(gesArea.getId());
            }

//            fromSb.append("order by a.isAdd desc , a.orderTag desc , a.id desc");
//         
//            List<GesArea> areaPageList =  (List<GesArea>) super.findByPageCallBack(fromSb.toString(),selectSb.toString(), paramList, gesArea, null);
//            map.put("totalCount", (long)0);
//            map.put("areaList", areaPageList);
        }    
        return map;
    }
    
    @Override
    public long count(GesAreaVO areaVO, String hql, List<Object> paramList){
        //如果hql为空，则执行默认hql
        long count = super.findByPageCallBackCount(hql, paramList);
        return count;
    }

    @Override
    public List<GesAreaVO> pageByHql(String finalHql, String finalhqlResultParameter, List<Object> finalLs,
            GesArea finalentity, ResultTransformer finalaliasToEntity) {

        List<GesAreaVO> areaVOList =   (List<GesAreaVO>)findByPageCallBack(finalHql, finalhqlResultParameter, finalLs, finalentity, finalaliasToEntity);
        return areaVOList;
    }
    
    public List<?> ListAllByClass(Class<?> className){
        
        return (List<?>) getHibernateTemplate().find("from " + className.getName());
    }

    @Override
    public Map<Object, Object> pageCountyByAreaVO(GesAreaVO areaVO) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<GesArea> listGesAreaByIsAdded() {

        return (List<GesArea>) getHibernateTemplate().find("From GesArea where isCity = 'y' and isAdd ='y' ");
    }

    @Override
    public List<GesArea> listByParentAndBuilding(Long parentId) {

        // 生成查询条件
        StringBuilder hql = new StringBuilder();
        hql.append("from GesArea a where a.parentArea.id = ? and a.id in ");
        hql.append("(select b.county.id from GesBuilding b where b.invalid = false ) ");
        hql.append(" order by a.orderTag asc");
        
        return (List<GesArea>) super.getHibernateTemplate().find(hql.toString(), parentId);
    }

    @Override
    public List<GesArea> getAll(String isAdd, String isCity) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesArea where 1=1");
        if(StringUtil.notEmpty(isAdd)){
            hql.append(" and isAdd = '"+isAdd+"'");
        }
        if(StringUtil.notEmpty(isCity)){
            hql.append(" and isCity = '"+isCity+"'");
        }
        return (List<GesArea>) getHibernateTemplate().find(hql.toString());
    }

    @Override
    public GesArea getByName(String name) {
        List<GesArea> list = (List<GesArea>) getHibernateTemplate().find(" from GesArea where name = '"+name+"'");
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;
    }

    public List<GesArea> listByParentArea() {
        // TODO Auto-generated method stub
        return (List<GesArea>) getHibernateTemplate().find("From GesArea where parentArea.id=0");
    }

    @Override
    public List<GesArea> listByChildingArea(Long parentId) {
        // TODO Auto-generated method stub
        String hql="From GesArea where parentArea.id=? and isAdd='y' ";
        return (List<GesArea>) getHibernateTemplate().find(hql,parentId);
    }
    
}
