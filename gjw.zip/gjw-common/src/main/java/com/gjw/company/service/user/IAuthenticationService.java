package com.gjw.company.service.user;

import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.User;

/**
 * created by 重剑 on 2015/9/17 0017
 */
public interface IAuthenticationService {

    void add(Authentication authentication);

    Authentication login(Authentication authentication);

    void modifyPassword(User user, String oldPassword, String newPassword);

    void resetPassword(User user, String newPassword);

    /**
     * @Description
     * @param name
     * @return
     * @author qingye
     * @date Dec 26, 2015 4:05:51 PM
     */

    Authentication getByLogin(String login);

    /**
     * @Description
     * @param user
     * @author qingye
     * @date Jan 11, 2016 4:08:03 PM
     */

    int encryptPassword();

    void modifyMobilePassword(User userFlag, String oldPassWord, String passwordKey);

}
