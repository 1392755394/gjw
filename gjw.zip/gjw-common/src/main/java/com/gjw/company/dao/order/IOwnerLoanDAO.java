package com.gjw.company.dao.order;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.LoanApplyInfo;
import com.gjw.vo.order.LoanApplyInfoVO;

public interface IOwnerLoanDAO extends IDAO {
	
	/**
	 * 根据订单id查询要贷款的订单的信息
	 * 在这里进行数据的处理，根据产品包的类型，处理装修房的面积
	 * @param orderId
	 */
	public LoanApplyInfoVO queryLoanOrderInfo(Long orderId);
	
	/**
	 * 统计申请成功的次数
	 * @param orderId
	 * @return
	 */
	public Long countOwnerLoanTimes(Long orderId);
	
	/**
	 * 统计申请的次数
	 * @param orderId
	 * @return
	 */
	public Long countApplyTimes(Long orderId);
	
	public void addOwnerLoanInfo(LoanApplyInfo loanApplyInfo);
	
	/**
	 * 更新贷款信息状态
	 * @param loanApplyInfo
	 * @return
	 */
	public int updateOwnerLoanInfoStatus(LoanApplyInfo loanApplyInfo);
	

}
