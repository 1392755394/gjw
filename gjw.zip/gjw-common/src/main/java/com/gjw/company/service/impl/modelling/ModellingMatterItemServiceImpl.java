package com.gjw.company.service.impl.modelling;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.modelling.IModellingMatterItemService;
import com.gjw.entity.modelling.ModellingMatterItem;
import com.gjw.utils.StringUtil;

/**
 * 
* @Description: 造型库service实现类
* @author  zhaoyonglian
* @date 2016年1月9日 下午3:32:53
*
 */
@Component("modellingMatterItemServiceImpl")
public class ModellingMatterItemServiceImpl extends AbstractServiceImpl implements IModellingMatterItemService {

    @Override
    @Transactional(readOnly = true)
    public List<ModellingMatterItem> pageByCodeAndName(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        List<ModellingMatterItem> list =  super.getModellingMatterItemDao().pageByCodeAndName(item);
        if(null != list && list.size()>0){
            for (ModellingMatterItem it : list) {
                Hibernate.initialize(it.getMatter());
                if(StringUtil.notEmpty(it.getMatter()) && StringUtil.notEmpty(it.getMatter().getId())){
                    Hibernate.initialize(it.getMatter().getBrand());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByCodeAndName(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        return super.getModellingMatterItemDao().countByCodeAndName(item);
    }

    @Override
    @Transactional
    public boolean update(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        return super.getModellingMatterItemDao().updateItem(item);
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        // TODO Auto-generated method stub
        return super.getModellingMatterItemDao().delBatchByID(ids);
    }

    @Override
    @Transactional
    public boolean create(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        return super.getModellingMatterItemDao().saveResultBoolean(item);
    }

}