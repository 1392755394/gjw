package com.gjw.company.service.order;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.order.WebOrderLog;
import com.gjw.entity.order.WebOrderLogImage;
import com.gjw.vo.WebOrderLogVO;

/**
 * 
* @Description: 日志service类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:22:44
*
 */
public interface IWebOrderLogService extends IService {
    /**
     * 
    * @Description  获取日志详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:31:48
     */
    public WebOrderLog getById(Long id);
    
    /**
     * 
    * @Description  分页列表，搜索条件：问题标题
    * @param subject
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:34:10
     */
    public List<WebOrderLog> pageByContent(WebOrderLogVO log);
    
    /**
     * 
    * @Description  总数
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午1:51:20
     */
    public Long countByContent(WebOrderLogVO log);
    /**
     * 
    * @Description  批量废弃问题
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午4:53:34
     */
    public String invalidByIds(String ids);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebOrderLog entity);
    /**
     * 
    * @Description  修改数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:45
     */
    public boolean update(WebOrderLog entity);
    /**
     * 
    * @Description  删除数据（物理删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:54
     */
    public int delete(Long id);
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    /**
     * 
    * @Description  标签下所有案例
    * @param labelId
    * @param log
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月2日 下午2:25:24
     */
    public List<Long> findOrderByLabel(Long labelId, WebOrderLog log);
    
    /**
     * 
    * @Description  订单最新的日志
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月2日 下午3:27:55
     */
    public WebOrderLog findLastByOrder(Long orderId);
    
    /**
     * 
    * @Description  获取订单所有日志
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月3日 下午4:39:12
     */
    public List<WebOrderLog> findAllByOrder(Long orderId);
    
    public boolean insertOrderLogImage(WebOrderLogImage logImage);
    
    /**
     * 
    * @Description  获取订单，标签下日志
    * @param labelId
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月23日 上午10:42:13
     */
    public List<WebOrderLog> findLogByLabelAndOrder(Long labelId,Long orderId);
    
    /**
     * 
    * @Description  获取所有有日志的订单id
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月23日 下午3:19:20
     */
    public List<Long> getAllOrder();
}
