package com.gjw.company.service.impl.label;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.exception.GenericException;
import com.gjw.company.service.label.IWebLabelService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.label.WebLabel;
import com.gjw.utils.StringUtil;
@Component("webLabelServiceImpl")
@Transactional
public class WebLabelServiceImpl extends AbstractServiceImpl implements IWebLabelService{

    @Override
    public void add(WebLabel label) {
        this.getWebLabelDAO().add(label);
    }

    @Override
    public void remove(Long id) {
        this.getWebLabelDAO().remove(id);
    }

    @Override
    public void update(WebLabel label) {
        WebLabel old=this.getWebLabelDAO().get(label.getId());
        if(old.getParent().getId().equals(0)){
            List<WebLabel> child=this.getWebLabelDAO().listChildByParent(old.getId());
            if(child.size()>0){
                if(!label.getParent().getId().equals(0))
                    throw new GenericException("更新失败，当前节点为一级节点，只有当子节点为空时才能更新为二级节点");
            }
            if(!label.getPropertyType().getId().equals(old.getPropertyType().getId())){
                this.getWebLabelDAO().updatePeropertyByParent(label.getPropertyType(),label.getId());
            }
        }
        StringUtil.copyProperties(label, old);
        this.getWebLabelDAO().update(old);
    }

    @Override
    public WebLabel get(Long id) {
        WebLabel label=this.getWebLabelDAO().get(id);
        Hibernate.initialize(label.getPropertyType());
        if(!label.getParent().getId().equals(0l))
            Hibernate.initialize(label.getParent());
        return label;
    }

    @Override
    public List<WebLabel> listParentByPeroperty(Dictionary peroperty) {
        return this.getWebLabelDAO().listParentByPeroperty(peroperty);
    }

    @Override
    public List<WebLabel> listChildByParent(Long parentId) {
        return this.getWebLabelDAO().listChildByParent(parentId);
    }

    @Override
    public void updatePeropertyByParent(Dictionary peroperty, Long parentId) {
        this.getWebLabelDAO().updatePeropertyByParent(peroperty, parentId);
    }

    @Override
    public List<WebLabel> batchRemove(List<Long> list) {
        List<WebLabel> result=new ArrayList<WebLabel>();
        for(Long id:list){
            List<WebLabel> child = this.getWebLabelDAO().listChildByParent(id);
            if(child!=null && child.size()!=0){
                result.add(this.getWebLabelDAO().get(id));
                continue;
            }
            this.getWebLabelDAO().remove(id);
        }
        return result;
    }

    @Override
    public List<WebLabel> batchReuse(List<Long> list) {
        List<WebLabel> result=new ArrayList<WebLabel>();
        for(Long id:list){
            WebLabel item=this.getWebLabelDAO().get(id);
            if(!item.getParent().getId().equals(0l) && item.getParent().getInvalid()){
                result.add(item);
                continue;
            }
            this.getWebLabelDAO().reuse(item.getId());
        }
        return result;
    }

    @Override
    public List<WebLabel> page(WebLabel label) {
        List<WebLabel> list = this.getWebLabelDAO().page(label);
        if(null != list && list.size()>0){
            for (WebLabel webLabel : list) {
                if(StringUtil.notEmpty(webLabel.getPropertyType().getId()))
                 webLabel.getPropertyType().getText();
            }
        }
        return list;
    }

    @Override
    public long count(WebLabel label) {
        return this.getWebLabelDAO().count(label);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebLabel> baikeLabel(Long parentId) {
        // TODO Auto-generated method stub
        Dictionary peroperty=new Dictionary();
        peroperty.setId(parentId);
        List<WebLabel> list=this.getWebLabelDAO().listParentByPeroperty(peroperty);
        for (WebLabel webLabel : list) {
            webLabel.setChildList(this.getWebLabelDAO().listChildByParent(webLabel.getId()));
        }
        return list;
    }
}
