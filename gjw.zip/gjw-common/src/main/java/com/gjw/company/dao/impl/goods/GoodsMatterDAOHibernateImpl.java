package com.gjw.company.dao.impl.goods;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.dao.goods.IGoodsMatterDAO;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsMatterVO;

/**
 * 
 * @Description: 房间物料关系dao实现类
 * @author zhaoyonglian
 * @date 2015年12月29日 上午10:58:04
 * 
 */
@Component("goodsMatterDAOHibernateImpl")
public class GoodsMatterDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsMatterDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsMatter.class;
    }

    @Override
    public GoodsMatter queryById(Long id) {
        return (GoodsMatter) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> pageStandardMatter(GoodsMatterVO goodsMatter) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and gm.type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and gm.room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCode())) {
            hql.append(" and gm.matter.code like ?");
            ls.add("%" + goodsMatter.getMatter().getCode() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getModel())) {
            hql.append(" and gm.matter.model like ?");
            ls.add("%" + goodsMatter.getMatter().getModel() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getName())) {
            hql.append(" and gm.matter.name like ?");
            ls.add("%" + goodsMatter.getMatter().getName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getBrandName())) {
            hql.append(" and gm.matter.brand.name like ?");
            ls.add("%" + goodsMatter.getBrandName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and gm.matter.id != ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMark()) && 0 == goodsMatter.getMark().getId()) {
            hql.append(" and gm.mark.id IS NULL");
        }
        hql.append(" and gm.matter.invalid = 0");
        hql.append(" order by gm.createdDatetime desc");
        return (List<GoodsMatter>) super.findByPageCallBack(hql.toString(), "", ls, goodsMatter, null);
    }

    @Override
    public Long countStandardMatter(GoodsMatterVO goodsMatter) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and gm.type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and gm.room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCode())) {
            hql.append(" and gm.matter.code like ?");
            ls.add("%" + goodsMatter.getMatter().getCode() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getModel())) {
            hql.append(" and gm.matter.model like ?");
            ls.add("%" + goodsMatter.getMatter().getModel() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getName())) {
            hql.append(" and gm.matter.name like ?");
            ls.add("%" + goodsMatter.getMatter().getName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getBrandName())) {
            hql.append(" and gm.matter.brand.name like ?");
            ls.add("%" + goodsMatter.getBrandName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and gm.matter.id != ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMark()) && 0 == goodsMatter.getMark().getId()) {
            hql.append(" and gm.mark.id IS NULL");
        }
        hql.append(" and gm.matter.invalid = 0");
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            if (StringUtil.notEmpty(id))
                idList.add(Long.parseLong(id));
        }

        return super.delBatchByID(idList) > 0;
    }

    @Override
    public boolean update(Long id, Integer amount, Boolean isStandard) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" update GoodsMatter set");
        hql.append(" updatedDatetime = ?");
        ls.add(new Timestamp(System.currentTimeMillis()));
        if (StringUtil.notEmpty(amount)) {
            hql.append(", amount = ? ");
            ls.add(amount);
        }
        if (StringUtil.notEmpty(isStandard)) {
            hql.append(" , isStandard = ? ");
            ls.add(isStandard);
        }
        if (StringUtil.notEmpty(id)) {
            hql.append(" where id = ?");
            ls.add(id);
        }
        return super.updateByParam(hql.toString(), ls);
    }

    @Override
    public long create(GoodsMatter goodsMatter) {
        if (null != goodsMatter.getMark() && null == goodsMatter.getMark().getId()) {
            goodsMatter.setMark(null);
        }
        goodsMatter.setIsStandard(true);
        super.add(goodsMatter);
        return goodsMatter.getId();
    }

    @Override
    public void updateMatter(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" update GoodsMatter set");
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" type.id = ? ,");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMark()) && StringUtil.notEmpty(goodsMatter.getMark().getId())) {
            hql.append(" mark.id = ? ,");
            ls.add(goodsMatter.getMark().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getAppMark()) && StringUtil.notEmpty(goodsMatter.getAppMark().getId())) {
            hql.append(" appMark.id = ? ,");
            ls.add(goodsMatter.getAppMark().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getIsStandard())) {
            hql.append(" isStandard = ? ,");
            ls.add(goodsMatter.getIsStandard());
        }
        hql.append("updatedDatetime = ?");
        ls.add(new Timestamp(System.currentTimeMillis()));
        hql.append(" where id != 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and matter.id = ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getId())) {
            hql.append(" and id = ?");
            ls.add(goodsMatter.getId());
        }
        super.updateByParam(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> listMatterWithType(Long markId, Long type) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        if (null == markId) {
            return null;
        }
        hql.append(" from GoodsMatter where matter.invalid = 0 and invalid = 0");
        hql.append(" and mark.id = ?");
        list.add(markId);
        if (null != type) {
            hql.append(" and type.id = ?");
            list.add(type);
        }
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.list();
    }

    @Override
    public boolean updateMatterByMark(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" update GoodsMatter set");
        hql.append(" mark.id = NULL");
        hql.append(" ,updatedDatetime = ?");
        ls.add(new Timestamp(System.currentTimeMillis()));
        hql.append(" ,type.id =" + DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
        hql.append(" where id != 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMark()) && StringUtil.notEmpty(goodsMatter.getMark().getId())) {
            hql.append(" and mark.id = ?");
            ls.add(goodsMatter.getMark().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and matter.id = ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        return super.updateByParam(hql.toString(), ls);
    }

    // DIY 接口 start

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> listMatter(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm left join fetch gm.mark where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and gm.type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and gm.room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and gm.matter.id != ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        hql.append(" and gm.matter.invalid = 0");
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setParameter(i, ls.get(i));
        }
        return query.list();
    }

    @Override
    public boolean batchCreate(List<GoodsMatter> list) {
        // TODO Auto-generated method stub
        return super.batchAdd(list) > 0;
    }

    @Override
    public boolean update(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        GoodsMatter old = (GoodsMatter) super.get(goodsMatter.getId());
        StringUtil.copyProperties(goodsMatter, old);
        return super.update(old) > 0;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> pageMatterByGoodsAndCategory(GoodsMatter goodsMatter) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCategory())
                && StringUtil.notEmpty(goodsMatter.getMatter().getCategory().getId()) && goodsMatter.getMatter().getCategory().getId() > 0) {
            hql.append(" and (gm.matter.category.id = ?");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent IS NOT NULL and gm.matter.category.parent.id = ?)");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent.parent IS NOT NULL and gm.matter.category.parent.parent.id = ?)");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent.parent.parent IS NOT NULL and gm.matter.category.parent.parent.parent.id = ?))");
            ls.add(goodsMatter.getMatter().getCategory().getId());
        }
        hql.append(" and gm.matter.invalid = 0");
        hql.append(" order by gm.createdDatetime desc");
        return (List<GoodsMatter>) super.findByPageCallBack(hql.toString(), "", ls, goodsMatter, null);
    }

    @Override
    public Long countMatterByGoodsAndCategory(GoodsMatter goodsMatter) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCategory())
                && StringUtil.notEmpty(goodsMatter.getMatter().getCategory().getId()) && goodsMatter.getMatter().getCategory().getId() > 0) {
            hql.append(" and (gm.matter.category.id = ?");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent IS NOT NULL and gm.matter.category.parent.id = ?)");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent.parent IS NOT NULL and gm.matter.category.parent.parent.id = ?)");
            ls.add(goodsMatter.getMatter().getCategory().getId());
            hql.append(" or (gm.matter.category.parent.parent.parent IS NOT NULL and gm.matter.category.parent.parent.parent.id = ?))");
            ls.add(goodsMatter.getMatter().getCategory().getId());
        }
        hql.append(" and gm.matter.invalid = 0");
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> listMarkForGes(Long roomId, Long type) {
        // TODO Auto-generated method stub
        List<Object> ls =  new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if(StringUtil.notEmpty(roomId)){
            hql.append(" and gm.room.id = ?");
            ls.add(roomId);
        }
        if(StringUtil.notEmpty(type)){
            hql.append(" and gm.type.id = ?");
            ls.add(type);
        }
        hql.append(" and gm.mark.id is not null and gm.mark.id != ''");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setString(i, ls.get(i).toString());
        }
        
        return query.list();
    }

    @Override
    public boolean updateMatterByAppMark(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" update GoodsMatter set");
        hql.append(" appMark.id = NULL");
        hql.append(" ,updatedDatetime = ?");
        ls.add(new Timestamp(System.currentTimeMillis()));
        //hql.append(" ,type.id =" + DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
        hql.append(" where id != 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getAppMark()) && StringUtil.notEmpty(goodsMatter.getAppMark().getId())) {
            hql.append(" and appMark.id = ?");
            ls.add(goodsMatter.getAppMark().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        /*if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }*/
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and matter.id = ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        return super.updateByParam(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> listAppMarkForGes(Long roomId, Long type) {
        List<Object> ls =  new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if(StringUtil.notEmpty(roomId)){
            hql.append(" and gm.room.id = ?");
            ls.add(roomId);
        }
        if(StringUtil.notEmpty(type)){
            hql.append(" and gm.type.id = ?");
            ls.add(type);
        }
        hql.append(" and gm.appMark.id is not null and gm.appMark.id != ''");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setString(i, ls.get(i).toString());
        }
        
        return query.list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> pageAppStandardMatter(GoodsMatterVO goodsMatter) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and gm.type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and gm.room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCode())) {
            hql.append(" and gm.matter.code like ?");
            ls.add("%" + goodsMatter.getMatter().getCode() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getModel())) {
            hql.append(" and gm.matter.model like ?");
            ls.add("%" + goodsMatter.getMatter().getModel() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getName())) {
            hql.append(" and gm.matter.name like ?");
            ls.add("%" + goodsMatter.getMatter().getName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getBrandName())) {
            hql.append(" and gm.matter.brand.name like ?");
            ls.add("%" + goodsMatter.getBrandName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and gm.matter.id != ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getAppMark()) && 0 == goodsMatter.getAppMark().getId()) {
            hql.append(" and gm.appMark.id IS NULL");
        }
        hql.append(" and gm.matter.invalid = 0");
        hql.append(" order by gm.createdDatetime desc");
        return (List<GoodsMatter>) super.findByPageCallBack(hql.toString(), "", ls, goodsMatter, null);
    }

    @Override
    public Long countAppStandardMatter(GoodsMatterVO goodsMatter) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMatter gm where gm.invalid = 0");
        if (StringUtil.notEmpty(goodsMatter.getGoods()) && StringUtil.notEmpty(goodsMatter.getGoods().getId())) {
            hql.append(" and gm.goods.id = ?");
            ls.add(goodsMatter.getGoods().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getType()) && StringUtil.notEmpty(goodsMatter.getType().getId())) {
            hql.append(" and gm.type.id = ?");
            ls.add(goodsMatter.getType().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getRoom()) && StringUtil.notEmpty(goodsMatter.getRoom().getId())) {
            hql.append(" and gm.room.id = ?");
            ls.add(goodsMatter.getRoom().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getCode())) {
            hql.append(" and gm.matter.code like ?");
            ls.add("%" + goodsMatter.getMatter().getCode() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getModel())) {
            hql.append(" and gm.matter.model like ?");
            ls.add("%" + goodsMatter.getMatter().getModel() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getName())) {
            hql.append(" and gm.matter.name like ?");
            ls.add("%" + goodsMatter.getMatter().getName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getBrandName())) {
            hql.append(" and gm.matter.brand.name like ?");
            ls.add("%" + goodsMatter.getBrandName() + "%");
        }
        if (StringUtil.notEmpty(goodsMatter.getMatter()) && StringUtil.notEmpty(goodsMatter.getMatter().getId())) {
            hql.append(" and gm.matter.id != ?");
            ls.add(goodsMatter.getMatter().getId());
        }
        if (StringUtil.notEmpty(goodsMatter.getAppMark()) && 0 == goodsMatter.getAppMark().getId()) {
            hql.append(" and gm.appMark.id IS NULL");
        }
        hql.append(" and gm.matter.invalid = 0");
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMatter> listMatterWithAppMark(Long markId, Long type) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        if (null == markId) {
            return null;
        }
        hql.append(" from GoodsMatter where matter.invalid = 0 and invalid = 0");
        hql.append(" and appMark.id = ?");
        list.add(markId);
        if (null != type) {
            hql.append(" and type.id = ?");
            list.add(type);
        }
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.list();
    }

}
