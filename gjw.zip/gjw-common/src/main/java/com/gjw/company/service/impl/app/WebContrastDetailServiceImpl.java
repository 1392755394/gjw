package com.gjw.company.service.impl.app;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.app.IWebContrastDetailService;
import com.gjw.entity.app.WebContrastDetail;

@Component("webContrastDetailServiceImpl")
public class WebContrastDetailServiceImpl extends AbstractServiceImpl implements IWebContrastDetailService{

    @Override
    @Transactional(readOnly=true)
    public WebContrastDetail get(Long id) {
        // TODO Auto-generated method stub
        WebContrastDetail model=super.getWebContrastDetailDAO().get(id);
        return model;
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebContrastDetail> getList(WebContrastDetail model) {
        // TODO Auto-generated method stub
        List<WebContrastDetail> list=super.getWebContrastDetailDAO().getList(model);
        for (WebContrastDetail webContrastDetail : list) {
            Hibernate.initialize(webContrastDetail.getContrast());
        }
        return list;
    }

    @Override
    @Transactional()
    public boolean addWebContrastDetail(WebContrastDetail model) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    @Transactional()
    public void updateWebContrastDetail(WebContrastDetail model) {
        // TODO Auto-generated method stub
        
    }

}
