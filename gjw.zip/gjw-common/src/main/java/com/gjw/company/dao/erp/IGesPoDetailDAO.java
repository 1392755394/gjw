package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesPoDetail;

/**
 * 采购管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月17日 下午1:30:08
 * 
 */
public interface IGesPoDetailDAO extends IDAO {

    /**
     * 分页查询
     * 
     * @Description
     * @param poCode
     * @return
     * @author gwb
     * @date 2015年12月30日 下午5:14:25
     */
    public List<GesPoDetail> pagePoDetailByPoCode(GesPoDetail poCode);

    /**
     * 分页总数查询
     * 
     * @Description
     * @param poDetail
     * @return
     * @author gwb
     * @date 2015年12月30日 下午5:14:33
     */
    public Long count(GesPoDetail poDetail);

    /**
     * 根据 poCode查询gesPoDetail
     * 
     * @Description
     * @param poCode
     * @return
     * @author gwb
     * @date 2015年12月30日 下午5:14:42
     */
    public GesPoDetail getByPoCode(String poCode);

    /**
     * 新增gesPodetail
     * 
     * @Description
     * @param poDetail
     * @author gwb
     * @date 2015年12月30日 下午5:15:05
     */
    public void create(GesPoDetail poDetail);

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 批量删除
     */
    public boolean batchDel(String ids);

    /**
     * 修改采购数量
     * 
     * @Description
     * @param id
     * @param amount
     * @return
     * @author gwb
     * @date 2015年12月31日 下午1:47:16
     */
    public boolean updateAmount(Long id, Double amount);

    public GesPoDetail getRoomIdById(Long iorderseq);

}
