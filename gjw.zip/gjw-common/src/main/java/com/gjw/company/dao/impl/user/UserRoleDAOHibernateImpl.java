package com.gjw.company.dao.impl.user;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IUserRoleDAO;
import com.gjw.entity.user.UserRoleItem;

@Component("userRoleDAOHibernateImpl")
public class UserRoleDAOHibernateImpl extends AbstractDAOHibernateImpl implements
        IUserRoleDAO {
    
    @Override
    protected Class getEntityClass() {
        return UserRoleItem.class;
    }

    @Override
    public List<UserRoleItem> listRolesOfUser(long userId) {
        List<UserRoleItem> userRoleList = (List<UserRoleItem>)this.getHibernateTemplate().find(" from UserRoleItem g left join fetch g.role where g.role.invalid = false and  g.gesUser.id=" + userId);
        return userRoleList;
    }

}
