package com.gjw.company.dao.impl.menu;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.menu.IGesMenuDAO;
import com.gjw.entity.menu.GesMenu;
import com.gjw.entity.menu.GesMenuRoleItem;
import com.gjw.utils.StringUtil;

/**
 * 菜单dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月10日 
 *
 */
@Component("gesMenuDAOHibernateImpl")
public class GesMenuDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesMenuDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GesMenu.class;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<GesMenu> listMenusByParentId(long parentId) {

        String hql = "from GesMenu m where m.parent.id = ? and m.invalid = false order by m.orderTag asc";
        
        return (List<GesMenu>) super.getHibernateTemplate().find(hql, parentId);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<GesMenu> listMenus() {

        String hql = "from GesMenu m where m.invalid = false order by m.orderTag asc";
        
        return (List<GesMenu>) super.getHibernateTemplate().find(hql);
    }

    @Override
    public long create(GesMenu menu) {

        super.add(menu);
        return menu.getId();
    }

    @Override
    public boolean update(GesMenu menu) {

        GesMenu old = (GesMenu)super.get(menu.getId());
        StringUtil.copyPropertiesAllowEmpty(menu, old);
        return super.update(old) == 1;
        
    }

    @Override
    public boolean delete(GesMenu menu) {

        return super.remove(menu.getId()) == 1;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<GesMenu> listMenusOfRole(long roleId) {
        List<GesMenuRoleItem> menuRoleList = (List<GesMenuRoleItem>)super.getHibernateTemplate().find("from GesMenuRoleItem g left join fetch g.menu where g.menu.invalid = false and  g.role.id = " + roleId + " order by g.menu.orderTag asc" );
        List<GesMenu> menuList = new ArrayList<GesMenu>();
        for (GesMenuRoleItem menuRoleItem : menuRoleList) {
            menuList.add(menuRoleItem.getMenu());
        }
        return menuList;
    }

    @Override
    public GesMenu getMenuWithParentById(long id) {
        List<GesMenu> list = (List<GesMenu>)super.getHibernateTemplate().find("from GesMenu g left join fetch g.parent where g.id = " + id);
        if (list != null && list.size() > 0){
            return list.get(0);
        }
        return null;
    }

    @Override
    public List<GesMenu> listMenusByTarget(String target) {
        List<GesMenu> list = (List<GesMenu>)super.getHibernateTemplate().find("from GesMenu where invalid = false and target='" + target + "'" );
        if (list != null && list.size() > 0){
            return list;
        }
        return null;
    }
}
