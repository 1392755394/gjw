package com.gjw.company.service.impl.validation;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.validation.ISmsValidationService;
import com.gjw.entity.validation.SmsValidation;

@Service("smsValidationServiceImpl")
@Transactional
public class SmsValidationServiceImpl extends AbstractServiceImpl implements ISmsValidationService {

    @Override
    public void remove(Long id) {
        this.getSmsValidationDAO().remove(id);
    }

    @Override
    public void add(SmsValidation smsValidation) {
        this.getSmsValidationDAO().add(smsValidation);
    }

    @Override
    public SmsValidation getLastByMobile(String mobile) {
        return this.getSmsValidationDAO().getLastByMobile(mobile);
    }


    
}
