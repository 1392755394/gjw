package com.gjw.company.dao.building;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.building.GesBuilding;

public interface IGesBuildingDAO extends IDAO{
    
    public GesBuilding listByID(Long id);

    public boolean updateGesBuilding(GesBuilding model);

    public boolean createGesBuilding(GesBuilding model);
    
    public List<GesBuilding> listByGesBuilding(GesBuilding building);
    
    public long count(GesBuilding model);
}
