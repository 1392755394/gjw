package com.gjw.company.dao.customer;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.customer.GesAppointment;


public interface IGesAppointmentDAO extends IDAO {
    
    /**
     * 
    * @Description  预约详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:31:51
     */
    public GesAppointment getById(Long id);

    /**
     * 修改预约状态等信息
    * @Description  
    * @param record
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:16:46
     */
    public int updateAppointment(GesAppointment record);

    /**
     * 
     * @Description 根据楼盘获取预约列表
     * @param buildingId
     *            楼盘id
     * @return
     * @author zhaoyonglian
     * @date 2015年10月26日 下午4:11:18
     */
    public List<GesAppointment> listByBuildingId(Long buildingId);
}
