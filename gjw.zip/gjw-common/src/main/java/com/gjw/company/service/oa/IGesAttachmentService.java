package com.gjw.company.service.oa;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gjw.entity.oa.GesAttachment;
import com.gjw.entity.user.User;

public interface IGesAttachmentService {
	
	public GesAttachment uploadAttachment(Long taskId,User user,MultipartFile file);
    
    /**
     * 获取节点的附件列表
     * @param attachment 附件（附件所属节点的id与类型）
     * @return 附件列表
     */
    public List<GesAttachment> listAttachmentByRelationId(GesAttachment attachment);
    
    /**
     * 下载附件
     * @param attachmentID 附件ID
     * @return 下载成功与否
     */
    public boolean downloadAttachment(Long attachmentID);

    /**
     * 删除附件
     * @param attachmentID 附件ID
     * @return 删除成功与否
     */
    public boolean deleteAttachment(Long attachmentID);

}
