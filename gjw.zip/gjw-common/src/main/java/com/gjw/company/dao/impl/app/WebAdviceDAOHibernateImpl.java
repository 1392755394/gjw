package com.gjw.company.dao.impl.app;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.app.IWebAdviceDAO;
import com.gjw.entity.app.WebAdvice;

@Component("webAdviceDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class WebAdviceDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebAdviceDAO{
    
    public WebAdvice get(Long id) {
        return (WebAdvice) super.get(id);
    }
    @Override
    public List<WebAdvice> getList(Integer index, Integer size) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean addWebAdvice(WebAdvice webAdvice){
        // TODO Auto-generated method stub
        super.add(webAdvice);
        return true;
    }

    @Override
    public void updateWebAdvice(WebAdvice webAdvice){
        // TODO Auto-generated method stub
        
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebAdvice.class;
    }

}
