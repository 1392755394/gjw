package com.gjw.company.dao.impl.goods;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.goods.IGoodsMarkDAO;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.utils.StringUtil;

/**
 * 
* @Description: 房间锚点关系dao实现类
* @author  zhaoyonglian
* @date 2015年12月29日 上午10:58:04
*
 */
@Component("goodsMarkDAOHibernateImpl")
public class GoodsMarkDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsMarkDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsMark.class;
    }

    @Override
    public GoodsMark queryById(Long id) {
        return (GoodsMark) super.get(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMark> listMarkByRoomIdAndType(Long roomId,Long type) {
        // TODO Auto-generated method stub
        List<Object> ls =  new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMark gm where gm.invalid = 0");
        if(StringUtil.notEmpty(roomId)){
            hql.append(" and gm.goodsRoom.id = ?");
            ls.add(roomId);
        }
        if(StringUtil.notEmpty(type)){
            hql.append(" and gm.type.id = ?");
            ls.add(type);
        }
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setString(i, ls.get(i).toString());
        }
        
        return query.list();
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            if(StringUtil.notEmpty(id))
            idList.add(Long.parseLong(id));
        }

        return super.delBatchByID(idList) > 0;
    }

    @Override
    public boolean update(GoodsMark mark) {
        GoodsMark old = (GoodsMark) super.get(mark.getId());
        StringUtil.copyProperties(mark, old);
        super.update(old);
        return true;
    }

    @Override
    public long create(GoodsMark mark) {
        super.add(mark);
        return mark.getId();
    }

    //DIY 接口start
    
    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsMark> listMarkByGoodsId(Long goodsId) {
        // TODO Auto-generated method stub
        List<Object> ls =  new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GoodsMark gm where gm.invalid = 0");
        if(StringUtil.notEmpty(goodsId)){
            hql.append(" and gm.goodsRoom.goods.id = ?");
            ls.add(goodsId);
        }
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setString(i, ls.get(i).toString());
        }
        return query.list();
    }

    @Override
    public boolean deleteByRoomId(Long roomId) {
        // TODO Auto-generated method stub
        StringBuilder hql = new StringBuilder();
        hql.append("update GoodsMark");
        hql.append(" set invalid = true, updatedDatetime = :updatedDatetime where goodsRoom.id=:roomId");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        // 修改时间
        query.setParameter("updatedDatetime", new Timestamp(System.currentTimeMillis()));
        query.setParameter("roomId", roomId);
        return query.executeUpdate()>0;
    }
}
