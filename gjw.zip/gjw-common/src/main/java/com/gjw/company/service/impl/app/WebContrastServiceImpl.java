package com.gjw.company.service.impl.app;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.app.IWebContrastService;
import com.gjw.entity.app.WebContrast;
@Component("webContrastServiceImpl")
public class WebContrastServiceImpl extends AbstractServiceImpl implements IWebContrastService{

    @Override
    @Transactional(readOnly=true)
    public WebContrast get(Long id) {
        // TODO Auto-generated method stub
        return super.getWebContrastDAO().get(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebContrast> getList(WebContrast model) {
        // TODO Auto-generated method stub
        List<WebContrast> list=super.getWebContrastDAO().getList(model);
        return list;
    }

    @Override
    @Transactional()
    public boolean addWebContrast(WebContrast webContrast){
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    @Transactional()
    public void updateWebContrast(WebContrast webContrast){
        // TODO Auto-generated method stub
        
    }

}
