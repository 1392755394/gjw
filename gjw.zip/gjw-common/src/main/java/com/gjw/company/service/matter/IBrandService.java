package com.gjw.company.service.matter;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.matter.Brand;

/**
 * 品牌service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月15日 
 *
 */
public interface IBrandService extends IService {

    /**
     * 查询品牌列表
     * @Description  
     * @param brandCriteria 查询条件：分类、品牌名称
     * @return 品牌列表
     * @author guojianbin   
     * @date 2015年12月15日
     */
    public List<Brand> pageBrandByNameAndType(Brand brandCriteria);

    /**
     * 查询品牌总数
     * @Description  
     * @param brandCriteria 查询条件：分类、品牌名称
     * @return 品牌总数
     * @author guojianbin   
     * @date 2015年12月15日
     */
    public Long countBrandByNameAndType(Brand brandCriteria);
    
    /**
     * 根据ID获取品牌信息
     * @Description  
     * @param id 品牌id
     * @return 品牌
     * @author guojianbin   
     * @date 2015年12月15日
     */
    public Brand queryByID(Long id);

    /**
     * 保存品牌
     * @Description  
     * @param brand 品牌
     * @return 品牌总数
     * @author guojianbin   
     * @date 2015年12月15日
     */
    public void saveOrUpdate(Brand brand);
}
