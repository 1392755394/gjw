package com.gjw.company.dao.user;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;

public interface IUserBuildingItemDAO extends IDAO {
    void create(UserBuildingItem item);
    void update(UserBuildingItem item);
    UserBuildingItem queryByUser(User user);
}
