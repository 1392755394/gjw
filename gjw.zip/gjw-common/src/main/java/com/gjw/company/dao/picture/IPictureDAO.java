package com.gjw.company.dao.picture;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.picture.Picture;


public interface IPictureDAO extends IDAO{
    public Picture get(Long id);
    public Picture getWithoutThumbnai(Long id);
}
