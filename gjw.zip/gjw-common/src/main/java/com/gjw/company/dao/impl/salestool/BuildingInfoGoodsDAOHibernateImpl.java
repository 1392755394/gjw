package com.gjw.company.dao.impl.salestool;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.IBuildingInfoGoodsDAO;
import com.gjw.entity.salestool.BuildingInfoGoods;
import com.gjw.utils.StringUtil;
/**
 * @author dabai email:qp(a)goujiawang.com
 */

@Component("buildingInfoGoodsDAOHibernateImpl")
public class BuildingInfoGoodsDAOHibernateImpl extends AbstractDAOHibernateImpl implements IBuildingInfoGoodsDAO {

    @Override
    protected Class<?> getEntityClass() {
        return BuildingInfoGoods.class;
    }
	
	@SuppressWarnings("unchecked")
    @Override
    public List<BuildingInfoGoods> pageBuildingInfoGoods(BuildingInfoGoods buildingInfoGoods) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingInfoGoods m ");     
        hql.append("where m.invalid = false ");
        if (buildingInfoGoods.getStatus() != null){
            ls.add(buildingInfoGoods.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingInfoGoods.getBuildingInfo() != null && buildingInfoGoods.getBuildingInfo().getId() != null){
            ls.add(buildingInfoGoods.getBuildingInfo().getId());
            hql.append("  and m.buildingInfo.id=?");
        }
        if (StringUtil.notEmpty(buildingInfoGoods.getSortField())) {
            hql.append("  order by m.").append(buildingInfoGoods.getSortField()).append(" ");
            hql.append(buildingInfoGoods.getSortOrder()).append(" ,m.updatedDatetime desc");
        } else {
            hql.append("  order by m.updatedDatetime desc");
        }
        return (List<BuildingInfoGoods>) super.findByPageCallBack(hql.toString(), "", ls, buildingInfoGoods, null);
    }
	
	 @Override
    public Long count(BuildingInfoGoods buildingInfoGoods) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingInfoGoods m ");
        hql.append("where m.invalid = false ");
        if (buildingInfoGoods.getStatus() != null){
            ls.add(buildingInfoGoods.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingInfoGoods.getBuildingInfo() != null && buildingInfoGoods.getBuildingInfo().getId() != null){
            ls.add(buildingInfoGoods.getBuildingInfo().getId());
            hql.append("  and m.buildingInfo.id=?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
	
	 @Override
    public BuildingInfoGoods queryByID(long id) {
       return (BuildingInfoGoods)super.get(id);
    }

    @Override
    public long create(BuildingInfoGoods buildingInfoGoods) {
        super.add(buildingInfoGoods);
        return buildingInfoGoods.getId();
    }
	
	   @Override
    public boolean update(BuildingInfoGoods buildingInfoGoods) {
        return super.update( buildingInfoGoods) == 1;
    }
    
    @Override
    public boolean deletes(String ids) {
        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
        return  super.delBatchByID(idList) > 0;
    }
    
}
