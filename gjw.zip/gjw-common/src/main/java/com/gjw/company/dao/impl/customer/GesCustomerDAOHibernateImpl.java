package com.gjw.company.dao.impl.customer;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.customer.IGesCustomerDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.building.GesBuilding;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.customer.GesCustomerQuestion;
import com.gjw.entity.customer.GesCustomerReserve;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.user.Platform;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.entity.user.UserPlatformItem;
import com.gjw.utils.DateUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.customer.GesCustomerReserveVO;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.customer.UserVO;
import com.gjw.vo.order.GesOrderVO;

@SuppressWarnings("unused")
@Component("gesCustomerDAOHibernateImpl")
public class GesCustomerDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCustomerDAO {
    
    protected long count(String hql, List<Object> paramList){
        
        long count = findByPageCallBackCount(hql, paramList);
        return count;
    }

    @SuppressWarnings("rawtypes")
    @Override
    protected Class getEntityClass() {
        
        return GesCustomer.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<User> ListUser(long id) {

        List<User> userList = (List<User>) this.getHibernateTemplate().get(User.class, id);
        return userList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<UserPlatformItem> SetPlatForm(Platform platForm) {

        String hql = "From UserPlatformItem where platform.id :=?";
        Set<UserPlatformItem> setPlat = (Set<UserPlatformItem>) this.getHibernateTemplate().find(hql, platForm.getId());
        return setPlat;
    }
    
    //客户分页列表
    @Override
    public Map<Object, Object> pageGesCustomer(GesCustomerVO gesCustomerVO){
        
        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();
        fromSb.append(" from GesCustomer gc ");
        if (StringUtil.notEmpty(gesCustomerVO.getOrgType())) {
            if (!"shop".equals(gesCustomerVO.getOrgType()) && !"city_operator".equals(gesCustomerVO.getOrgType())) {
                fromSb.append(",User user  ");
            } else {
                fromSb.append(",UserInfoGES  userInfo ");
            }
        }
        List<Object> paramList = new ArrayList<Object>();
        whereSb.append(" where 1 = 1 ");
        whereSb.append(" and gc.invalid =0 ");

        if (StringUtil.notEmpty(gesCustomerVO.getName())) {
            whereSb.append(" and gc.name like ? ");
            paramList.add("%" + gesCustomerVO.getName() + "%");
        }
        if (StringUtil.notEmpty(gesCustomerVO.getShopName())) {
            whereSb.append(" and gc.shop.name like ? ");
            paramList.add("%" + gesCustomerVO.getShopName() + "%");
        }
        if (StringUtil.notEmpty(gesCustomerVO.getOperatorName())) {
            whereSb.append(" and gc.shop.operator.companyName like ? ");
            paramList.add("%" + gesCustomerVO.getOperatorName() + "%");
        }
        if (StringUtil.notEmpty(gesCustomerVO.getPhone())) {
            whereSb.append(" and gc.phone = ?");
            paramList.add(gesCustomerVO.getPhone());
        }
        if (StringUtil.notEmpty(gesCustomerVO.getEmail())) {
            whereSb.append(" and gc.email = ?");
            paramList.add(gesCustomerVO.getEmail());
        }
        if (StringUtil.notEmpty(gesCustomerVO.getBuildingName())) {
            whereSb.append(" and gc.buildingName like ? ");
            paramList.add(super.getFuzzyCondition(gesCustomerVO.getBuildingName()));
        }
        if (StringUtil.notEmpty(gesCustomerVO.getGmtCreateFrom())
                && StringUtil.notEmpty(gesCustomerVO.getGmtCreateTo())) {
            whereSb.append(" and ( ? <=  date_format(gc.createdDatetime,'%Y-%m-%d') and date_format(gc.createdDatetime,'%Y-%m-%d') <= ? ) ");
            paramList.add(gesCustomerVO.getGmtCreateFrom());
            paramList.add(gesCustomerVO.getGmtCreateTo());
        }else if(StringUtil.notEmpty(gesCustomerVO.getGmtCreateFrom())
                && !StringUtil.notEmpty(gesCustomerVO.getGmtCreateTo())){
            whereSb.append(" and gc.createdDatetime > ? ");
            paramList.add(DateUtil.parseDate(gesCustomerVO.getGmtCreateFrom()));
        }else if(!StringUtil.notEmpty(gesCustomerVO.getGmtCreateFrom())
                && StringUtil.notEmpty(gesCustomerVO.getGmtCreateTo())){
            whereSb.append(" and gc.createdDatetime < ? ");
            paramList.add(DateUtil.parseDate(gesCustomerVO.getGmtCreateTo()));
        }
        if (StringUtil.notEmpty(gesCustomerVO.getOrgType())) {
            if ("shop".equals(gesCustomerVO.getOrgType())) {
                whereSb.append(" and gc.shop.id = userInfo.shop.id and userInfo.user.id = ? ");
                paramList.add(gesCustomerVO.getId());
                if(!"4S店-店长".equals(gesCustomerVO.getRoleName())){
                    whereSb.append(" and gc.personInCharge.id = ? ");
                    paramList.add(gesCustomerVO.getId());
                }
            } else if ("city_operator".equals(gesCustomerVO.getOrgType())) {
                whereSb.append(" and gc.shop.operator.id = userInfo.operator.id and userInfo.user.id = ? ");
                paramList.add(gesCustomerVO.getId());
            } else {
                whereSb.append(" and user.id = ? ");
                paramList.add(gesCustomerVO.getId());
            }
        }
        if(StringUtil.notEmpty(gesCustomerVO.getDistributionType())){
            if(1==gesCustomerVO.getDistributionType()){
                whereSb.append(" and gc.personInCharge.id is not null ");
            }else if(2==gesCustomerVO.getDistributionType()){
                whereSb.append(" and gc.personInCharge.id is null ");
            }
        }
        fromSb.append(whereSb);
        orderSb.append(" order by gc.updatedDatetime desc ");
        long count = count(fromSb.toString(), paramList);
        fromSb.append(orderSb);
        ResultTransformer resultTransformer = null;
        List<?> gesCustomerVOList =  findByPageCallBack(fromSb.toString(), selectSb.toString(),
                paramList, gesCustomerVO, resultTransformer);
        Map<Object, Object> map = new HashMap<Object, Object>();
        map.put("list", gesCustomerVOList);
        map.put("count", count);
        return map;
    }

    @Override
    public long updateGesCustomerByGesCustomer(GesCustomer gesCustomer) {

        this.getHibernateTemplate().update(gesCustomer);
//        this.getHibernateTemplate().getSessionFactory().getCurrentSession().flush();
        return gesCustomer.getId();
    }

    @Override
    public GesCustomer getGesCustomerById(long id) {

        return (GesCustomer) get(id);
    }

    @Override
    public long saveGesCustomer(GesCustomer gesCustomer) {

        super.saveResultBoolean(gesCustomer);
        return gesCustomer.getId();
    }

    @Override
    public long updateGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {
        
        this.getHibernateTemplate().update(gesCustomerQuestion);
        return gesCustomerQuestion.getId();
    }

    @Override
    public long saveGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {

        super.saveResultBoolean(gesCustomerQuestion);
        return gesCustomerQuestion.getId();
    }

    @Override
    public GesCustomerQuestion getGesCustomerQuestionById(long id) {

        return this.getHibernateTemplate().get(GesCustomerQuestion.class, id);
    }

    @Override
    public GesCustomerReserve getGesCustomerReserveById(long id) {

        StringBuffer hql = new StringBuffer();
        hql.append(" From GesCustomerReserve gcr where gcr.invalid = 0 ");
        List<Object> paramList = new ArrayList<Object>();
        if(StringUtil.notEmpty(id)&&id>0){
          hql.append(" and gcr.id = ? ");
          paramList.add(id);
        }
        GesCustomerReserve gesCustomerReserve = (GesCustomerReserve) queryByParam(hql.toString(),paramList );  
        return gesCustomerReserve;
    } 
    
    @Override
    public boolean delBatchByID(String ids,Class<?> clazz) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
            
     // 生成删除语句
        StringBuilder hql = new StringBuilder();
        hql.append("update ");
        hql.append(clazz.getSimpleName());
        hql.append(" set invalid = true, updatedDatetime = :updatedDatetime where id in (:id_list) ");

        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        // 修改时间
        query.setParameter("updatedDatetime", new Timestamp(System.currentTimeMillis()));
        // ID列表
        query.setParameterList("id_list", idList);
        
        return query.executeUpdate() >0;
    }

    @Override
    public long saveGesCustomerReserve(GesCustomerReserve gesCustomerReserve) {
        
        saveResultBoolean(gesCustomerReserve);
        return gesCustomerReserve.getId();
    }

    @SuppressWarnings("unchecked")
    @Override
    public GesCustomer customerValidate(GesCustomer model) {

        String hql="from GesCustomer item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(StringUtil.notEmpty(model.getName())){
            hql=hql+" and item.name=?";
            params.add(model.getName());
        }
        if(StringUtil.notEmpty(model.getEmail())){
            hql=hql+" and item.email=?";
            params.add(model.getEmail());
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone=?";
            params.add(model.getPhone());
        }
        List<GesCustomer> list=(List<GesCustomer>) super.findByPageCallBack(hql,"",params,model,null);
        if(null!=list && list.size()>0){
            return list.get(0);
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public GesCustomer customerByPhone(GesCustomer model) {
        String hql="from GesCustomer item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone=?";
            params.add(model.getPhone());
        }
        List<GesCustomer> list=(List<GesCustomer>) super.findByPageCallBack(hql,"",params,model,null);
        if(null!=list && list.size()>0){
            return list.get(0);
        }
        return null;
    }

    @Override
    public long updateGesCustomerReserve(GesCustomerReserve gesCustomerReserve) {

        update(gesCustomerReserve);
        return gesCustomerReserve.getId();
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<GesCustomer> getGesCustomerByGesCustomer(GesCustomer gesCustomer) {

        StringBuffer selectBuffer = new StringBuffer();
        StringBuffer fromBuffer = new StringBuffer();
        StringBuffer whereBuffer = new StringBuffer();
        fromBuffer.append(" from GesCustomer gc where 1=1 ");
        //排除禁用的
        whereBuffer.append(" and invalid = 0 ");
        List<Object> paramList = new ArrayList<Object>();
        if (null!=gesCustomer) {
            if(StringUtil.notEmpty(gesCustomer.getPhone())){
                whereBuffer.append(" and phone = ? ");
                paramList.add(gesCustomer.getPhone());
            }
            if(StringUtil.notEmpty(gesCustomer.getId())){
                whereBuffer.append(" and id = ? ");
                paramList.add(gesCustomer.getId());
            }
            if(StringUtil.notEmpty(gesCustomer.getName())){
                whereBuffer.append(" and name = ? ");
                paramList.add(gesCustomer.getName());
            }
            if(StringUtil.notEmpty(gesCustomer.getEmail())){
                whereBuffer.append(" and email = ? ");
                paramList.add(gesCustomer.getEmail());
            }
            if(StringUtil.notEmpty(gesCustomer.getShop())){
                if(null!=gesCustomer.getShop().getId()){
                    whereBuffer.append(" and gc.shop.id = ? ");
                    paramList.add(gesCustomer.getShop().getId());
                }
            }
        }
        fromBuffer.append(whereBuffer);
        gesCustomer.setPageSize(null);
        gesCustomer.setStart(null);
        List<GesCustomer> gesCustomerList =  (List<GesCustomer>) findByPageCallBack(fromBuffer.toString(),null, paramList, gesCustomer, null);
        return gesCustomerList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<Object, Object> pageUserByUser(UserVO user) {

        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();
        fromSb.append(" from User u,UserInfo ui, UserInfoGES uig where 1=1 and u.id = ui.user.id and ui.id = uig.id ");
        
        List<Object> paramList = new ArrayList<Object>();
        //param
        if(null!=user){
            whereSb.append(" and u.invalid = ? ");
            paramList.add(false);
            if(StringUtil.notEmpty(user.getOrgType())&&StringUtil.notEmpty(user.getOrgId())){
                if("shop".equals(user.getOrgType())){
                    whereSb.append("  and uig.orgType = 'shop' and uig.shop.id = ? ");
                    paramList.add(user.getOrgId());
                }else if("admin".equals(user.getOrgType())){
                    whereSb.append(" and uig.orgType != 'developer' ");
                }else if("city_operator".equals(user.getOrgType())){
                    whereSb.append(" and uig.orgType = 'shop' and uig.shop.id in (select shop.id from GesShop shop where shop.operator.id = ?) ");
                    paramList.add(user.getOrgId());
                }
            }

            if(StringUtil.notEmpty(user.getEmail())){
                whereSb.append(" and u.email like ? ");
                paramList.add(getFuzzyCondition(user.getEmail()));
            }
            if(StringUtil.notEmpty(user.getUsername())){
                whereSb.append(" and u.username like ? ");
                paramList.add(getFuzzyCondition(user.getUsername()));
            }

        }
        fromSb.append(whereSb);
        List<Object[]> pageUser =  (List<Object[]>)findByPageCallBack(fromSb.toString(), null, paramList, user, null);
        List<UserVO> userVOList = new ArrayList<UserVO>();
        for(Object[] o : pageUser){
            User users = (User)o[0];
            String userName = users.getUsername();
            String email = users.getEmail();
            long userId = users.getId();
            UserVO userVO = new UserVO();
            userVO.setId(userId);
            userVO.setUsername(userName);
            userVO.setEmail(email);
            UserInfo userInfo  = (UserInfo)o[1];
            String realName = userInfo.getRealName();
            userVO.setRealName(realName);
            UserInfoGES userInfoGES = (UserInfoGES)o[2];
            String orgType = userInfoGES.getOrgType();
            userVO.setOrgType(orgType);
            userVOList.add(userVO);
        }
        long count = count(fromSb.toString(), paramList);
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        hashMap.put("pageUser", userVOList);
        hashMap.put("count", count);
        return hashMap;
    }

    @Override
    public GesCustomerReserve getCustomerReserveLatest(GesCustomer customer) {

        StringBuffer hql = new StringBuffer(); 
        hql.append(" From GesCustomerReserve where invalid = 0 ");
        List<Object> paramList = new ArrayList<Object>();
        if(StringUtil.notEmpty(customer.getId())){
            hql.append(" and customer.id = ? ");
            paramList.add(customer.getId());
        }
        hql.append(" order by createdDatetime desc");
        customer.setStart(1);     customer.setPageSize(1);
        List<?> reserveList =  findByPageHql(hql.toString(), "",paramList , customer, false);
        return reserveList.isEmpty()?null:(GesCustomerReserve) reserveList.get(0);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesCustomerReserve> pageByGesCustomerReserve(
            GesCustomerReserve model) {
        // TODO //$NON-NLS-N$
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        String hql=" from GesCustomerReserve model where 1=1 ";
        List<Object> params = new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and model.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getShop() && null!=model.getShop().getId()){
            hql=hql+" and model.shop.id=?";
            params.add(model.getShop().getId());
        }
        hql=hql+" order by created_datetime desc";
        return (List<GesCustomerReserve>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public Map<Object, Object> pageGesCustomerReserve(GesCustomerReserveVO gesCustomerReserveVO) {

        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();
        fromSb.append(" from GesCustomerReserve gcr ");
        if (StringUtil.notEmpty(gesCustomerReserveVO.getOrgType())) {
            if (!"shop".equals(gesCustomerReserveVO.getOrgType())
                    && !"city_operator".equals(gesCustomerReserveVO.getOrgType())) {
                fromSb.append(",User user  ");
            } else {
                fromSb.append(",UserInfoGES  userInfo ");
            }
        }
        whereSb.append(" where 1=1 and gcr.invalid = 0 ");
        List<Object> paramList = new ArrayList<Object>();
        GesCustomer gesCustomerUsePara = gesCustomerReserveVO.getCustomer();
         if(gesCustomerUsePara!=null){
            if(StringUtil.notEmpty(gesCustomerUsePara.getId())){
                whereSb.append(" and gcr.customer.id = ? ");
                paramList.add(gesCustomerUsePara.getId());
            }
            if(StringUtil.notEmpty(gesCustomerUsePara.getName())){
                whereSb.append(" and gcr.customer.name like ? ");
                paramList.add("%" + gesCustomerUsePara.getName() + "%");
            }
            if (StringUtil.notEmpty(gesCustomerUsePara.getPhone())) {
                whereSb.append(" and gcr.customer.phone = ? ");
                paramList.add(gesCustomerUsePara.getPhone());
            }
            if (StringUtil.notEmpty(gesCustomerUsePara.getEmail())) {
                whereSb.append(" and gcr.customer.email = ? ");
                paramList.add(gesCustomerUsePara.getEmail());
            }
        }
        if (StringUtil.notEmpty(gesCustomerReserveVO.getShopName())) {
            whereSb.append(" and gcr.shop.name like ? ");
            paramList.add("%" + gesCustomerReserveVO.getShopName() + "%");
        }
        if (StringUtil.notEmpty(gesCustomerReserveVO.getCompanyName())) {
            whereSb.append(" and gcr.shop.operator.companyName like ? ");
            paramList.add("%" + gesCustomerReserveVO.getCompanyName() + "%");
        }
        //预约时间查询条件处理
        if (StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveFrom())
                && StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveTo())) {
            whereSb.append(" and ( ? <=  date_format(gcr.gmtReserve,'%Y-%m-%d') and date_format(gcr.gmtReserve,'%Y-%m-%d') <= ? ) ");
            paramList.add(DateUtil.formatYYYYMMDD(gesCustomerReserveVO.getGmtReserveFrom()));
            paramList.add(DateUtil.formatYYYYMMDD(gesCustomerReserveVO.getGmtReserveTo()));
        }else if(StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveFrom())
                && !StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveTo())){
            whereSb.append(" and gcr.gmtReserve > ? ");
            paramList.add(gesCustomerReserveVO.getGmtReserveFrom());
        }else if(!StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveFrom())
                && StringUtil.notEmpty(gesCustomerReserveVO.getGmtReserveTo())){
            whereSb.append(" and gcr.gmtReserve < ? ");
            paramList.add(gesCustomerReserveVO.getGmtReserveTo());
        }
        //创建时间查询条件处理
        if (StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateFrom())
                && StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateTo())) {
            whereSb.append(" and ( ? <=  date_format(gcr.createdDatetime,'%Y-%m-%d') and date_format(gcr.createdDatetime,'%Y-%m-%d') <= ? ) ");
            paramList.add(DateUtil.formatYYYYMMDD(gesCustomerReserveVO.getGmtCreateFrom()));
            paramList.add(DateUtil.formatYYYYMMDD(gesCustomerReserveVO.getGmtCreateTo()));
        }else if(StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateFrom())
                && !StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateTo())){
            whereSb.append(" and gcr.createdDatetime > ? ");
            paramList.add(gesCustomerReserveVO.getGmtCreateFrom());
        }else if(!StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateFrom())
                && StringUtil.notEmpty(gesCustomerReserveVO.getGmtCreateTo())){
            whereSb.append(" and gcr.createdDatetime < ? ");
            paramList.add(gesCustomerReserveVO.getGmtCreateTo());
        }
        
        if (StringUtil.notEmpty(gesCustomerReserveVO.getOrgType())) {
            if ("shop".equals(gesCustomerReserveVO.getOrgType())) {
                whereSb.append(" and gcr.customer.shop.id = userInfo.shop.id and userInfo.user.id = ? ");
                paramList.add(gesCustomerReserveVO.getId());
                if(!"4S店-店长".equals(gesCustomerReserveVO.getRoleName())){
                    whereSb.append(" and gcr.customer.personInCharge.id = ? ");
                    paramList.add(gesCustomerReserveVO.getId());
                }
            } else if ("city_operator".equals(gesCustomerReserveVO.getOrgType())) {
                whereSb.append(" and gcr.customer.shop.operator.id = userInfo.operator.id and userInfo.user.id = ? ");
                paramList.add(gesCustomerReserveVO.getId());
            } else {
                whereSb.append(" and user.id = ? ");
                paramList.add(gesCustomerReserveVO.getId());
            }
        }
        fromSb.append(whereSb);
        long count = count(fromSb.toString(), paramList);
        orderSb.append(" order by gcr.gmtReserve desc,  gcr.updatedDatetime desc ");
        fromSb.append(orderSb);
        ResultTransformer transformer = null;
        List<?> gesCustomerReserveVOList =  findByPageCallBack(fromSb.toString(), selectSb.toString(),
                paramList, gesCustomerReserveVO, transformer);
        Map<Object, Object> map = new HashMap<Object, Object>();
        map.put("list", gesCustomerReserveVOList);
        map.put("count", count);
        return map;
    }

    @Override
    public Map<Object, Object> pageGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {

        StringBuffer selectSb = new StringBuffer();
        StringBuffer fromSb = new StringBuffer();
        StringBuffer whereSb = new StringBuffer();
        StringBuffer orderSb = new StringBuffer();
        selectSb.append(" select gcq.theme as theme, gcq.content as content, gcq.createdDatetime as createdDatetime, u.username as userName  ");
        // usre 即为 own --负责人
        fromSb.append(" from GesCustomerQuestion gcq left join gcq.user u  where 1=1 and gcq.invalid = 0 ");
        List<Object> paramList = new ArrayList<Object>();
        if (null != gesCustomerQuestion.getUser() && gesCustomerQuestion.getUser().getId() > 0) {
            whereSb.append(" and gcq.customer.id = ?  ");
            paramList.add(gesCustomerQuestion.getUser().getId());
        }
        if (null != gesCustomerQuestion.getGesOrder() && gesCustomerQuestion.getGesOrder().getId() > 0) {
            whereSb.append(" and gcq.gesOrder.id = ? ");
            paramList.add(gesCustomerQuestion.getGesOrder().getId());
        }
        fromSb.append(whereSb);
        long count = count(fromSb.toString(), paramList);
        orderSb.append(" order by gcq.updatedDatetime desc ");
        fromSb.append(orderSb);
        List<?> gesCustomerQuestionList =  findByPageCallBack(fromSb.toString(), selectSb.toString(),
                paramList, gesCustomerQuestion, Transformers.ALIAS_TO_ENTITY_MAP);
        Map<Object, Object> map = new HashMap<Object, Object>();
        map.put("list", gesCustomerQuestionList);
        map.put("count", count);
        return map;
    }
}
