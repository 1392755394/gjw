package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesErpCode;

/**
 * 基础数据同步
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月16日 下午3:49:24
 * 
 */
public interface IGesErpCodeService extends IService {

    /**
     * 基础数据同步---总数
     * 
     * @Description
     * @param gesErpCode
     * @return
     * @author gwb
     * @date 2015年12月16日 下午4:00:47
     */
    public Long count(GesErpCode gesErpCode);

    /**
     * 基础数据同步 ---分页
     * 
     * @Description
     * @param gesErpCode
     * @return
     * @author gwb
     * @date 2015年12月16日 下午4:00:51
     */
    public List<GesErpCode> pageByGesErpCode(GesErpCode gesErpCode);

}
