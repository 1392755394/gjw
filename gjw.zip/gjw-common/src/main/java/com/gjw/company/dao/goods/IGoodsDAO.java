package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.entity.goods.Goods;
import com.gjw.vo.GoodsVO;

/**
 * 产品包dao接口
 */
public interface IGoodsDAO extends IDAO {

    /**
     * 分页查询产品包
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件
     * @return 产品包列表
     * @author guojianbin
     * @date 2015年12月23日
     */
    public List<Goods> page(Goods goodsCriteria);

    /**
     * 根据城市和产品包名分页查询产品包
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件:产品包名
     * @param cityId
     *            查询条件:城市ID
     * @return 产品包列表
     * @author guojianbin
     * @date 2015年12月31日
     */
    public List<Goods> pageByCityAndName(Goods goodsCriteria, Long cityId);

    /**
     * 查询产品包总数
     * 
     * @Description
     * @param matterCriteria
     *            查询条件
     * @return 产品包总数
     * @author guojianbin
     * @date 2015年12月23日
     */
    public Long count(Goods goodsCriteria);

    /**
     * 根据城市和产品包名查询产品包总数
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件:产品包名
     * @param cityId
     *            查询条件:城市ID
     * @return 产品包总数
     * @author guojianbin
     * @date 2015年12月31日
     */
    public Long countByCityAndName(Goods goodsCriteria, Long cityId);

    /**
     * 获取普通产品包列表
     * 
     * @param goodsCriteria
     *            产品包查询条件
     * @return 产品包列表
     */
    public List<Goods> listGoods(Goods goodsCriteria);

    /**
     * 保存产品包信息
     * 
     * @Description
     * @param goods
     *            产品包
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月23日
     */
    public boolean update(Goods goods);

    /**
     * 新增产品包信息
     * 
     * @Description
     * @param goods
     *            产品包
     * @return 产品包ID
     * @author guojianbin
     * @date 2015年12月23日
     */
    public long create(Goods goods);

    /**
     * 根据ID查询产品包
     * 
     * @Description
     * @param id
     *            产品包id
     * @return 产品包
     * @author guojianbin
     * @date 2015年12月23日
     */
    public Goods queryById(Long id);

    /**
     * 批量删除产品包
     * 
     * @Description
     * @param ids
     *            产品包ID
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月23日
     */
    public boolean delBatchByID(String ids);

    /**
     * 分页查询产品包
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件
     * @return 产品包列表
     * @author guojianbin
     * @date 2016年1月26日
     */
    public List<Goods> pageForWebSite(GoodsVO goodsCriteria);

    /**
     * 查询产品包总数
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件
     * @return 产品包总数
     * @author guojianbin
     * @date 2016年1月26日
     */
    public Long countForWebSite(GoodsVO goodsCriteria);

    /**
     * diy频道列表
     * 
     * @Description
     * @return 校准DIY列表
     * @author guojianbin
     * @date 2016年3月1日
     */
    public List<Goods> standardDiyList();

    /**
     * 根据楼盘获取普通产品包列表
     * 
     * @param buildingId
     *            楼盘
     * @return 产品包列表
     */
   public List<Goods> listGoodsByBuilding(long buildingId);
   
   /**
    * 保存产品包信息
    * 
    * @Description
    * @param goods
    *            产品包
    * @return 成功与否
    * @author guojianbin
    * @date 2015年12月23日
    */
   public boolean updateAveragePrice(Goods goods);

   /**
    * 分页查询产品包
    * 
    * @Description
    * @param goodsCriteria
    *            查询条件
    * @return 产品包列表
    * @author guojianbin
    * @date 2016年1月26日
    */
   public List<Goods> pageForWebSiteH5(GoodsVO goodsCriteria);
   
   /**
    * 查询产品包总数
    * 
    * @Description
    * @param goodsCriteria
    *            查询条件
    * @return 产品包总数
    * @author guojianbin
    * @date 2016年1月26日
    */
   public Long countForWebSiteH5(GoodsVO goodsCriteria);

   /**
    * 分页查询产品包(构家APP)
    * 
    * @Description
    * @param goodsCriteria
    *            查询条件
    * @param type
    *            查询种类
    * @return 产品包列表
    * @author guojianbin
    * @date 2016年3月28日
    */
   public List<Goods> pageForWebApp(GoodsVO goodsCriteria, String type);

    /**
     * 根据用户id获取用户收藏产品包信息
     * 
     * @Description
     * @param list
     * @return
     * @author gwb
     * @date 2016年3月29日 上午10:51:15
     */
    public List<Goods> listGoodsByCollectionItem(List<WebCollectionItem> list);

    /**
     * 分页查询产品包_4S店未关联
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件
     * @return 产品包列表
     * @author guojianbin
     * @date 2016年4月8日
     */
    public List<Goods> pageNoSelect(Goods goodsCriteria);

    /**
     * 查询产品包总数_4S店未关联
     * 
     * @Description
     * @param goodsCriteria
     *            查询条件
     * @return 产品包总数
     * @author guojianbin
     * @date 2016年4月8日
     */
    public Long countNoSelect(Goods goodsCriteria);
    
    /**
     * 
    * @Description  房产产品包列表
    * @param goodsCriteria
    * @return
    * @author zhaoyonglian   
    * @date 2016年4月11日 下午1:43:40
     */
    public List<Goods> pageForSales(GoodsVO goodsCriteria);
}
