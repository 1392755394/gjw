package com.gjw.company.service.salestool;


import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.salestool.BuildingInfoGoods;

public interface IBuildingInfoGoodsService extends IService{
	
	public List<BuildingInfoGoods> pageBuildingInfoGoods(BuildingInfoGoods buildinginfogoods);
	
	public Long count(BuildingInfoGoods buildinginfogoods);

	public long create(BuildingInfoGoods buildinginfogoods);
	
	public boolean update(BuildingInfoGoods buildinginfogoods);
			
	public BuildingInfoGoods queryByID(Long id);
	
	public boolean deletes(String ids);
	
}
