package com.gjw.company.dao.impl.goods;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.company.dao.goods.IGoodsDAO;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.entity.goods.Goods;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsVO;

/**
 * 产品包dao的Hibernate实现
 */
@Component("goodsDAOHibernateImpl")
public class GoodsDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsDAO {

    @Override
    protected Class<?> getEntityClass() {
        return Goods.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> listGoods(Goods goodsCriteria) {
        // 生成查询条件
        StringBuilder hql = new StringBuilder();
        List<Object> params = new ArrayList<Object>();
        hql.append("from Goods g where 1=1");
        if (StringUtil.isNotEmpty(goodsCriteria.getName())) {
            hql.append(" and g.name like ?");
            params.add(super.getFuzzyCondition(goodsCriteria.getName()));
        }
        if (goodsCriteria.getStyle() != null) {
            hql.append(" and g.style.id = ?");
            params.add(goodsCriteria.getStyle());
        }
        if (goodsCriteria.getHouseType() != null) {
            hql.append(" and g.houseType.id = ?");
            params.add(goodsCriteria.getHouseType().getId());
        }
        if (null != goodsCriteria.getIsRecommend()) {
            hql.append(" and g.isRecommend = ?");
            params.add(goodsCriteria.getIsRecommend());
        }
        hql.append(" order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", params, goodsCriteria, null);
    }

    @Override
    public long create(Goods goods) {
        super.add(goods);
        return goods.getId();
    }

    @Override
    public boolean update(Goods goods) {
        Goods old = (Goods) super.get(goods.getId());
        StringUtil.copyPropertiesAllowEmpty(goods, old);
        return super.update(old) == 1;
    }

    @Override
    public Goods queryById(Long id) {
        return (Goods) super.get(id);
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }

        return super.delBatchByID(idList) > 0;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> page(Goods goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g left join fetch g.style left join fetch g.houseType ");
        hql.append("where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status != ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_DELETED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (goodsCriteria.getStyle() != null && null != goodsCriteria.getStyle().getId()) {
            ls.add(goodsCriteria.getStyle().getId());
            hql.append("  and g.style.id=?");
        }
        if (goodsCriteria.getHouseType() != null && null != goodsCriteria.getHouseType().getId()) {
            ls.add(goodsCriteria.getHouseType().getId());
            hql.append("  and g.houseType.id=?");
        }
        if (StringUtil.notEmpty(goodsCriteria.getShopGoodIds())) {
            String[] ids = goodsCriteria.getShopGoodIds().split(",");
            for (String id : ids) {
                hql.append("  and g.id!=?");
                ls.add(Long.valueOf(id));
            }
        }
        hql.append("  order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @Override
    public Long count(Goods goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status != ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_DELETED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (goodsCriteria.getStyle() != null && null != goodsCriteria.getStyle().getId()) {
            ls.add(goodsCriteria.getStyle().getId());
            hql.append("  and g.style.id=?");
        }
        if (goodsCriteria.getHouseType() != null && null != goodsCriteria.getHouseType().getId()) {
            ls.add(goodsCriteria.getHouseType().getId());
            hql.append("  and g.houseType.id=?");
        }
        if (StringUtil.notEmpty(goodsCriteria.getShopGoodIds())) {
            String[] ids = goodsCriteria.getShopGoodIds().split(",");
            for (String id : ids) {
                hql.append("  and g.id!=?");
                ls.add(Long.valueOf(id));
            }
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> pageByCityAndName(Goods goodsCriteria, Long cityId) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status = ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (cityId != null && cityId > 0) {
            ls.add(cityId);
            hql.append("  and g.house.building.city.id=?");
        }
        hql.append("  order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @Override
    public Long countByCityAndName(Goods goodsCriteria, Long cityId) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status = ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (cityId != null && cityId > 0) {
            ls.add(cityId);
            hql.append("  and g.house.building.city.id=?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> pageForWebSite(GoodsVO goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and (g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        hql.append(" and (sg.goods.averagePrice is not null or (1 = 1 ");
        if (goodsCriteria.getShopId() != null && goodsCriteria.getShopId() != 0) {
            hql.append("  and sg.shop.id = ?");
            ls.add(goodsCriteria.getShopId());
        }
        if (goodsCriteria.getHouse() != null && goodsCriteria.getHouse().getBuilding() != null) {
            if (goodsCriteria.getHouse().getBuilding().getId() != null) {
                hql.append("  and sg.goods.house.building.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCity() != null
                    && goodsCriteria.getHouse().getBuilding().getCity().getId() != null) {
                hql.append("  and sg.goods.house.building.city.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCity().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCounty() != null
                    && goodsCriteria.getHouse().getBuilding().getCounty().getId() != null) {
                hql.append("  and sg.goods.house.building.county.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCounty().getId());
            }
        }
        if (goodsCriteria.getStyle() != null && goodsCriteria.getStyle().getId() != null) {
            hql.append("  and sg.goods.style.id=?");
            ls.add(goodsCriteria.getStyle().getId());
        }
        if (goodsCriteria.getIsPromotion() != null) {
            hql.append("  and sg.goods.isPromotion=?");
            ls.add(goodsCriteria.getIsPromotion());
        }
        if (goodsCriteria.getHouseType() != null && goodsCriteria.getHouseType().getId() != null) {
            hql.append("  and sg.goods.houseType.id=?");
            ls.add(goodsCriteria.getHouseType().getId());
        }
        if (goodsCriteria.getMinPrice() != null && goodsCriteria.getMinPrice() != 0) {
            hql.append("  and sg.goods.discountPrice>=?");
            ls.add(goodsCriteria.getMinPrice());
        }
        if (goodsCriteria.getMaxPrice() != null && goodsCriteria.getMaxPrice() != 0) {
            hql.append("  and sg.goods.discountPrice<=?");
            ls.add(goodsCriteria.getMaxPrice());
        }
        if (goodsCriteria.getMinArea() != null && goodsCriteria.getMinArea() != 0) {
            hql.append("  and sg.goods.house.floorArea>=?");
            ls.add(goodsCriteria.getMinArea());
        }
        if (goodsCriteria.getMaxArea() != null && goodsCriteria.getMaxArea() != 0) {
            hql.append("  and sg.goods.house.floorArea<=?");
            ls.add(goodsCriteria.getMaxArea());
        }
        if (StringUtil.notEmpty(goodsCriteria.getQ())) {
            hql.append("  and (sg.goods.name like ? or sg.goods.houseType.text like ?  or sg.goods.style.text like ? ");
            hql.append("  or sg.goods.house.building.name like ?  or sg.goods.house.building.county.name like ?) ");
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
        }
        hql.append(") ) ) ) ");
        if ("default".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.createdDatetime desc");
        }
        if ("price".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.discountPrice asc");
        }
        if ("last".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.updatedDatetime desc");
        }
        if ("sales".equals(goodsCriteria.getSortField())) {
            // 没有依据销量排序
            hql.append("  order by g.isPromotion desc ");
        }
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @Override
    public Long countForWebSite(GoodsVO goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and (g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        hql.append(" and (sg.goods.averagePrice is not null or (1 = 1 ");
        if (goodsCriteria.getShopId() != null && goodsCriteria.getShopId() != 0) {
            hql.append("  and sg.shop.id = ?");
            ls.add(goodsCriteria.getShopId());
        }
        if (goodsCriteria.getHouse() != null && goodsCriteria.getHouse().getBuilding() != null) {
            if (goodsCriteria.getHouse().getBuilding().getId() != null) {
                hql.append("  and sg.goods.house.building.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCity() != null
                    && goodsCriteria.getHouse().getBuilding().getCity().getId() != null) {
                hql.append("  and sg.goods.house.building.city.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCity().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCounty() != null
                    && goodsCriteria.getHouse().getBuilding().getCounty().getId() != null) {
                hql.append("  and sg.goods.house.building.county.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCounty().getId());
            }
        }
        if (goodsCriteria.getStyle() != null && goodsCriteria.getStyle().getId() != null) {
            hql.append("  and sg.goods.style.id=?");
            ls.add(goodsCriteria.getStyle().getId());
        }
        if (goodsCriteria.getIsPromotion() != null) {
            hql.append("  and sg.goods.isPromotion=?");
            ls.add(goodsCriteria.getIsPromotion());
        }
        if (goodsCriteria.getHouseType() != null && goodsCriteria.getHouseType().getId() != null) {
            hql.append("  and sg.goods.houseType.id=?");
            ls.add(goodsCriteria.getHouseType().getId());
        }
        if (goodsCriteria.getMinPrice() != null && goodsCriteria.getMinPrice() != 0) {
            hql.append("  and sg.goods.discountPrice>=?");
            ls.add(goodsCriteria.getMinPrice());
        }
        if (goodsCriteria.getMaxPrice() != null && goodsCriteria.getMaxPrice() != 0) {
            hql.append("  and sg.goods.discountPrice<=?");
            ls.add(goodsCriteria.getMaxPrice());
        }
        if (goodsCriteria.getMinArea() != null && goodsCriteria.getMinArea() != 0) {
            hql.append("  and sg.goods.house.floorArea>=?");
            ls.add(goodsCriteria.getMinArea());
        }
        if (goodsCriteria.getMaxArea() != null && goodsCriteria.getMaxArea() != 0) {
            hql.append("  and sg.goods.house.floorArea<=?");
            ls.add(goodsCriteria.getMaxArea());
        }
        if (StringUtil.notEmpty(goodsCriteria.getQ())) {
            hql.append("  and (sg.goods.name like ? or sg.goods.houseType.text like ?  or sg.goods.style.text like ? ");
            hql.append("  or sg.goods.house.building.name like ?  or sg.goods.house.building.county.name like ?) ");
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
        }
        hql.append(") ) ) )");
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> standardDiyList() {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        hql.append("  and g.diyType.id=?");
        ls.add(GoodsDiyConstant.IS_DIY_STANDARD);
        hql.append("  order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, new Goods(), null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> listGoodsByBuilding(long buildingId) {
        // 生成查询条件
        StringBuilder hql = new StringBuilder();
        List<Object> params = new ArrayList<Object>();
        hql.append("from Goods g where g.invalid = false and g.diyType.id = ? ");
        params.add(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status = ? ");
        params.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        hql.append(" and g.house.building.id=?");
        params.add(buildingId);
        hql.append(" order by g.createdDatetime desc");
        Goods goods = new Goods();
        goods.setPageSize(null);
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", params, goods, null);
    }

    @Override
    public boolean updateAveragePrice(Goods goods) {

        StringBuilder hql = new StringBuilder();
        List<Object> params = new ArrayList<Object>();
        hql.append("update Goods g set g.averagePrice = null ");
        hql.append(" where g.id = ? ");
        params.add(goods.getId());
        return super.updateByParam(hql.toString(), params);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> pageForWebSiteH5(GoodsVO goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and g.isPromotion = true ");
        hql.append(" and g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        hql.append(") ");
        hql.append("  order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @Override
    public Long countForWebSiteH5(GoodsVO goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and g.isPromotion = true ");
        hql.append(" and g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        hql.append(") ");
        return super.findByPageCallBackCount(hql.toString(), ls);
     }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> pageForWebApp(GoodsVO goodsCriteria, String type) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and (g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        
        if ("X".equals(type)) {
            hql.append(" and (sg.goods.averagePrice is null and sg.goods.isPromotion != true and (1 = 1 ");
        } else if ("B".equals(type)) {
            hql.append(" and (sg.goods.averagePrice is not null and (1 = 1 ");
        } else if ("Y".equals(type)) {
            hql.append(" and ( (1 = 1 ");
        } else if ("P".equals(type)) {
            hql.append(" and (sg.goods.averagePrice is not null and sg.goods.isPromotion = false or sg.goods.isPromotion = false and (1 = 1 ");
        } else {
            hql.append(" and (sg.goods.averagePrice is not null or (1 = 1 ");
        }
        if (goodsCriteria.getShopId() != null && goodsCriteria.getShopId() != 0) {
            hql.append("  and sg.shop.id = ?");
            ls.add(goodsCriteria.getShopId());
        }
        if (goodsCriteria.getHouse() != null && goodsCriteria.getHouse().getBuilding() != null) {
            if (goodsCriteria.getHouse().getBuilding().getId() != null ) {
                hql.append("  and sg.goods.house.building.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCity() != null 
                    && goodsCriteria.getHouse().getBuilding().getCity().getId() != null ) {
                hql.append("  and sg.goods.house.building.city.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCity().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getCounty() != null 
                    && goodsCriteria.getHouse().getBuilding().getCounty().getId() != null ) {
                hql.append("  and sg.goods.house.building.county.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getCounty().getId());
            }
            if (goodsCriteria.getHouse().getBuilding().getProvince() != null 
                    && goodsCriteria.getHouse().getBuilding().getProvince().getId() != null ) {
                hql.append("  and sg.goods.house.building.province.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getProvince().getId());
            }
        }
        if (goodsCriteria.getStyle() != null && goodsCriteria.getStyle().getId() != null) {
            hql.append("  and sg.goods.style.id=?");
            ls.add(goodsCriteria.getStyle().getId());
        }
        if ("Y".equals(type)) {
            if (goodsCriteria.getIsPromotion() != null) {
                hql.append("  and sg.goods.isPromotion=?");
                ls.add(goodsCriteria.getIsPromotion());
            }
        } else if ("".equals(type)) {
            if (goodsCriteria.getIsPromotion() != null) {
                hql.append("  and sg.goods.isPromotion=?");
                ls.add(goodsCriteria.getIsPromotion());
            }
            if (goodsCriteria.getIsPromotion() != null && goodsCriteria.getIsPromotion() == true) {
                hql.append("  and sg.goods.averagePrice is not null");
            }
        }
        if (goodsCriteria.getIsRecommend() != null) {
            hql.append("  and sg.goods.isRecommend= true ");
        }
        if (goodsCriteria.getHouseType() != null && goodsCriteria.getHouseType().getId() != null) {
            hql.append("  and sg.goods.houseType.id=?");
            ls.add(goodsCriteria.getHouseType().getId());
        }
        if (goodsCriteria.getMinPrice() != null && goodsCriteria.getMinPrice() != 0) {
            hql.append("  and sg.goods.discountPrice>=?");
            ls.add(goodsCriteria.getMinPrice());
        }
        if (goodsCriteria.getMaxPrice() != null && goodsCriteria.getMaxPrice() != 0) {
            hql.append("  and sg.goods.discountPrice<=?");
            ls.add(goodsCriteria.getMaxPrice());
        }
        if (goodsCriteria.getMinArea() != null && goodsCriteria.getMinArea() != 0) {
            hql.append("  and sg.goods.house.floorArea>=?");
            ls.add(goodsCriteria.getMinArea());
        }
        if (goodsCriteria.getMaxArea() != null && goodsCriteria.getMaxArea() != 0) {
            hql.append("  and sg.goods.house.floorArea<=?");
            ls.add(goodsCriteria.getMaxArea());
        }
        if (StringUtil.notEmpty(goodsCriteria.getQ())) {
            hql.append("  and (sg.goods.name like ? or sg.goods.houseType.text like ?  or sg.goods.style.text like ? ");
            hql.append("  or sg.goods.house.building.name like ?  or sg.goods.house.building.county.name like ?) ");
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
            ls.add(getFuzzyCondition(goodsCriteria.getQ()));
        }
        hql.append(") ) ) ) ");
        if ("default".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.createdDatetime desc");
        }
        if ("price".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.discountPrice asc");
        }
        if ("last".equals(goodsCriteria.getSortField())) {
            hql.append("  order by g.isPromotion desc, g.updatedDatetime desc");
        }
        if ("sales".equals(goodsCriteria.getSortField())) {
            // 没有依据销量排序
            hql.append("  order by g.isPromotion desc ");
        }
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> listGoodsByCollectionItem(List<WebCollectionItem> list) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from Goods where invalid=0 and status=2 and id in ( :ids)");
        Query query = session.createQuery(hql.toString());
        if (list.size() > 0) {
            List<Long> ls = new ArrayList<Long>();
            for (WebCollectionItem matter : list) {
                ls.add(matter.getInfo());
            }
            query.setParameterList("ids", ls);
        } else {
            query.setParameter("ids", -1l);
        }
        return query.list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Goods> pageNoSelect(Goods goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g left join fetch g.style left join fetch g.houseType ");
        hql.append("where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status = ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (goodsCriteria.getStyle() != null && null != goodsCriteria.getStyle().getId()) {
            ls.add(goodsCriteria.getStyle().getId());
            hql.append("  and g.style.id=?");
        }
        if (goodsCriteria.getHouseType() != null && null != goodsCriteria.getHouseType().getId()) {
            ls.add(goodsCriteria.getHouseType().getId());
            hql.append("  and g.houseType.id=?");
        }
        if (StringUtil.notEmpty(goodsCriteria.getShopGoodIds())) {
            String[] ids = goodsCriteria.getShopGoodIds().split(",");
            for (String id : ids) {
                hql.append("  and g.id!=?");
                ls.add(Long.valueOf(id));
            }
        }
        hql.append("  order by g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }

    @Override
    public Long countNoSelect(Goods goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.invalid = false and g.diyType.id = ");
        hql.append(GoodsDiyConstant.IS_DIY_GOODS);
        hql.append(" and g.status = ");
        hql.append(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (StringUtil.notEmpty(goodsCriteria.getName())) {
            hql.append("  and g.name like ?");
            ls.add(getFuzzyCondition(goodsCriteria.getName()));
        }
        if (goodsCriteria.getStyle() != null && null != goodsCriteria.getStyle().getId()) {
            ls.add(goodsCriteria.getStyle().getId());
            hql.append("  and g.style.id=?");
        }
        if (goodsCriteria.getHouseType() != null && null != goodsCriteria.getHouseType().getId()) {
            ls.add(goodsCriteria.getHouseType().getId());
            hql.append("  and g.houseType.id=?");
        }
        if (StringUtil.notEmpty(goodsCriteria.getShopGoodIds())) {
            String[] ids = goodsCriteria.getShopGoodIds().split(",");
            for (String id : ids) {
                hql.append("  and g.id!=?");
                ls.add(Long.valueOf(id));
            }
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public List<Goods> pageForSales(GoodsVO goodsCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods g  ");
        hql.append("where g.status = ? ");
        ls.add(GoodsDiyConstant.GOODS_STATUS_PUBLISHED);
        if (goodsCriteria.getGoodsType() != null && goodsCriteria.getGoodsType().getId() != null) {
            hql.append("  and g.goodsType.id=?");
            ls.add(goodsCriteria.getGoodsType().getId());
        }
        hql.append(" and (g.id in (select sg.goods.id from GesShopGoodsItem sg where sg.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);
        if (goodsCriteria.getHouse() != null && goodsCriteria.getHouse().getBuilding() != null) {
            if (goodsCriteria.getHouse().getBuilding().getId() != null) {
                hql.append("  and sg.goods.house.building.id=?");
                ls.add(goodsCriteria.getHouse().getBuilding().getId());
            }
        }
        hql.append(") ) ");
            hql.append("  order by g.isPromotion desc, g.createdDatetime desc");
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, goodsCriteria, null);
    }
}
