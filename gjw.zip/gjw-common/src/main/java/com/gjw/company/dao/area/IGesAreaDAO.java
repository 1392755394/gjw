package com.gjw.company.dao.area;

import java.util.List;
import java.util.Map;

import org.hibernate.transform.ResultTransformer;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.area.GesArea;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.vo.GesAreaVO;


public interface IGesAreaDAO extends IDAO{
    
    /**
    * @Description  获得城市详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月3日 下午4:00:55
     */
    public GesArea getById(Long id);
    
    /**
     * @Description 根据父级Id获取地区列表  
     * @param parentId
     * @return
     * @author yanghaiyang   
     * @date 2015年12月10日 下午4:36:33
      */
     public List<GesArea> listByParentId(Long parentId);
     
     /**
      * @Description 根据父级Id获取地区分页列表数据  
      * @param gesArea
      * @return
      * @author yanghaiyang   
      * @date 2015年12月11日 上午10:17:41
       */
      public Map<Object, Object> pageByParentId(GesArea gesArea);
      
      /**
       * @Description 根据父级ID取分页列表数据  
       * @param area
       * @return
       * @author yanghaiyang   
       * @date 2015年12月11日 上午9:28:19
        */
      public Map<Object, Object> pageCityByParentId(GesAreaVO area);
      
      /**
      * @Description 查询已开通的城市  
      * @param area
      * @return
      * @author haiyang   
      * @date 2015年12月12日 上午9:57:56
       */
      public Map<Object, Object> pageCityDredgeByParentId(GesArea area);
      
      /**
       * @Description  获取地市分页列表数据
       * @param areaVO
       * @return
       * @author haiyang   
       * @date 2015年12月15日 上午11:33:50
        */
       public Map<Object, Object> pageCityByAreaVO(GesAreaVO areaVO);

       /**
       * @Description 分页总记录数查询  
       * @param areaVO
       * @param hql
       * @param paramList
       * @return
       * @author haiyang   
       * @date 2015年12月15日 下午7:27:57
        */
       public long count(GesAreaVO areaVO, String hql, List<Object> paramList); 
       
       /**
       * @Description 根据sql与参数查询列表  
       * @param hql
       * @param paramList
       * @return
       * @author haiyang   
       * @date 2015年12月16日 下午1:22:28
        */
       public List<?> pageByHql(final String finalHql, final String finalhqlResultParameter,
               final List<Object> finalLs, final GesArea finalentity, final ResultTransformer finalaliasToEntity);

       /**
       * @Description 根据实体获取对应表全部数据！  
       * @param className
       * @return
       * @author haiyang   
       * @date 2015年12月16日 下午3:21:16
        */
       public List<?> ListAllByClass(Class<?> className);
       
       /**
        * @Description  获取县区分页列表
        * @param areaVO
        * @return
        * @author xiaoyang   
        * @date 2015年12月21日 上午11:15:21
         */
        public Map<Object, Object> pageCountyByAreaVO(GesAreaVO areaVO);
        
        public List<GesArea> listGesAreaByIsAdded();
        
        /**
        * @Description 根据父级Id获取有楼盘的地区列表  
        * @param parentId 父级Id
        * @return
        * @author guojianbin   
        * @date 2016年1月26日
         */
        public List<GesArea> listByParentAndBuilding(Long parentId);
        

        //官网城市切换
        
        public List<GesArea> getAll(String isAdd,String isCity);
        
        public GesArea getByName(String name);

        public List<GesArea> listByParentArea();
        
        public List<GesArea> listByChildingArea(Long parentId);

}
