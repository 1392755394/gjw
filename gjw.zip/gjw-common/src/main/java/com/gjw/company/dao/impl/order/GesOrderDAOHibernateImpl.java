package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.OrderConstant;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.company.dao.order.IGesOrderDAO;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.shop.GesShop;
import com.gjw.utils.DateUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.order.GesOrderVO;

/**
 * 订单数据库操作实现类
 * 
 * @author jjw
 * 
 */
@Component("gesOrderDAOHibernateImpl")
public class GesOrderDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesOrderDAO {

    private static final Logger log = LoggerFactory.getLogger(GesOrderDAOHibernateImpl.class);

    @Override
    protected Class<?> getEntityClass() {
        return GesOrder.class;
    }

    /**
     * 官网 根据购买者ID分页获取订单信息
     * 
     * @param buyerId
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<GesOrderVO> pageOrderByBuyerIdForWeb(GesOrder gesOrder) {
        StringBuffer hql = new StringBuffer();
        hql.append("select o.id as id,o.code as code,o.createdDatetime as createdDatetime,o.goods.id as goodsId,g.name as goodsName,"
                + "p.path as photoPath,o.orderStatus as orderStatus ");
        hql.append(" from GesOrder o,Goods g,Picture p where o.goods.id=g.id and g.photo.id=p.id and o.invalid=? ");
        hql.append(" and o.buyer.id=? ");
        hql.append(" order by o.createdDatetime desc ");
        List<Object> param = new ArrayList<Object>();
        param.add(false);
        param.add(gesOrder.getBuyer().getId());
        List<GesOrderVO> list = (List<GesOrderVO>) super.findByListCallBack(hql.toString(), null, param,
                new CustomBeanTransform(GesOrderVO.class, true));
        return list;
    }

    /**
     * Ges系统中构家网用户分页查询订单信息
     */
    @Override
    public List<GesOrderVO> pageOrderByGjwIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可以添加查询的字段
        hql.append("select o.id as id, o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,g.id as goodsId,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,b.id as buyerId,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact,o.projectStatus as projectStatus,"
                + "o.remark as remark,o.updatedDatetime as updatedDatetime ");
        return pageOrder(gesOrderVO, hql);
    }

    /**
     * 订单查询条件组装
     * 
     * @param gesOrderVO
     * @param hql
     * @param param
     */
    protected void assembleOrderQueryCriteria(GesOrderVO gesOrderVO, StringBuffer hql, List<Object> param) {
        hql.append("from GesOrder o join o.goods g join  o.operator p join o.buyer b join  o.shop s left join o.gesOrderPayMoney m where s.id=o.shop.id and p.id=o.operator.id and o.goods.id=g.id ");
        hql.append(" and o.invalid=? ");
        param.add(false);
        if (StringUtil.notEmpty(gesOrderVO.getCode())) {
            hql.append(" and o.code like ? ");
            param.add("%" + gesOrderVO.getCode() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getPlaceOrderFromTime())) {
            hql.append(" and o.createdDatetime>?");
            param.add(DateUtil.parseDate(gesOrderVO.getPlaceOrderFromTime()));
        }
        if (StringUtil.notEmpty(gesOrderVO.getPlaceOrderToTime())) {
            hql.append(" and o.createdDatetime<=?");
            param.add(DateUtil.parseDate(gesOrderVO.getPlaceOrderToTime()));
        }
        if (StringUtil.notEmpty(gesOrderVO.getProjectStartFromTime())) {
            hql.append(" and o.gmtStart>?");
            param.add(DateUtil.parseDate(gesOrderVO.getProjectStartFromTime()));
        }
        if (StringUtil.notEmpty(gesOrderVO.getProjectStartToTime())) {
            hql.append(" and o.gmtStart<=?");
            param.add(DateUtil.parseDate(gesOrderVO.getProjectStartToTime()));
        }
        if (StringUtil.notEmpty(gesOrderVO.getOperatorName())) {
            hql.append(" and p.companyName like ?");
            param.add("%" + gesOrderVO.getOperatorName() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getShopName())) {
            hql.append(" and s.name like ?");
            param.add("%" + gesOrderVO.getShopName() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getGoodsName())) {
            hql.append(" and g.name like ?");
            param.add("%" + gesOrderVO.getGoodsName() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getTakeContact())) {
            hql.append(" and o.takeContact like ?");
            param.add("%" + gesOrderVO.getTakeContact() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getTakeContactMobile())) {
            hql.append(" and o.takeContactMobile=?");
            param.add(gesOrderVO.getTakeContactMobile());
        }
        if (StringUtil.notEmpty(gesOrderVO.getTakeAddress())) {
            hql.append(" and o.takeAddress like ?");
            param.add("%" + gesOrderVO.getTakeAddress() + "%");
        }
        if (StringUtil.notEmpty(gesOrderVO.getOrderStatus())) {
            hql.append(" and (o.orderStatus=?");
            param.add(gesOrderVO.getOrderStatus());
            if(StringUtil.notEmpty(gesOrderVO.getAppCode()) && "hedui".equals(gesOrderVO.getAppCode())){
                hql.append(" or o.orderStatus = ? )");
                param.add(OrderStatus.auditing.name());
            }else{
                hql.append(")");
            }
        }
        if (StringUtil.notEmpty(gesOrderVO.getBuyerId())) {
            hql.append(" and  o.buyer.id=?");
            param.add(gesOrderVO.getBuyerId());
        }
        if (gesOrderVO.getIsValid() != null) {
            // hql.append(" and o.invalid=?");
            // if (gesOrderVO.getIsValid().equals("1")) {
            // param.add(false);
            // } else {
            // param.add(true);
            // }
        }
        if (gesOrderVO.getOperatorId() != null) {
            hql.append(" and o.operator.id=?");
            param.add(gesOrderVO.getOperatorId());
        }
        if (gesOrderVO.getShopId() != null) {
            hql.append(" and o.shop.id=?");
            param.add(gesOrderVO.getShopId());
            if (StringUtil.notEmpty(gesOrderVO.getOrgType())) {
                if(!"4S店-店长".equals(gesOrderVO.getRoleName())){
                    hql.append(" and o.customer.personInCharge.id = ? ");
                    param.add(gesOrderVO.getId());
                }
            }
        }
        if (StringUtil.notEmpty(gesOrderVO.getBuyerName())) {
            hql.append(" and b.username like ?");
            param.add("%" + gesOrderVO.getBuyerName() + "%");
        }

        if (gesOrderVO.getSearchType() != null
                && gesOrderVO.getSearchType().intValue() == OrderConstant.QUERY_PROJECT.intValue()) {
            hql.append(" and o.orderStatus != ? ");
            param.add(OrderStatus.booked.name());
        }
        if(StringUtil.notEmpty(gesOrderVO.getAppCode()) && "shigong".equals(gesOrderVO.getAppCode())){
            hql.append(" and o.orderStatus != ? ");
            param.add(OrderStatus.booked.name());
            hql.append(" and o.orderStatus != ? ");
            param.add(OrderStatus.auditing.name());
            hql.append(" and o.orderStatus != ? ");
            param.add(OrderStatus.completed.name());
        }
        if (gesOrderVO.getUseType() == null) {
            hql.append(" and o.useType=? ");
            param.add(1);
        } else if (gesOrderVO.getUseType() > 0) {
            hql.append(" and o.useType=? ");
            param.add(gesOrderVO.getUseType());
        }
        if (StringUtil.notEmpty(gesOrderVO.getOrderBy())) {
            hql.append(" order by o." + gesOrderVO.getOrderBy() + " desc ");
        } else {
            hql.append(" order by o.createdDatetime desc ");
        }
    }

    /**
     * Ges系统中城运商用户查询订单
     */
    @Override
    public List<GesOrderVO> pageOrderByOperatorIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可以添加查询的字段
        hql.append("select o.id as id,o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,g.id as goodsId,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,b.id as buyerId,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact,"
                + "o.remark as remark ");
        return pageOrder(gesOrderVO, hql);
    }

    /**
     * Ges系统中4S店用户分页查询订单信息
     */
    @Override
    public List<GesOrderVO> pageOrderByShopIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可添加具体的查询字段
        hql.append("select o.id as id,o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,g.id as goodsId,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,b.id as buyerId,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact,"
                + "o.remark as remark ");
        return pageOrder(gesOrderVO, hql);
    }

    @Override
    public Long countOrderByBuyerIdForWeb(GesOrder gesOrder) {
        String hql = "from GesOrder o join fetch o.goods g where o.goods.id=g.id and o.buyer.id=?";
        List<Object> param = new ArrayList<Object>();
        param.add(gesOrder.getBuyer().getId());
        return super.findByPageCallBackCount(hql, param);
    }

    /**
     * Ges系统中构家网用户根据条件统计订单的数量
     */
    @Override
    public Long countOrderByGjwIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        return countOrder(gesOrderVO, hql);
    }

    /**
     * Ges系统中城运商用户根据条件统计订单的数量
     */
    @Override
    public Long countOrderByOperatorIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        return countOrder(gesOrderVO, hql);
    }

    /**
     * Ges系统中4s店用户根据条件统计订单的数量
     */
    @Override
    public Long countOrderByShopIdForGes(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        return countOrder(gesOrderVO, hql);
    }

    /**
     * 订单统计
     * 
     * @param gesOrderVO
     * @param hql
     * @return
     */
    protected Long countOrder(GesOrderVO gesOrderVO, StringBuffer hql) {
        List<Object> param = new ArrayList<Object>();
        assembleOrderQueryCriteria(gesOrderVO, hql, param);
        return super.findByPageCallBackCount(hql.toString(), param);
    }

    /**
     * 根据订单的id更行订单的状态
     * 
     * @param gesOrder
     * @return
     */
    @Override
    public Boolean updateOrderStatusByOrderId(GesOrder gesOrder) {
        StringBuffer hql = new StringBuffer("update GesOrder set updatedDatetime=?,user.id=?,orderStatus=? ");
        List<Object> param = new ArrayList<Object>();
        param.add(new Date());
        param.add(gesOrder.getUser().getId());
        param.add(gesOrder.getOrderStatus());
        if (StringUtil.notEmpty(gesOrder.getProjectStatus())) {
            hql.append(" ,projectStatus=? ");
            param.add(gesOrder.getProjectStatus());
        }
        if (StringUtil.notEmpty(gesOrder.getMobile())) {
            hql.append(" ,mobile=? ");
            param.add(gesOrder.getMobile());
        }
        hql.append(" where id=? ");
        param.add(gesOrder.getId());
        return super.updateByParam(hql.toString(), param);
    }

    /**
     * 官网后台 分页查询订单信息
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public List<GesOrderVO> pageOrderForWebConsole(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可以添加查询的字段
        hql.append("select o.id as id, o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact ");
        return (List<GesOrderVO>) pageOrder(gesOrderVO, hql);
    }

    /**
     * 官网后台 统计订单数量
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public Long countOrderForWebConsole(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        return countOrder(gesOrderVO, hql);
    }

    /**
     * 分页查询订单信息
     * 
     * @param gesOrderVO
     * @param hql
     * @return
     */
    @SuppressWarnings("unchecked")
    protected List<GesOrderVO> pageOrder(GesOrderVO gesOrderVO, StringBuffer hql) {
        List<Object> param = new ArrayList<Object>();
        assembleOrderQueryCriteria(gesOrderVO, hql, param);
        List<GesOrderVO> list = (List<GesOrderVO>) super.findByPageCallBack(hql.toString(), null, param, gesOrderVO,
                new CustomBeanTransform(GesOrderVO.class, true));
        return list;
    }

    /**
     * 根据订单id 查询订单信息
     * 
     * @param orderId
     * @return
     */
    @Override
    public GesOrder queryOrderByOrderId(Long orderId) {
        return (GesOrder) super.get(orderId);
    }

    /**
     * Ges 根据4S店ID分页查询该店已完成的订单
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public List<GesOrderVO> pageOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可以添加查询的字段
        hql.append("select o.id as id,o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact ");
        return (List<GesOrderVO>) pageOrder(gesOrderVO, hql);
    }

    /**
     * Ges 根据4S店ID统计已完成订单的数量
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public Long countOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        return countOrder(gesOrderVO, hql);
    }

    /**
     * 采购清单查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<GesOrder> pageByOrder(GesOrderVO model) {
        Map<String, Object> map = this.getHql(model);
        return (List<GesOrder>) super.findByPageCallBack(map.get("hql").toString(), null,
                (List<Object>) map.get("list"), model, null);
    }

    /**
     * 采购清单总数查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public Long countByOrder(GesOrderVO model) {
        Map<String, Object> map = this.getHql(model);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    /**
     * 采购清单查询hql
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2016年1月5日 上午9:24:05
     */
    protected Map<String, Object> getHql(GesOrderVO model) {
        Map<String, Object> map = new HashMap<String, Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from  GesOrder where invalid=0 and   orderStatus not in ('booked') ");
        List<Object> list = new ArrayList<Object>();

        if (StringUtil.notEmpty(model.getShopName())) {
            hql.append(" and shop.name=?");
            list.add(model.getShopName());
        }
        if (model.getId() != null) {
            hql.append(" and shop.id=?");
            list.add(model.getId());
        }
        if (StringUtil.notEmpty(model.getOperatorName())) {
            hql.append(" and operator.companyName=?");
            list.add(model.getOperatorName());
        }
        if (model.getOperatorId() != null) {
            hql.append(" and operator.id=?");
            list.add(model.getOperatorId());
        }
        if (StringUtil.notEmpty(model.getCode())) {
            hql.append(" and code=?");
            list.add(model.getCode());
        }

        if (StringUtil.notEmpty(model.getCode())) {
            hql.append(" and code=?");
            list.add(model.getCode());
        }
        if (StringUtil.notEmpty(model.getPlaceOrderFromTime())) {
            hql.append(" and  DATE_FORMAT(createdDatetime,'%Y-%m-%d')>=?");
            list.add(model.getPlaceOrderFromTime());
        }
        if (StringUtil.notEmpty(model.getPlaceOrderToTime())) {
            hql.append(" and  DATE_FORMAT(createdDatetime,'%Y-%m-%d')<=?");

            list.add(model.getPlaceOrderToTime());
        }

        if (StringUtil.notEmpty(model.getProjectStartFromTime())) {
            hql.append(" and  DATE_FORMAT(gmtStart,'%Y-%m-%d')>=?");
            list.add(model.getProjectStartFromTime());
        }
        if (StringUtil.notEmpty(model.getProjectStartToTime())) {
            hql.append(" and  DATE_FORMAT(gmtStart,'%Y-%m-%d'<=?");
            list.add(model.getProjectStartToTime());
        }
        hql.append(" order by createdDatetime desc");

        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }

    @Override
    public boolean updateProjectStatusByOrderId(GesOrder gesOrder) {
        GesOrder old = (GesOrder) super.get(gesOrder.getId());
        StringUtil.copyPropertiesAllowEmpty(gesOrder, old);
        return super.update(old) == 1;
    }

    /**
     * 更新订单信息 备注 面积 总额
     */
    @Override
    public int updateOrder(GesOrder order) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append(" update GesOrder set ");
        hql.append(" updatedDatetime=? ");
        param.add(order.getUpdatedDatetime());
        if(null!=order.getUser() && null!=order.getUser().getId()){
            hql.append(",user.id=? ");
            param.add(order.getUser().getId());
        }
        if (order.getArea() != null) {
            hql.append(",area=?");
            param.add(order.getArea());
        }
        if (order.getTotalAmount() != null && order.getTotalAmount().longValue() > 0) {
            hql.append(",totalAmount=?");
            param.add(order.getTotalAmount());
        }
        hql.append(",remark=?");
        param.add(order.getRemark());
        if (StringUtil.notEmpty(order.getOrderStatus())) {
            hql.append(",orderStatus=? ");
            param.add(order.getOrderStatus());
        }
        if (StringUtil.notEmpty(order.getBargainPath())) {
            hql.append(",bargainPath=? ");
            param.add(order.getBargainPath());
        }
        if (order.getUseType() != null && order.getUseType() > 0) {
            hql.append(",useType=? ");
            param.add(order.getUseType());
        }
        hql.append(" where id=? ");
        param.add(order.getId());
        super.updateByParam(hql.toString(), param);
        return 1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesOrder> baseProjectListPage(GesOrder order) {
        String hql = " from GesOrder where invalid=0 and projectStatus is not null and (projectType not in(1130102,1130105) or project_type IS NULL )";
        List<Object> list = new ArrayList<Object>();
        return (List<GesOrder>) super.findByListCallBack(hql, null, list, null);
    }

    /**
     * 基础数据同步---修改同步结果
     */
    @Override
    public void updateProjectSynch(GesOrder order) {
        String hql = "update   GesOrder set projectType= ? where id=? ";
        List<Object> list = new ArrayList<Object>();
        list.add(order.getProjectType());
        list.add(order.getId());
        super.updateByParam(hql, list);
    }

    @Override
    public Long countStandardMatter(GesSoMatterVO soMatter) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append(" from GesSoMatterItem s where 1=1 and s.invalid=? ");
        param.add(false);
        if (soMatter.getRoomId().longValue() != -1 && soMatter.getRoomId().longValue() != 0) {
            hql.append(" and s.room.id=? ");
            param.add(soMatter.getRoomId());
        }
        hql.append(" and s.gesOrder.id=? ");
        param.add(soMatter.getSoId());

        return super.findByPageCallBackCount(hql.toString(), param);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesSoMatterVO> pageStandardMatter(GesSoMatterVO soMatter) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("select s.id as id,m.code as code,m.name as name,b.name as brandName,m.dimension as dimension,"
                + "m.materials as materials,m.model as model,m.color as color,m.unit as unit,r.name as roomName,"
                + "s.quantity as quantity,s.purchasePrice as purchasePrice,s.marketPrice as marketPrice ");
        hql.append(" from GesSoMatterItem s join s.matter m join m.brand b join s.room r where 1=1 and s.invalid=? ");
        param.add(false);
        if (soMatter.getRoomId().longValue() != -1) {
            hql.append(" and s.room.id=? ");
            param.add(soMatter.getRoomId());
        }
        hql.append(" and s.gesOrder.id=? ");
        param.add(soMatter.getSoId());
        List<GesSoMatterVO> list = (List<GesSoMatterVO>) super.findByPageCallBack(hql.toString(), null, param,
                soMatter, Transformers.aliasToBean(GesSoMatterVO.class));
        return list;
    }

    @Override
    public Boolean updateOrderInfoByOrderId(GesOrder gesOrder) {
        GesOrder order = (GesOrder) super.get(gesOrder.getId());
        order.getShop().getName();
        GesShop shop = new GesShop();
        shop.setId(333l);
        shop.setName("shopNmae");
        StringUtil.copyProperties(gesOrder, order);
        super.update(order);
        return true;
    }

    @Override
    public Long countOrderByGoodsForWeb(Goods goods) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesOrder g where g.invalid = false ");
        hql.append(" and g.goods.id = ? ");
        ls.add(goods.getId());
        if (goods.getHouse() != null && goods.getHouse().getBuilding() != null) {
            if (goods.getHouse().getBuilding().getCity() != null
                    && goods.getHouse().getBuilding().getCity().getId() != null) {
                hql.append("  and g.shop.city.id=?");
                ls.add(goods.getHouse().getBuilding().getCity().getId());
            }
            if (goods.getHouse().getBuilding().getCounty() != null
                    && goods.getHouse().getBuilding().getCounty().getId() != null) {
                hql.append("  and g.shop.county.id=?");
                ls.add(goods.getHouse().getBuilding().getCounty().getId());
            }
        }

        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    /**
     * 直播家 查询订单信息(不用了)
     */
    @Override
    public GesOrderVO queryOrderInfoForLiveHome(Long orderId) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("");
        hql.append(" from GesOrder o,GesShop s,Goods g,User u");

        return null;
    }

    @Override
    public List<GesOrder> queryOrderInfoForCustomer(GesOrder order) {

        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("from GesOrder o where o.invalid=? and o.customer.id=?");
        param.add(false);
        param.add(order.getCustomer().getId());
        @SuppressWarnings("unchecked")
        List<GesOrder> orderList = (List<GesOrder>) super.findByPageCallBack(hql.toString(), "", param, order, null);
        return orderList;
    }

    /**
     * 系统修改订单状态
     */
    @Override
    public int updateOrderStatusBySystem(GesOrder order) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("update GesOrder o set o.updatedDatetime=? , o.orderStatus=? where o.id=? ");
        param.add(new Date());
        param.add(order.getOrderStatus());
        param.add(order.getId());
        return updateByParamReturnInt(hql.toString(), param);
    }

    protected int updateByParamReturnInt(String hql, List<Object> list) {
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql);
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.executeUpdate();
    }

    @Override
    public GesOrderVO queryOrderByIdForGjb(Long orderId) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("select o.id as id,o.totalAmount as totalAmount,g.name as goodsName,g.goodsType.id as goodsType,"
                + "o.code as code,o.buyer.id as buyerId,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime,"
                + "o.shop.id as shopId,o.buyer.username as buyerName,o.mobile as mobile,s.code as shopCode ");
        hql.append("from User u,GesShop s,Goods g,GesOrder o ");
        hql.append("where o.invalid=? and o.buyer.id=u.id and s.id=o.shop.id and o.goods.id=g.id and o.id=? ");
        param.add(false);
        param.add(orderId);
        List<GesOrderVO> list = (List<GesOrderVO>) super.findByListCallBack(hql.toString(), null, param,
                Transformers.aliasToBean(GesOrderVO.class));
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    /**
     * 根据支付的流水号查询订单的信息
     */
    @Override
    public GesOrderVO queryOrderByTradeId(String tradeId) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("select o.id as id,o.orderStatus as orderStatus,o.totalAmount as totalAmount ");
        hql.append("from GesOrder o,MultiplePayment m ");
        hql.append("where o.invalid=? and o.id=m.gesOrder.id and m.serialPayNo=? ");
        param.add(false);
        param.add(tradeId);
        List<GesOrderVO> list = (List<GesOrderVO>) super.findByListCallBack(hql.toString(), null, param,
                Transformers.aliasToBean(GesOrderVO.class));
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public int deleteGesOrder(GesOrder order) {
        StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("update GesOrder o set o.updatedDatetime=?,o.user.id=?,o.invalid=? where o.id=? ");
        param.add(new Date());
        param.add(order.getUser().getId());
        param.add(true);
        param.add(order.getId());
        return updateByParamReturnInt(hql.toString(), param);
    }

    @Override
    public List<GesOrderVO> queryOrderInfoForExcel(GesOrderVO gesOrderVO) {
        StringBuffer hql = new StringBuffer();
        // 此处可以添加查询的字段
        hql.append("select o.id as id, o.code as code,s.name as shopName,p.companyName as operatorName,g.name as goodsName,g.id as goodsId,o.totalAmount as totalAmount,o.orderStatus as orderStatus,o.createdDatetime as createdDatetime "
                + ",m.earnestPay as earnestPay,m.batchPay as batchPay,m.batchPayNum as batchPayNum,b.username as buyerName,b.id as buyerId,"
                + "o.takeAddress as takeAddress,o.takeContactMobile as takeContactMobile,o.takeContact as takeContact,o.projectStatus as projectStatus,"
                + "o.remark as remark,o.updatedDatetime as updatedDatetime ");
        List<Object> param = new ArrayList<Object>();
        assembleOrderQueryCriteria(gesOrderVO, hql, param);
        List<GesOrderVO> list = (List<GesOrderVO>) super.findByListCallBack(hql.toString(), null, param,
                new CustomBeanTransform(GesOrderVO.class, true));
        return list;
    }

}
