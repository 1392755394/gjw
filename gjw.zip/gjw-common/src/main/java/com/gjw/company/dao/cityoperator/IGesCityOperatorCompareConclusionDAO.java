package com.gjw.company.dao.cityoperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperatorCompareConclusion;

public interface IGesCityOperatorCompareConclusionDAO extends IDAO{
    
    public GesCityOperatorCompareConclusion listByID(Long id);

    public boolean updateGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);

    public boolean createGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);
    
    public long count(GesCityOperatorCompareConclusion model);
    
    public List<GesCityOperatorCompareConclusion> listByGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);
}
