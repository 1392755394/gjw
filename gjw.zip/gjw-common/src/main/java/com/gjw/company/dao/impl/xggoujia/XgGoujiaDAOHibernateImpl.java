package com.gjw.company.dao.impl.xggoujia;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.xggoujia.XgGoujiaDAO;
import com.gjw.entity.xggoujia.XgGoujia;

@Component("xgGoujiaDaoImpl")
public class XgGoujiaDAOHibernateImpl extends AbstractDAOHibernateImpl implements
		XgGoujiaDAO {

	@SuppressWarnings("unchecked")
	@Override
	public List<XgGoujia> getListXgGoujia(XgGoujia xgGoujia) {
		// 调用公共静态方法
//		String hql="from XgGoujia";
//		return  (List<XgGoujia>) super.findByPageCallBack(hql, "", null, xgGoujia, null);

//		return (List<XgGoujia>) super.getHibernateTemplate().find(hql, xgGoujia);
		Session session = super.getHibernateTemplate().getSessionFactory()
				.getCurrentSession();
		Query query = session.createQuery("from XgGoujia");
		System.out.println("查询全部成功");
		return query.list();
		
	}
	
	@Override
	public Long saveXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		System.out.println("添加成功");
		return (Long) super.getHibernateTemplate().save(xgGoujia);
	}

	@Override
	public Long updateXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().update(xgGoujia);
		System.out.println("修改成功");
		return xgGoujia.getId();
	}

	@Override
	public Long deleteXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(xgGoujia);
		System.out.println("删除成功");
		return xgGoujia.getId();
	}

	@Override
	protected Class<?> getEntityClass() {
		// TODO Auto-generated method stub
		return XgGoujia.class;
	}

	
	@Override
	public XgGoujia getByIdXgGoujia(Long id) {
		// TODO Auto-generated method stub
		System.out.println("匹配ID查询成功");
		return (XgGoujia) super.get(id);
	}

	@Override
	public Long count(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		String hql = " from XgGoujia where invalid =?";
        List<Object> list = new ArrayList<Object>();
        list.add(false);
        System.out.println("总记录查询成功");
        return super.findByPageCallBackCount(hql, list);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<XgGoujia> pageListXgGoujia(XgGoujia xgGoujia) {
		String hql="from XgGoujia where invalid =?";
		List<Object> list=new ArrayList<Object>();
		list.add(false);
		System.out.println("分页查询成功");
		return (List<XgGoujia>) super.findByPageCallBack(hql, "", list, xgGoujia, null);
	}
	  

	@SuppressWarnings("unchecked")
	@Override
	public List<XgGoujia> pageListByName(XgGoujia xgGoujia) {
		StringBuffer hql = new StringBuffer("from XgGoujia xgGoujia where xgGoujia.invalid =?");
		List<Object> ls = new ArrayList<Object>();
		ls.add(false);
		System.out.println("匹配查询成功");
		hql.append(" and xgGoujia.name like ? ");
		ls.add("%"+xgGoujia.getName()+"%");
		return (List<XgGoujia>) super.findByPageCallBack(hql.toString(), "", ls, xgGoujia, null);
	}

}
