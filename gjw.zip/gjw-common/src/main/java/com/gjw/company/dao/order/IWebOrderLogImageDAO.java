package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.WebOrderLogImage;

/**
 * 
* @Description: 日志图片dao接口类
* @author  zhaoyonglian
* @date 2015年12月19日 上午10:40:49
*
 */
public interface IWebOrderLogImageDAO extends IDAO {

	/**
	 * 
	* @Description  日志图片列表
	* @param logId
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月22日 上午10:32:45
	 */
	public List<WebOrderLogImage> listByLog(Long logId);
	
	
	/**
	 * 
	* @Description  删除日志图片
	* @param logId
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月22日 上午10:33:41
	 */
	public boolean deleteByLog(Long logId);
	
}
