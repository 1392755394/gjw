package com.gjw.company.dao.salestool;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.salestool.IpadAdvert;

public interface IIpadAdvertDAO extends IDAO{
    public IpadAdvert listByID(Long id);

    public boolean updateIpadAdvert(IpadAdvert model);

    public boolean createIpadAdvert(IpadAdvert model);
    
    public long count(IpadAdvert model);
    
    public List<IpadAdvert> listByIPadAdvert();
}
