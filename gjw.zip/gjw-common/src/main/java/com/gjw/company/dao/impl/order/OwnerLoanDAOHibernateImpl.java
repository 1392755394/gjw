package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IOwnerLoanDAO;
import com.gjw.entity.order.LoanApplyInfo;
import com.gjw.vo.order.LoanApplyInfoVO;

@Component("ownerLoanDAOHibernateImpl")
public class OwnerLoanDAOHibernateImpl extends AbstractDAOHibernateImpl
		implements IOwnerLoanDAO {

	@Override
	protected Class getEntityClass() {
		return LoanApplyInfo.class;
	}

	/**
	 * 根据订单id查询要贷款的订单的信息
	 * 在这里进行数据的处理，根据产品包的类型，处理装修房的面积
	 * @param orderId
	 */
	@Override
	public LoanApplyInfoVO queryLoanOrderInfo(Long orderId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select o.id as orderId,o.code as orderCode,o.goods.id as goodsId,o.orderStatus as orderStatus,"+
  			"o.buyer.id as buyerId,g.name as goodsName,o.area as houseAcreage,s.code as shopCode,s.name as shopName,"+
  			"s.id as shopId,o.totalAmount as totalAmount,o.takeAddress as houseAddress,h.floorArea as goodsSize,g.isPromotion as isPromotion ");
		hql.append(" from GesShop s,House h,Goods g,GesOrder o ");
		hql.append(" where o.invalid=? and o.shop.id=s.id and g.house.id=h.id and o.goods.id=g.id and o.id=? ");
		param.add(false);
		param.add(orderId);
		List<LoanApplyInfoVO> list=(List<LoanApplyInfoVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(LoanApplyInfoVO.class));
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	@Override
	public Long countOwnerLoanTimes(Long orderId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" from LoanApplyInfo l where l.loanApplyStatus=1 and l.order.id=? ");
		param.add(orderId);
		return super.countHql(hql.toString(), param);
	}

	@Override
	public Long countApplyTimes(Long orderId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" from LoanApplyInfo l where l.createdDatetime>current_date() and l.order.id=? ");
		param.add(orderId);
		return super.countHql(hql.toString(), param);
	}

	@Override
	public void addOwnerLoanInfo(LoanApplyInfo loanApplyInfo) {
		super.add(loanApplyInfo);
	}

	@Override
	public int updateOwnerLoanInfoStatus(LoanApplyInfo loanApplyInfo) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update LoanApplyInfo l set l.loanApplyStatus=? ,l.updatedDatetime=? where id=? ");
		param.add(loanApplyInfo.getLoanApplyStatus());
		param.add(new Date());
		param.add(loanApplyInfo.getId());
		return updateByParamReturnInt(hql.toString(), param);
	}
	
	public int updateByParamReturnInt(String hql, List<Object> list) {
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql);
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.executeUpdate();
    }

}
