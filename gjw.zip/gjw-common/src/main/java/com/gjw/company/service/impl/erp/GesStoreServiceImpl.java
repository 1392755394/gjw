package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesStoreService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.store.GesStore;

/**
 * 仓库管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 上午10:22:57
 * 
 */
@Component("gesStoreServiceImpl")
public class GesStoreServiceImpl extends AbstractServiceImpl implements IGesStoreService {

    /**
    * 
    */
    @Override
    @Transactional(readOnly = true)
    public Long count(GesStore storeCriteria) {
        return super.getGesStoreDAO().count(storeCriteria);
    }

    /**
     * 仓库分页仓库
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesStore> listGesStore(GesStore storeCriteria) {

        List<GesStore> ls = super.getGesStoreDAO().listGesStore(storeCriteria);
        for (GesStore gesStore : ls) {
            if (gesStore.getShop() != null && gesStore.getShop().getId() != null) {
                gesStore.getShop().getName();
            }
            if (gesStore.getCityOperator() != null && gesStore.getCityOperator().getId() > 0
                    && gesStore.getCityOperator().getId() > 0) {
                gesStore.getCityOperator().getCompanyName();
            }
            if (gesStore.getStoreType() != null && gesStore.getStoreType().getId() != null) {
                gesStore.getStoreType().getText();
            }
            if (gesStore.getGesOrder() != null && gesStore.getGesOrder().getGoods() != null) {
                gesStore.getGesOrder().getGoods().getName();
            }
            gesStore.getCity().getName();
            gesStore.getProvince().getName();
            gesStore.getCounty().getName();
        }
        return ls;
    }

    /**
     * 根据仓库id查询仓库信息
     */
    @Override
    @Transactional(readOnly = true)
    public GesStore getById(Long id) {
        GesStore store = super.getGesStoreDAO().queryByID(id);
        if (store.getShop() != null) {
            store.getShop().getName();
        }
        if (store.getCityOperator() != null && store.getCityOperator().getId() != null
                && store.getCityOperator().getId() > 0) {
            store.getCityOperator().getCompanyName();
        } else {
            GesCityOperator cp = new GesCityOperator();
            cp.setCompanyName("");
            store.setCityOperator(cp);
        }
        if (store.getGesOrder() != null) {
            store.getGesOrder().getGoods().getName();
        }
        if (store.getStoreType() != null && store.getStoreType().getId() != null) {
            store.getStoreType().getText();
        }
        store.getCity().getName();
        store.getProvince().getName();
        store.getCounty().getName();
        return store;
    }

    /**
     * 修改仓库信息
     */
    @Override
    @Transactional
    public boolean updateGesStore(GesStore model) {

        return super.getGesStoreDAO().updateGesStore(model);
    }

    /**
     * 新增仓库信息
     */
    @Override
    @Transactional
    public boolean createGesStore(GesStore model) {

        if (model.getShop().getId() == null) {
            model.setShop(null);
        } else {
            GesShop shop = super.getGesShopDAO().listByID(model.getShop().getId());
            GesCityOperator cityOperator = new GesCityOperator();
            cityOperator.setId(shop.getOperator().getId());
            model.setCityOperator(cityOperator);
        }
        if (model.getCityOperator().getId() == null) {
            model.setCityOperator(null);
        }
        if (model.getGesOrder() == null || model.getGesOrder().getId() == null) {
            model.setGesOrder(null);
            ;
        }
        boolean falg = super.getGesStoreDAO().createGesStore(model);
        return falg;
    }

    /**
     * 删除仓库
     */
    @Override
    @Transactional
    public boolean deleteGesStoreByIds(String ids) {
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesStore gesStore = new GesStore();
            gesStore.setId(Long.parseLong(id));
            gesStore.setInvalid(true);
            try {
                updateGesStore(gesStore);
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesStore> listStoreBySynchType(GesStore stoe) {
        List<GesStore> list = super.getGesStoreDAO().listStoreBySynchType(stoe);
        for (GesStore obj : list) {
            obj.getSynchType().getText();
        }
        return list;
    }
}
