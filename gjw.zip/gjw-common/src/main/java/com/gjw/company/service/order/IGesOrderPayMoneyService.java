package com.gjw.company.service.order;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.vo.order.GesOrderVO;

public interface IGesOrderPayMoneyService extends IService {

    /**
     * <p>
     * 采购管理
     * <p>
     * 采购清单,分页查询
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2015年12月26日 下午3:57:29
     */
    public List<GesOrderPayMoney> pageByGesOrderPayMoney(GesOrderVO order);

    /**
     * <p>
     * 采购管理
     * <p>
     * 采购清单,分页查询总数
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2015年12月26日 下午4:11:07
     */
    public Long count(GesOrderVO order);

    /**
     * 根据订单id查询订单状态
     * 
     * @Description
     * @param id
     * @return
     * @author gwb
     * @date 2016年1月18日 上午9:54:40
     */
    public GesOrderPayMoney getGesOrderPayMoneyByOrderId(Long id);

}
