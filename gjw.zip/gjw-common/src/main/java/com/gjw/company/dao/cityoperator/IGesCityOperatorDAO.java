package com.gjw.company.dao.cityoperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperator;

public interface IGesCityOperatorDAO extends IDAO{
    public GesCityOperator listByID(Long id);

    public boolean updateGesCityOperator(GesCityOperator model);

    public boolean createGesCityOperator(GesCityOperator model);
    
    public long count(GesCityOperator model,Integer... stars);
    
    public List<GesCityOperator> listByGesCityOperator(GesCityOperator model,Integer... stars);
}
