package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Service;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesStoreInventoryDAO;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.utils.StringUtil;
import com.gjw.vo.RdRecordsVO;
import com.gjw.vo.StoreInventoryVO;

/**
 * 库存管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 上午9:23:02
 * 
 */
@Service("gesStoreInventoryDAOHibernateImpl")
public class GesStoreInventoryDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesStoreInventoryDAO {

    @Override
    protected Class getEntityClass() {
        return GesStoreInventory.class;
    }

    @Override
    public Long sumInventory(RdRecordsVO records, List<GesStore> listStore) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append("select sum(a.inventoryAmount) as  inventoryAmount from GesStoreInventory as a where a.invalid=0  and a.matter.id=:matterId ");

        if (records.getStoreId() != null && records.getStoreId() >= 0) {
            hql.append(" and a.store.id=:storeId ");
        }
        List<Long> storeIds = new ArrayList<Long>();
        if ((records.getShopId() != null || records.getOperatorId() != null) && listStore.size() > 0) {
            hql.append(" and a.store.id in ( :ids ) ");
            for (GesStore gesStore : listStore) {
                storeIds.add(gesStore.getId());
            }
        }
        Query query = session.createQuery(hql.toString());
        query.setParameter("matterId", records.getMatterId());

        if (records.getStoreId() != null && records.getStoreId() >= 0) {
            query.setParameter("storeId", records.getStoreId());
        }
        if (storeIds.size() > 0) {
            query.setParameterList("ids", storeIds);
        }
        return (Long) query.uniqueResult();
    }

    @Override
    public GesStoreInventory getGesStoreInventoryByMatterIdAndStoreId(GesStoreInventory condition) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesStoreInventory where invalid=0 ");
        if (condition.getMatter().getId() != null) {
            hql.append("  and matter.id=? ");
            list.add(condition.getMatter().getId());
        }
        if (condition.getStore().getId() != null) {
            hql.append("  and store.id=? ");
            list.add(condition.getStore().getId());
        }
        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return (GesStoreInventory) query.uniqueResult();
    }

    @Override
    public void updateInventoryAmountById(GesStoreInventory storeInventory) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update GesStoreInventory set inventoryAmount=? where id=?");
        list.add(storeInventory.getInventoryAmount());
        list.add(storeInventory.getId());
        super.updateByParam(hql.toString(), list);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesStoreInventory> pageByGesStoreInventory(StoreInventoryVO gesStoreInventory) {
        Map<String, Object> map = this.getHql(gesStoreInventory);
        return (List<GesStoreInventory>) super.findByPageCallBack(map.get("hql").toString(), null,
                (List<Object>) map.get("list"), gesStoreInventory, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long count(StoreInventoryVO gesStoreInventory) {
        Map<String, Object> map = this.getHql(gesStoreInventory);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    private Map<String, Object> getHql(StoreInventoryVO gesStoreInventory) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        hql.append(" from GesStoreInventory  where invalid=0");
        if (StringUtil.notEmpty(gesStoreInventory.getStoreType())) {
            if (gesStoreInventory.getStoreType().equals("1110104")) {
                hql.append(" store.gesOrder.id in (select id from GesOrder o where invalid=0");
                if (gesStoreInventory.getCityOperatorId() != null) {
                    hql.append(" and o.operator.id=? ");
                    list.add(gesStoreInventory.getCityOperatorId());
                }
                if (gesStoreInventory.getShopId() != null) {
                    hql.append(" and o.shop.id=? ");
                    list.add(gesStoreInventory.getShopId());
                }
                hql.append(" )");
            }
            if (gesStoreInventory.getStoreType().equals("1110102")) {
                hql.append("and store.cityOperator.id=?");
                list.add(Long.parseLong(gesStoreInventory.getCityOperatorId().toString()));
            }
            if (gesStoreInventory.getStoreType().equals("1110103")) {
                hql.append(" and store.shop.id=?");
                list.add(Long.parseLong(gesStoreInventory.getShopId().toString()));
            }
            hql.append(" and store.storeType.id=?");
            list.add(Long.parseLong(gesStoreInventory.getStoreType()));

        }

        if (StringUtil.notEmpty(gesStoreInventory.getStoreName())) {
            hql.append(" and store.name like ?");
            list.add(super.getFuzzyCondition(gesStoreInventory.getStoreName()));
        }
        if (StringUtil.notEmpty(gesStoreInventory.getMatterName())) {
            hql.append(" and matter.name like ?");
            list.add(super.getFuzzyCondition(gesStoreInventory.getMatterName()));
        }
        if (StringUtil.notEmpty(gesStoreInventory.getMatterCode())) {
            hql.append(" and matter.code like ?");
            list.add(super.getFuzzyCondition(gesStoreInventory.getMatterCode()));
        }
        if (StringUtil.notEmpty(gesStoreInventory.getStoreLocationName())) {
            hql.append(" and storeLocation.name like ?");
            list.add(super.getFuzzyCondition(gesStoreInventory.getStoreLocationName()));
        }
        if (StringUtil.notEmpty(gesStoreInventory.getStoreLocationCode())) {
            hql.append("  and storeLocation.code like ?");
            list.add(super.getFuzzyCondition(gesStoreInventory.getStoreLocationCode()));
        }
        hql.append(" order by createdDatetime desc");
        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }
}
