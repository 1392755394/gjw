package com.gjw.company.dao.impl.order;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IWebOrderLogImageDAO;
import com.gjw.entity.order.WebOrderLogImage;

/**
 * 
 * @Description: 日志实现类
 * @author zhaoyonglian
 * @date 2015年12月19日 上午10:41:15
 * 
 */
@Component("webOrderLogImageDAOHibernateImpl")
public class WebOrderLogImageDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebOrderLogImageDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebOrderLogImage.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebOrderLogImage> listByLog(Long logId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLogImage where invalid = 0 and log_id = :log_id");
        Query query = session.createQuery(hql.toString());
        query.setLong("log_id", logId);
        return query.list();
    
    }

    @Override
    public boolean deleteByLog(Long logId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" update  WebOrderLogImage set invalid = 1  where log_id = :log_id");
        Query query = session.createQuery(hql.toString());
        query.setLong("log_id", logId);
        query.executeUpdate();
        return true;
    }

}
