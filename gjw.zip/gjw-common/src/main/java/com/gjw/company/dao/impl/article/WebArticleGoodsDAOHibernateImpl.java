package com.gjw.company.dao.impl.article;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.article.IWebArticleGoodsDAO;
import com.gjw.entity.article.WebArticleGoods;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("webArticleGoodsDAOHibernateImpl")
public class WebArticleGoodsDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebArticleGoodsDAO {

    @Override
    protected Class<?> getEntityClass() {
        return WebArticleGoods.class;
    }

    @Override
    public List<WebArticleGoods> listByArticle(Long article) {
        String hql="from WebArticleGoods where invalid=0 and article.id=?";
        return (List<WebArticleGoods>)this.getHibernateTemplate().find(hql, article);
        
    }

    @Override
    public void deleteByArticleAndGoods(WebArticleGoods item) {
        String hql="delete from WebArticleGoods where article.id=? and goods.id=?";
        this.getHibernateTemplate().bulkUpdate(hql, item.getArticle().getId(),item.getGoods().getId());
    }
}
