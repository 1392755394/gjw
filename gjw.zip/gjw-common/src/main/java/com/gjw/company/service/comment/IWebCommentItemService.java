package com.gjw.company.service.comment;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.comment.WebCommentItem;

/**
 * 
* @Description: 评论service接口
* @author  zhaoyonglian
* @date 2015年12月26日 下午4:03:43
*
 */
public interface IWebCommentItemService extends IService {
    /**
     * 
    * @Description  分页列表，搜索条件：字典，内容，废弃，创建者
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月26日 下午3:49:56
     */
    public List<WebCommentItem> pageByCondition(WebCommentItem item);
    
    /**
     * 
    * @Description  总数
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月26日 下午3:50:34
     */
    public Long countByCondition(WebCommentItem item);
    /**
     * 
    * @Description  批量废弃评论
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午4:53:34
     */
    public String invalidByIds(String ids);
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    public boolean insert(WebCommentItem item);
}
