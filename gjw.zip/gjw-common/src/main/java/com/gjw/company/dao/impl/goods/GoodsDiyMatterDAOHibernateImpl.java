package com.gjw.company.dao.impl.goods;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.goods.IGoodsDiyMatterDAO;
import com.gjw.entity.goods.GoodsDiyMatter;
import com.gjw.utils.StringUtil;

/**
 * DIY清单dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月28日 
 *
 */
@Component("goodsDiyMatterDAOHibernateImpl")
public class GoodsDiyMatterDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsDiyMatterDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsDiyMatter.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsDiyMatter> listRoomDiyMatter(Long roomId) {

        String hql = "from GoodsDiyMatter g where g.room.id = ? and g.invalid = false";
        
        return (List<GoodsDiyMatter>) super.getHibernateTemplate().find(hql, roomId);
    }

    @Override
    public Integer batchCreate(List<GoodsDiyMatter> matterList) {
        return super.batchAdd(matterList);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsDiyMatter> listByGoodsId(Long goodsId) {

        String hql = "from GoodsDiyMatter g where g.goods.id = ? and g.invalid = false";
        
        return (List<GoodsDiyMatter>) super.getHibernateTemplate().find(hql, goodsId);
    }

    @Override
    public boolean update(GoodsDiyMatter goodsDiyMatter) {
        GoodsDiyMatter old = (GoodsDiyMatter) super.get(goodsDiyMatter.getId());
        StringUtil.copyProperties(goodsDiyMatter, old);
        return super.update(old) == 1;
    }

    @Override
    public boolean deleteByGoodsId(Long goodsId) {
        StringBuilder hql = new StringBuilder();
        hql.append("update GoodsDiyMatter");
        hql.append(" set invalid = true, updatedDatetime = :updatedDatetime where goods.id=:goodsId");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        // 修改时间
        query.setParameter("updatedDatetime", new Timestamp(System.currentTimeMillis()));
        query.setParameter("goodsId", goodsId);
        return query.executeUpdate()>0;
    }

}
