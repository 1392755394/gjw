package com.gjw.company.dao.app;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.app.WebAdvice;


public interface IWebAdviceDAO extends IDAO{
    public WebAdvice get(Long id);

    public List<WebAdvice> getList(Integer index,Integer size);
    
    public boolean addWebAdvice(WebAdvice webAdvice);
    
    public void updateWebAdvice(WebAdvice webAdvice);
}
