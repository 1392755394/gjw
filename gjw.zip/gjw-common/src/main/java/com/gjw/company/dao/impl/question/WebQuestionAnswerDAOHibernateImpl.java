package com.gjw.company.dao.impl.question;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.question.IWebQuestionAnswerDAO;
import com.gjw.entity.question.WebQuestionAnswer;
import com.gjw.utils.StringUtil;
import com.gjw.vo.WebQuestionAnswerVO;

/**
 * 产品包dao的Hibernate实现
 */
@Component("webQuestionAnswerDAOHibernateImpl")
public class WebQuestionAnswerDAOHibernateImpl extends AbstractDAOHibernateImpl implements
		IWebQuestionAnswerDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebQuestionAnswer.class;
    }

    @Override
    public WebQuestionAnswer getById(Long id) {
        // TODO Auto-generated method stub
        return (WebQuestionAnswer) super.get(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<WebQuestionAnswer> pageBySubjectAndInvalid(WebQuestionAnswerVO answer) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if(answer.getInvalid()){
            hql.append(" from WebQuestionAnswer as answer"
                    + " where answer.invalid = 1");
        }else{
            hql.append(" from WebQuestionAnswer as answer"
                    + " where answer.invalid = 0");
        }
        if(StringUtil.notEmpty(answer.getSubject())){
            hql.append(" and answer.question.subject like ?");
            ls.add("%"+answer.getSubject()+"%");
        }
        hql.append("order by answer.id desc");
         return (List<WebQuestionAnswer>) super.findByPageCallBack(hql.toString(), "", ls, answer, null);
    }

    @Override
    public Long countBySubjectAndInvalid(WebQuestionAnswerVO answer) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if(answer.getInvalid()){
            hql.append(" from WebQuestionAnswer as answer"
                    + " where answer.invalid = 1");
        }else{
            hql.append(" from WebQuestionAnswer as answer"
                    + " where answer.invalid = 0");
        }
        if(StringUtil.notEmpty(answer.getSubject())){
            hql.append(" and answer.question.subject like ?");
            ls.add("%"+answer.getSubject()+"%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updateAnswer(WebQuestionAnswer answer) {
        // TODO Auto-generated method stub
        WebQuestionAnswer ans = (WebQuestionAnswer) super.get(answer.getId());
        StringUtil.copyProperties(answer, ans);
        super.update(ans);
        return true;
    }

    @Override
    public boolean invalidByQuestion(Long questionId) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" update WebQuestionAnswer set invalid = 1"
                + " where question.id = ?");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        query.setParameter(0, questionId);
        return query.executeUpdate() > 0;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebQuestionAnswer> listByQuestion(Long questionId) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebQuestionAnswer where invalid = 0 and question.id =? ");
        return (List<WebQuestionAnswer>) getHibernateTemplate().find(hql.toString(),questionId);
    }

    @Override
    public void isEssence(Long answerId) {
        // TODO Auto-generated method stub
        String hql = " update WebQuestionAnswer set isEssence = 'y' where id = "+answerId;
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        query.executeUpdate();
    }


}
