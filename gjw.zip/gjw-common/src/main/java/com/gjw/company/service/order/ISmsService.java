package com.gjw.company.service.order;

import com.gjw.entity.validation.SmsValidation;

public interface ISmsService {
	
	public boolean sendValidationMessage(SmsValidation smsValidation);

}
