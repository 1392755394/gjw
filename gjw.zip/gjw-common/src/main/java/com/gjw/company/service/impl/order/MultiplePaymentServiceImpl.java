package com.gjw.company.service.impl.order;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.common.error.ErrorMessage;
import com.gjw.common.exception.GenericException;
import com.gjw.common.web.JsonResult;
import com.gjw.company.dao.order.IGesOrderPayMoneyDAO;
import com.gjw.company.dao.order.IMultiplePaymentDAO;
import com.gjw.company.service.order.IMultiplePaymentService;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.entity.user.User;
import com.gjw.utils.StringUtil;
import com.gjw.vo.order.GesOrderVO;
import com.gjw.vo.order.MultiplePaymentVO;

@Component("multiplePaymentServiceImpl")
public class MultiplePaymentServiceImpl extends AbstractServiceImpl implements
		IMultiplePaymentService {
	
	private static final Logger log=LoggerFactory.getLogger(MultiplePaymentServiceImpl.class);
	private static final int SOURCE_TYPE=0;
	
	@Resource(name="multiplePaymentDAOHibernateImpl")
	private IMultiplePaymentDAO multiplePaymentDAO;
	
	@Resource(name="gesOrderPayMoneyDAOHibernateImpl")
	private IGesOrderPayMoneyDAO gesOrderPayMoneyDAO;

	public IMultiplePaymentDAO getMultiplePaymentDAO() {
		return multiplePaymentDAO;
	}

	public void setMultiplePaymentDAO(IMultiplePaymentDAO multiplePaymentDAO) {
		this.multiplePaymentDAO = multiplePaymentDAO;
	}

	public IGesOrderPayMoneyDAO getGesOrderPayMoneyDAO() {
		return gesOrderPayMoneyDAO;
	}

	public void setGesOrderPayMoneyDAO(IGesOrderPayMoneyDAO gesOrderPayMoneyDAO) {
		this.gesOrderPayMoneyDAO = gesOrderPayMoneyDAO;
	}

	/**
     * 查询记录
     */
	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> queryMultiplePaymentRecord(Long orderId) {
		//查询订单
		GesOrder order=getGesOrderDAO().queryOrderByOrderId(orderId);
		//查询支付记录
        MultiplePayment mp=new MultiplePayment();
        mp.setGesOrder(order);
        //目前只有10%阶段有这个功能
        mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
        Map<String, Object> map=getMultiplePaymentDAO().queryPaymentRecord(mp);
        //10%应付金额
        BigDecimal money=new BigDecimal(order.getTotalAmount()).divide(new BigDecimal(PaymentConstant.THOUSAND),2,RoundingMode.DOWN);
        log.info("应付的总金额为（10%）："+money);
        map.put("total", money);
        //已付金额
        long payedMoney=(long) map.get("payedMoney");
        log.info("已付的金额："+payedMoney);
        //待付
        BigDecimal waitPay=money.subtract(new BigDecimal(payedMoney).divide(new BigDecimal(100),2,RoundingMode.DOWN));
        log.info("待付的金额为:"+waitPay);
        map.put("waitPay",waitPay);
        return map;
	}

	 /**
     * 添加记录
     */
	@Override
	@Transactional
	public JsonResult<Boolean> addMultiplePayment(MultiplePaymentVO multiplePayment, int type) {
		JsonResult<Boolean> jsonResult=new JsonResult<Boolean>();
		if(multiplePayment.getOrderId()==null){
            jsonResult.setMsg("订单id不能为空");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        //根据订单id查询订单信息
		GesOrder order=getGesOrderDAO().queryOrderByOrderId(multiplePayment.getOrderId());
		//需要支付的总金额
        long totalAmount=0l;
        //通过订单状态判断支付的阶段
        if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus()) || PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())){//10%
            multiplePayment.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            totalAmount=order.getTotalAmount()/10;
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            multiplePayment.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount()/10)*9;
        }else if(PaymentConstant.STATUS_THIRTY_FIRST.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_SECOND.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_THIRD.equals(order.getOrderStatus())){
            multiplePayment.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
            totalAmount=(order.getTotalAmount()/10)*9;
        }else{
            jsonResult.setMsg("该阶段不支持添加支付记录！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        multiplePayment.setOrderStatus(order.getOrderStatus());
        multiplePayment.setInvalid(false);
        if(type==SOURCE_TYPE){
            multiplePayment.setPayStatus(PaymentConstant.PAY_STATUS_ZERO);
            multiplePayment.setPayWay(PaymentConstant.PayWay.WAIT.ordinal());
            multiplePayment.setRecordSource(PaymentConstant.RECORD_SOURCE_ZERO);
            //判断是否已经有未支付的记录
            List<MultiplePayment> list=getMultiplePaymentDAO().queryRecordNoPay(multiplePayment);
            if(list.size()>0){
                log.info("已有未支付记录，无法再次添加记录！");
                jsonResult.setMsg("已有未支付记录，无法再次添加记录!");
                jsonResult.setResult(false);
                jsonResult.setRet("1");
                return jsonResult;
            }
        }else{
            multiplePayment.setPayStatus(PaymentConstant.PAY_STATUS_THREE);
            multiplePayment.setPayWay(PaymentConstant.PayWay.OFFLINE.ordinal());
            multiplePayment.setPaySuccessTime(new Timestamp(System.currentTimeMillis()));
            multiplePayment.setRecordSource(PaymentConstant.RECORD_SOURCE_ZERO);
        }
        if(multiplePayment.getPayMoney()==null){
            log.info("金额为："+multiplePayment.getPayMoney());
            jsonResult.setMsg("支付金额不能为空");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        //判断需要的支付金额是否符合要求 查询出已付的金额+要支付的金额<=总金额
        MultiplePayment mpay=new MultiplePayment();
        mpay.setGesOrder(order);
        mpay.setPeriod(multiplePayment.getPeriod());
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mpay);
        //当前要支付的金额
        long payMoney=multiplePayment.getPayMoney().multiply(new BigDecimal(100)).longValue();
        //
        log.info("当前已经支付的金额为："+payedMoney+",当前要支付的金额为:"+payMoney+",需要支付的总金额为:"+totalAmount);
        if((payedMoney+payMoney)>totalAmount){
            jsonResult.setMsg("支付金额太大，已超出需要支付的总金额！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        multiplePayment.setMoney(payMoney);
        log.info("设置的金额为："+multiplePayment.getMoney()+"分！");
        //VO转实体
        MultiplePayment mp=new MultiplePayment();
        mp.setMoney(multiplePayment.getMoney());
        mp.setGesOrder(order);
        mp.setOrderStatus(order.getOrderStatus());
        mp.setPeriod(multiplePayment.getPeriod());
        mp.setPayWay(multiplePayment.getPayWay());
        mp.setPayStatus(multiplePayment.getPayStatus());
        mp.setPaySuccessTime(multiplePayment.getPaySuccessTime());
        mp.setSystemUpdateTime(multiplePayment.getSystemUpdateTime());
        mp.setRecordSource(multiplePayment.getRecordSource());
        mp.setUser(multiplePayment.getUser());
        getMultiplePaymentDAO().addMultiplePayment(mp);
        if(mp.getId()>0){
            //更新订单支付总额统计表中的金额
            saveOrUpdateOrderPay(type, mp);
            //如果是财务添加记录信息，判断目前已支付的金额是否已经等于总金额，若等于，修改订单状态
            updateOrderStatus(type, mp, totalAmount,order);
            
            jsonResult.setMsg("添加成功！");
            jsonResult.setResult(true);
            jsonResult.setRet("0");
            return jsonResult;
        }else{
            jsonResult.setMsg("添加失败！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
		
	}
	
	/**
     * 财务 添加或者更新订单的金额统计记录
     * @param type
     * @param mp
     */
    public void saveOrUpdateOrderPay(int type,MultiplePayment mp){
        if(type==SOURCE_TYPE){
            log.info("不需要添加记录！");
            return ;
        }else{
            GesOrderPayMoney orderPay=new GesOrderPayMoney();
            orderPay.setGesOrder(mp.getGesOrder());
            if(mp.getPeriod()==PaymentConstant.PAY_PERIOD_TEN){
                orderPay.setEarnestPay(mp.getMoney());
                orderPay.setEarnestPayNum(1);
            }else if(mp.getPeriod()==PaymentConstant.PAY_PERIOD_NINETY){
                orderPay.setDepositPay(mp.getMoney());
                orderPay.setDepositPayNum(1);
            }else if(mp.getPeriod()==PaymentConstant.PAY_PERIOD_THIRTY){
                orderPay.setBatchPay(mp.getMoney());
                orderPay.setBatchPayNum(1);
            }
            orderPay.setInvalid(false);
            //更新记录
            int flag=getGesOrderPayMoneyDAO().updateOrderPay(orderPay);
            log.info("更新订单金额统计记录状态："+flag);
            if(flag<1){
                //flag为false说明没有该条记录，需要插入一条数据
                getGesOrderPayMoneyDAO().addGesOrderPayMoney(orderPay);
                log.info("添加订单金额统计记录的id："+orderPay.getId());
                if(orderPay.getId()>0){//插入成功
                    return ;
                }else{
                    throw new GenericException(new ErrorMessage("插入失败！"));
                }
            }
        }
    }
    
    /**
     * 线下支付完成后 修改订单状态
     * @param type
     * @param mp
     */
    public void updateOrderStatus(int type,MultiplePayment mp,long totalAmount,GesOrder order){
        if(type==SOURCE_TYPE){
            return ;
        }else{
            //判断线下已付的金额是否等于总金额
            long payedMoneyOff=getMultiplePaymentDAO().queryCompletePay(mp);
            if(payedMoneyOff==totalAmount){
                //更新订单状态
            	if(order.getOrderStatus().equals(OrderStatus.booked.name())){
            		order.setOrderStatus(OrderStatus.booked.name());
            	}else if(order.getOrderStatus().equals(OrderStatus.prepaying.name())){
            		order.setOrderStatus(OrderStatus.starting_AZZC.name());
            	}else if(order.getOrderStatus().equals(OrderStatus.arriving_earnest.name())){
            		order.setOrderStatus(OrderStatus.starting_AZZC.name());
            	}else if(order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())){
            		order.setOrderStatus(OrderStatus.arriving_credit.name());
            	}else if(order.getOrderStatus().equals(OrderStatus.arriving_credit.name())){
            		order.setOrderStatus(OrderStatus.paying_AZZC.name());
            	}
            	getGesOrderDAO().updateOrderStatusBySystem(order);
            }else{
              //判断线上线下已支付的金额是否等于总金额
                long payedMoneyOn=getMultiplePaymentDAO().queryPayedMoney(mp);
                if(payedMoneyOn==totalAmount){
                	if(order.getOrderStatus().equals(OrderStatus.booked.name())){
                		order.setOrderStatus(OrderStatus.booked.name());
                	}else if(order.getOrderStatus().equals(OrderStatus.prepaying.name())){
                		order.setOrderStatus(OrderStatus.arriving_earnest.name());
                	}else if(order.getOrderStatus().equals(OrderStatus.arriving_earnest.name())){
                		order.setOrderStatus(OrderStatus.starting_AZZC.name());
                	}else if(order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())){
                		order.setOrderStatus(OrderStatus.arriving_credit.name());
                	}else if(order.getOrderStatus().equals(OrderStatus.arriving_credit.name())){
                		order.setOrderStatus(OrderStatus.paying_AZZC.name());
                	}
                    int num=getGesOrderDAO().updateOrderStatusBySystem(order);
                    log.info("更新订单状态的结果"+num);
                }
            }
        }
    }

    /**
	 * 订单支付记录查询及余额查询(官网)
	 * @param orderId
	 * @param userId
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> queryOrderPaymentRecord(Long orderId, Long userId) {
		//根据订单id查询订单信息
		GesOrder order=getGesOrderDAO().queryOrderByOrderId(orderId);
		Map<String, Object> map=new HashMap<String, Object>();
		if(order==null){
			map.put("warn", "不用试了，没有该订单！");
            return map;
		}
        if(order.getBuyer().getId().longValue()!=userId.longValue()){
            map.put("warn", "不用试了，小心有陷阱！");
            return map;
        }
        //根据订单id，查询该订单的所有支付记录
        List<MultiplePaymentVO> list=getMultiplePaymentDAO().queryPersonalPaymentRecord(orderId);
      //因为记录的条数不多，在这里通过循环的方式处理数据
        if(list.size()>0){
            long balance=resultDealAndBalanceCalc(list,map);
            log.error("计算的余额为："+balance);
            map.put("balance", new BigDecimal(balance).divide(new BigDecimal(100),2,BigDecimal.ROUND_UP)+"");
        }else{
            map.put("balance", 0);
            map.put("isShow", false);
        }
        map.put("list", list);
		
		return map;
	}
	
	/**
     * 查询结果处理以及余额计算
     * @param list
     */
    protected long resultDealAndBalanceCalc(List<MultiplePaymentVO> list,Map<String, Object> map) {
        //90%多次支付之和 30%多次支付之和
        long creditMoney=0l;//支付的90%金额之和
        long confirmMoney=0l;//支付30%金额之和
        boolean isShow=false;
        for(MultiplePaymentVO mp:list){
            if(mp.getPayWay()==PaymentConstant.PayWay.POS.ordinal()){
                mp.setPayWayName(PaymentConstant.PayWay.POS.getText());
            }else if(mp.getPayWay()==PaymentConstant.PayWay.EBANK.ordinal()){
                mp.setPayWayName(PaymentConstant.PayWay.EBANK.getText());
            }else if(mp.getPayWay()==PaymentConstant.PayWay.OFFLINE.ordinal()){
                mp.setPayWayName(PaymentConstant.PayWay.OFFLINE.getText());
            }else if(mp.getPayWay()==PaymentConstant.PayWay.GJB.ordinal()){
                mp.setPayWayName(PaymentConstant.PayWay.GJB.getText());
            }
            if(mp.getPeriod().intValue()==PaymentConstant.PAY_PERIOD_NINETY.intValue()){
                creditMoney=creditMoney+mp.getMoney();
                log.error("支付阶段："+mp.getPeriod()+",creditMoney:"+creditMoney);
                isShow=true;
            }
            if(mp.getPeriod().intValue()==PaymentConstant.PAY_PERIOD_THIRTY.intValue()){
                confirmMoney=confirmMoney+mp.getMoney();
                log.error("支付阶段："+mp.getPeriod()+",confirmMoney:"+confirmMoney);
            }
            mp.setHavePayedMoney(new BigDecimal(mp.getMoney()).divide(new BigDecimal(100), 2,BigDecimal.ROUND_UP)+"");
        }
        map.put("isShow", isShow);
        return (creditMoney-confirmMoney);
    }

    /**
     * 查询需要确认支付的金额，仅限30%确认支付调用，后期和10%、90%支付合并到一个方法中
     * @param order
     */
	@Override
	@Transactional
	public Long queryConfirmPayMoneyForThirty(GesOrderVO order) {
		//查询是否有配置的支付金额,有的话，直接支付配置的金额
        MultiplePayment mp=new MultiplePayment();
        GesOrder gesOrder=new GesOrder();
        gesOrder.setId(order.getId());
        mp.setGesOrder(gesOrder);
        mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
        mp.setPayWay(PaymentConstant.PayWay.GJB.ordinal());
        //查询已支付的金额
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        log.error("已经支付的金额为："+payedMoney);
        //查询是否有未支付的记录
        MultiplePayment result=getMultiplePaymentDAO().queryLatestRecordNoPay(mp);
        //查询90%支付的金额
        MultiplePayment tempMp=new MultiplePayment();
        tempMp.setGesOrder(gesOrder);
        tempMp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
        long totalAmount=getMultiplePaymentDAO().queryCompletePay(tempMp);
//        GesOrderPayMoney gesOrderPayMoney=getGesOrderPayMoneyDAO().queryOrderPayMoneyByOrderId(order.getId());
//        if(gesOrderPayMoney==null){
//        	log.info("未查找到该订单的支付信息，订单id为："+order.getId());
//        	return 0l;
//        }
//        long totalAmount=gesOrderPayMoney.getDepositPay();
        log.error("90%支付的总金额为:"+totalAmount);
        if(result!=null){
            log.error("要支付的金额为："+result.getMoney());
            if((payedMoney+result.getMoney())>totalAmount){
                log.error("支付记录中设置的要支付的金额超出要支付的总金额，请修改后，再支付！");
                return 0l;
            }else{
                log.error("获取成功！");
                return result.getMoney();
            }
        }else{
            long payMoney=0l;
            //判断是否是阳台包，是阳台包，一次确认支付（支付金额为90%支付的金额）
            //最后一次确认支付，支付余额
            if(order.getGoodsType().longValue()==PaymentConstant.GOODS_TYPE_BALCONY.longValue() || order.getOrderStatus().equals(PaymentConstant.STATUS_THIRTY_THIRD)){
                payMoney=totalAmount-payedMoney;
            }else{
                //判断90%支付的金额与订单总价的90%是否相等，相等，每次确认支付总额的30%，不相等，90%支付的金额的30%，
                long orderCreditTotal=(order.getTotalAmount().longValue()/10)*9;
                log.error("订单的总金额的90%为："+orderCreditTotal);
                if(totalAmount==orderCreditTotal){
                    //计算总价的30%
                    payMoney=(order.getTotalAmount().longValue()/10)*3;
                    log.error("总价的30%："+payMoney);
                }else{
                    //计算90%支付金额的30%
                    payMoney=(totalAmount*3)/10;
                    log.error("0%支付金额的30%:"+payMoney);
                }
                
            }
            //说明是自动计算的金额，需要添加一条记录到记录表中
            assemblePayRecordAndSave(order, mp,payMoney);
            
            return payMoney;
        }
	}
    
	/**
     * 组装多次支付记录，并保存
     * @param order
     * @param mp
     * @param payMoney
     */
    protected void assemblePayRecordAndSave(GesOrderVO order, MultiplePayment mp,long payMoney) {
        mp.setOrderStatus(order.getOrderStatus());
        mp.setMoney(payMoney);
        mp.setPayStatus(PaymentConstant.PAY_STATUS_ZERO);
        mp.setInvalid(false);
//        //此处不能设置官网的登录用户名，跟ges用户不统一
//        User tempUser=new User();
//        mp.setUser(tempUser);
        mp.setRecordSource(PaymentConstant.RECORD_SOURCE_ONE);
        mp.setSystemUpdateTime(new Timestamp(System.currentTimeMillis()));
        getMultiplePaymentDAO().addMultiplePayment(mp);
    }

    /**
	 * 查询需要支付的金额 web 本次只是copy，可以和ges中的合并，统一返回值
	 */
	@Override
	@Transactional
	public Long queryNeedPayMoney(GesOrderVO order, Long userId) {
		//需要支付的总金额
        long totalAmount=0l;
        //
        MultiplePayment mp=new MultiplePayment();
        GesOrder gesOrder=new GesOrder();
        gesOrder.setId(order.getId());
        mp.setGesOrder(gesOrder);
        //根据订单状态设置支付的阶段
        if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus())){//10%
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            totalAmount=order.getTotalAmount().longValue()/10;
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else if(PaymentConstant.STATUS_THIRTY_FIRST.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_SECOND.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_THIRD.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else{
            return 0l;
        }
        //查询已支付的金额
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        log.error("已经支付的金额为："+payedMoney);
        //查询未支付的记录
        MultiplePayment result=getMultiplePaymentDAO().queryLatestRecordNoPay(mp);
        if(result!=null){
            log.error("要支付的金额为："+result.getMoney());
            if((payedMoney+result.getMoney())>totalAmount){
                log.error("支付记录中设置的要支付的金额超出要支付的总金额，请修改后，再支付！");
                return 0l;
            }else{
                log.error("获取成功！");
                return result.getMoney();
            }
        }else{
            //要支付的金额
            long payMoney=totalAmount-payedMoney;
            log.error("需要支付的总额为："+totalAmount+",已支付的金额为："+payedMoney+",需要支付的金额为："+payMoney);
            if(payMoney<=0){
                log.error("需要支付的金额已支付完成，无需再支付！");
                return 0l;
            }else{
                //说明是自动计算的金额，需要添加一条记录到记录表中
                mp.setOrderStatus(order.getOrderStatus());
                mp.setMoney(payMoney);
                mp.setPayWay(PaymentConstant.PayWay.WAIT.ordinal());
                mp.setPayStatus(PaymentConstant.PAY_STATUS_ZERO);
                mp.setInvalid(false);
                //此处不能设置官网的登录用户名，跟ges用户不统一
//                User tempUser=new User();
//              mp.setUser(tempUser);
                log.error("当前的登录用户为："+userId);
                mp.setRecordSource(PaymentConstant.RECORD_SOURCE_ONE);
                mp.setSystemUpdateTime(new Timestamp(System.currentTimeMillis()));
                getMultiplePaymentDAO().addMultiplePayment(mp);
                log.error("获取成功！");
                return payMoney;
            }
        }
	}

	/**
	 * 更新多次支付记录的支付状态和支付方式以及支付的金额字段
	 */
	@Override
	public void updateMultiplePaymentStatus(GesOrderVO order,GesPaymentRecord paymentRecord) {
		MultiplePayment mp=new MultiplePayment();
	    GesOrderPayMoney orderPay=new GesOrderPayMoney();
	    GesOrder gesOrder=new GesOrder();
	    gesOrder.setId(order.getId());
	    mp.setGesOrder(gesOrder);
	    mp.setMoney(paymentRecord.getMoney().longValue());
	    mp.setSerialPayNo(paymentRecord.getCode());
	    mp.setPayStatus(PaymentConstant.PAY_STATUS_TWO);
	    mp.setPayWay(PaymentConstant.PayWay.EBANK.ordinal());
	    //阶段
	    if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus())){//10%
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            orderPay.setEarnestPay(mp.getMoney());
            orderPay.setEarnestPayNum(1);
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            orderPay.setDepositPay(mp.getMoney());
            orderPay.setDepositPayNum(1);
        }else{
            log.error("订单状态异常，请查看！"+order.getOrderStatus());
            return ;
        }
	    
	    int flag=getMultiplePaymentDAO().updateMultiplePay(mp);
	    log.error("更新支付的状态结果："+flag);
	    //支付金额
        orderPay.setGesOrder(gesOrder);
        orderPay.setInvalid(false);
	    int payFlag=getGesOrderPayMoneyDAO().updateOrderPay(orderPay);
        log.error("更新订单金额统计记录状态："+payFlag);
        if(payFlag<1){
            //flag为false说明没有该条记录，需要插入一条数据
            getGesOrderPayMoneyDAO().addGesOrderPayMoney(orderPay);
            log.info("添加订单金额统计记录id："+orderPay.getId());
        }
		
	}

	/**
	 * 判断已支付的金额是否等于需要支付的金额，如果是，则更新订单的状态和支付记录状态 否则只更新支付记录为已收到银行反馈信息
	 * @param order
	 * @param paymentRecord
	 */
	@Override
	public boolean updateOrderStatusWeb(GesOrderVO order,GesPaymentRecord paymentRecord, String status) {
		long totalAmount=0l;
	    MultiplePayment mp=new MultiplePayment();
	    log.info("更新订单状态："+order.getOrderStatus());
	    if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus())){
	        mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
	        totalAmount=order.getTotalAmount().longValue()/10;
	    }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
	        mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }
	    GesOrder gesOrder=new GesOrder();
	    gesOrder.setId(order.getId());
	    mp.setGesOrder(gesOrder);
	    //判断已付的金额是否等于总金额
	    log.info("判断已付的金额是否等于总金额!");
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        log.error("支付阶段为："+mp.getPeriod()+",已支付金额为："+payedMoney+",要支付的金额为："+totalAmount);
        if(payedMoney==totalAmount){
        	GesOrder orderTemp = new GesOrder();
        	orderTemp.setId(order.getId());
        	orderTemp.setOrderStatus(status);
        	int num=getGesOrderDAO().updateOrderStatusBySystem(orderTemp);
        	log.error("更新状态个数："+num);
        }
	    return true;
	}

	/**
     * 更新多次支付记录表中的状态，以后和updateMultiplePaymentStatus合并
     * @return
     */
	@Override
	public int updateRecordStatusAndOrderStatus(GesOrderVO order,GesPaymentRecord paymentRecord) {
		MultiplePayment mp=new MultiplePayment();
		GesOrder gesOrder=new GesOrder();
	    gesOrder.setId(order.getId());
        mp.setGesOrder(gesOrder);
        mp.setSerialPayNo(paymentRecord.getCode());
        mp.setPayStatus(PaymentConstant.PAY_STATUS_THREE);
        mp.setPayWay(PaymentConstant.PayWay.GJB.ordinal());
        mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
        int flag=getMultiplePaymentDAO().updateMultiplePay(mp);
        log.error("更新支付的状态结果："+flag);
        return flag;
	}

	/**
	 * 获取需要支付的金额，可以和web合并，统一返回值，本次只是copy
	 */
	@Override
	@Transactional
	public JsonResult<BigDecimal> queryNeedPayMoneyForGes(Long orderId,Long userId) {
		JsonResult<BigDecimal> jsonResult=new JsonResult<BigDecimal>();
        if(orderId==null){
            jsonResult.setMsg("程序错误！");
            jsonResult.setResult(new BigDecimal(0));
            jsonResult.setRet("1");
            return jsonResult;
        }
        //根据订单id查询订单信息
        GesOrder order =getGesOrderDAO().queryOrderByOrderId(orderId);
        //需要支付的总金额
        long totalAmount=0l;
        //
        MultiplePayment mp=new MultiplePayment();
        mp.setGesOrder(order);
        //根据订单状态设置支付的阶段
        if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus()) || PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())){//10%
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            totalAmount=order.getTotalAmount().longValue()/10;
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else if(PaymentConstant.STATUS_THIRTY_FIRST.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_SECOND.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_THIRD.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else{
            jsonResult.setMsg("该阶段没有权限");
            jsonResult.setResult(new BigDecimal(0));
            jsonResult.setRet("1");
            return jsonResult;
        }
        //查询已支付的金额
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        log.info("已经支付的金额为："+payedMoney);
        //查询未支付的记录
        MultiplePayment result=getMultiplePaymentDAO().queryLatestRecordNoPay(mp);
        if(result!=null){
            log.info("要支付的金额为："+result.getMoney());
            if((payedMoney+result.getMoney())>totalAmount){
                jsonResult.setMsg("支付金额请勿大于待付金额，请修改后，再支付！");
                jsonResult.setResult(new BigDecimal(0));
                jsonResult.setRet("1");
                return jsonResult;
            }else{
                jsonResult.setMsg("获取成功！");
                jsonResult.setResult(new BigDecimal(result.getMoney()).divide(new BigDecimal(100)));
                jsonResult.setRet("0");
                return jsonResult;
            }
        }else{
            //要支付的金额
            long payMoney=totalAmount-payedMoney;
            log.info("需要支付的总额为："+totalAmount+",已支付的金额为："+payedMoney+",需要支付的金额为："+payMoney);
            if(payMoney<=0){
                jsonResult.setMsg("需要支付的金额已支付完成，无需再支付！");
                jsonResult.setResult(new BigDecimal(0));
                jsonResult.setRet("1");
                return jsonResult;
            }else{
                //说明是自动计算的金额，需要添加一条记录到记录表中
                mp.setOrderStatus(order.getOrderStatus());
                mp.setMoney(payMoney);
                mp.setPayWay(PaymentConstant.PayWay.WAIT.ordinal());
                mp.setPayStatus(PaymentConstant.PAY_STATUS_ZERO);
                mp.setInvalid(false);
                
                User tempUser=new User();
                tempUser.setId(userId);
                mp.setUser(tempUser);
                log.error("当前的登录用户为："+userId);
                mp.setRecordSource(PaymentConstant.RECORD_SOURCE_ONE);
                mp.setSystemUpdateTime(new Timestamp(System.currentTimeMillis()));
                getMultiplePaymentDAO().addMultiplePayment(mp);
                jsonResult.setMsg("获取成功！");
                jsonResult.setResult(new BigDecimal(payMoney).divide(new BigDecimal(100)));
                jsonResult.setRet("0");
                return jsonResult;
            }
        }
	}

	@Override
	@Transactional
	public JsonResult<Boolean> updateMultiplePaymentRecord(MultiplePaymentVO multiplePayment) {
		MultiplePayment mp=new MultiplePayment();
		JsonResult<Boolean> jsonResult=new JsonResult<Boolean>();
        if(multiplePayment.getId()==null||multiplePayment.getPayMoney()==null||multiplePayment.getOrderId()==null){
            jsonResult.setMsg("程序错误，请重试！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        //设置修改人
        mp.setUser(multiplePayment.getUser());
        mp.setId(multiplePayment.getId());
        //根据订单id查询订单信息
        GesOrder order=getGesOrderDAO().queryOrderByOrderId(multiplePayment.getOrderId());
        mp.setGesOrder(order);
        //需要支付的总金额
        long totalAmount=0l;
        //通过订单状态判断支付的阶段
        if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus())|| PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())){//10%
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            totalAmount=order.getTotalAmount().longValue()/10;
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else if(PaymentConstant.STATUS_THIRTY_FIRST.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_SECOND.equals(order.getOrderStatus())||
                PaymentConstant.STATUS_THIRTY_THIRD.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_THIRTY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else{
            jsonResult.setMsg("该阶段不支持编辑支付记录！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        //判断需要的支付金额是否符合要求 查询出已付的金额+要支付的金额<=总金额
        long payedMoney=getMultiplePaymentDAO().queryPayedMoney(mp);
        //当前要支付的金额
        long payMoney=multiplePayment.getPayMoney().multiply(new BigDecimal(100)).longValue();
        log.info("当前已经支付的金额为："+payedMoney+",当前要支付的金额为:"+payMoney+",需要支付的总金额为:"+totalAmount);
        if((payedMoney+payMoney)>totalAmount){
            jsonResult.setMsg("支付金额太大，已超出需要支付的总金额！请重新设置！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
        //设置修改的支付金额
        log.info("修改后的支付金额为："+multiplePayment.getPayMoney());
        mp.setMoney(payMoney);
        mp.setRecordSource(PaymentConstant.RECORD_SOURCE_ZERO);
        boolean flag=getMultiplePaymentDAO().updateRecordById(mp);
        if(flag){
            jsonResult.setMsg("修改成功！");
            jsonResult.setResult(true);
            jsonResult.setRet("0");
            return jsonResult;
        }else{
            jsonResult.setMsg("修改失败！");
            jsonResult.setResult(false);
            jsonResult.setRet("1");
            return jsonResult;
        }
	}
    
	/**
     * 核对合同时，根据订单支付的金额，修改订单状态(后期和线下支付的判断合并)
     * @param orderId
     */
    public void checkContractUpdateStatus(Long userId,Long orderId,String phone){
        //查询订单信息
        GesOrder order=getGesOrderDAO().queryOrderByOrderId(orderId);
        long totalAmount=order.getTotalAmount().longValue()/10;
        //查询已支付的金额 10%
        MultiplePayment mp=new MultiplePayment();
        mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
        mp.setGesOrder(order);
        //获取已到账的金额
        long payedMoneyOff=getMultiplePaymentDAO().queryCompletePay(mp);
        GesOrder tempOrder=new GesOrder();
        User tempUser=new User();
        tempUser.setId(userId);
        tempOrder.setUser(tempUser);
        tempOrder.setId(orderId);
        tempOrder.setMobile(phone);
        if(payedMoneyOff==totalAmount){
            tempOrder.setOrderStatus(OrderStatus.starting_AZZC.name());
        }else{
            //判断已支付的金额是否等于总金额
            long payedMoneyOn=getMultiplePaymentDAO().queryPayedMoney(mp);
            if(payedMoneyOn==totalAmount){
                tempOrder.setOrderStatus(OrderStatus.arriving_earnest.name());
            }else{
                tempOrder.setOrderStatus(OrderStatus.prepaying.name());
            }
        }
        //更新订单状态
        boolean flag=getGesOrderDAO().updateOrderStatusByOrderId(tempOrder);
        log.info("更新订单状态的结果"+flag);
    }
    

}
