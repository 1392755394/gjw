package com.gjw.company.dao.impl.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IDeptDAO;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;
import com.gjw.utils.StringUtil;

/**
 * 部门dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月9日
 * 
 */
@Component("deptDAOHibernateImpl")
public class DeptDAOHibernateImpl extends AbstractDAOHibernateImpl implements IDeptDAO {

    @Override
    protected Class<?> getEntityClass() {
        return Dept.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Dept> listDeptByParentId(long parentId) {

        String hql = "from Dept d where d.parent.id = ? and d.invalid = false order by d.orderTag asc";

        return (List<Dept>) super.getHibernateTemplate().find(hql, parentId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Dept> listDepts() {

        String hql = "from Dept d where d.invalid = false order by d.orderTag asc";

        return (List<Dept>) super.getHibernateTemplate().find(hql);
    }

    @Override
    public long create(Dept dept) {

        super.add(dept);
        return dept.getId();
    }

    @Override
    public boolean update(Dept dept) {

        Dept old = (Dept) super.get(dept.getId());
        StringUtil.copyPropertiesAllowEmpty(dept, old);
        return super.update(old) == 1;

    }

    @Override
    public boolean delete(Dept dept) {

        return super.remove(dept.getId()) == 1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Dept> listDeptForSynch() {

        String hql = " from Dept where invalid=0 and propertyType not in(1130102,1130105) or propertyType IS NULL ";

        return (List<Dept>) super.getHibernateTemplate().find(hql);
    }

    @Override
    public void updateDeptForSynch(Dept dept) {
        String hql = " update  Dept set  propertyType.id=? where id=?";
        List<Object> list = new ArrayList<Object>();
        list.add(dept.getPropertyType().getId());
        list.add(dept.getId());
        super.updateByParam(hql, list);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<DeptUser> listDeptUserForSynch() {
        String hql = " from  DeptUser where invalid=0 and ( synchType.id not in (1130102,1130105) or synchType.id is null) ";
        return (List<DeptUser>) super.getHibernateTemplate().find(hql);
    }

    @Override
    public void updateDeptUserForSynch(DeptUser dept) {
        String hql = " update  DeptUser set  synchType.id=? where id=?";
        List<Object> list = new ArrayList<Object>();
        list.add(dept.getSynchType().getId());
        list.add(dept.getId());
        super.updateByParam(hql, list);

    }

}
