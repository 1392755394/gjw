package com.gjw.company.dao.app;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.app.WebContrastDetail;

public interface IWebContrastDetailDAO extends IDAO{
    public WebContrastDetail get(Long id);

    public List<WebContrastDetail> getList(WebContrastDetail model);
    
    public boolean addWebContrastDetail(WebContrastDetail model);
    
    public void updateWebContrastDetail(WebContrastDetail model);
}
