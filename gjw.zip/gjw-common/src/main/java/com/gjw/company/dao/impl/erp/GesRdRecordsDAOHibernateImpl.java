package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesRdRecordsDAO;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.utils.StringUtil;
import com.gjw.vo.RdRecordsVO;

/**
 * 出入库单明细实体
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月18日 上午11:00:15
 * 
 */
@Component("gesRdRecordsDAOHibernateImpl")
public class GesRdRecordsDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesRdRecordsDAO {

    @Override
    protected Class getEntityClass() {
        return GesRdRecords.class;
    }

    @Override
    public void create(GesRdRecords rdRecords) {
        super.saveResultBoolean(rdRecords);

    }

    @Override
    public Long countByCode(GesRdRecords rCodes) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords where invalid=0 ");
        if (StringUtil.notEmpty(rCodes.getRecordCode())) {
            hql.append(" and recordCode =?");
            list.add(rCodes.getRecordCode());
        }
        return super.findByPageCallBackCount(hql.toString(), list);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesRdRecords> pageByRdRecord(RdRecordsVO rdRecords) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords where invalid=0 ");
        // if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
        hql.append(" and recordCode =?");
        list.add(rdRecords.getRecordCode());
        // }
        if (rdRecords.getRoomId() != -1) {
            hql.append(" and room.id =?");
            list.add(rdRecords.getRoomId());
        }
        if (StringUtil.notEmpty(rdRecords.getCode())) {
            hql.append(" and matter.code=?");
            list.add(rdRecords.getCode());
        }
        if (StringUtil.notEmpty(rdRecords.getName())) {
            hql.append(" and matter.name=?");
            list.add(rdRecords.getName());
        }
        if (StringUtil.notEmpty(rdRecords.getBrandName())) {
            hql.append(" and matter.brand.name=?");
            list.add(rdRecords.getBrandName());
        }
        if (StringUtil.notEmpty(rdRecords.getModel())) {
            hql.append(" and matter.model=?");
            list.add(rdRecords.getModel());
        }
        return (List<GesRdRecords>) super.findByPageCallBack(hql.toString(), "", list, rdRecords, null);
    }

    @Override
    public Long countByRdRecords(RdRecordsVO rdRecords) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords where invalid=0 ");
        if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
            hql.append(" and recordCode =?");
            list.add(rdRecords.getRecordCode());
        }
        if (rdRecords.getRoomId() != -1) {
            hql.append(" and room.id =?");
            list.add(rdRecords.getRoomId());
        }
        if (StringUtil.notEmpty(rdRecords.getCode())) {
            hql.append(" and matter.code=?");
            list.add(rdRecords.getCode());
        }
        if (StringUtil.notEmpty(rdRecords.getName())) {
            hql.append(" and matter.name=?");
            list.add(rdRecords.getName());
        }
        if (StringUtil.notEmpty(rdRecords.getBrandName())) {
            hql.append(" and matter.brand.name=?");
            list.add(rdRecords.getBrandName());
        }
        if (StringUtil.notEmpty(rdRecords.getModel())) {
            hql.append(" and matter.model=?");
            list.add(rdRecords.getModel());
        }
        return super.findByPageCallBackCount(hql.toString(), list);
    }

    @Override
    public List<GesRdRecords> listArrivalByRdRecords(RdRecordsVO rdRecords) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords rds left join fetch rds.matter m where rds.invalid=0 and rds.recordCode=? and  rds.stockIn != rds.quantity "
                + "and m.id not in (select  matter.id as id from GesRdRecords where  recordCode=? and ( room.id=rds.room.id OR room.id IS NULL ) )");
        // if (StringUtil.notEmpty(rdRecords.getStockInCode())) {
        // hql.append(" and rds.recordCode =?");
        list.add(rdRecords.getRecordCode());
        list.add(rdRecords.getStockInCode());
        // }
        rdRecords.setStart(null);
        rdRecords.setPageSize(null);
        return (List<GesRdRecords>) super.findByPageCallBack(hql.toString(), "", list, rdRecords, null);
    }

    /**
     * 删除关联产品
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<GesRdRecords> pageArrivalByRdRecords(RdRecordsVO rdRecords, List<GesRdRecords> list) {
        Query query = arrivalByRdRecordsHqlAndList(rdRecords, list, false);
        query.setFirstResult(rdRecords.getStart());
        query.setMaxResults(rdRecords.getPageSize());
        return query.list();
        // Session session =
        // super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        // Map<String, Object> map =
        // this.arrivalByRdRecordsHqlAndList(rdRecords, list);
        // Query query = session.createQuery(map.get("hql").toString());
        // List<Long> listId = new ArrayList<Long>();
        // if (list.size() > 0) {
        // for (GesRdRecords rds : list) {
        // listId.add(rds.getId());
        // }
        // query.setParameterList("ids", listId);
        // } else {
        // listId.add(-1l);
        // query.setParameterList("ids", listId);
        // }
        // if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
        // query.setParameter("recordCode", rdRecords.getRecordCode());
        // }
        // if (rdRecords.getRoomId() != -1) {
        // query.setParameter("roomId", rdRecords.getRoomId());
        // }
        //
        // if (StringUtil.notEmpty(rdRecords.getCode())) {
        // query.setParameter("code", rdRecords.getCode());
        // }
        // if (StringUtil.notEmpty(rdRecords.getName())) {
        // query.setParameter("matterName", rdRecords.getName());
        // }
        // if (StringUtil.notEmpty(rdRecords.getBrandName())) {
        // query.setParameter("brandName", rdRecords.getBrandName());
        // }
        // if (StringUtil.notEmpty(rdRecords.getModel())) {
        // query.setParameter("model", rdRecords.getModel());
        // }
        // query.setFirstResult(rdRecords.getStart());
        // query.setMaxResults(rdRecords.getPageSize());
        // // return query.list();
        // return (List<GesRdRecords>)
        // super.findByPageCallBack(map.get("hql").toString(), "",
        // (List<Object>) map.get("list"), new GesRdRecords(), null);
    }

    /**
     * 删除关联产品分页查询总数
     */
    @SuppressWarnings("unchecked")
    @Override
    public Long countArrivalByRecords(RdRecordsVO rdRecords, List<GesRdRecords> list) {
        Query query = arrivalByRdRecordsHqlAndList(rdRecords, list, true);
        return (Long) query.uniqueResult();
        // Map<String, Object> map =
        // this.arrivalByRdRecordsHqlAndList(rdRecords, list);
        // Session session =
        // super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        //
        // Query query = session.createQuery(" select count(*)   " +
        // map.get("hql").toString());
        // List<Long> listId = new ArrayList<Long>();
        // if (list.size() > 0) {
        // for (GesRdRecords rds : list) {
        // listId.add(rds.getId());
        // }
        // query.setParameterList("ids", listId);
        // } else {
        // listId.add(-1l);
        // query.setParameterList("ids", listId);
        // }
        //
        // if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
        // query.setParameter("recordCode", rdRecords.getRecordCode());
        // }
        // if (rdRecords.getRoomId() != -1) {
        // query.setParameter("roomId", rdRecords.getRoomId());
        // }
        // if (StringUtil.notEmpty(rdRecords.getCode())) {
        // query.setParameter("code", rdRecords.getCode());
        // }
        // if (StringUtil.notEmpty(rdRecords.getName())) {
        // query.setParameter("matterName", rdRecords.getName());
        // }
        // if (StringUtil.notEmpty(rdRecords.getBrandName())) {
        // query.setParameter("brandName", rdRecords.getBrandName());
        // }
        // if (StringUtil.notEmpty(rdRecords.getModel())) {
        // query.setParameter("model", rdRecords.getModel());
        // }
        //
        // return (Long) query.uniqueResult();
    }

    /**
     * 删除关联产品HQL
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月23日 上午9:47:35
     */
    public Map<String, Object> arrivalByRdRecordsHqlAndList(RdRecordsVO rdRecords, List<GesRdRecords> ls) {
        // Session session =
        // super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Map<String, Object> map = new HashMap<String, Object>();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords rds where rds.invalid=0  ");

        // if (ls.size() > 0) {
        // List<Long> listId = new ArrayList<Long>();
        // for (GesRdRecords rds : ls) {
        // listId.add(rds.getId());
        // }
        hql.append(" and rds.id  in ( :ids)");
        // list.add(listId);
        // }
        if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
            hql.append(" and rds.recordCode=:recordCode");
            // list.add(rdRecords.getRecordCode());
        }
        if (StringUtil.notEmpty(rdRecords.getCode())) {
            hql.append(" and matter.code=:code");
            // list.add(rdRecords.getCode());
        }
        if (StringUtil.notEmpty(rdRecords.getName())) {
            hql.append(" and matter.name=:matterName");
            // list.add(rdRecords.getName());
        }
        if (StringUtil.notEmpty(rdRecords.getBrandName())) {
            hql.append(" and matter.brand.name=:brandName");
            // list.add(rdRecords.getBrandName());
        }
        if (StringUtil.notEmpty(rdRecords.getModel())) {
            hql.append(" and matter.model=:model");
            // list.add(rdRecords.getModel());
        }
        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }

    public Query arrivalByRdRecordsHqlAndList(RdRecordsVO rdRecords, List<GesRdRecords> ls, Boolean count) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append("  from GesRdRecords rds where rds.invalid=0  ");
        hql.append(" and rds.id  in ( :ids)");

        if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
            hql.append(" and rds.recordCode=:recordCode");
        }
        if (StringUtil.notEmpty(rdRecords.getCode())) {
            hql.append(" and matter.code=:code");
        }
        if (StringUtil.notEmpty(rdRecords.getName())) {
            hql.append(" and matter.name=:matterName");
        }
        if (StringUtil.notEmpty(rdRecords.getBrandName())) {
            hql.append(" and matter.brand.name=:brandName");
        }
        if (StringUtil.notEmpty(rdRecords.getModel())) {
            hql.append(" and matter.model=:model");
        }
        String hqlStr = "";
        if (count) {
            hqlStr = (" select count(*)   " + hql.toString());

        } else {
            hqlStr = hql.toString().toString();
        }
        Query query = session.createQuery(hqlStr);
        List<Long> listId = new ArrayList<Long>();
        if (ls.size() > 0) {
            for (GesRdRecords rds : ls) {
                listId.add(rds.getId());
            }
            query.setParameterList("ids", listId);
        } else {
            listId.add(-1l);
            query.setParameterList("ids", listId);
        }
        if (StringUtil.notEmpty(rdRecords.getRecordCode())) {
            query.setParameter("recordCode", rdRecords.getRecordCode());
        }
        if (rdRecords.getRoomId() != -1) {
            query.setParameter("roomId", rdRecords.getRoomId());
        }
        if (StringUtil.notEmpty(rdRecords.getCode())) {
            query.setParameter("code", rdRecords.getCode());
        }
        if (StringUtil.notEmpty(rdRecords.getName())) {
            query.setParameter("matterName", rdRecords.getName());
        }
        if (StringUtil.notEmpty(rdRecords.getBrandName())) {
            query.setParameter("brandName", rdRecords.getBrandName());
        }
        if (StringUtil.notEmpty(rdRecords.getModel())) {
            query.setParameter("model", rdRecords.getModel());
        }
        return query;
    }

    @Override
    public List<GesRdRecords> listGesRdRecord(GesRdRecord rdRecord) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesRdRecords where invalid=0 ");
        if (StringUtil.notEmpty(rdRecord.getRecordCode())) {
            hql.append(" and recordCode =?");
            list.add(rdRecord.getRecordCode());
        }
        return (List<GesRdRecords>) super.findByListCallBack(hql.toString(), null, list, null);
    }

    @Override
    public boolean updateAmountById(Long id, Long amount) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update   GesRdRecords  set quantity=? where id=? ");
        list.add(Double.parseDouble(amount.toString()));
        list.add(id);
        return super.updateByParam(hql.toString(), list);
    }

    /**
     * 更新已入库数量
     */
    @Override
    public void updateStockIn(GesRdRecords rdRecords) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update   GesRdRecords  set stockIn=IFNULL(stockIn,0)+? where recordCode=? and poDetail.id=? ");
        list.add(rdRecords.getQuantity());
        list.add(rdRecords.getRecordCode());
        list.add(rdRecords.getPoDetail().getId());
        super.updateByParam(hql.toString(), list);
    }
}
