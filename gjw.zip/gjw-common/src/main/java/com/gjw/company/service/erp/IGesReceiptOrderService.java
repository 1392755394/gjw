package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesReceiptOrder;
import com.gjw.vo.GesReceiptOrderVO;

/**
 * 收款单service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月30日 
 *
 */
public interface IGesReceiptOrderService extends IService {

    /**
     * 查询收款单列表
     * @Description  
     * @param receiptOrder 查询条件：日期范围、单据编号、单据状态、付款单位
     * @return 收款单列表
     * @author guojianbin   
     * @date 2015年12月30日
     */
    public List<GesReceiptOrder> pageReceiptOrder(GesReceiptOrderVO receiptOrder);

    /**
     * 查询收款单总数
     * @Description  
     * @param receiptOrder 查询条件：日期范围、单据编号、单据状态、付款单位
     * @return 收款单总数
     * @author guojianbin   
     * @date 2015年12月30日
     */
    public Long countReceiptOrder(GesReceiptOrderVO receiptOrder);
    
    /**
     * 根据ID获取收款单信息
     * @Description  
     * @param id 收款单id
     * @return 收款单
     * @author guojianbin   
     * @date 2015年12月30日
     */
    public GesReceiptOrder queryByID(Long id);

    /**
     * 新增收款单
     * 
     * @Description
     * @param receiptOrder 收款单
     * @return 收款单ID
     * @author guojianbin
     * @date 2015年12月30日
     */
    public long create(GesReceiptOrder receiptOrder);

    /**
     * 修改收款单
     * 
     * @Description
     * @param receiptOrder 收款单
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月30日
     */
    public boolean update(GesReceiptOrder receiptOrder);
    
    /**
     * 批量新增收款单
     * 
     * @Description
     * @param receiptOrderList 收款单列表
     * @return 新增条数
     * @author guojianbin
     * @date 2015年12月31日
     */
    public Integer batchCreate(List<GesReceiptOrder> receiptOrderList);
    
    /**
     * 根据收款单唯一标识获取收款单信息
     * @Description  
     * @param id 收款单唯一标识
     * @return 收款单
     * @author guojianbin   
     * @date 2015年12月30日
     */
    public GesReceiptOrder queryByUniqueID(Long uniqueId);
}
