package com.gjw.company.service.order;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.gjw.entity.order.LoanApplyInfo;
import com.gjw.vo.order.LoanApplyInfoVO;

public interface IOwnerLoanService {
	
	/**
     * 根据订单的id查询订单的相关信息
     * @param orderId 订单id
     */
    public LoanApplyInfoVO queryLoanOrderInfo(Long orderId);
    
    /**
     * 统计次数及是否已申请成功
     * @param orderId
     * @return
     */
    public String countOwnerLoanTimes(Long orderId);
    
    /**
     * 根据贷款金额计算不同期数的还款数
     * @param amount
     */
    public List<Map<String, String>> loanCalculate(BigDecimal amount);
    
    /**
     * 根据输入的金额和贷款期数计算还款数
     * 信用卡分期付款每期还款额=（分期金额+分期金额*分期期数的手续费费率）/分期期数
     * @param inputAmount
     * @param term
     */
    public Map<String, Object> loanRepayCalcu(BigDecimal inputAmount,int term);
    
    /**
     * 统计本日内申请的次数
     */
    public String countApplyTimes(long orderId);
    
    /**
     * 保存业主贷款信息
     * @param 
     */
    public LoanApplyInfo addOwnerLoanInfo(LoanApplyInfoVO loanApplyInfoExt,LoanApplyInfo loanApplyInfo);
    
    /**
     * 贷款信息发送给银行(需要修改，异常处理不好)
     * @param loanApplyInfo
     * @return
     */
    public String loanInfoSendToBank(LoanApplyInfoVO loanApplyInfoExt,LoanApplyInfo loanApplyInfo,String confirmUrl);

}
