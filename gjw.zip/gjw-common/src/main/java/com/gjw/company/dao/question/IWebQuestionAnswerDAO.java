package com.gjw.company.dao.question;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.question.WebQuestionAnswer;
import com.gjw.vo.WebQuestionAnswerVO;

/**
 * 
* @Description: 问题答案dao接口类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:28:30
*
 */
public interface IWebQuestionAnswerDAO extends IDAO {

	/**
	 * 
	* @Description  获取问题答案详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月10日 下午2:31:48
	 */
	public WebQuestionAnswer getById(Long id);
	
	/**
	 * 
	* @Description  分页列表，搜索条件：问题标题
	* @param subject
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月10日 下午2:34:10
	 */
	public List<WebQuestionAnswer> pageBySubjectAndInvalid(WebQuestionAnswerVO answer);
	
	/**
	 * 
	* @Description  总数
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月14日 下午1:51:20
	 */
	public Long countBySubjectAndInvalid(WebQuestionAnswerVO answer);
	
	/**
	 * 
	* @Description  修改答案
	* @param answer
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月16日 下午3:48:09
	 */
	public boolean updateAnswer(WebQuestionAnswer answer);
	
	/**
	 * 
	* @Description  废弃问题下所有答案
	* @param questionId
	* @return
	* @author zhaoyonglian   
	* @date 2016年1月4日 上午10:02:26
	 */
	public boolean invalidByQuestion(Long questionId);
	
	/**
	 * 
	* @Description  所有答案（未废弃）
	* @param questionId
	* @return
	* @author zhaoyonglian   
	* @date 2016年3月1日 下午3:05:18
	 */
	public List<WebQuestionAnswer> listByQuestion(Long questionId);
	
	/**
	 * 
	* @Description  答案被采纳
	* @param answerId
	* @author zhaoyonglian   
	* @date 2016年3月1日 下午3:32:45
	 */
	public void isEssence(Long answerId);
}
