package com.gjw.company.service.order;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.order.WebOrderVideo;

/**
 * 
* @Description: 日志service类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:22:44
*
 */
public interface IWebOrderVideoService extends IService {
    
    /**
     * 
    * @Description  获得订单视频列表
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月19日 下午3:21:34
     */
    public List<WebOrderVideo> listByOrder(Long orderId);
    
    
    /**
     * 
    * @Description  修改视频信息
    * @param log
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月19日 上午10:40:00
     */
    public boolean update(WebOrderVideo video);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebOrderVideo entity);
}
