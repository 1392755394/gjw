package com.gjw.company.service.impl.picture;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.picture.IPictureService;
import com.gjw.entity.picture.Picture;
@Component("pictureServiceImpl")
@Transactional
public class PictureServiceImpl extends AbstractServiceImpl implements IPictureService{

    @Override
    public Picture get(Long id) {
        return this.getPictureDAO().get(id);
    }

    @Override
    public void add(Picture picture) {
        this.getPictureDAO().add(picture);
    }

    @Override
    public void remove(Picture picture) {
        this.getPictureDAO().remove(picture.getId());
    }
    
}
