package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IMatterUnitDAO;
import com.gjw.entity.matter.MatterUnit;

/**
 * 物料单位
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月21日 上午9:17:28
 * 
 */
@Component("matterUnitDAOHibernater")
public class MatterUnitDAOHibernaterImpl extends AbstractDAOHibernateImpl implements IMatterUnitDAO {

    @Override
    protected Class getEntityClass() {
        return MatterUnit.class;
    }

    /**
     * 物料单位列表查询
     */
    @Override
    public List<MatterUnit> listByMatterUnitSynch(MatterUnit matterUnit) {

        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from MatterUnit where invalid=0 and ( synchType.id not in(1130102,1130105) or synchType.id is null)");
        return (List<MatterUnit>) super.findByListCallBack(hql.toString(), "", null, null);
    }

    /**
     * 修改物料单位同步结果
     */
    @Override
    public boolean updateMatterUnitSynch(MatterUnit matterUnit) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update MatterUnit set synchType.id =? where id=?");
        list.add(matterUnit.getSynchType().getId());
        list.add(matterUnit.getId());
        return super.updateByParam(hql.toString(), list);
    }

    @Override
    public List<MatterUnit> listAllValidMatter() {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from MatterUnit where invalid=0 ");
        return (List<MatterUnit>) super.findByListCallBack(hql.toString(), "", null, null);
    }
}
