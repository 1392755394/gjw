package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsPriceDetail;

/**
 * 产品包价格service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月25日 
 *
 */
public interface IGoodsPriceDetailService extends IService {

    /**
     * 查询产品包价格列表
     * @Description  
     * @param goodsId 查询条件：产品包ID
     * @return 产品包价格列表
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public List<GoodsPriceDetail> listGoodsPriceByGoodsId(Long goodsId);
    
    /**
     * 保存产品包价格信息
     * 
     * @Description
     * @param goodsPriceDetail
     *            产品包价格
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月25日
     */
    public boolean saveGoodsPrice(List<GoodsPriceDetail> goodsPriceList);
}
