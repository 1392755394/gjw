package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.matter.MatterUnit;

/**
 * 物料单位
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月21日 上午9:18:09
 * 
 */
public interface IMatterUnitDAO extends IDAO {
    /**
     * 物料单位列表查询
     * 
     * @Description
     * @param matterUnit
     * @return
     * @author gwb
     * @date 2015年12月21日 上午9:19:40
     */
    public List<MatterUnit> listByMatterUnitSynch(MatterUnit matterUnit);
    
    public List<MatterUnit> listAllValidMatter();

    /**
     * 修改物料单位同步结果
     * 
     * @Description
     * @param matterUnit
     * @return
     * @author gwb
     * @date 2015年12月21日 上午9:19:53
     */
    public boolean updateMatterUnitSynch(MatterUnit matterUnit);

}
