package com.gjw.company.dao.impl.article;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.article.IWebArticleDAO;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.utils.StringUtil;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("webArticleDAOHibernateImpl")
public class WebArticleDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebArticleDAO {
    @Override
    public WebArticle get(Long id) {
        return (WebArticle) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebArticle> pageByName(WebArticle article) {
        StringBuffer hql = new StringBuffer("from WebArticle article where invalid=?");
        List<Object> ls = new ArrayList<Object>();
        ls.add(article.getInvalid() == null ? false : article.getInvalid());
        if (article.getName() != null && !article.getName().equals("")) {
            hql.append("and article.name like ?");
            ls.add("%" + article.getName() + "%");
        }
        hql.append(" order by article.createdDatetime desc");
        return (List<WebArticle>) super.findByPageCallBack(hql.toString(), "", ls, article, null);
    }

    @Override
    public long countByName(WebArticle article) {
        StringBuilder hql = new StringBuilder("from WebArticle where invalid=?");
        List<Object> ls = new ArrayList<Object>();
        ls.add(article.getInvalid() == null ? false : article.getInvalid());
        if (article.getName() != null && !article.getName().equals("")) {
            hql.append("and name like ?");
            ls.add("%" + article.getName() + "%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public void batchDelete(List<Long> idList) {

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < idList.size(); i++) {
            if (i != 0)
                sb.append(",");
            sb.append(idList.get(i));
        }
        String hql = "update WebArticle set invalid=1 where id in (" + sb + ")";
        this.getHibernateTemplate().bulkUpdate(hql, null);
    }

    @Override
    public void batchReuse(List<Long> idList) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < idList.size(); i++) {
            if (i != 0)
                sb.append(",");
            sb.append(idList.get(i));
        }
        String hql = "update WebArticle set invalid=0 where id in (" + sb + ")";
        this.getHibernateTemplate().bulkUpdate(hql, null);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebArticle.class;
    }

    @Override
    public List<WebArticle> listByArticle(WebArticle model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from WebArticle item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql = hql + " and item.name like ?";
            params.add(super.getFuzzyCondition(model.getName()));
        }
        hql = hql + " order by item.createdDatetime desc";
        return (List<WebArticle>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public long count(WebArticle model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from WebArticle item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql = hql + " and item.name like ?";
            params.add(super.getFuzzyCondition(model.getName()));
        }
        hql = hql + " order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<WebArticle> listArticleBy(List<WebCollectionItem> list) {
        Session sesion = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer("from WebArticle article where invalid=0 and id in( :ids )");
        Query query = sesion.createQuery(hql.toString());

        if (list.size() > 0) {
            List<Long> ls = new ArrayList<Long>();
            for (WebCollectionItem matter : list) {
                ls.add(matter.getInfo());
            }
            query.setParameterList("ids", ls);
        } else {
            query.setParameter("ids", -1l);
        }
        return query.list();

    }
}
