package com.gjw.company.service.impl.customer;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.customer.IGesCustomerMessageLogService;
import com.gjw.entity.customer.GesCustomerMessageLog;
import com.gjw.utils.StringUtil;
@Component("gesCustomerMessageLogServiceImpl")
public class GesCustomerMessageLogServiceImpl extends AbstractServiceImpl implements IGesCustomerMessageLogService{
    /**
     * 根据ID 查询客户消息日志
     */
    @Override
    @Transactional(readOnly=true)
    public GesCustomerMessageLog listByID(Long id) {
        // TODO Auto-generated method stub
        GesCustomerMessageLog model=super.getGesCustomerMessageLogDAO().listByID(id);
        Hibernate.initialize(model.getEvent());
        Hibernate.initialize(model.getMessage());
        Hibernate.initialize(model.getCustomer());
        if(null!=model.getCustomer()){
//            Hibernate.initialize(model.getCustomer().getBuilding());
            Hibernate.initialize(model.getCustomer().getProvince());
            Hibernate.initialize(model.getCustomer().getCity());
            Hibernate.initialize(model.getCustomer().getShop());
            Hibernate.initialize(model.getCustomer().getOperator());
        }
        return model;
    }
    /**
     * 更新客户消息日志
     */
    @Override
    @Transactional()
    public boolean updateGesCustomerMessageLog(GesCustomerMessageLog model) {
        // TODO Auto-generated method stub
        GesCustomerMessageLog item=super.getGesCustomerMessageLogDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCustomerMessageLogDAO().updateGesCustomerMessageLog(item);
    }
    /**
     * 创建客户消息日志
     */
    @Override
    @Transactional()
    public boolean createGesCustomerMessageLog(GesCustomerMessageLog model) {
        // TODO Auto-generated method stub
        return super.getGesCustomerMessageLogDAO().createGesCustomerMessageLog(model);
    }
    /**
     * 客户消息日志列表
     */
    @Override
    @Transactional(readOnly=true)
    public List<GesCustomerMessageLog> listByGesCustomerMessageLog(
            GesCustomerMessageLog model) {
        // TODO Auto-generated method stub
        List<GesCustomerMessageLog> real=new ArrayList<>();
        List<GesCustomerMessageLog> list=super.getGesCustomerMessageLogDAO().listByGesCustomerMessageLog(model);
        Long customerId=0l;
        for (GesCustomerMessageLog item : list) {
            Hibernate.initialize(item.getCustomer());
            if(null!=item.getCustomer()){
                if(customerId==item.getCustomer().getId()){
                    continue;
                }
                customerId=item.getCustomer().getId();
//                Hibernate.initialize(item.getCustomer().getBuilding());
                Hibernate.initialize(item.getCustomer().getShop());
                Hibernate.initialize(item.getCustomer().getOperator());
                Hibernate.initialize(item.getCustomer().getProvince());
                Hibernate.initialize(item.getCustomer().getCity());
            }
            Hibernate.initialize(item.getEvent());
            Hibernate.initialize(item.getMessage());
            if(null!=item.getMessage()){
                Hibernate.initialize(item.getMessage().getDictionary());
                Hibernate.initialize(item.getMessage().getUser());
                if(null!=item.getMessage().getDictionary()){
                    Hibernate.initialize(item.getMessage().getDictionary().getParent());
                }
            }
            real.add(item);
        }
        return real;
    }
    
    @Override
    @Transactional(readOnly=true)
    public List<GesCustomerMessageLog> listByGesCustomerMessageLogItem(
            GesCustomerMessageLog model) {
        // TODO Auto-generated method stub
        List<GesCustomerMessageLog> real=new ArrayList<>();
        List<GesCustomerMessageLog> list=super.getGesCustomerMessageLogDAO().listByGesCustomerMessageLog(model);
        for (GesCustomerMessageLog item : list) {
            Hibernate.initialize(item.getCustomer());
            if(null!=item.getCustomer()){
//                Hibernate.initialize(item.getCustomer().getBuilding());
                Hibernate.initialize(item.getCustomer().getShop());
                Hibernate.initialize(item.getCustomer().getOperator());
                Hibernate.initialize(item.getCustomer().getProvince());
                Hibernate.initialize(item.getCustomer().getCity());
            }
            Hibernate.initialize(item.getEvent());
            Hibernate.initialize(item.getMessage());
            if(null!=item.getMessage()){
                Hibernate.initialize(item.getMessage().getDictionary());
                Hibernate.initialize(item.getMessage().getUser());
                if(null!=item.getMessage().getDictionary()){
                    Hibernate.initialize(item.getMessage().getDictionary().getParent());
                }
            }
            real.add(item);
        }
        return real;
    }
    /**
     * 客户消息日志总数
     */
    @Override
    @Transactional(readOnly=true)
    public long count(GesCustomerMessageLog model) {
        // TODO Auto-generated method stub
        return super.getGesCustomerMessageLogDAO().count(model);
    }

}
