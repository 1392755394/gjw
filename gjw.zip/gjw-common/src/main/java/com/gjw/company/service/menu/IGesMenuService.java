package com.gjw.company.service.menu;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.gjw.base.service.IService;
import com.gjw.entity.menu.GesMenu;
import com.gjw.vo.menu.GesMenuVO;

/**
 * 菜单service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月10日 
 *
 */
public interface IGesMenuService extends IService {
    
    /**
     * 获取用户相关联的菜单
    * @Description  
    * @param userId
    * @return
    * @author dabai   
    * @date 2016年3月10日 下午3:55:13
     */
    public List<GesMenu> listMenusOfUser(long userId);
    
    
    /**
     * 获得角色对应的菜单
    * @Description  
    * @param roleId
    * @return
    * @author dabai   
    * @date 2016年3月8日 上午9:57:03
     */
    public List<GesMenu> listMenusOfRole(long roleId);

    /**
     * 根据父菜单取得的子菜单列表
     * @Description  
     * @param parentId 父菜单ID
     * @return 子菜单列表
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public List<GesMenu> listMenusByParentId(long parentId);
    
    /**
     * 新增菜单
     * @Description  
     * @param menu 菜单
     * @return 菜单ID
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public long create(GesMenu menu);
    
    /**
     * 修改菜单
     * @Description  
     * @param menu 菜单
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public boolean update(GesMenu menu);
    
    /**
     * 删除菜单
     * @Description  
     * @param menu 菜单
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public boolean delete(GesMenu menu);

    /**
     * 取得全体菜单列表
     * @Description  
     * @return 菜单列表
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public List<GesMenu> listMenus();
    
    /**
     *  根据父类取得角色的子菜单  
    * @Description  
    * @param roleId
    * @param parentId
    * @return
    * @author dabai   
    * @date 2016年3月8日 下午4:47:42
     */
    public List<GesMenuVO> roletreeInitAll(int roleId, int parentId);
    
    /**
     * 为菜单生成权限
    * @Description  
    * @author dabai   
    * @date 2016年3月17日 下午4:20:59
     */
    public boolean generatePermission4Menu(String target, String permission, boolean init);
}
