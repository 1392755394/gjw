package com.gjw.company.service.impl.customer;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.customer.IGesCustomerService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.customer.GesCustomerQuestion;
import com.gjw.entity.customer.GesCustomerReserve;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.utils.StringUtil;
import com.gjw.vo.customer.GesCustomerReserveVO;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.customer.UserVO;

@Component("gesCustomerServiceImpl")
@Transactional
public class GesCustomerServiceImpl extends AbstractServiceImpl implements IGesCustomerService {

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public Map<Object, Object> pageGesCustomer(GesCustomerVO gesCustomerVO) {

        Map<Object, Object> responseMap = new HashMap<Object, Object>();
        Map<Object, Object> ListAndCount = getGesCustomerDAO().pageGesCustomer(gesCustomerVO);
        List<Object[]> list = (List<Object[]>) ListAndCount.get("list");
        long count = (long) ListAndCount.get("count");
        List<GesCustomerVO> customerVOList = new ArrayList<GesCustomerVO>();
        for (Object[] o : list) {
            GesCustomer gc = (GesCustomer) o[0];
            if (null != gc && null != gc.getId()) {
                Hibernate.initialize(gc.getProvince());
                Hibernate.initialize(gc.getCity());
                // Hibernate.initialize(gc.getBuilding());
                Hibernate.initialize(gc.getPersonInCharge());
                if (null != gc.getShop() && null != gc.getShop().getId()) {
                    Hibernate.initialize(gc.getShop());
                }
                GesCustomerVO gcv = new GesCustomerVO();
                if (null != gc.getShop() && null != gc.getShop().getId()) {
                    // String userNameStr = "";
                    GesShop gs = gc.getShop();
                    if (null != gs.getOperator() && null != gs.getOperator().getId()) {
                        Hibernate.initialize(gc.getShop().getOperator());
                    }
                    gcv.setShop(gc.getShop());
                    // 处理shop中的BD经理与客服
                    if (null != gcv.getShop().getService())
                        gcv.getShop().getService().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                    if (null != gcv.getShop().getBdManager())
                        gcv.getShop().getBdManager().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                    gc.getShop().setOperator(gc.getShop().getOperator());
                    if (StringUtil.notEmpty(gesCustomerVO.getOrgType())) {
                        Set<UserInfoGES> sets = null;
                        if ("shop".equals(gesCustomerVO.getOrgType())) {
                            Hibernate.initialize(gc.getShop().getShopUserInfoGesSet());
                            sets = gc.getShop().getShopUserInfoGesSet();
                        } else if ("city_operator".equals(gesCustomerVO.getOrgType())) {
                            if (null != gc.getShop().getOperator()) {
                                Hibernate.initialize(gc.getShop().getOperator().getOperatorUserInfoGesSet());
                                sets = gc.getShop().getShopUserInfoGesSet();
                            }
                        } else {
                            gcv.setUserName(gesCustomerVO.getRealName());
                        }
                        if (null != sets) {
                            List<UserInfoGES> lists = new ArrayList<UserInfoGES>(sets);
                            if (!lists.isEmpty()) {
                                Long[] temId = new Long[lists.size()];
                                for (int i = 0; i < lists.size(); i++) {
                                    temId[i] = lists.get(i).getId();
                                }
                                if (null != temId) {
                                    Arrays.sort(temId);
                                    for (UserInfoGES uifg : lists) {
                                        if (uifg.getId() == temId[0])
                                            gcv.setUserName(uifg.getRealName());
                                    }
                                }
                                // List<UserInfoGES> lists = new
                                // ArrayList<UserInfoGES>(sets);
                                // String temUserName =
                                // !lists.isEmpty()?lists.get(0).getRealName():"";
                                // if("".equals(temUserName))
                                // gcv.setUserName(temUserName);
                            }
                        }
                    }
                }
                gcv.setId(gc.getId());
                gcv.setName(gc.getName());
                gcv.setGender(gc.getGender());
                gcv.setPhone(gc.getPhone());
                gcv.setEmail(gc.getEmail());
                gcv.setCity(gc.getCity());
                gcv.setProvince(gc.getProvince());
                // gcv.setBuilding(gc.getBuilding());
                gcv.setBuildingName(gc.getBuildingName());
                gcv.setCreatedDatetime(gc.getCreatedDatetime());
                gcv.setCompany(gc.getCompany());
                gcv.setAge(gc.getAge());
                gcv.setAddress(gc.getAddress());
                gcv.setIdNo(gc.getIdNo());
                gcv.setRemark(gc.getRemark());
                gcv.setCustomerType(gc.getCustomerType());
                gcv.setCustomerOrigion(gc.getCustomerOrigion());
                gcv.setCustomerLevel(gc.getCustomerLevel());

                // 查询客户最新预约信息
                GesCustomerReserve reserve = super.getGesCustomerDAO().getCustomerReserveLatest(gc);
                if (null != reserve) {
                    gcv.setCustomerReserve(reserve);
                }
                // 查询客户最新订单
                GesOrder order = new GesOrder();
                order.setCustomer(gc);
                List<GesOrder> orderList = getGesOrderDAO().queryOrderInfoForCustomer(order);
                gcv.setGesOrder(!orderList.isEmpty() ? orderList.get(0) : null);
                if (null != gc.getPersonInCharge()) {
                    gcv.setPersonInCharge(gc.getPersonInCharge());
                    if (null != gcv.getPersonInCharge() && null != gcv.getPersonInCharge().getId()) {
                        if (null != gcv.getPersonInCharge().initPlatformUserInfo(PlatformEnum.Ges)) {
                            gcv.getPersonInCharge().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                        }
                    }
                }
                // 获取客户订单的最新项目进展
                GesProjectTask projectTask = super.getGesProjectTaskDAO().projectTaskByCustomer(gcv);
                if (null != projectTask && null != projectTask.getPmModel()
                        && StringUtil.notEmpty(projectTask.getPmModel().getAccentedphase())
                        && StringUtil.notEmpty(projectTask.getPmModel().getKeypoint())) {
                    gcv.setProjectProcess(projectTask.getPmModel().getAccentedphase() + "["
                            + projectTask.getPmModel().getKeypoint() + "]");
                }
                
                customerVOList.add(gcv);
            }
        }
        responseMap.put("pageList", customerVOList);
        responseMap.put("count", count);
        return responseMap;
    }
    
    /**
     * 方法后期需要重写 
    * @Description  
    * @param gesCustomerVO
    * @return
    * @author dabai   
    * @date 2016年4月18日 下午2:41:01
     */
    private Map<Object, Object> pageGesCustomer4Export(GesCustomerVO gesCustomerVO) {

        Map<Object, Object> responseMap = new HashMap<Object, Object>();
        Map<Object, Object> ListAndCount = getGesCustomerDAO().pageGesCustomer(gesCustomerVO);
        List<Object[]> list = (List<Object[]>) ListAndCount.get("list");
        long count = (long) ListAndCount.get("count");
        List<GesCustomerVO> customerVOList = new ArrayList<GesCustomerVO>();
        for (Object[] o : list) {
            GesCustomer gc = (GesCustomer) o[0];
            if (null != gc && null != gc.getId()) {
                Hibernate.initialize(gc.getProvince());
                Hibernate.initialize(gc.getCity());
                // Hibernate.initialize(gc.getBuilding());
                Hibernate.initialize(gc.getPersonInCharge());
                if (null != gc.getShop() && null != gc.getShop().getId()) {
                    Hibernate.initialize(gc.getShop());
                }
                GesCustomerVO gcv = new GesCustomerVO();
                if (null != gc.getShop() && null != gc.getShop().getId()) {
                    // String userNameStr = "";
                    GesShop gs = gc.getShop();
                    if (null != gs.getOperator() && null != gs.getOperator().getId()) {
                        Hibernate.initialize(gc.getShop().getOperator());
                    }
                    gcv.setShop(gc.getShop());
                    // 处理shop中的BD经理与客服
                    if (null != gcv.getShop().getService())
                        gcv.getShop().getService().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                    if (null != gcv.getShop().getBdManager())
                        gcv.getShop().getBdManager().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                    gc.getShop().setOperator(gc.getShop().getOperator());
                    if (StringUtil.notEmpty(gesCustomerVO.getOrgType())) {
                        Set<UserInfoGES> sets = null;
                        if ("shop".equals(gesCustomerVO.getOrgType())) {
                            Hibernate.initialize(gc.getShop().getShopUserInfoGesSet());
                            sets = gc.getShop().getShopUserInfoGesSet();
                        } else if ("city_operator".equals(gesCustomerVO.getOrgType())) {
                            if (null != gc.getShop().getOperator()) {
                                Hibernate.initialize(gc.getShop().getOperator().getOperatorUserInfoGesSet());
                                sets = gc.getShop().getShopUserInfoGesSet();
                            }
                        } else {
                            gcv.setUserName(gesCustomerVO.getRealName());
                        }
                        if (null != sets) {
                            List<UserInfoGES> lists = new ArrayList<UserInfoGES>(sets);
                            if (!lists.isEmpty()) {
                                Long[] temId = new Long[lists.size()];
                                for (int i = 0; i < lists.size(); i++) {
                                    temId[i] = lists.get(i).getId();
                                }
                                if (null != temId) {
                                    Arrays.sort(temId);
                                    for (UserInfoGES uifg : lists) {
                                        if (uifg.getId() == temId[0])
                                            gcv.setUserName(uifg.getRealName());
                                    }
                                }
                            }
                        }
                    }
                }
                gcv.setId(gc.getId());
                gcv.setName(gc.getName());
                gcv.setGender(gc.getGender());
                gcv.setPhone(gc.getPhone());
                gcv.setEmail(gc.getEmail());
                gcv.setCity(gc.getCity());
                gcv.setProvince(gc.getProvince());
                gcv.setBuildingName(gc.getBuildingName());
                gcv.setCreatedDatetime(gc.getCreatedDatetime());
                gcv.setCompany(gc.getCompany());
                gcv.setAge(gc.getAge());
                gcv.setAddress(gc.getAddress());
                gcv.setIdNo(gc.getIdNo());
                gcv.setRemark(gc.getRemark());
                gcv.setCustomerType(gc.getCustomerType());
                gcv.setCustomerOrigion(gc.getCustomerOrigion());
                gcv.setCustomerLevel(gc.getCustomerLevel());
                gcv.setCreatedDate(gc.getCreatedDatetime());
                customerVOList.add(gcv);
            }
        }
        responseMap.put("pageList", customerVOList);
        responseMap.put("count", count);
        return responseMap;
    }
    
    @Override
    public List<GesCustomerVO> listByGesCustomer4Export(GesCustomerVO gesCustomerVO) {
        gesCustomerVO.setPageSize(Integer.MAX_VALUE);
        Map<Object, Object> responseMap = pageGesCustomer4Export(gesCustomerVO);
        List<GesCustomerVO> pageList = (List<GesCustomerVO>)responseMap.get("pageList");
        List<GesCustomerVO> resultList = new ArrayList<GesCustomerVO>();
        for (GesCustomerVO item : pageList) {
            switch (item.getGender()!=null?item.getGender():"") {
            case "male":
                item.setGenderStr("男");
                break;
            case "female":
                item.setGenderStr("女");
                break;
            default:
                break;
            }
            item.setProvinceName(item.getProvince() != null? item.getProvince().getName():"");
            item.setCityName(item.getCity() != null? item.getCity().getName():"");
            if (item.getPersonInCharge() != null){
                if (item.getPersonInCharge().getPlatformUserInfo() != null){
                    item.setPersonInChargeName(item.getPersonInCharge().getPlatformUserInfo().getRealName());
                }
            }
            item.setOperatorName(item.getShop()!=null?(item.getShop().getOperator() != null?item.getShop().getOperator().getCompanyName():""):"");
            switch (item.getCustomerType()!=null?item.getCustomerType():0) {
            case 1:
                item.setCustomerTypeStr("初次拜访");
                break;
            case 2:
                item.setCustomerTypeStr("竞争对手");
                break;    
            default:
                break;
            }
            switch (item.getCustomerOrigion()!=null?item.getCustomerOrigion():0) {
            case 1:
                item.setCustomerOrigionStr("网站");
                break;
            case 2:
                item.setCustomerOrigionStr("APP");
                break;
            case 3:
                item.setCustomerOrigionStr("朋友介绍");
                break;
            case 4:
                item.setCustomerOrigionStr("其他");
                break;
            default:
                item.setCustomerOrigionStr("");
                break;
            }
            switch (item.getCustomerLevel()!=null?item.getCustomerLevel():0) {
            case 1:
                item.setCustomerLevelStr("3个月处理");
                break;
            case 2:
                item.setCustomerLevelStr("3-6个月处理");
                break;
            case 3:
                item.setCustomerLevelStr("6-12个月处理");
                break;
            case 4:
                item.setCustomerLevelStr("12个月以后");
                break;
            default:
                item.setCustomerLevelStr("");
                break;
            
            }
            if (item.getShop()!=null){
                item.setShopName(item.getShop().getName());
                if (item.getShop().getBdManager()!=null){
                    if (item.getShop().getBdManager().getPlatformUserInfo()!=null){
                        item.setBdManager(item.getShop().getBdManager().getPlatformUserInfo().getRealName());
                    }
                }
                if (item.getShop().getService()!=null){
                    if (item.getShop().getService().getPlatformUserInfo()!=null){
                        item.setCustomerServiceName(item.getShop().getService().getPlatformUserInfo().getRealName());
                    }
                }
            }
            item.setNewreserve(item.getCustomerReserve()!=null?item.getCustomerReserve().getContent():"");
            if (item.getGesOrder()!=null){
                item.setOrderType(OrderStatus.valueOf(item.getGesOrder().getOrderStatus()).getText());
            }
            resultList.add(item);
        }
        return resultList;
    }
    
    
    

    @Override
    public List<GesCustomer> getGesCustomerByGesCustomer(GesCustomer gesCustomer) {

        List<GesCustomer> list = this.getGesCustomerDAO().getGesCustomerByGesCustomer(gesCustomer);
        if (!list.isEmpty()) {
            for (GesCustomer customer : list) {
                if (null != customer && null != customer.getId()) {
                    if (null != customer.getPersonInCharge() && null != customer.getPersonInCharge().getId()) {
                        Hibernate.initialize(customer.getPersonInCharge());
                        Hibernate.initialize(customer.getPersonInCharge().getUserInfo(PlatformEnum.Ges));
                    }
                }
            }
        }
        return list;
    }

    @Override
    @Transactional
    public long updateGesCustomerByGesCustomer(GesCustomer gesCustomer) {

        GesCustomer customer = getGesCustomerDAO().getGesCustomerById(gesCustomer.getId());
        StringUtil.copyProperties(gesCustomer, customer);
        // 对应的页面上为空就为空
        if (null != gesCustomer.getDictionaryFocus() && null == gesCustomer.getDictionaryFocus().getId()) {
            customer.setDictionaryFocus(null);
        }
        // if (null != gesCustomer.getBuilding() && null ==
        // gesCustomer.getBuilding().getId()) {
        // customer.setBuilding(null);
        // }
        if (null != gesCustomer.getShop() && null == gesCustomer.getShop().getId()) {
            customer.setShop(null);
        } else if (null != gesCustomer.getShop() && null != gesCustomer.getShop().getId()) {
            if (null != gesCustomer.getShop().getOperator() && null == gesCustomer.getShop().getOperator().getId()) {
                customer.getShop().setOperator(null);
            }
        }
        if (null != gesCustomer.getProvince() && null == gesCustomer.getProvince().getId()) {
            customer.setProvince(null);
        }
        if (null != gesCustomer.getCity() && null == gesCustomer.getCity().getId()) {
            customer.setCity(null);
        }
        return this.getGesCustomerDAO().updateGesCustomerByGesCustomer(customer);
    }

    @Override
    @Transactional(readOnly = true)
    public GesCustomer getGesCustomerById(long id) {

        GesCustomer gesCustomer = getGesCustomerDAO().getGesCustomerById(id);
        Hibernate.initialize(gesCustomer.getShop());
        // Hibernate.initialize(gesCustomer.getBuilding());
        if (null != gesCustomer.getPersonInCharge()) {
            Hibernate.initialize(gesCustomer.getPersonInCharge());
            // 根据userId查找realName at userInfo
            UserInfo userInfo = gesCustomer.getPersonInCharge().getUserInfo(PlatformEnum.Ges);
            gesCustomer.getPersonInCharge().setUsername(
                    gesCustomer.getPersonInCharge().getUsername()
                            + (null != userInfo ? "(" + userInfo.getRealName() + ")" : ""));
        }
        if (null != gesCustomer.getShop()) {
            Hibernate.initialize(gesCustomer.getShop().getOperator());
            if (null != gesCustomer.getShop().getBdManager()) {
                gesCustomer.getShop().getBdManager().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                gesCustomer.getShop().getService().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
            }
        }
        return gesCustomer;
    }

    @Override
    @Transactional
    public long saveGesCustomer(GesCustomer gesCustomer) {
        if (gesCustomer.getShop() != null && null == gesCustomer.getShop().getId()) {
            gesCustomer.setShop(null);
        }
        if (gesCustomer.getShop() != null && null != gesCustomer.getShop().getId()) {
            if (null != gesCustomer.getShop().getOperator() && null == gesCustomer.getShop().getOperator().getId()) {
                gesCustomer.getShop().setOperator(null);
            }
        }
        // if (gesCustomer.getBuilding() != null && null ==
        // gesCustomer.getBuilding().getId()) {
        // gesCustomer.setBuilding(null);
        // }
        if (gesCustomer.getProvince() != null && null == gesCustomer.getProvince().getId()) {
            gesCustomer.setProvince(null);
        }
        if (gesCustomer.getCity() != null && null == gesCustomer.getCity().getId()) {
            gesCustomer.setCity(null);
        }
        if (gesCustomer.getDictionaryFocus() != null && null == gesCustomer.getDictionaryFocus().getId()) {
            gesCustomer.setDictionaryFocus(null);
        }
        if (null != gesCustomer.getDictionaryAccount() && null == gesCustomer.getDictionaryAccount().getId()) {
            gesCustomer.setDictionaryAccount(null);
        }
        if (null != gesCustomer.getOperator() && null == gesCustomer.getOperator().getId()) {
            gesCustomer.setOperator(null);
        }
        return this.getGesCustomerDAO().saveGesCustomer(gesCustomer);
    }

    @Override
    public long updateGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {

        return this.getGesCustomerDAO().updateGesCustomerQuestion(gesCustomerQuestion);
    }

    @Override
    @Transactional
    public long saveGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {

        return this.getGesCustomerDAO().saveGesCustomerQuestion(gesCustomerQuestion);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<Object, Object> pageGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion) {

        Map<Object, Object> responseMap = new HashMap<Object, Object>();
        Map<Object, Object> ListAndCount = this.getGesCustomerDAO().pageGesCustomerQuestion(gesCustomerQuestion);
        List<Object[]> list = (List<Object[]>) ListAndCount.get("list");
        long count = (long) ListAndCount.get("count");
        responseMap.put("pageList", list);
        responseMap.put("count", count);
        return responseMap;
    }

    @SuppressWarnings({ "unchecked" })
    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> pageGesCustomerReserve(GesCustomerReserveVO gesCustomerReserveVO) {

        Map<String, Object> responseMap = new HashMap<String, Object>();
        Map<Object, Object> ListAndCount = this.getGesCustomerDAO().pageGesCustomerReserve(gesCustomerReserveVO);
        List<Object[]> list = (List<Object[]>) ListAndCount.get("list");
        long count = (long) ListAndCount.get("count");
        List<GesCustomerReserveVO> customerVOList = new ArrayList<GesCustomerReserveVO>();
        for (Object[] o : list) {
            GesCustomerReserve gcr = (GesCustomerReserve) o[0];
            if (null != gcr.getCustomer()) {
                Hibernate.initialize(gcr.getCustomer());
            }
            GesCustomerReserveVO gcv = new GesCustomerReserveVO();
            if (null != gcr.getCustomer()) {
                Hibernate.initialize(gcr.getCustomer().getShop());
                if (null != gcr.getCustomer().getShop()) {
                    Hibernate.initialize(gcr.getCustomer().getShop().getOperator());
                }
                if (null != gcr.getCustomer().getShop()) {
                    if (StringUtil.notEmpty(gesCustomerReserveVO.getOrgType())) {
                        String userNameStr = "";
                        Set<UserInfoGES> sets = null;
                        if ("shop".equals(gesCustomerReserveVO.getOrgType())) {
                            Hibernate.initialize(gcr.getCustomer().getShop().getShopUserInfoGesSet());
                            sets = gcr.getCustomer().getShop().getShopUserInfoGesSet();
                        } else if ("city_operator".equals(gesCustomerReserveVO.getOrgType())) {
                            if (null != gcr.getCustomer().getShop().getOperator()) {
                                Hibernate.initialize(gcr.getCustomer().getShop().getOperator()
                                        .getOperatorUserInfoGesSet());
                                sets = gcr.getCustomer().getShop().getOperator().getOperatorUserInfoGesSet();
                            }
                        } else {
                            userNameStr += null != gesCustomerReserveVO.getUser() ? gesCustomerReserveVO.getUser()
                                    .getUserInfo(PlatformEnum.Ges).getRealName() : "";
                            gcv.setUserName(userNameStr);
                        }
                        if (null != sets) {
                            List<UserInfoGES> lists = new ArrayList<UserInfoGES>(sets);
                            if (!lists.isEmpty()) {
                                Long[] temId = new Long[lists.size()];
                                for (int i = 0; i < lists.size(); i++) {
                                    temId[i] = lists.get(i).getId();
                                }
                                if (null != temId) {
                                    Arrays.sort(temId);
                                    for (UserInfoGES uifg : lists) {
                                        if (uifg.getId() == temId[0])
                                            gcv.setUserName(uifg.getRealName());
                                    }
                                }
                            }
                            // String temUserName =
                            // !lists.isEmpty()?lists.get(0).getRealName():"";
                            // if(!"".equals(temUserName))
                            // gcv.setUserName(temUserName)
                        }
                    }
                }
            }
            Hibernate.initialize(gcr.getShop());
            gcv.setId(gcr.getId());
            gcv.setCustomer(gcr.getCustomer());
            gcv.setGmtReserve(gcr.getGmtReserve());
            gcv.setContent(gcr.getContent());
            gcv.setMemo(gcr.getMemo());
            gcv.setCreatedDatetime(gcr.getCreatedDatetime());
            customerVOList.add(gcv);
        }
        responseMap.put("pageList", customerVOList);
        responseMap.put("count", count);
        return responseMap;
    }

    @Override
    public GesCustomerQuestion getGesCustomerQuestionById(long id) {

        GesCustomerQuestion customerQuestion = this.getGesCustomerDAO().getGesCustomerQuestionById(id);
        Hibernate.initialize(customerQuestion.getUser());
        return customerQuestion;
    }

    @Override
    @Transactional(readOnly = true)
    public GesCustomerReserve getGesCustomerReserveById(long id) {

        GesCustomerReserve gesCustomerReserve = this.getGesCustomerDAO().getGesCustomerReserveById(id);
        if (null != gesCustomerReserve) {
            Hibernate.initialize(gesCustomerReserve.getCustomer());
            if (null != gesCustomerReserve.getCustomer()) {
                // Hibernate.initialize(gesCustomerReserve.getCustomer().getBuilding());
                if (null != gesCustomerReserve.getCustomer().getId()) {
                    Hibernate.initialize(gesCustomerReserve.getCustomer().getShop());
                    if (null != gesCustomerReserve.getCustomer().getShop()
                            && gesCustomerReserve.getCustomer().getShop().getId() > 0
                            && StringUtil.notEmpty(gesCustomerReserve.getCustomer().getShop().getOperator())
                            && StringUtil.notEmpty(gesCustomerReserve.getCustomer().getShop().getOperator().getId())) {
                        GesCityOperator op = super.getGesCityOperatorDAO().listByID(gesCustomerReserve.getCustomer().getShop().getOperator().getId());
                        if(StringUtil.notEmpty(op))
                        Hibernate.initialize(gesCustomerReserve.getCustomer().getShop().getOperator());
                    }
                }
            }
            Hibernate.initialize(gesCustomerReserve.getShop());
            if (null != gesCustomerReserve.getShop()) {
                if (null != gesCustomerReserve.getShop().getOperator()) {
                    if (null != gesCustomerReserve.getShop().getOperator().getId()) {
                        GesCityOperator op = super.getGesCityOperatorDAO().listByID(gesCustomerReserve.getShop().getOperator().getId());
                        if(StringUtil.notEmpty(op))
                        Hibernate.initialize(gesCustomerReserve.getShop().getOperator());
                    }
                }
            }
        }
        return gesCustomerReserve;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesCityOperator> listGesCityOperator(String orgType, long shopId, long operatorId) {

        List<GesCityOperator> listCityOperator = new ArrayList<GesCityOperator>();
        if ("admin".equals(orgType)) {
            // 查詢全部
            GesCityOperator gco = new GesCityOperator();
            gco.setPageSize(null);
            gco.setPageNo(1);
            listCityOperator = super.getGesCityOperatorDAO().listByGesCityOperator(gco);
        } else if ("city_operator".equals(orgType)) {
            // 查询自己所在的cityoperator，一条结果
            GesCityOperator gesCityOperator = super.getGesCityOperatorDAO().listByID(operatorId);
            listCityOperator.add(gesCityOperator);
        } else if ("shop".equals(orgType)) {
            // 需要shop与operator内关联,结果只有一条
            GesShop gesShop = super.getGesShopDAO().listByID(shopId);
            Hibernate.initialize(gesShop.getOperator());
            listCityOperator.add(gesShop.getOperator());
        }
        return listCityOperator;
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids, Class<?> clazz) {

        String[] idArray = ids.split(",");
        // 如果是删除客户//有订单或 预约客户的无法删除
        if (clazz.equals(GesCustomer.class)) {
            GesCustomer customer = new GesCustomer();
            for (String id : idArray) {
                customer.setId(Long.valueOf(id));
                GesCustomerReserve reserve = this.getGesCustomerDAO().getCustomerReserveLatest(customer);
                if (null == reserve) {
                    // 继续判断有无有效订单
                    GesOrder gesOrder = new GesOrder();
                    gesOrder.setCustomer(customer);
                    List<GesOrder> orderList = this.getGesOrderDAO().queryOrderInfoForCustomer(gesOrder);
                    if (null != orderList && orderList.size() > 0) {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        }
        return getGesCustomerDAO().delBatchByID(ids, clazz);
    }

    @Override
    @Transactional(readOnly = true)
    public GesCustomer customerValidate(GesCustomer model) {

        GesCustomer item = super.getGesCustomerDAO().customerValidate(model);
        if (null != item) {
            // Hibernate.initialize(item.getBuilding());
            Hibernate.initialize(item.getShop());
            Hibernate.initialize(item.getOperator());
            Hibernate.initialize(item.getProvince());
            Hibernate.initialize(item.getCity());
        }
        return item;
    }

    @Override
    @Transactional
    public long saveCustomerReserve(GesCustomerReserve gesCustomerReserve) {

        return getGesCustomerDAO().saveGesCustomerReserve(gesCustomerReserve);
    }

    @Override
    @Transactional
    public long updateCustomerReserve(GesCustomerReserve gesCustomerReserve) {

        GesCustomerReserve gesCustomerReserveRet = getGesCustomerDAO().getGesCustomerReserveById(
                gesCustomerReserve.getId());
        StringUtil.copyProperties(gesCustomerReserve, gesCustomerReserveRet);
        return getGesCustomerDAO().updateGesCustomerReserve(gesCustomerReserveRet);
    }

    @Override
    public Map<Object, Object> pageUserByUser(UserVO user) {

        return this.getGesCustomerDAO().pageUserByUser(user);
    }

    /**
     * 客户预约
     */
    @Override
    @Transactional()
    public void addGesCustomer(GesCustomer gesCustomer, GesCustomerReserve gesCustomerReserve, Long shopId) {

        GesCustomer customerFlag = this.getGesCustomerDAO().customerByPhone(gesCustomer);
        GesShop shop = this.getGesShopDAO().listByID(shopId);
        if (null != customerFlag) {
            gesCustomer = customerFlag;
            gesCustomer.setShop(shop);
            gesCustomer.setOperator(shop.getOperator());
            gesCustomerReserve.setCustomer(gesCustomer);
            gesCustomerReserve.setShop(shop);
            gesCustomerReserve.setOperator(shop.getOperator());
        } else {
            this.getGesCustomerDAO().add(gesCustomer);
            gesCustomer.setShop(shop);
            gesCustomer.setOperator(shop.getOperator());
            gesCustomerReserve.setCustomer(gesCustomer);
            gesCustomerReserve.setShop(shop);
            gesCustomerReserve.setOperator(shop.getOperator());
        }
        gesCustomerReserve.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        gesCustomerReserve.setGmtReserve(new Timestamp(System.currentTimeMillis()));
        super.getGesCustomerDAO().saveGesCustomerReserve(gesCustomerReserve);
    }

    @Override
    public List<GesOrder> pageOrderByGesOrder(GesOrder gesOrder) {

        List<GesOrder> orderList = this.getGesOrderDAO().queryOrderInfoForCustomer(gesOrder);
        for (GesOrder gesOrder2 : orderList) {
            Hibernate.initialize(gesOrder2.getBuyer());
            Hibernate.initialize(gesOrder2.getGoods());
            Hibernate.initialize(gesOrder2.getOperator());
            Hibernate.initialize(gesOrder2.getShop());
        }
        return orderList;
    }

    @Override
    public List<GesCustomerReserve> pageByGesCustomerReserve(GesCustomerReserve model) {

        List<GesCustomerReserve> list = super.getGesCustomerDAO().pageByGesCustomerReserve(model);
        for (GesCustomerReserve gesCustomerReserve : list) {
            Hibernate.initialize(gesCustomerReserve.getCustomer());
        }
        return list;
    }

   

}
