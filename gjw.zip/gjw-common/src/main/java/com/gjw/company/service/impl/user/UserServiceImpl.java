package com.gjw.company.service.impl.user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.service.menu.IGesMenuService;
import com.gjw.company.service.user.IUserService;
import com.gjw.entity.menu.GesMenu;
import com.gjw.entity.menu.GesMenuPermissionItem;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.AuthenticationEmail;
import com.gjw.entity.user.AuthenticationMobile;
import com.gjw.entity.user.AuthenticationUsername;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.entity.user.UserInfoWebsite;
import com.gjw.entity.user.UserRoleItem;
import com.gjw.utils.PasswordUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.user.UserVO;

@Service("userServiceImpl")
@Transactional
public class UserServiceImpl extends AbstractServiceImpl implements IUserService {

    @Autowired
    private IGesMenuService iGesMenuService;

    @Override
    public void modifyEmail(User user) {
        if (user == null || user.getId() == null) {
            throw new ErrorCodeException(SECode.u_100001);
        }
        User tmp = this.getUserDAO().get(user.getId());
        tmp.setEmail(user.getEmail());
        this.getUserDAO().update(tmp);

        Authentication authEmail = this.getAuthenticationDAO().getByLoginTypeAndUser(user,
                AuthenticationEmail.class.getSimpleName());
        if (authEmail != null) {
            Authentication auth = new AuthenticationEmail();
            auth.setUser(tmp);
            auth.setLogin(tmp.getEmail());
            this.getAuthenticationDAO().updateByUser(auth);
        } else {
            List<Authentication> authList = this.getAuthenticationDAO().findByUser(user);
            Authentication auth = new AuthenticationEmail();
            auth.setUser(tmp);
            auth.setLogin(tmp.getEmail());
            auth.setPassword(authList.get(0).getPassword());
            auth.setSalt(authList.get(0).getSalt());
            this.getAuthenticationDAO().add(auth);
        }
    }

    @Override
    public void modifyMobile(User user) {
        if (user == null || user.getId() == null) {
            throw new ErrorCodeException(SECode.u_100004);
        }
        User tmp = this.getUserDAO().get(user.getId());
        tmp.setMobile(user.getMobile());
        this.getUserDAO().update(tmp);
        Authentication auth = new AuthenticationMobile();
        auth.setUser(tmp);
        auth.setLogin(tmp.getMobile());
        this.getAuthenticationDAO().updateByUser(auth);
    }

    @Override
    public User get(Long id) {
        // TODO Auto-generated method stub
        return this.getUserDAO().get(id);
    }

    @Override
    public User getWithAllInfo(Long id) {
        User user = this.getUserDAO().get(id);
        Hibernate.initialize(user.getUserInfoMap());
        Hibernate.initialize(user.getPlatformSet());
        UserInfoGES userinfo = (UserInfoGES) user.getUserInfo(PlatformEnum.Ges);
        if (userinfo != null) {
            Hibernate.initialize(userinfo.getAvatar());
            Hibernate.initialize(userinfo.getQrCode());
            if (userinfo.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)) {
                if (userinfo.getShop() != null) {
                    userinfo.setOrgId(userinfo.getShop().getId());
                    userinfo.setOrgName(userinfo.getShop().getName());
                }
            } else if (userinfo.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)) {
                if (userinfo.getOperator() != null) {
                    userinfo.setOrgId(userinfo.getOperator().getId());
                    userinfo.setOrgName(userinfo.getOperator().getCompanyName());
                }
            }
        }
        UserInfoWebsite info = (UserInfoWebsite) user.getUserInfo(PlatformEnum.Website);
        if (info != null) {
            Hibernate.initialize(info.getAvatar());
        }
        List<UserRoleItem> list = this.getUserRoleDAO().listRolesOfUser(id);
        if (list.size() > 0) {
            user.setRole(list.get(0).getRole());
        }
        return user;
    }

    @Override
    public List<UserRoleItem> listRolesOfUser(Long userId) {
        return super.getUserRoleDAO().listRolesOfUser(userId);
    }

    @Override
    public List<User> test() {
        return this.getUserDAO().test();
    }

    @Override
    public User getByUsername(String username) {
        return this.getUserDAO().getByUsername(username);
    }

    @Override
    public List<String> loadAllRoleNames(Long userId) {
        return getRoleDAO().loadAllRoleNames(userId);
    }

    @Override
    public List<String> loadAllPermissionNames(Long userId) {
        Set<String> permissions = new HashSet<String>();
        List<UserRoleItem> userRoleList = super.getUserRoleDAO().listRolesOfUser(userId);
        List<GesMenu> menuList = new ArrayList<GesMenu>();
        if (userRoleList != null && userRoleList.size() > 0) {
            menuList = super.getGesMenuDAO().listMenusOfRole(
                    userRoleList.get(0).getRole().getId());
        }
        if (menuList != null && menuList.size() > 0) {
            for (GesMenu gesMenu : menuList) {
                permissions.add(gesMenu.getName());
            }
            List<GesMenuPermissionItem> mpItems = super
                    .getGesMenuPermissionItemDAO()
                    .listMenuPermissionItemsByMenus(menuList);

            for (GesMenuPermissionItem gesMenuPermissionItem : mpItems) {
                permissions
                        .add(gesMenuPermissionItem.getPermission().getName());
            }
        }
      

        return new ArrayList<String>(permissions);
    }

    @Override
    @Transactional
    public boolean updateUser(User user) {
        // TODO Auto-generated method stub
        User u = this.getUserDAO().get(user.getId());
        StringUtil.copyProperties(user, u);
        return this.getUserDAO().update(u) > 0 ? true : false;
    }

    @Override
    @Transactional(readOnly=true)
    public User getByMobile(String phone) {
        // TODO Auto-generated method stub
        return this.getUserDAO().getByMobile(phone);
    }

    @Override
    public boolean saveResultBoolean(User user) {
        // TODO Auto-generated method stub
        return this.getUserDAO().saveResultBoolean(user);
    }

    @Override
    public User getByUserNameAndPassWord(User user) {
        // TODO Auto-generated method stub
        return this.getUserDAO().getByUserNameAndPassWord(user);
    }

    @Override
    public UserVO getSalesToolUser(String account, String passwordKey) {

        Authentication tmp = getAuthenticationDAO().getByLogin(account, AuthenticationUsername.class.getSimpleName());

        if (tmp == null)
            return null;
        else {
            String newPassword = PasswordUtil.genPasswordByEncryptPassword(passwordKey, tmp.getSalt());
            if (newPassword.equals(tmp.getPassword())) {
                Hibernate.initialize(tmp.getUser());
                User user = getWithAllInfo(tmp.getUser().getId());
                UserInfoGES userinfo = (UserInfoGES) user.getUserInfo(PlatformEnum.Ges);
                if (GesCommonConstants.ORG_TYPE_DEVELOPER.equals(userinfo.getOrgType())) {
                    UserVO userVO = new UserVO(user);
                    UserBuildingItem item = super.getUserBuildingItemDAO().queryByUser(user);
                    if (item != null) {
                        userVO.setBuildingId(item.getBuilding().getId());
                        userVO.setBuildingName(item.getBuilding().getName());
                    }
                    return userVO;
                } else {
                    return null;
                }
            } else
                return null;
        }
    }

    @Override
    public User getWapUser(String account, String passwordKey) {

        Authentication tmp = getAuthenticationDAO().getByLogin(account, AuthenticationUsername.class.getSimpleName());

        if (tmp == null)
            return null;
        else {
            String newPassword = PasswordUtil.genPassword(passwordKey, tmp.getSalt());
            if (newPassword.equals(tmp.getPassword())) {
                Hibernate.initialize(tmp.getUser());
                User user = getWithAllInfo(tmp.getUser().getId());
                return user;
            } else
                return null;
        }
    }

    @Override
    @Transactional(readOnly=true)
    public User getByAccount(String account) {
        return this.getUserDAO().getByAccount(account);
    }

    @Override
    public User getByEmail(String email) {
        return this.getUserDAO().getByEmail(email);
    }

    @Override
    public boolean remove(long id) {
        int r=this.getUserDAO().remove(id);
        return r>0;
    }

    @Override
    public User getAppUser(String account, String passwordKey) {
        // TODO Auto-generated method stub
        Authentication tmp = getAuthenticationDAO().getByLogin(account, "Authentication");

        if (tmp == null)
            return null;
        else {
            String newPassword = PasswordUtil.genPasswordByEncryptPassword(passwordKey, tmp.getSalt());
            if (newPassword.equals(tmp.getPassword())) {
                Hibernate.initialize(tmp.getUser());
                User user = getWithAllInfo(tmp.getUser().getId());
                return user;
            } else{
                return null;
            }
        }
    }
    
    
}
