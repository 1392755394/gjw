package com.gjw.company.service.salestool;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.salestool.Captcha;

public interface ICaptchaService extends IService{
    public Captcha listByID(Long id);

    public boolean updateCaptcha(Captcha model);

    public boolean createCaptcha(Captcha model);
    
    public long count(Captcha model);
    /**
     * 
    * @Description  分页验证码
    * @param cap
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月9日 下午4:32:07
     */
    public List<Captcha> pageBycaptchaAndBuilding(Captcha cap);
    
    /**
     * 
    * @Description  总数
    * @param cap
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月9日 下午4:32:51
     */
    public Long  countBycaptchaAndBuilding(Captcha cap);
    
    /**
     * 
    * @Description  批量删除
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月9日 下午5:00:04
     */
    public boolean batchDel(String ids);
    
    /**
     * 
    * @Description  根据验证码查列表
    * @param captcha
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月11日 下午4:34:57
     */
    public List<Captcha> listByCaptcha(String captcha);
    
}
