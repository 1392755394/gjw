package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.store.GesStoreLocation;

/**
 * 库位管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 上午9:33:52
 * 
 */
public interface IGesStoreLocationService extends IService {

    /**
     * 库位分页总数
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月10日 上午9:34:03
     */
    public Long count(GesStoreLocation model);

    /**
     * 库位分页查询
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月10日 上午9:34:18
     */
    public List<?> pageByStoreLocation(GesStoreLocation model);

    /**
     * 根据ID 查询库位
     * 
     * @Description
     * @param id
     * @return
     * @author gwb
     * @date 2015年12月10日 上午10:12:07
     */
    public GesStoreLocation getByID(Long id);

    /**
     * 修改信息
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月10日 上午10:19:13
     */
    public boolean update(GesStoreLocation model);

    /**
     * 新增库位信息
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月10日 上午10:19:34
     */
    public boolean create(GesStoreLocation model);

    /**
     * 根据id删除库位
     * 
     * @Description
     * @param ids
     * @return
     * @author gwb
     * @date 2015年12月10日 上午10:55:51
     */
    public boolean delBatchById(String ids);

}
