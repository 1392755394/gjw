package com.gjw.company.dao.shop;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.shop.GesShopOrderFeedback;

public interface IGesShopOrderFeedbackDAO extends IDAO{
    public GesShopOrderFeedback listByID(Long id);

    public boolean updateGesShopOrderFeedback(GesShopOrderFeedback model);

    public boolean createGesShopOrderFeedback(GesShopOrderFeedback model);
    
    public long count(GesShopOrderFeedback model);
    
    public List<GesShopOrderFeedback> listByGesShopOrderFeedback(GesShopOrderFeedback model);
}
