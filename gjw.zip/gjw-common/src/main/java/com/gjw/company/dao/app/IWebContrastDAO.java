package com.gjw.company.dao.app;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.app.WebContrast;

public interface IWebContrastDAO extends IDAO{
    public WebContrast get(Long id);

    public List<WebContrast> getList(WebContrast model);
    
    public boolean addWebContrast(WebContrast webContrast);
    
    public void updateWebContrast(WebContrast webContrast);
}
