package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;

/**
 * 
* @Description: 
* @author  qingye
* @date Dec 23, 2015 3:27:30 PM
*
 */
public interface IUserInfoDAO extends IDAO {
    public UserInfo get(Long id);

    /** 
    * @Description  
    * @param id
    * @return
    * @author qingye   
    * @date Jan 7, 2016 9:53:14 AM
    */
    
    public List<User> pageUserInfoByOwnerForGes(UserInfo owner);

    /** 
    * @Description  
    * @param owner
    * @return
    * @author qingye   
    * @date Jan 7, 2016 9:59:20 AM
    */
    
    long countUserInfoByOwnerForGes(UserInfo owner);

    /** 
    * @Description  
    * @param orgId
    * @param orgType
    * @return
    * @author qingye   
    * @date Jan 7, 2016 10:04:13 AM
    */
    
    public List<UserInfo> getByOrgIdAndTypeForGes(Long orgId, String orgType);

    /** 
    * @Description  
    * @param userInfo
    * @return
    * @author qingye   
    * @date Jan 9, 2016 11:17:05 AM
    */
    
    public Long countForGes(UserInfoGES userInfo);

    /** 
    * @Description  
    * @param userInfo
    * @return
    * @author qingye   
    * @date Jan 9, 2016 11:18:09 AM
    */
    
    public List<User> pageForGes(UserInfoGES userInfo);
    
    
    public UserInfoGES userInfoForGes(UserInfoGES userInfo);
}
