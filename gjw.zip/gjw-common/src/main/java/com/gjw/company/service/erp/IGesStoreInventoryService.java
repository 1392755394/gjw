package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.vo.StoreInventoryVO;

/**
 * 库存管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 下午5:24:58
 * 
 */
public interface IGesStoreInventoryService extends IService {

    /**
     * 仓库管理
     * <p>
     * 库存分页查询
     * 
     * @Description
     * @param gesStoreInventory
     * @return
     * @author gwb
     * @date 2016年1月7日 下午2:00:16
     */
    public List<GesStoreInventory> pageByGesStoreInventory(StoreInventoryVO gesStoreInventory);

    /**
     * 仓库管理
     * <p>
     * 库存分页总数
     * 
     * @Description
     * @param gesStoreInventory
     * @return
     * @author gwb
     * @date 2016年1月7日 下午2:00:34
     */
    public Long count(StoreInventoryVO gesStoreInventory);

}
