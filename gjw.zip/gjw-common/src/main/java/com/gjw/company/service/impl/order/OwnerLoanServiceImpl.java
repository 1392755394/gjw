package com.gjw.company.service.impl.order;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.common.constants.GoodsConstant;
import com.gjw.company.dao.order.ILoanDictDAO;
import com.gjw.company.dao.order.IOwnerLoanDAO;
import com.gjw.company.service.order.IHttpRequestService;
import com.gjw.company.service.order.IOwnerLoanService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.LoanApplyInfo;
import com.gjw.entity.order.LoanDict;
import com.gjw.entity.shop.GesShop;
import com.gjw.gjb.constants.Confirm;
import com.gjw.gjb.constants.Constants;
import com.gjw.gjb.constants.LoanConstant;
import com.gjw.gjb.model.PackageRespXmlInfo;
import com.gjw.gjb.model.PackageSendXmlInfo;
import com.gjw.gjb.model.PubSendXmlInfo;
import com.gjw.gjb.model.ReqSendXmlInfo;
import com.gjw.gjb.utils.Base64;
import com.gjw.gjb.utils.RASUtil;
import com.gjw.gjb.utils.Tool;
import com.gjw.utils.DateUtil;
import com.gjw.vo.order.LoanApplyInfoVO;

@Component("ownerLoanServiceImpl")
public class OwnerLoanServiceImpl implements IOwnerLoanService {
	
	private final static Logger log=LoggerFactory.getLogger(OwnerLoanServiceImpl.class);
	
	@Resource(name="ownerLoanDAOHibernateImpl")
	private IOwnerLoanDAO ownerLoanDAO;
	
	public IOwnerLoanDAO getOwnerLoanDAO() {
		return ownerLoanDAO;
	}

	public void setOwnerLoanDAO(IOwnerLoanDAO ownerLoanDAO) {
		this.ownerLoanDAO = ownerLoanDAO;
	}
	
	@Resource(name="loanDictDAOHibernate")
	private ILoanDictDAO loanDictDAO;
	
	@Resource(name="httpRequestServiceImpl")
	private IHttpRequestService httpRequestService;

	/**
     * 根据订单的id查询订单的相关信息
     * @param orderId 订单id
     */
	@Override
	@Transactional(readOnly=true)
	public LoanApplyInfoVO queryLoanOrderInfo(Long orderId) {
		LoanApplyInfoVO loanApplyInfoExt=getOwnerLoanDAO().queryLoanOrderInfo(orderId);
        log.info("该订单关联的产品包类型是否为爆款："+loanApplyInfoExt.getIsPromotion());
        if(loanApplyInfoExt.getIsPromotion()){
            //是爆款 面积取订单中的面积
            log.info("房产面积取订单中的面积："+loanApplyInfoExt.getHouseAcreage());
        }else{
            //不是爆款 面积取房屋表中的面积
            log.info("房产面积取房屋表中的面积："+loanApplyInfoExt.getGoodsSize()+",订单中的面积为："+loanApplyInfoExt.getHouseAcreage());
            loanApplyInfoExt.setHouseAcreage(loanApplyInfoExt.getGoodsSize());
            log.info("房产面积为："+loanApplyInfoExt.getHouseAcreage());
        }
        return loanApplyInfoExt;
	}

	/**
     * 统计次数及是否已申请成功
     * @param orderId
     * @return
     */
	@Override
	@Transactional(readOnly=true)
	public String countOwnerLoanTimes(Long orderId) {
		long times=getOwnerLoanDAO().countOwnerLoanTimes(orderId);
        if(times>0){
            return "0";//申请成功
        }else{
            long totalTimes=getOwnerLoanDAO().countApplyTimes(orderId);
            if(totalTimes>=10){
                return "1";//申请太频繁
            }else{
                return "2";//可以申请
            }
        }
	}

	/**
     * 根据贷款金额计算不同期数的还款数
     * @param amount
     */
	@Override
	@Transactional(readOnly=true)
	public List<Map<String, String>> loanCalculate(BigDecimal amount) {
		LoanDict dict=new LoanDict();
        dict.setCode(LoanConstant.LOAN_RATE);
        //获取利率信息
        List<LoanDict> dictList=loanDictDAO.queryByCIP(dict);
        List<Map<String, String>> list=new ArrayList<Map<String,String>>();
        //循环
        for(LoanDict d: dictList){
            //总利息
            BigDecimal totalInterest = amount.multiply(new BigDecimal(d.getValue())).multiply(new BigDecimal(d.getLevel()));
            //每期利息
            BigDecimal averageInterest = totalInterest.divide(new BigDecimal(d.getName()), 2, RoundingMode.HALF_UP);
            //每期还款额
            BigDecimal averageMoney = (amount.add(totalInterest)).divide(new BigDecimal(d.getName()), 2, RoundingMode.HALF_UP);
            Map<String, String> map=new HashMap<String, String>();
            map.put("term", d.getName());
            map.put("repay", averageMoney.toString());
            map.put("charge", averageInterest.toString());
            list.add(map);
        }
        return list;
	}

	/**
     * 根据输入的金额和贷款期数计算还款数
     * 信用卡分期付款每期还款额=（分期金额+分期金额*分期期数的手续费费率）/分期期数
     * @param inputAmount
     * @param term
     */
	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> loanRepayCalcu(BigDecimal inputAmount, int term) {
		LoanDict dict=new LoanDict();
        dict.setCode(LoanConstant.LOAN_RATE);
        dict.setName(term+"");
        //获取利率信息
        LoanDict dictOne=loanDictDAO.queryRate(dict);
        Map<String, Object> map=new HashMap<String, Object>();
        //手续费总额
        BigDecimal charge=inputAmount.multiply(new BigDecimal(dictOne.getValue())).multiply(new BigDecimal(dictOne.getLevel())).setScale(2,RoundingMode.HALF_UP);
        log.error("手续费总额为："+charge+",转double值为："+charge.doubleValue());
        //需要还款的总额
        BigDecimal totalRepay = inputAmount.add(charge);
        log.error("需要还款的总金额为："+totalRepay);
        //之后每期数额
        BigDecimal averageRepay = totalRepay.divide(new BigDecimal(term), 0, RoundingMode.DOWN);
        log.error("除去第一个月后，每个月需要还款的金额为："+averageRepay);
        // 首期数额
        BigDecimal firstRepay = totalRepay.subtract(averageRepay.multiply(new BigDecimal(term-1)));
        log.error("第一个月应还款金额为："+firstRepay);
        map.put("rate", dictOne.getValue());
        map.put("firstMonthRepay", firstRepay);
        map.put("everyMonthRepay", averageRepay);
        return map;
	}

	/**
     * 统计本日内申请的次数
     */
	@Override
	@Transactional(readOnly=true)
	public String countApplyTimes(long orderId) {
		long times=getOwnerLoanDAO().countApplyTimes(orderId);
        if(times>=10){
            return "false";
        }else{
            return "true";
        }
	}

	/**
     * 保存业主贷款信息
     * @param 
     */
	@Override
	@Transactional
	public LoanApplyInfo addOwnerLoanInfo(LoanApplyInfoVO loanApplyInfoExt,
			LoanApplyInfo loanApplyInfo) {
		//填充实体属性
		Goods tempGoods=new Goods();
		tempGoods.setId(loanApplyInfoExt.getGoodsId());
        loanApplyInfo.setGoods(tempGoods);
        GesShop tempShop=new GesShop();
        tempShop.setId(loanApplyInfoExt.getShopId());
        loanApplyInfo.setShop(tempShop);
        //生成交易流水号
        String code=DateUtil.formatYMDHMS(new Date()) + (int) (Math.random() * 1000000000);
        loanApplyInfo.setCmptxsno(code);
        log.error("贷款交易流水号为："+code);
        //保存数据
        getOwnerLoanDAO().addOwnerLoanInfo(loanApplyInfo);
        log.error("信息的id为："+loanApplyInfo.getId());
        return loanApplyInfo;
	}

	/**
     * 贷款信息发送给银行(需要修改，异常处理不好)
     * @param loanApplyInfo
     * @return
     */
	@Override
	@Transactional
	public String loanInfoSendToBank(LoanApplyInfoVO loanApplyInfoExt,LoanApplyInfo loanApplyInfo,
			String confirmUrl) {
		log.info("贷款信息本地库id为："+loanApplyInfo.getId());
        //判断id是否大于零，判断信息是否保存成功
        if(loanApplyInfo.getId()>0){
            //组装发给银行的信息
            PackageSendXmlInfo psxi=assemblePackageXmlInfo(loanApplyInfoExt,loanApplyInfo);
            String psxiToXml=psxi.toXmlString(null, true);
//          String psxiToXml="<pub><orgcode>GJW</orgcode><zoneno>1202</zoneno><txcode>20301</txcode><cmpdate>20151211</cmpdate><cmptime>192748</cmptime><cmptxsno>LOAN20151211192748918350966</cmptxsno></pub><req><contractno>1003</contractno><subsellerid>1500000004</subsellerid><subsellername>asdffffs</subsellername><houseaddr>address</houseaddr><housesize>90.0</housesize><amount>100000.0000</amount><custname>department</custname><idtype>000</idtype><idno>369852147852369852</idno><me>未婚</me><corpname>tear</corpname><mobile>18653261452</mobile><yearincome>100000</yearincome><housetype>002</housetype><houseowntype>001</houseowntype><loanamount>80000</loanamount><term>36</term></req>";
            log.info("要发送给银行的贷款的信息为："+psxiToXml);
            //对贷款的信息进行加签
            String signature="";
            try {
                signature = RASUtil.sign(psxiToXml.getBytes(Confirm.charset_gbk));
            } catch (UnsupportedEncodingException e1) {
                log.error("cuowu",e1);
                return "false";
            }
//            String signature=RASUtil.sign(psxiToXml.getBytes());
            log.error("加签之后的信息为："+signature);
            if("".equals(signature)){
                return "false";
            }
            String base64Xml = null;
            String xml=psxi.addGbkXmlHeadAndPackage(psxiToXml);
//          String xml="<?xml version=\"1.0\" encoding=\"GBK\"?><package>"+psxiToXml+"</package>";
            log.info("完整的xml信息为："+xml);
            //base64编码
            base64Xml = Base64.encode(xml,Confirm.charset_gbk);
            log.error("xml编码后的信息为："+base64Xml);
            String resp=httpRequestService.sendRequestToBank(base64Xml, signature,confirmUrl);
//            String resp=httpRequestService.dataPost(base64Xml, signature);
            if("".equals(resp)){
                return "false";
            }
            String decodeResp=Base64.decode(resp, Confirm.charset_gbk);
            log.error("解码后的银行返回信息为："+decodeResp);
            //将xml信息转为model
            PackageRespXmlInfo prxi=new PackageRespXmlInfo();
            prxi.parseXml(decodeResp, prxi);
            log.error("贷款信息提交给银行后，银行返回的结果为"+prxi.getPub().getRetcode());
            if(prxi==null||prxi.getPub().getRetcode()==null){
                log.error("银行返回的信息错误或者解析错误！");
                return "false";
            }
            //验签
            String respSignature=prxi.getSignature();
            log.error("银行返回的签名为："+respSignature);
            String signatureXml=decodeResp.substring(decodeResp.indexOf("<pub>"),decodeResp.indexOf("<signature>"));
            log.error("加签的内容为："+signatureXml);
            try {
                if(RASUtil.verify(respSignature, signatureXml.getBytes(Confirm.charset_gbk))){
                    //验签成功 更新本地记录的状态 
                    if(prxi.getPub().getRetcode().equals("00000")){
                        loanApplyInfo.setLoanApplyStatus(LoanConstant.LOAN_STATUS_SUCCESSS);
                        getOwnerLoanDAO().updateOwnerLoanInfoStatus(loanApplyInfo);
                        return "true";
                    }else{
                        loanApplyInfo.setLoanApplyStatus(LoanConstant.LOAN_STATUS_FAILURE);
                        getOwnerLoanDAO().updateOwnerLoanInfoStatus(loanApplyInfo);
                        return "false";
                    }
                }else{
                    log.info("验签失败！");
                    //更新申请状态为：retcode成功：提交成功，验签失败 retcode失败：提交失败，验签失败
                    if(prxi.getPub().getRetcode().equals("00000")){
                        loanApplyInfo.setLoanApplyStatus(LoanConstant.LOAN_STATUS_SUCCESSS_SIGN);
                        getOwnerLoanDAO().updateOwnerLoanInfoStatus(loanApplyInfo);
                    }else{
                        loanApplyInfo.setLoanApplyStatus(LoanConstant.LOAN_STATUS_FAILURE_SIGN);
                        getOwnerLoanDAO().updateOwnerLoanInfoStatus(loanApplyInfo);
                    }
                    return "false";
                }
            } catch (UnsupportedEncodingException e) {
                log.error("验签失败",e);
                return "false";
            }
            
        }else{
            return "false";
        }
	}
	
	/**
     * 组装贷款信息
     * @param loanApplyInfo
     * @return
     */
    public PackageSendXmlInfo assemblePackageXmlInfo(LoanApplyInfoVO loanApplyInfoExt,LoanApplyInfo loanApplyInfo){
        PubSendXmlInfo pub=new PubSendXmlInfo();
        pub.setOrgcode(Constants.ORG_CODE);
        pub.setZoneno(loanApplyInfo.getCityCode());
        pub.setTxcode(Confirm.loanTxcode);
        String date = Tool.formatTime(new Date());
        pub.setCmpdate(date.substring(0, 8));
        pub.setCmptime(date.substring(8));
        pub.setCmptxsno(Constants.OWNER_LOAN_PREFIX+loanApplyInfo.getCmptxsno());
        PackageSendXmlInfo pack=new PackageSendXmlInfo();
        pack.setPub(pub);
        ReqSendXmlInfo req=new ReqSendXmlInfo();
        req.setContractno(loanApplyInfo.getOrder().getId()+"");
        req.setSubsellerid(loanApplyInfoExt.getShopCode());
        //后期银行要求加的
        req.setSubsellername(loanApplyInfoExt.getShopName());
        req.setHouseaddr(loanApplyInfoExt.getHouseAddress());
        req.setHousesize(loanApplyInfoExt.getHouseAcreage()+"");
        req.setAmount(new BigDecimal(loanApplyInfoExt.getTotalAmount()).divide(new BigDecimal(100)) +"");
        req.setCustname(loanApplyInfo.getCustomerName());
        req.setIdtype(loanApplyInfo.getIdentityType());
        req.setIdno(loanApplyInfo.getIdentityNumber());
        req.setMe(loanApplyInfo.getMaritalStatus().equals("0")?LoanConstant.MARITAL_MARRIED:LoanConstant.MARITAL_SINGLE);
        req.setCorpname(loanApplyInfo.getWorkDept());
        req.setMobile(loanApplyInfo.getPhone());
        req.setYearincome(new BigDecimal(loanApplyInfo.getYearIncome()).divide(new BigDecimal(100))+"");
        req.setHousetype(loanApplyInfo.getHouseType());
        req.setHouseowntype(loanApplyInfo.getHouseOwnType());
        req.setLoanamount(new BigDecimal(loanApplyInfo.getAmount()).divide(new BigDecimal(100))+"");
        req.setTerm(loanApplyInfo.getTerm()+"");
        pack.setReq(req);
        log.error("贷款信息："+pack.toXmlStringRecursion(null, true));
        
        return pack;
    }


}
