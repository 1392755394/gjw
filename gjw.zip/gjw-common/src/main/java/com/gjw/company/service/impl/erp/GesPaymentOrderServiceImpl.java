package com.gjw.company.service.impl.erp;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.erp.IGesPaymentOrderService;
import com.gjw.entity.erp.GesPaymentOrder;
import com.gjw.vo.GesPaymentOrderVO;

/**
 * 付款单service实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月31日 
 *
 */
@Component("gesPaymentOrderServiceImpl")
public class GesPaymentOrderServiceImpl extends AbstractServiceImpl implements IGesPaymentOrderService {

    @Override
    @Transactional(readOnly = true)
    public List<GesPaymentOrder> pagePaymentOrder(GesPaymentOrderVO paymentOrder) {
        List<GesPaymentOrder> list = super.getGesPaymentOrderDAO().pagePaymentOrder(paymentOrder);
        for (GesPaymentOrder r: list) {
            if (r.getAuditUser() != null) {
                Hibernate.initialize(r.getAuditUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
            }
        }
        
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countPaymentOrder(GesPaymentOrderVO paymentOrder) {
        return super.getGesPaymentOrderDAO().countPaymentOrder(paymentOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public GesPaymentOrder queryByID(Long id) {
        return super.getGesPaymentOrderDAO().queryByID(id);
    }

    @Override
    @Transactional
    public long create(GesPaymentOrder paymentOrder) {
        return super.getGesPaymentOrderDAO().create(paymentOrder);
    }

    @Override
    @Transactional
    public boolean update(GesPaymentOrder paymentOrder) {
        return super.getGesPaymentOrderDAO().update(paymentOrder);
    }

}
