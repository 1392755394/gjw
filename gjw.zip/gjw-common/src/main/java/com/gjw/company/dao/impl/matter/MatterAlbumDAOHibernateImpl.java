package com.gjw.company.dao.impl.matter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IMatterAlbumDAO;
import com.gjw.entity.matter.MatterAlbum;

/**
 * 物料规格dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月22日
 * 
 */
@Component("matterAlbumDAOHibernateImpl")
public class MatterAlbumDAOHibernateImpl extends AbstractDAOHibernateImpl implements IMatterAlbumDAO {

    @Override
    protected Class<?> getEntityClass() {
        return MatterAlbum.class;
    }

    @Override
    public Long create(MatterAlbum matterAlbum) {
        super.add(matterAlbum);
        return matterAlbum.getId();
    }

    @Override
    public boolean deleteById(long id) {
        return super.remove(id) == 1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<MatterAlbum> listAlbumByMatterID(long matterId) {

        String hql = "from MatterAlbum ma left join fetch ma.image "
                   + "where ma.invalid = false and ma.matter.id = ? order by ma.orderTag asc";
        
        return (List<MatterAlbum>) super.getHibernateTemplate().find(hql, matterId);
    }

}
