package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.vo.GoodsMarkVO;

/**
 * 
 * @Description: 产品包物料关系service接口
 * @author zhaoyonglian
 * @date 2015年12月29日 上午11:43:36
 * 
 */
public interface IGoodsMarkService extends IService {

    /**
     * 
     * @Description 房间及类型 参数列表mark
     * @param mark
     * @return
     * @author zhaoyonglian
     * @date 2015年12月30日 下午2:41:11
     */
    public List<GoodsMark> listMarkByRoomIdAndType(Long roomId, Long type);

    /**
     * 
     * @Description 查看详情
     * @param id
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:34:16
     */
    public GoodsMark queryById(Long id);

    /**
     * 
     * @Description 删除关系
     * @param ids
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:35:36
     */
    public boolean delBatchByID(String ids);

    /**
     * 
     * @Description 修改关系
     * @param mark
     * @return
     * @author zhaoyonglian
     * @date 2015年12月30日 下午2:42:22
     */
    public boolean update(GoodsMark mark);

    /**
     * 
     * @Description 新增产品包物料关系
     * @param goodsMatter
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:36:38
     */
    public long create(GoodsMark mark);

    /**
     * 
     * @Description 新增锚点及标配选配物料信息
     * @param mark
     * @return
     * @author zhaoyonglian
     * @date 2015年12月31日 上午10:36:03
     */
    public boolean createMarkAndMatter(GoodsMarkVO mark);

    /**
     * 
     * @Description 修改锚点及标配选配物料信息
     * @param mark
     * @return
     * @author zhaoyonglian
     * @date 2016年1月4日 下午5:52:11
     */
    public boolean updateMarkAndMatter(GoodsMarkVO markVO);

    /**
     * 
     * @Description 删除锚点，并把goods_matter关联的锚点置空
     * @param markId
     * @return
     * @author zhaoyonglian
     * @date 2016年1月6日 下午1:45:39
     */
    public boolean deleteById(Long markId);

    // DIY 接口start

    /**
     * 
     * @Description 产品包下所有锚点
     * @param goodsId
     * @return
     * @author zhaoyonglian
     * @date 2016年1月11日 下午4:43:33
     */
    public List<GoodsMark> listMarkByGoodsId(Long goodsId);
    
    /**
     * 
    * @Description  根据房间id删除锚点
    * @param roomId
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月13日 下午1:23:21
     */
    public boolean deleteByRoomId(Long roomId);
}
