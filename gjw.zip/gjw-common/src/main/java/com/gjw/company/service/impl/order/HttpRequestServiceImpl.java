package com.gjw.company.service.impl.order;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.company.service.order.IHttpRequestService;
import com.gjw.gjb.constants.Confirm;
import com.gjw.gjb.constants.Constants;
import com.gjw.gjb.utils.Base64;

/**
 * 提供公共服务
 * 
 * @author User
 * 
 */
@Component("httpRequestServiceImpl")
public class HttpRequestServiceImpl implements IHttpRequestService {
	
	private static final Logger log=LoggerFactory.getLogger(HttpRequestServiceImpl.class);

	/**
	 * 发送请求给银行
	 * @param xmlStr   base64编码的xml信息
	 * @param signature 加签的信息
	 */
	@Override
	public String sendRequestToBank(String xmlStr, String signature) {
		return sendMessageByHttp(xmlStr, signature,null);
	}

	/**
	 * 发送请求给银行 
	 * @param xmlStr base64编码的xml信息
	 * @param signature 加签的信息
	 * @param url 发送的地址
	 */
	@Override
	public String sendRequestToBank(String xmlStr, String signature, String url) {
		return sendMessageByHttp(xmlStr, signature,url);
	}
	
	/**
	 * http请求私有方法
	 * @param xmlStr
	 * @param signature
	 * @param url
	 * @return
	 */
	private String sendMessageByHttp(String xmlStr, String signature,String url) {
		log.error("向银行发起请求开始！");
		String stringXml = "";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		List<BasicNameValuePair> pairs = new ArrayList<BasicNameValuePair>();
		pairs.add(new BasicNameValuePair("reqdata", xmlStr));
		pairs.add(new BasicNameValuePair("signature", signature));
		pairs.add(new BasicNameValuePair("charset", Constants.CHARSET));
		UrlEncodedFormEntity entity = null;
		try {
			entity = new UrlEncodedFormEntity(pairs, Constants.CHARSET);
		} catch (UnsupportedEncodingException e2) {
			log.error("参数编码出错",e2);
			return stringXml;
		}
		HttpPost httppost = new HttpPost();
		if(url==null){
			httppost = new HttpPost("");
		}else{
			httppost = new HttpPost(url);
		}
		httppost.setEntity(entity);
		httppost.setHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
		httppost.setConfig(requestConfig);
		CloseableHttpResponse responseBody = null;
		log.info("#######################responseBody请求开始###############");
		try {
			responseBody = httpclient.execute(httppost);
			log.error("--------------------向银行发起请求响应信息="+ responseBody);
			stringXml = EntityUtils.toString(responseBody.getEntity(),Confirm.charset_gbk);
			log.error("##############################="+ Base64.decode(stringXml, Confirm.charset_gbk));
		} catch (ClientProtocolException e1) {
			log.error("-------------------httpclient.execute请求失败=", e1);
			return stringXml;
		} catch (IOException e1) {
			log.error("--------------------httpclient.executet请求出现异常=", e1);
			return stringXml;
		} finally {
			try {
				httpclient.close();
				log.error("-------------------------------httpclient关闭成功-------------------");
			} catch (IOException e) {
				log.error("-------------------------------httpclient关闭失败-------------------",e);
			}
		}
		return stringXml;
	}
	
	/***
	 * 测试
	 */
	public String dataPost(String reqdata,String signature){
        CloseableHttpClient httpclient = HttpClients.createDefault();
        List<BasicNameValuePair> pairs = new ArrayList<BasicNameValuePair>();
        pairs.add(new BasicNameValuePair("reqdata", reqdata));
        pairs.add(new BasicNameValuePair("signature", signature));
        pairs.add(new BasicNameValuePair("charset", Constants.CHARSET));
        pairs.add(new BasicNameValuePair("url","http://12.1.1.1:12074"));
        UrlEncodedFormEntity entity = null;
        try {
            entity = new UrlEncodedFormEntity(pairs, Constants.CHARSET);
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        HttpPost httppost = new HttpPost("http://xiaoji.goujiawang.com/alert/redirectMethod");//
        httppost.setEntity(entity);
        httppost.setHeader("Content-Type",
                "application/x-www-form-urlencoded;charset=utf-8");
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(15000).setConnectTimeout(15000).build();// 设置请求和传输超时时间
        httppost.setConfig(requestConfig);
        CloseableHttpResponse responseBody = null;
        String stringXml = "";
        try {
            responseBody = httpclient.execute(httppost);
            stringXml = EntityUtils.toString(responseBody.getEntity(),
                    Confirm.charset_gbk);
        } catch (ClientProtocolException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
            try {
                httpclient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
      return stringXml;
  }

	

}
