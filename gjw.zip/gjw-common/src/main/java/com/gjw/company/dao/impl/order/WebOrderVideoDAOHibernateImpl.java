package com.gjw.company.dao.impl.order;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IWebOrderVideoDAO;
import com.gjw.entity.order.WebOrderVideo;
import com.gjw.utils.StringUtil;

/**
 * 
 * @Description: 日志实现类
 * @author zhaoyonglian
 * @date 2015年12月19日 上午10:41:15
 * 
 */
@Component("webOrderVideoDAOHibernateImpl")
public class WebOrderVideoDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebOrderVideoDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebOrderVideo.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebOrderVideo> listByOrder(Long orderId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderVideo where order_id = :order_id order by id desc");
        Query query = session.createQuery(hql.toString());
        query.setLong("order_id", orderId);
        return query.list();
    
    }


    @Override
    public boolean updateVideo(WebOrderVideo video) {
        // TODO Auto-generated method stub
        WebOrderVideo vi = (WebOrderVideo) super.get(video.getId());
//        StringUtil.copyProperties(video, vi);
        StringUtil.copyPropertiesAllowEmpty(video, vi);
        super.update(vi);
        return true;
    }

}
