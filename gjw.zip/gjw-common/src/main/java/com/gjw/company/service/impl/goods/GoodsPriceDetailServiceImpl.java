package com.gjw.company.service.impl.goods;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.service.goods.IGoodsPriceDetailService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsPriceDetail;

/**
 * 产品包价格service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月25日
 * 
 */
@Component("goodsPriceDetailServiceImpl")
public class GoodsPriceDetailServiceImpl extends AbstractServiceImpl implements IGoodsPriceDetailService {

    @Override
    @Transactional(readOnly = true)
    public List<GoodsPriceDetail> listGoodsPriceByGoodsId(Long goodsId) {
        List<GoodsPriceDetail> list = super.getGoodsPriceDetailDAO().listGoodsPriceByGoodsId(goodsId);
        if (list.size() > 0) {
            for (GoodsPriceDetail gp: list) {
                Hibernate.initialize(gp.getType());
            }
        } else {
            Goods goods = new Goods();
            goods.setId(goodsId);
            List<Dictionary> typeList = super.getDictionaryDao().listChildrenById(DictionaryConstants.DICTIONARY_GOODS_PRICE);
            for (Dictionary type: typeList) {
                GoodsPriceDetail goodsPriceDetail = new GoodsPriceDetail();
                goodsPriceDetail.setGoods(goods);
                goodsPriceDetail.setType(type);
                goodsPriceDetail.setPrice(0L);
                list.add(goodsPriceDetail);
            }
        }
        return list;
    }

    @Override
    @Transactional
    public boolean saveGoodsPrice(List<GoodsPriceDetail> goodsPriceList) {
        
        /**产品总价 **/
        Long totalPrice = 0L;
        for(GoodsPriceDetail goodsPriceDetail : goodsPriceList) {
            Long id = goodsPriceDetail.getId();
            if(id != null && id > 0){
                super.getGoodsPriceDetailDAO().update(goodsPriceDetail);
            }else{
                super.getGoodsPriceDetailDAO().create(goodsPriceDetail);
            }
            totalPrice = totalPrice + goodsPriceDetail.getPrice();
        }
        
        Goods goods = goodsPriceList.get(0).getGoods();
        goods.setOriginalPrice(totalPrice);
        super.getGoodsDAO().update(goods);
        
        return true;
    }

}
