package com.gjw.company.service.impl.user;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.user.IUserRoleService;
import com.gjw.entity.user.UserRoleItem;

@Service("userRoleServiceImpl")
@Transactional
public class UserRoleServiceImpl extends AbstractServiceImpl implements IUserRoleService {

    @Override
    public List<UserRoleItem> listRolesOfUser(long userId) {
        return super.getUserRoleDAO().listRolesOfUser(userId);
    }

}
