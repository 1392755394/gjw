package com.gjw.company.service.impl.user;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.service.user.IAuthenticationService;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.User;
import com.gjw.utils.PasswordUtil;
import com.gjw.utils.RandomUtil;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("authenticationServiceImpl")
@Transactional
public class AuthenticationServiceImpl extends AbstractServiceImpl implements IAuthenticationService {

    @Override
    public void add(Authentication authentication) {
        authentication.setLogin(authentication.getLogin().toLowerCase());
        getAuthenticationDAO().add(authentication);
    }

    @Override
    public Authentication login(Authentication authentication) {
        Authentication tmp = getAuthenticationDAO().getByLogin(authentication.getLogin(),
                authentication.getClass().getSimpleName());
        if (tmp == null)
            return null;
        else {
            String newPassword = PasswordUtil.genPassword(authentication.getPassword(), tmp.getSalt());
            if (newPassword.equals(tmp.getPassword())) {
                Hibernate.initialize(tmp.getUser());
                return tmp;
            } else
                return null;
        }

    }

    @Override
    public void modifyPassword(User user, String oldPassword, String newPassword) {
        if (user == null || user.getId() == null)
            throw new ErrorCodeException(SECode.u_100001);
        List<Authentication> authList = this.getAuthenticationDAO().findByUser(user);
        if (!authList.isEmpty()) {
            if (PasswordUtil.genPassword(oldPassword, authList.get(0).getSalt()).equals(authList.get(0).getPassword())) {
                for (Authentication auth : authList) {
                    auth.setPassword(PasswordUtil.genPassword(newPassword, auth.getSalt()));
                    this.getAuthenticationDAO().update(auth);
                }
            } else
                throw new ErrorCodeException(SECode.u_100002);
        } else {
            throw new ErrorCodeException(SECode.u_100003);
        }
    }

    @Override
    public Authentication getByLogin(String login) {
        Authentication authen = this.getAuthenticationDAO().getByLogin(login, Authentication.class.getSimpleName());
        if (authen != null) {
            Hibernate.initialize(authen.getUser());
        }

        return authen;
    }

    @Override
    public void resetPassword(User user, String newPassword) {
        if (user == null || user.getId() == null)
            throw new ErrorCodeException(SECode.u_100001);
        List<Authentication> authList = this.getAuthenticationDAO().findByUser(user);
        if (!authList.isEmpty()) {
            for (Authentication auth : authList) {
                auth.setPassword(PasswordUtil.genPassword(newPassword, auth.getSalt()));
                this.getAuthenticationDAO().update(auth);
            }
        } else {
            throw new ErrorCodeException(SECode.u_100003);
        }
    }

    @Override
    public int encryptPassword() {
        List<Authentication> authList = this.getAuthenticationDAO().listAllForPassword();
        if (!authList.isEmpty()) {
            for (Authentication auth : authList) {
                auth.setSalt(RandomUtil.randomStr(8));
                auth.setPassword(PasswordUtil.genPasswordByEncryptPassword(auth.getPassword(), auth.getSalt()));
                this.getAuthenticationDAO().update(auth);
            }
            return authList.size();
        }
        return 0;
    }

    @Override
    public void modifyMobilePassword(User user, String oldPassword, String passwordKey) {
        if (user == null || user.getId() == null)
            throw new ErrorCodeException(SECode.u_100001);
        List<Authentication> authList = this.getAuthenticationDAO().findByUser(user);
        if (!authList.isEmpty()) {
            if (PasswordUtil.genPasswordByEncryptPassword(oldPassword, authList.get(0).getSalt()).equals(
                    authList.get(0).getPassword())) {
                for (Authentication auth : authList) {
                    auth.setPassword(PasswordUtil.genPasswordByEncryptPassword(passwordKey, auth.getSalt()));
                    this.getAuthenticationDAO().update(auth);
                }
            } else
                throw new ErrorCodeException(SECode.u_100002);
        } else {
            throw new ErrorCodeException(SECode.u_100003);
        }
    }

}
