package com.gjw.company.service.impl.matter;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.matter.IMatterSpecService;
import com.gjw.entity.matter.MatterSpec;

/**
 * 物料规格service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("matterSpecServiceImpl")
public class MatterSpecServiceImpl extends AbstractServiceImpl implements IMatterSpecService {

    @Override
    @Transactional(readOnly = true)
    public List<MatterSpec> pageMatterSpec(MatterSpec matterSpecCriteria) {
        return super.getMatterSpecDAO().pageMatterSpec(matterSpecCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countMatterSpec(MatterSpec matterSpecCriteria) {
        return super.getMatterSpecDAO().countMatterSpec(matterSpecCriteria);
    }

    @Override
    @Transactional
    public long create(MatterSpec matterSpec) {
        return super.getMatterSpecDAO().create(matterSpec);
    }

    @Override
    @Transactional
    public boolean update(MatterSpec matterSpec) {
        return super.getMatterSpecDAO().update(matterSpec);
    }

    @Override
    @Transactional
    public boolean deletedByID(long id) {
        return super.getMatterSpecDAO().deletedByID(id);
    }

}
