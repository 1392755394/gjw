package com.gjw.company.service.impl.order;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.order.IWebOrderVideoDAO;
import com.gjw.company.service.order.IWebOrderVideoService;
import com.gjw.entity.order.WebOrderVideo;

@Component("webOrderVideoServiceImpl")
public class WebOrderVideoServiceImpl implements IWebOrderVideoService {

    @Autowired
    private IWebOrderVideoDAO dao;

    @Override
    @Transactional(readOnly = true)
    public List<WebOrderVideo> listByOrder(Long orderId) {
        // TODO Auto-generated method stub
        return dao.listByOrder(orderId);
    }

    @Override
    @Transactional
    public boolean insert(WebOrderVideo entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public boolean update(WebOrderVideo entity) {
        // TODO Auto-generated method stub
        return dao.updateVideo(entity);
    }

}
