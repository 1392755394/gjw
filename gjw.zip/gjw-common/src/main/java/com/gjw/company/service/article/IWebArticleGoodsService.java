package com.gjw.company.service.article;

import java.util.List;

import com.gjw.entity.article.WebArticleGoods;


/**
 * created by 重剑 on 2015/9/17 0017
 */
public interface IWebArticleGoodsService {

    /** 
    * @Description  
    * @param articleId
    * @return
    * @author qingye   
    * @date Dec 31, 2015 3:15:15 PM
    */
    
    List<WebArticleGoods> listByArticle(Long articleId);

    /** 
    * @Description  
    * @param item
    * @author qingye   
    * @date Dec 31, 2015 5:07:21 PM
    */
    
    void add(WebArticleGoods item);


    /** 
    * @Description  
    * @param item
    * @author qingye   
    * @date Dec 31, 2015 5:29:27 PM
    */
    
    void deleteByArticleAndGoods(WebArticleGoods item);
}
