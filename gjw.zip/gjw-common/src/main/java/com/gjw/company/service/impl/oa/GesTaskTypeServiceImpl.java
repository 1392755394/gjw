package com.gjw.company.service.impl.oa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.constants.TaskConstant;
import com.gjw.company.dao.oa.IGesTaskTypeDAO;
import com.gjw.company.service.oa.IGesTaskTypeService;
import com.gjw.entity.oa.GesTaskType;
import com.gjw.vo.oa.GesTaskTypeVO;

@Component("gesTaskTypeServiceImpl")
public class GesTaskTypeServiceImpl extends AbstractServiceImpl implements
		IGesTaskTypeService {
	
	@Resource(name="gesTaskTypeHibernateImpl")
	private IGesTaskTypeDAO gesTaskTypeDAO;
	
	public IGesTaskTypeDAO getGesTaskTypeDAO() {
		return gesTaskTypeDAO;
	}

	public void setGesTaskTypeDAO(IGesTaskTypeDAO gesTaskTypeDAO) {
		this.gesTaskTypeDAO = gesTaskTypeDAO;
	}

	/**
	 * 获取任务类型列表
	 * 
	 * @param parentId    父节点id
	 * @param type        类型
	 */
	@Override
	@Transactional(readOnly=true)
	public List<GesTaskTypeVO> listTaskType(long parentId, int type,String orgType) {
		GesTaskType taskType = new GesTaskType();
		taskType.setType(type);
		//任务类型列表排除已删除任务类型
		taskType.setInvalid(TaskConstant.DEL_FLAG_NO);
		// 获取指定区分的全部类型
		List<GesTaskType> allls = getGesTaskTypeDAO().listTaskTypeByType(taskType);
		//设置父节点id
		GesTaskType temp=new GesTaskType();
		temp.setId(parentId);
		taskType.setTaskType(temp);
		// 根据父任务类型取得的子任务类型列表
		List<GesTaskType> ls = getGesTaskTypeDAO().listTaskTypeByTypeAndParentId(taskType);

		List<GesTaskTypeVO> newls = new ArrayList<GesTaskTypeVO>();
		//要获取登录用户的组织类型  ------------------------------------------------------------------
		String orgtype =orgType;
		for (GesTaskType gesTaskType : ls) {
			GesTaskTypeVO taskTypeVO = new GesTaskTypeVO();

			taskTypeVO.setId(gesTaskType.getId());
			taskTypeVO.setName(gesTaskType.getName());
			taskTypeVO.setParentId(gesTaskType.getTaskType().getId());

			// 展开状态
			if (hasChildType(allls, gesTaskType.getId())) {
				taskTypeVO.setState("closed");
				taskTypeVO.setIsLeaf(false);
			} else {
				taskTypeVO.setIsLeaf(true);
			}
			if (isOrgtype(orgtype, taskTypeVO.getName())) {
				newls.add(taskTypeVO);
			}
		}

		return newls;
	}
	
	private boolean hasChildType(List<GesTaskType> allls, long parentId){
		
		for(GesTaskType taskType:allls){
			if(taskType.getTaskType().getId().longValue()==parentId){
				return true;
			}
		}
		return false;
	}
	
	//过滤构家网、城运商、4S店
	private boolean isOrgtype(String orgtype, String name){
			
		if(orgtype.equals("city_operator")){
			if("构家网".equals(name) || "4S店".equals(name)){
				return false;
			}
		}else if(orgtype.equals("shop")){
			if("构家网".equals(name) || "城运商".equals(name)){
				return false;
			}
		}else{
			if("4S店".equals(name) || "城运商".equals(name)){
				return false;
			}
		}

		return true;
	}

    @Override
    @Transactional(readOnly=true)
    public List<Map<String,Object>> listType(int type, String orgType) {
        GesTaskType taskType = new GesTaskType();
        taskType.setType(type);
        //任务类型列表排除已删除任务类型
        taskType.setInvalid(TaskConstant.DEL_FLAG_NO);
        // 获取指定区分的全部类型
        List<GesTaskType> allls = getGesTaskTypeDAO().listTaskTypeByType(taskType);
        //设置父节点id
        GesTaskType temp=new GesTaskType();
        // 根据父任务类型取得的子任务类型列表
        List<GesTaskType> ls = new ArrayList<GesTaskType>();
        if (GesCommonConstants.ORG_TYPE_GJW.equals(orgType)){
            temp.setId(10L);
            taskType.setTaskType(temp);
            ls = getGesTaskTypeDAO().listTaskTypeByTypeAndParentId(taskType);
        } else if (GesCommonConstants.ORG_TYPE_CITY_OPERATOR.equals(orgType)){
            ls.add(getGesTaskTypeDAO().getTaskTypeById(11));
        } else if (GesCommonConstants.ORG_TYPE_SHOP.equals(orgType)){
            ls.add(getGesTaskTypeDAO().getTaskTypeById(12));
        }  

        List<Map<String,Object>> newls = new ArrayList<Map<String,Object>>();

        for (GesTaskType gesTaskType : ls) {
            Map<String,Object> map = new HashMap<String, Object>();
            map.put("name", gesTaskType.getName());
            taskType.setTaskType(gesTaskType);
            List<GesTaskType> ll = getGesTaskTypeDAO().listTaskTypeByTypeAndParentId(taskType);
            List<GesTaskType> children = new ArrayList<GesTaskType>();
            for (GesTaskType taskType2 : ll) {
                if (hasChildType(allls, taskType2.getId())) {
                    taskType.setTaskType(taskType2);
                    children.addAll(getGesTaskTypeDAO().listTaskTypeByTypeAndParentId(taskType));
                }
            }
            if (children != null && children.size() > 0) {
                map.put("children", children);
            } else {
                map.put("children", ll);
            }
            newls.add(map);
        }

        return newls;
    }
	
	
	

}
