package com.gjw.company.service.order;

/**
 * http请求银行服务service，目前使用这种方式提供服务，可以放到goujiabao包中改成工具类
 * @author User
 *
 */
public interface IHttpRequestService {
	 
	public String sendRequestToBank(String xmlStr, String signature);
	
	public String sendRequestToBank(String xmlStr, String signature,String url);
	
	/**
	 * 测试
	 * @param reqdata
	 * @param signature
	 * @return
	 */
	public String dataPost(String reqdata,String signature);

}
