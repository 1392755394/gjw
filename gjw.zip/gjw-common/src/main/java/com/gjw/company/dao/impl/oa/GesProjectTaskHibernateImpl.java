package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.constants.TaskConstant;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesProjectTaskDAO;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesProjectTaskQueryVO;
import com.gjw.vo.oa.GesProjectTaskVO;
import com.gjw.vo.oa.UserVO;

/**
 * 项目任务
 * @author jjw
 *
 */
@Component("gesProjectTaskHibernateImpl")
public class GesProjectTaskHibernateImpl extends AbstractDAOHibernateImpl implements IGesProjectTaskDAO {

	private final static Logger log=LoggerFactory.getLogger(GesProjectTaskHibernateImpl.class);
	
	@Override
	protected Class<?> getEntityClass() {
		return GesProjectTask.class;
	}

	/**
	 * 查询用户的所有任务项目以及最新的交流信息
	 * @param userId
	 * @return
	 */
//	@SuppressWarnings("unchecked")
//	@Override
//	public List<GesProjectTaskQueryVO> queryAllProjectTaskCommunicationByUserId(
//			GesProjectTaskQueryVO gesProjectTaskVO) {
////		StringBuffer hql=new StringBuffer();
////		List<Object> param=new ArrayList<Object>();
////		param.add(false);
////		param.add(false);
////		param.add(gesProjectTaskVO.getUser().getId());
////		hql.append("select b.id,b.content,b.created_datetime createdDatetime,b.IS_URGENCY isUrgency,a.IS_HANDLE isDeal,b.difference,"+
////				"f.USER_NAME userName,f.CHAT_CONTENT chatContent,f.LATEST_TIME latestTime,"+
////				"a.COMMUNICATION_ID communicateId,f.ID latestComId "+   
////				"from ges_project_task b,ges_task_participant a ,"+
////				"(select * from (select c.id,c.TASK_ID,e.REAL_NAME USER_NAME,c.CONTENT CHAT_CONTENT,c.created_datetime LATEST_TIME "+
////				"from ges_communication c,u_user_info e where e.ID=c.USER_ID and c.invalid =? order by c.created_datetime DESC ) t GROUP BY t.TASK_ID ) f  "+
////				"where a.TASK_ID=b.ID and f.TASK_ID=a.TASK_ID AND a.invalid=? AND a.USER_ID=? "+ 							
////				"GROUP BY b.ID ORDER BY f.LATEST_TIME DESC,b.created_datetime DESC ");
////		return (List<GesProjectTaskQueryVO>) super.findByPageSql(hql.toString(), "", param, gesProjectTaskVO, false);
//		
////		String hql="select a,c FROM GesTaskParticipant a "+
////					" left join GesCommunication c on a.task.id = c.task.id "+ 
////					"  WHERE  a.invalid = ? "+
////					" AND a.user.id = ? GROUP BY a ORDER BY c.createdDatetime DESC,a.task.createdDatetime DESC";
//		String hql="SELECT a ,c  FROM com.gjw.entity.oa.GesTaskParticipant a join fetch a.task "+
//				", GesCommunication c join fetch c.user WHERE a.invalid = ? and a.task.id = c.task.id  AND a.user.id = ? "
//				+ "   GROUP BY a ORDER BY c.createdDatetime DESC,a.task.createdDatetime DESC";
//		List<Object> param=new ArrayList<Object>();
//		param.add(false);
//		param.add(gesProjectTaskVO.getUser().getId());
//		super.findByPageCallBack(hql, null, param, gesProjectTaskVO, null);
//		return null;
//	}

	@Override
	public Long countAllProjectTaskCommunicationByUserId(
			GesProjectTaskQueryVO gesProjectTaskVO) {
		StringBuffer sql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		param.add(false);
		param.add(gesProjectTaskVO.getUser().getId());
		sql.append("select count(a.TASK_ID) as count from ges_task_participant a "+
				" where a.invalid=? and a.USER_ID=?");
		Session session = this.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query queryCount = session.createSQLQuery(sql.toString());
        for (int i = 0; i < param.size(); i++) {
            queryCount.setParameter(i, param.get(i));
        }
        Long count = Long.parseLong(queryCount.uniqueResult()+"") ;
		return count;
	}

	/**
	 * 查询用户的所有任务项目以及最新的交流信息
	 * @param gesProjectTaskVO
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesProjectTaskQueryVO> queryAllProjectTaskCommunicationByUserId(
			GesProjectTaskQueryVO gesProjectTaskVO) {
		StringBuffer hql=new StringBuffer();
		hql.append("select b.id as id,b.content as content,b.createdDatetime as createTime,b.isUrgency as isUrgency,"
				+ "a.isHandle as isDeal,b.difference as difference,u.realName as userName,c.content as chatContent,"
				+ "c.createdDatetime as latestTime,a.communication.id as communicateId,c.id as latestComId ");
		hql.append(" from GesProjectTask b,GesTaskParticipant a,GesCommunication c,UserInfoGES u ");
		hql.append(" where c.user.id=u.user.id and b.communication.id=c.id and a.task.id=b.id and a.invalid=? and a.participant.id=? ");
		hql.append(" order by c.createdDatetime desc,b.createdDatetime desc");
		List<Object> param=new ArrayList<Object>();
		param.add(false);
		param.add(gesProjectTaskVO.getUser().getId());
		return (List<GesProjectTaskQueryVO>) super.findByPageCallBack(hql.toString(), null, param, gesProjectTaskVO, Transformers.aliasToBean(GesProjectTaskQueryVO.class));
	}

	/**
	 * 更新任务项目的最新交流ID
	 */
	@Override
	public int updateGesProjectTaskCommunicationId(GesProjectTask gesProjectTask) {
		String hql="update GesProjectTask p set p.communication.id=? where p.id=? ";
		List<Object> param=new ArrayList<Object>();
		param.add(gesProjectTask.getCommunication().getId());
		param.add(gesProjectTask.getId());
		super.updateByParam(hql, param);
		return 1;
	}

	@Override
	public void addGesProjectTask(GesProjectTask gesProjectTask) {
		super.add(gesProjectTask);
	}

	/**
	 * 根据条件查询任务项目统计信息
	 * @param gesProjectTaskVO
	 * @param choose 标记执行哪一条sql语句 0:项目
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesProjectTaskQueryVO> queryTaskByFeature(
			GesProjectTaskQueryVO gesProjectTaskVO, int choose) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		if(choose==1||choose==2){
			excuteProject(gesProjectTaskVO, hql, param,choose);
		}
		if(choose==3||choose==4){
			excuteTask(gesProjectTaskVO, hql, param, choose);
		}
		return (List<GesProjectTaskQueryVO>) super.findByPageCallBack(hql.toString(), null, param, gesProjectTaskVO, Transformers.aliasToBean(GesProjectTaskQueryVO.class));
	}

	protected void excuteProject(GesProjectTaskQueryVO gesProjectTaskVO,
			StringBuffer hql, List<Object> param,int choose) {
		hql.append(" select b.id as id,b.content as content,b.planEndDate as planEndDate,b.taskStatus as taskStatus"
				+ ",(select concat(count(e.id),'') from GesCommunication e where e.task.id=b.id) as chatNum ,"
				+ "(select concat(count(d.id),'') from GesTaskParticipant d where d.task.id=b.id) as memberNum,"
				+ "(select concat(count(c.id),'') from GesAttachment c where c.relationId=b.id and c.relationType=0) as fileNum "
				);
		if(choose==1){
			hql.append(" ,2 as memberType");
		}else if(choose==2){
			hql.append(" ,a.participantType as memberType");
		}
		hql.append(" from GesProjectTask b ");
		if(choose==2){
			hql.append(" ,GesTaskParticipant a ");
		}
		hql.append(" where 1=1 and b.invalid=? and b.difference=? ");
		param.add(false);
		param.add(gesProjectTaskVO.getDifference());
		if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
			hql.append(" and b.id=? ");
			param.add(gesProjectTaskVO.getId());
		}else{
			hql.append(" and b.taskStatus=? ");
			param.add(gesProjectTaskVO.getTaskStatus());
		}
		if(choose==1){
			if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and b.operator.id=? ");
				param.add(gesProjectTaskVO.getOperatorId());
			}else if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and b.shop.id=? ");
				param.add(gesProjectTaskVO.getShopId());
			}
		}
		if(choose==2){
			hql.append(" and a.task.id=b.id and a.invalid=? and a.difference=0 ");
			param.add(false);
			if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
				
			}else{
				if(gesProjectTaskVO.getMemberType()!=null&&(
						gesProjectTaskVO.getMemberType()==0||gesProjectTaskVO.getMemberType()==1)){
					hql.append(" and a.participantType=? ");
					param.add(gesProjectTaskVO.getMemberType());
				}
			}
			hql.append(" and a.participant.id=?");
			param.add(gesProjectTaskVO.getUser().getId());
		}
		hql.append(" order by b.id desc ");
	}
	
	/**
	 * 任务
	 * @param gesProjectTaskVO
	 * @param hql
	 * @param param
	 * @param choose
	 */
	protected void excuteTask(GesProjectTaskQueryVO gesProjectTaskVO,
			StringBuffer hql, List<Object> param,int choose) {
		hql.append("select b.id as id,b.content as content,b.createdDatetime as createTime,b.isUrgency as isUrgency,"
				+ "b.difference as difference,u.realName as userName,c.content as chatContent,"
		        + "b.planStartDate as planStartDate,b.planEndDate as planEndDate,b.taskStatus as taskStatus,"
				+ "c.createdDatetime as latestTime,c.id as latestComId ");
		if(choose==3){
			hql.append(" ,c.id as communicateId,2 as isDeal ");
		}else if(choose==4){
			hql.append(",a.communication.id as communicateId ,a.isHandle as isDeal ");
		}
		hql.append(" from GesProjectTask b ");
		if(choose==4){
			hql.append(",GesTaskParticipant a ");
		}
		hql.append(",GesCommunication c,UserInfoGES u ");
		hql.append(" where c.user.id=u.user.id and b.communication.id=c.id "
				+ "and b.difference=? ");
		param.add(1);
		if(choose==4){
			hql.append(" and a.task.id=b.id and a.invalid=? ");
			param.add(false);
		}
		if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
			hql.append(" and b.id=? ");
			param.add(gesProjectTaskVO.getId());
		}
		if(choose==3){
			if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and b.operator.id=? ");
				param.add(gesProjectTaskVO.getOperatorId());
			}else if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and b.shop.id=? ");
				param.add(gesProjectTaskVO.getShopId());
			}
		}
		
		if(choose==4){
			hql.append(" and a.participant.id=? ");
			param.add(gesProjectTaskVO.getUser().getId());
			if(gesProjectTaskVO.getIsDeal()==0||gesProjectTaskVO.getIsDeal()==1){
				hql.append(" and a.isHandle=? ");
				param.add(gesProjectTaskVO.getIsDeal());
			}
	        if(gesProjectTaskVO.getTaskStatus()!=null && gesProjectTaskVO.getTaskStatus()!=5){
	            hql.append(" and b.taskStatus=? ");
	            param.add(gesProjectTaskVO.getTaskStatus());
	        }
            if(gesProjectTaskVO.getTypeId()!=null && gesProjectTaskVO.getTypeId()>0){
                hql.append(" and b.taskType.id=? ");
                param.add(gesProjectTaskVO.getTypeId());
            }
		}
		
		hql.append(" order by b.isUrgency desc, c.createdDatetime desc,b.createdDatetime desc");
		
		
	}

	/**
	 * 根据条件统计任务项目总数
	 * @param gesProjectTaskVO
	 * @param choose 标记执行哪一条sql语句
	 * @return
	 */
	@Override
	public Long countTaskByFeature(GesProjectTaskQueryVO gesProjectTaskVO,
			int choose) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		if(choose==1||choose==2){
			excuteCountProject(gesProjectTaskVO, hql, param,choose);
		}
		if(choose==3||choose==4){
			excuteCountTask(gesProjectTaskVO, hql, param, choose);
		}
		Session session = this.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query queryCount = session.createQuery(hql.toString());
        for (int i = 0; i < param.size(); i++) {
            queryCount.setParameter(i, param.get(i));
        }
        Long count = Long.parseLong(queryCount.uniqueResult()+"") ;
		return count;
	}
	
	protected void excuteCountProject(GesProjectTaskQueryVO gesProjectTaskVO,
			StringBuffer hql, List<Object> param,int choose) {
		hql.append(" select count(b.id)  ");
		hql.append(" from GesProjectTask b ");
		if(choose==2){
			hql.append(" ,GesTaskParticipant a ");
		}
		hql.append(" where 1=1 and b.invalid=? and b.difference=? ");
		param.add(false);
		param.add(gesProjectTaskVO.getDifference());
		if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
			hql.append(" and b.id=? ");
			param.add(gesProjectTaskVO.getId());
		}else{
			hql.append(" and b.taskStatus=? ");
			param.add(gesProjectTaskVO.getTaskStatus());
		}
		if(choose==1){
			if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and b.operator.id=? ");
				param.add(gesProjectTaskVO.getOperatorId());
			}else if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and b.shop.id=? ");
				param.add(gesProjectTaskVO.getShopId());
			}
		}
		if(choose==2){
			hql.append(" and a.task.id=b.id and a.invalid=? and a.difference=0 ");
			param.add(false);
			if(gesProjectTaskVO.getMemberType()!=null&&(
					gesProjectTaskVO.getMemberType()==0||gesProjectTaskVO.getMemberType()==1)){
				hql.append(" and a.participantType=? ");
				param.add(gesProjectTaskVO.getMemberType());
			}
			hql.append(" and a.participant.id=?");
			param.add(gesProjectTaskVO.getUser().getId());
		}
	}
	
	/**
	 * 任务
	 * @param gesProjectTaskVO
	 * @param hql
	 * @param param
	 * @param choose
	 */
	protected void excuteCountTask(GesProjectTaskQueryVO gesProjectTaskVO,
			StringBuffer hql, List<Object> param,int choose) {
		if(choose==3){
			hql.append(" select count(b.id)  ");
			hql.append(" from GesProjectTask b ");
			hql.append(" where b.difference=? and b.invalid=? ");
			param.add(1);
			param.add(false);
			if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
				hql.append(" and b.id=? ");
				param.add(gesProjectTaskVO.getId());
			}
			if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and b.operator.id=? ");
				param.add(gesProjectTaskVO.getOperatorId());
			}else if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and b.shop.id=? ");
				param.add(gesProjectTaskVO.getShopId());
			}
			
		}else if(choose==4){
			hql.append(" select count(a.id)  ");
			hql.append(" from GesTaskParticipant a , GesProjectTask b ");
			hql.append(" where a.difference=? and a.invalid=? and a.task.id=b.id ");
			param.add(1);
			param.add(false);
			if(gesProjectTaskVO.getId()!=null && gesProjectTaskVO.getId().longValue()>0){
				hql.append(" and a.task.id=? ");
				param.add(gesProjectTaskVO.getId());
			}
			if(gesProjectTaskVO.getIsDeal()==0||gesProjectTaskVO.getIsDeal()==1){
				hql.append(" and a.isHandle=? ");
				param.add(gesProjectTaskVO.getIsDeal());
			}
//			if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
//				hql.append(" and b.operator.id=? ");
//				param.add(gesProjectTaskVO.getOperatorId());
//			}else if(gesProjectTaskVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
//				hql.append(" and b.shop.id=? ");
//				param.add(gesProjectTaskVO.getShopId());
//			}
			hql.append(" and a.participant.id=? ");
			param.add(gesProjectTaskVO.getUser().getId());
            if(gesProjectTaskVO.getTaskStatus()!=null && gesProjectTaskVO.getTaskStatus()!=5){
                hql.append(" and b.taskStatus=? ");
                param.add(gesProjectTaskVO.getTaskStatus());
            }
            if(gesProjectTaskVO.getTypeId()!=null && gesProjectTaskVO.getTypeId()>0){
                hql.append(" and b.taskType.id=? ");
                param.add(gesProjectTaskVO.getTypeId());
            }
		}
		
	}

	/**
	 * 根据任务的id获取任务的信息
	 */
	@SuppressWarnings("unchecked")
    @Override
	public GesProjectTaskVO queryTaskById(Long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.content as content,b.realName as userName,a.createdDatetime as createTime,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.difference as difference,a.taskStatus as taskStatus,"
				+ "a.parent.id as parentId,a.taskType.id as typeId ");
		hql.append(" from GesProjectTask a ,UserInfoGES b ");
		hql.append(" where a.founder.id=b.user.id and a.id=? ");
		param.add(taskId);
		List<GesProjectTaskVO> list=(List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
		log.info("+++++++**************查询结果：list.size()="+list.size());
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

    @Override
    public int batchAddProjectTask(List<GesProjectTask> list) {
        return super.batchAdd(list);
    }

    /**
     * 根据任务的id查询任务的阶段和子任务  (丢弃)
     * @param taskId
     * @return
     */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,b.periodName as periodName,a.content as content,a.taskStatus as taskStatus,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.actualStartDate as actualStartDate,"
				+ "a.actualEndDate as actualEndDate,a.checkDate as checkDate,a.checkUser as checkUser ");
		hql.append(" from GesProjectTask a right join a.period b left join a.checkUser u "
//				+ "left join a.checkUser u "
//				+ "left join u.userInfoMap m left join u.platformSet s left join s.platform f  "
				);
		hql.append(" where b.invalid=?  and b.task.id=? ");
		hql.append(" order by b.orderTag asc ");
		param.add(false);
//		param.add(PlatformEnum.Ges.getObj().getId());
//		param.add(false);
		param.add(taskId);
		return (List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
	}
	
    @SuppressWarnings("unchecked")
    @Override
    public List<GesProjectTask> queryByOrderId(Long orderId) {
        String hql = "from GesProjectTask where gesOrder.id = ? and difference = ?";
        return (List<GesProjectTask>) super.getHibernateTemplate().find(hql, orderId, TaskConstant.TASK_TYPE_PROJECT);
    }

    /**
     * 根据任务id获取任务的信息，不关联其他表，获取全部的信息
     */
	@Override
	public GesProjectTask queryAllTaskInfoByTaskId(Long taskId) {
		return (GesProjectTask) super.get(taskId);
	}

	/**
	 * 根据任务的id更新任务的状态
	 */
	@Override
	public int updateTaskStatusByTaskId(GesProjectTask projectTask) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesProjectTask p ");
		hql.append(" set p.taskStatus=? ,p.updatedDatetime=? ");
		param.add(projectTask.getTaskStatus());
		param.add(projectTask.getUpdatedDatetime());
		if(projectTask.getActualStartDate()!=null){
			hql.append(", p.actualStartDate=? ");
			param.add(projectTask.getActualStartDate());
		}
		if(projectTask.getActualEndDate()!=null){
			hql.append(", p.actualEndDate=? ");
			param.add(projectTask.getActualEndDate());
		}
		hql.append(" where p.id=? ");
		param.add(projectTask.getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

	/**
     * 根据阶段的id查询阶段下的任务信息
     * @param periodId
     * @return
     */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesProjectTaskVO> queryTaskByTaskPeriod(Long periodId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.content as content,a.taskStatus as taskStatus,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.actualStartDate as actualStartDate,"
				+ "a.actualEndDate as actualEndDate,a.checkDate as checkDate,"
				+ "a.checkStatus as checkStatus,c.content as chatContent,g.realName as userName,"
				+ "c.createdDatetime as latestTime,t.path as headPortrait ");
		hql.append(" from GesProjectTask a join a.communication c,UserInfo g left join g.avatar t");
		hql.append(" where a.invalid=?  and g.type=? and c.user.id=g.user.id and a.period.id=? ");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		param.add(periodId);
		return (List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
	}

	/**
	 * 目前未使用
	 */
	@SuppressWarnings("unchecked")
    @Override
	public GesProjectTaskVO queryNewTaskByTaskId(Long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.content as content,a.taskStatus as taskStatus,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.actualStartDate as actualStartDate,"
				+ "a.actualEndDate as actualEndDate,a.checkDate as checkDate,"
				+ "a.checkStatus as checkStatus,c.content as chatContent,g.realName as userName,"
				+ "c.createdDatetime as latestTime,t.path as headPortrait ");
		hql.append(" from GesProjectTask a left join a.communication c left join c.user u left join u.userInfoMap g "
				+ "left join u.platformSet s left join s.platform f left join g.avatar t");
		hql.append(" where a.invalid=?  and f.id=? and a.id=? ");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId());
		param.add(taskId);
		List<GesProjectTaskVO> list=(List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	/**
	 * 根据用户的id查询用户的信息
	 */
	@SuppressWarnings("unchecked")
    @Override
	public UserVO queryUserInfoByUserId(Long userId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select a.path as headPortrait,u.realName as realName ");
		hql.append(" from UserInfoGES u left join u.avatar a where u.user.id=?");
		param.add(userId);
		List<UserVO> list=(List<UserVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(UserVO.class));
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	/**
	 * 根据施工管理项目的任务id和阶段名称查询任务
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesProjectTaskVO> queryTaskByTaskPeriodForPM(Long taskId,String periodName) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.content as content,a.taskStatus as taskStatus,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.actualStartDate as actualStartDate,"
				+ "a.actualEndDate as actualEndDate,a.checkDate as checkDate,"
				+ "a.checkStatus as checkStatus,c.content as chatContent,g.realName as userName,"
				+ "c.createdDatetime as latestTime,t.path as headPortrait ");
		hql.append(" from GesProjectTask a join a.communication c ,UserInfo g left join g.avatar t");
		hql.append(" where a.invalid=? and g.type=? and c.user.id=g.user.id and a.pmModel.type=? and a.parent.id=? and a.pmModel.accentedphase=? ");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		param.add(3);
		param.add(taskId);
		param.add(periodName);
		return (List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
	}

	/**
	 * 更新任务的验收状态和验收时间
	 */
	@Override
	public int updateTaskCheckInfo(GesProjectTask projectTask) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesProjectTask p ");
		hql.append(" set p.checkUser=? ,p.checkDate=? ,p.checkStatus=? ,actualStartDate=? "
				+ ",actualEndDate=? ,updatedDatetime=? ");
		hql.append(" where p.id=? ");
		param.add(projectTask.getCheckUser());
		param.add(projectTask.getCheckDate());
		param.add(projectTask.getCheckStatus());
		param.add(projectTask.getActualStartDate());
		param.add(projectTask.getActualEndDate());
		param.add(projectTask.getUpdatedDatetime());
		param.add(projectTask.getId());
		updateByParam(hql.toString(), param);
		return 1;
	}

	@Override
	public GesProjectTask queryGesProject(Long id) {
		return (GesProjectTask) super.get(id);
	}

    @SuppressWarnings("unchecked")
    @Override
    public GesProjectTask projectTaskByCustomer(GesCustomerVO customer) {

        StringBuffer sBHql = new StringBuffer();
        sBHql.append("  From GesProjectTask gpt where 1=1 " );
        List<Object> paramList = new ArrayList<Object>();
        sBHql.append(" and gpt.checkStatus = ? ");
        paramList.add(true);
        if(null!=customer){
            if(null!=customer.getGesOrder()){
                sBHql.append(" and gpt.gesOrder.id = ? ");
                paramList.add(customer.getGesOrder().getId());
            }else{
                return null;
            }
        }
        sBHql.append(" order by gpt.pmModel.id desc ");
//        Session session = this.getHibernateTemplate().getSessionFactory().openSession();
//        Query query =session.createQuery(sBHql.toString());
//        for (int i = 0; i<paramList.size();i++) {
//            query.setParameter(i, paramList.get(i));
//        }
//        List<GesProjectTask> list =  query.list();
        customer.setStart(1);
        customer.setPageSize(1);
        List<GesProjectTask> list = (List<GesProjectTask>)findByPageCallBack(sBHql.toString(), null,paramList, customer, null);
        return !list.isEmpty()?list.get(0):null;
        
//        return gpt;
    }

	@Override
	public long countGesProjectTaskByParentId(long parentId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
//		hql.append(" select count() ");
		hql.append(" from GesProjectTask p where p.invalid =? ");
		param.add(false);
		hql.append(" and p.parent.id =? ");
		param.add(parentId);
		return super.findByPageCallBackCount(hql.toString(), param);
	}
	
}
