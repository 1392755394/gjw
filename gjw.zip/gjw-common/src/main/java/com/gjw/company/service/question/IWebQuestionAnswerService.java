package com.gjw.company.service.question;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.question.WebQuestionAnswer;
import com.gjw.vo.WebQuestionAnswerVO;

/**
 * 
* @Description: 问题service类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:22:44
*
 */
public interface IWebQuestionAnswerService extends IService {
    /**
     * 
    * @Description  获取问题答案详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:31:48
     */
    public WebQuestionAnswer getById(Long id);
    
    /**
     * 
    * @Description  分页列表，搜索条件：问题标题
    * @param subject
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:34:10
     */
    public List<WebQuestionAnswer> pageBySubjectAndInvalid(WebQuestionAnswerVO answer);
    
    /**
     * 
    * @Description  总数
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午1:51:20
     */
    public Long countBySubjectAndInvalid(WebQuestionAnswerVO answer);
    /**
     * 
    * @Description  批量废弃问题答案
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午4:53:34
     */
    public String invalidByIds(String ids);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebQuestionAnswer entity);
    /**
     * 
    * @Description  修改数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:45
     */
    public boolean update(WebQuestionAnswer entity);
    /**
     * 
    * @Description  删除数据（物理删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:54
     */
    public int delete(Long id);
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    /**
     * 
    * @Description  所有答案（未废弃）
    * @param questionId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月1日 下午3:05:18
     */
    public List<WebQuestionAnswer> listByQuestion(Long questionId);
}
