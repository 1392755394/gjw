package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.vo.order.GesOrderVO;

/**
 * 订单支付的金额和次数统计表
 * 
 * @author jjw
 * 
 */
public interface IGesOrderPayMoneyDAO extends IDAO {

    /**
     * 更新订单支付的金额和次数
     * 
     * @param gesOrderPayMoney
     * @return
     */
    public int updateGesOrderPayMoney(GesOrderPayMoney gesOrderPayMoney);

    /**
     * <p>
     * 采购管理
     * <p>
     * 采购清单分页查询
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2015年12月26日 下午4:05:43
     */
    public List<GesOrderPayMoney> pageByGesOrderPayMoney(GesOrderVO order);

    /**
     * 采购管理
     * <p>
     * 采购清单分页查询--总数
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2015年12月26日 下午4:12:01
     */
    public Long count(GesOrderVO order);

    /**
     * 根据订单id查询订单状态（包括支付情况）
     * 
     * @Description
     * @param id
     * @return
     * @author gwb
     * @date 2016年1月18日 上午9:56:01
     */
    public GesOrderPayMoney getGesOrderPayMoneyByOrderId(Long id);
    
    /**
     * 添加支付的金额记录
     * @param orderPay
     */
    public void addGesOrderPayMoney(GesOrderPayMoney orderPay);
    
    /**
     * 更新订单的金额（通过字段增加）
     * @param orderPay
     * @return
     */
    public int updateOrderPay(GesOrderPayMoney orderPay);
    
    /**
     * 根据订单id查询订单90%支付的金额
     * @param orderId
     * @return
     */
    public GesOrderPayMoney queryOrderPayMoneyByOrderId(Long orderId);

}
