package com.gjw.company.dao.impl.matter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IMatterSequenceDAO;
import com.gjw.entity.matter.MatterSequence;

/**
 * 物料序列dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月18日 
 *
 */
@Component("matterSequenceDAOHibernateImpl")
public class MatterSequenceDAOHibernateImpl extends AbstractDAOHibernateImpl implements IMatterSequenceDAO {

    @Override
    protected Class<?> getEntityClass() {
        return MatterSequence.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public MatterSequence queryByBrandID(Long brandId) {

        // 生成查询条件
        StringBuilder hql = new StringBuilder();
        hql.append("from MatterSequence m where m.brand.id =?");
        
        List<MatterSequence> list = (List<MatterSequence>) super.getHibernateTemplate().find(hql.toString(), brandId);
        if (list != null && list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public boolean update(MatterSequence matterSequence) {
        return super.update(matterSequence) == 1;
    }

    @Override
    public long create(MatterSequence matterSequence) {
        super.add(matterSequence);
        return matterSequence.getId();
    }

}
