package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.GoodsMark;

/**
 * 
* @Description: 房间标记关系
* @author  zhaoyonglian
* @date 2015年12月29日 上午10:57:50
*
 */
public interface IGoodsMarkDAO extends IDAO {

    /**
     * 
    * @Description  房间及类型 参数列表mark
    * @param mark
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月30日 下午2:41:11
     */
    public List<GoodsMark> listMarkByRoomIdAndType(Long roomId,Long type);
    
    /**
     * 
    * @Description  查看详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月29日 上午10:34:16
     */
    public GoodsMark queryById(Long id);

    /**
     * 
    * @Description  删除关系
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月29日 上午10:35:36
     */
    public boolean delBatchByID(String ids);
    
    /**
     * 
    * @Description  修改关系
    * @param mark
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月30日 下午2:42:22
     */
    public boolean update(GoodsMark mark);
    
    /**
     * 
    * @Description  新增产品包物料关系
    * @param goodsMatter
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月29日 上午10:36:38
     */
    public long create(GoodsMark mark);
    
    //DIY 接口start
    
    /**
     * 
    * @Description  产品包下所有锚点
    * @param goodsId
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月11日 下午4:43:33
     */
    public List<GoodsMark> listMarkByGoodsId(Long goodsId);
    
    /**
     * 
    * @Description  根据房间id删除锚点
    * @param roomId
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月13日 下午1:23:21
     */
    public boolean deleteByRoomId(Long roomId);
}
