package com.gjw.company.dao.order;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.GesPaymentRecord;

public interface IGesPaymentRecordDAO extends IDAO {
	
	/**
	 * 根据订单id删除冗余的数据
	 * @return
	 */
	public boolean deleteRedundantData(GesPaymentRecord paymentRecord);
	
	/**
	 * 更新支付记录的状态为已到账
	 * @param paymentRecord
	 * @return
	 */
	public boolean updateRecordStatus(GesPaymentRecord paymentRecord);
	
	/**
	 * 保存支付记录
	 * @param paymentRecord
	 */
	public void createPaymentRecord(GesPaymentRecord paymentRecord);
	
	/**
	 * 获取最新的一条记录
	 * @param orderId
	 * @return
	 */
	public GesPaymentRecord judgeTimeInterval(long orderId);
	
	/**
	 * 根据支付记录的id查询订单记录
	 * @param id
	 * @return
	 */
	public GesPaymentRecord queryPaymentRecordById(long id);

}
