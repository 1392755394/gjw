package com.gjw.company.dao.article;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.collection.WebCollectionItem;

public interface IWebArticleDAO extends IDAO {

    WebArticle get(Long id);

    List<WebArticle> pageByName(WebArticle article);

    long countByName(WebArticle article);

    void batchDelete(List<Long> idList);

    void batchReuse(List<Long> idList);

    List<WebArticle> listByArticle(WebArticle model);

    long count(WebArticle model);

    /**
     * 根据用户收藏文章id查询文章列表
     * 
     * @Description
     * @param list
     * @return
     * @author gwb
     * @date 2016年3月29日 上午11:37:05
     */
    List<WebArticle> listArticleBy(List<WebCollectionItem> list);

}
