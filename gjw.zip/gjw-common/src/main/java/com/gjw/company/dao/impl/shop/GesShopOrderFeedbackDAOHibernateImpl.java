package com.gjw.company.dao.impl.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.shop.IGesShopOrderFeedbackDAO;
import com.gjw.entity.shop.GesShopOrderFeedback;
import com.gjw.utils.StringUtil;

@Component("gesShopOrderFeedbackDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesShopOrderFeedbackDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesShopOrderFeedbackDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesShopOrderFeedback.class;
    }

    @Override
    public GesShopOrderFeedback listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesShopOrderFeedback) super.get(id);
    }

    @Override
    public boolean updateGesShopOrderFeedback(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesShopOrderFeedback(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopOrderFeedback item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getUser() && null!=model.getUser().initPlatformUserInfo(PlatformEnum.Ges) && StringUtil.notEmpty(model.getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName())){
            hql=hql+" and item.user.userInfo.realName like ?";
            params.add(super.getFuzzyCondition(model.getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName()));
        }
        if(null!=model.getGesOrder() && null!=model.getGesOrder().getId()){
            hql=hql+" and item.gesOrder.id=?";
            params.add(model.getGesOrder().getId());
            if(StringUtil.notEmpty(model.getGesOrder().getCode())){
                hql=hql+" and item.gesOrder.code like ?";
                params.add(super.getFuzzyCondition(model.getGesOrder().getCode()));
            }
            if(null!=model.getGesOrder().getShop() && null!=model.getGesOrder().getShop().getId()){
                hql=hql+" and item.gesOrder.shop.id=?";
                params.add(model.getGesOrder().getShop().getId());
            }
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        if(StringUtil.notEmpty(model.getGmtStartFrom())){
            hql=hql+" and DATE_FORMAT(item.order.gmtStart,'%Y-%m-%d')>=?";
            params.add(model.getGmtStartFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtStartTo())){
            hql=hql+" and DATE_FORMAT(item.order.gmtStart,'%Y-%m-%d')<=?";
            params.add(model.getGmtStartTo().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateFrom())){
            hql=hql+" and DATE_FORMAT(item.order.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtCreateFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateTo())){
            hql=hql+" and DATE_FORMAT(item.order.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtCreateTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesShopOrderFeedback> listByGesShopOrderFeedback(
            GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopOrderFeedback item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getUser() && null!=model.getUser().initPlatformUserInfo(PlatformEnum.Ges) && StringUtil.notEmpty(model.getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName())){
            hql=hql+" and item.user.userInfo.realName like ?";
            params.add(super.getFuzzyCondition(model.getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName()));
        }
        if(null!=model.getGesOrder() && null!=model.getGesOrder().getId()){
            hql=hql+" and item.gesOrder.id=?";
            params.add(model.getGesOrder().getId());
            if(StringUtil.notEmpty(model.getGesOrder().getCode())){
                hql=hql+" and item.gesOrder.code like ?";
                params.add(super.getFuzzyCondition(model.getGesOrder().getCode()));
            }
            if(null!=model.getGesOrder().getShop() && null!=model.getGesOrder().getShop().getId()){
                hql=hql+" and item.gesOrder.shop.id=?";
                params.add(model.getGesOrder().getShop().getId());
            }
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        if(StringUtil.notEmpty(model.getGmtStartFrom())){
            hql=hql+" and DATE_FORMAT(item.order.gmtStart,'%Y-%m-%d')>=?";
            params.add(model.getGmtStartFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtStartTo())){
            hql=hql+" and DATE_FORMAT(item.order.gmtStart,'%Y-%m-%d')<=?";
            params.add(model.getGmtStartTo().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateFrom())){
            hql=hql+" and DATE_FORMAT(item.order.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtCreateFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateTo())){
            hql=hql+" and DATE_FORMAT(item.order.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtCreateTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesShopOrderFeedback>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
