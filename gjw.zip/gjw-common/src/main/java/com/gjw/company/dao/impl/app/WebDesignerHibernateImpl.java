package com.gjw.company.dao.impl.app;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.app.IWebDesignerDAO;
import com.gjw.entity.app.WebDesigner;
import com.gjw.entity.topic.WebTopic;

@Component("webDesignerHibernateImpl")
@SuppressWarnings("unchecked")
public class WebDesignerHibernateImpl extends AbstractDAOHibernateImpl implements IWebDesignerDAO{
    public WebDesigner get(Long id) {
        return (WebDesigner) super.get(id);
    }
    @Override
    public List<WebDesigner> getList(WebDesigner model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from WebDesigner item where 1=1";
        List<Object> params = new ArrayList<Object>();
        hql = hql + " order by item.createdDatetime desc";
        return (List<WebDesigner>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public boolean addWebDesigner(WebDesigner model) {
        // TODO Auto-generated method stub
        super.add(model);
        return true;
    }

    @Override
    public void updateWebDesigner(WebDesigner model) {
        // TODO Auto-generated method stub
        super.update(model);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebDesigner.class;
    }
    @Override
    public WebDesigner getTopic(Long topicId) {
        // TODO Auto-generated method stub
        String hql = " from WebDesigner item where item.topic.id=?";
        hql = hql + " order by item.createdDatetime desc";
        List<Object> params=new ArrayList<Object>();
        params.add(topicId);
        WebTopic topic=new WebTopic();
        topic.setId(topicId);
        WebDesigner model=new WebDesigner();
        model.setTopic(topic);
        List<WebDesigner> list=(List<WebDesigner>) super.findByPageCallBack(hql, "", params, model, null);
        if(null!=list && list.size()>0){
            return list.get(0);
        }
        return null;
    }

}
