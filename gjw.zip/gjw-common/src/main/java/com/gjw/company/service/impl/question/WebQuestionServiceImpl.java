package com.gjw.company.service.impl.question;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.question.IWebQuestionAnswerDAO;
import com.gjw.company.dao.question.IWebQuestionDAO;
import com.gjw.company.service.question.IWebQuestionService;
import com.gjw.entity.question.WebQuestion;

@Component("webQuestionServiceImpl")
public class WebQuestionServiceImpl implements IWebQuestionService {

    @Autowired
    private IWebQuestionDAO dao;
    @Autowired
    private IWebQuestionAnswerDAO answerDao;

    @Override
    @Transactional(readOnly = true)
    public WebQuestion getById(Long id) {
        // TODO Auto-generated method stub
        return dao.getById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebQuestion> pageBySubjectAndInvalid(WebQuestion question) {
        // TODO Auto-generated method stub
        List<WebQuestion> list = dao.pageBySubjectAndInvalid(question);
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countBySubjectAndInvalid(WebQuestion question) {
        // TODO Auto-generated method stub
        return dao.countBySubjectAndInvalid(question);
    }

    @Override
    @Transactional
    public boolean insert(WebQuestion entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public boolean update(WebQuestion entity) {
        // TODO Auto-generated method stub
        return dao.updateQuestion(entity);
    }

    @Override
    public int delete(Long id) {
        // TODO Auto-generated method stub
        return dao.delete(id);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = this.invalid(Long.valueOf(id));
                    if (row > 0) {
                        ++success;
                        // 废弃对应答案
                        answerDao.invalidByQuestion(Long.valueOf(id));
                    } else {
                        ++error;
                    }
                }
            } else {
                row = this.invalid(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                    // 废弃对应答案
                    answerDao.invalidByQuestion(Long.valueOf(ids));
                } else {
                    ++error;
                }
            }
        }
        if (0 == success && 0 != error) {
            return "失败废弃" + error + "条问题！";
        } else if (0 == error && 0 != success) {
            return "成功废弃" + success + "条问题！";
        } else if (0 == success && 0 == error) {
            return "请选择废弃的问题！";
        } else {
            return "成功废弃" + success + "条问题,失败废弃" + error + "条问题！";
        }

    }

    @Override
    @Transactional(readOnly = true)
    public List<WebQuestion> pageByUserAndState(WebQuestion question) {
        // TODO Auto-generated method stub
        return dao.pageByUserAndState(question);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByUserAndState(WebQuestion question) {
        // TODO Auto-generated method stub
        return dao.countByUserAndState(question);
    }

    @Override
    public void setConfirm(Long questionId, Long answerId) {
        // TODO Auto-generated method stub
        //问题状态改变
        dao.isConfirm(questionId);
        //答案加精
        answerDao.isEssence(answerId);
    }

}
