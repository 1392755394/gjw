package com.gjw.company.service.salestool;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.salestool.IpadAdvert;

public interface IIpadAdvertService extends IService{
    public IpadAdvert listByID(Long id);

    public boolean updateIpadAdvert(IpadAdvert model);

    public boolean createIpadAdvert(IpadAdvert model);
    
    public long count(IpadAdvert model);
    
    public List<IpadAdvert> listByIPadAdvert();
}
