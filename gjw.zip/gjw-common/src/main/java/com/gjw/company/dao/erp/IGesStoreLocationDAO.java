package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.store.GesStoreLocation;

/**
 * 库位管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 上午9:26:23
 * 
 */
public interface IGesStoreLocationDAO extends IDAO {

    public Long count(GesStoreLocation model);

    public List<?> pageByStoreLocation(GesStoreLocation model);

    public GesStoreLocation getById(Long id);

}
