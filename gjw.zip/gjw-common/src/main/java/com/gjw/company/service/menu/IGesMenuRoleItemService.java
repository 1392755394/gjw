package com.gjw.company.service.menu;

import com.gjw.base.service.IService;
import com.gjw.entity.menu.GesMenuRoleItem;

public interface IGesMenuRoleItemService extends IService {

    public boolean create(GesMenuRoleItem menuRoleItem);
    
    public boolean delete(GesMenuRoleItem menuRoleItem);
}
