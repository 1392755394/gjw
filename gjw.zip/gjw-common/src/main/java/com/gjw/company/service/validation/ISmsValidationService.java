package com.gjw.company.service.validation;

import com.gjw.entity.validation.SmsValidation;


/**
 * created by 重剑 on 2015/9/17 0017
 */
public interface ISmsValidationService {
    void remove(Long id);
    void add(SmsValidation smsValidation);
    SmsValidation getLastByMobile(String mobile);
}
