package com.gjw.company.dao.impl.menu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.menu.IGesMenuPermissionItemDAO;
import com.gjw.entity.menu.GesMenu;
import com.gjw.entity.menu.GesMenuPermissionItem;
@Component("gesMenuPermissionItemDAOHiberateImpl")
public class GesMenuPermissionItemDAOHiberateImpl extends
        AbstractDAOHibernateImpl implements IGesMenuPermissionItemDAO {
    
    @Override
    protected Class getEntityClass() {
        return GesMenuPermissionItem.class;
    }

    @Override
    public boolean delete(GesMenuPermissionItem menuPermissionItem) {
        return super.delete(menuPermissionItem.getId()) == 1 ?true:false;
    }

    @Override
    public long create(GesMenuPermissionItem menuPermissionItem) {
       super.add(menuPermissionItem);
       return menuPermissionItem.getId();
    }

    @Override
    public List<GesMenuPermissionItem> listMenuPermissionItemsByMenus(List<GesMenu> menuList) {
        List<Long> menuIds = new ArrayList<Long>();
        for (GesMenu menu : menuList) {
            menuIds.add(menu.getId());
        }
        StringBuffer hql = new StringBuffer("from GesMenuPermissionItem g left join fetch g.permission where g.gesMenu.id in (");
        for(int i = 0; i < menuIds.size(); i++){
            if ( i < menuIds.size() -1 ){
                hql.append(menuIds.get(i)).append(",");
            } else {
                hql.append(menuIds.get(i)).append(")");
            }
        }
        return (List<GesMenuPermissionItem>)super.getHibernateTemplate().find(hql.toString());
    }

    @Override
    public void deleteAll() {
        List<GesMenuPermissionItem> list = (List<GesMenuPermissionItem>)super.getHibernateTemplate().find("from GesMenuPermissionItem g");
        super.getHibernateTemplate().deleteAll(list);;
    }

    

}
