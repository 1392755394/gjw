package com.gjw.company.dao.building;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.building.GesBuildingColorConfig;

public interface IGesBuildingColorConfigDAO extends IDAO{
    
    public GesBuildingColorConfig listByID(Long id);

    public boolean updateGesBuildingColorConfig(GesBuildingColorConfig model);

    public boolean createGesBuildingColorConfig(GesBuildingColorConfig model);
    
    public long count(GesBuildingColorConfig model);
    
    public List<GesBuildingColorConfig> listByGesBuildingColorConfig(GesBuildingColorConfig model);
}
