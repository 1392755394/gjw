package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.oa.IGesPmModelDAO;
import com.gjw.entity.oa.GesPmModel;
import com.gjw.vo.oa.GesProjectTaskVO;

/**
 * 施工项目模板dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月6日 
 * 
 */
@Component("gesPmModelDAOHibernateImpl")
public class GesPmModelDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesPmModelDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GesPmModel.class;
    }

    @Override
    public List<GesPmModel> listAll() {
        return super.getHibernateTemplate().loadAll(GesPmModel.class);
    }

	@Override
	public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,b.accentedphase as periodName,a.content as content,a.taskStatus as taskStatus,"
				+ "a.planStartDate as planStartDate,a.planEndDate as planEndDate,a.actualStartDate as actualStartDate,"
				+ "a.actualEndDate as actualEndDate,a.checkDate as checkDate,a.checkUser as checkUser,b.timelimitday as timeLimit ");
		hql.append(" from GesProjectTask a join a.pmModel b left join a.checkUser u ");
		hql.append(" where b.invalid=? and b.type=? and a.parent.id=? ");
		hql.append(" order by b.id asc ");
		param.add(false);
		param.add(3);
		param.add(taskId);
		return (List<GesProjectTaskVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesProjectTaskVO.class));
	}

}
