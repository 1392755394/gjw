package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesSoMatterItemDAO;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesSoMatterVO;

/**
 * <P>
 * 构家网---- 产品包销售订单关联的物料(采购清单)实体
 * <P>
 * 城运商，4s店发起采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月30日 下午2:19:35
 * 
 */
@Component("gesSoMatterItemDAOHibernateImpl")
public class GesSoMatterItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesSoMatterItemDAO {

    @Override
    protected Class<GesSoMatterItem> getEntityClass() {
        return GesSoMatterItem.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesSoMatterItem> ListSoMatter(GesSoMatterVO soMatter) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesSoMatterItem soMatter left join fetch soMatter.matter m where soMatter.invalid=0 and m.id not in ( select matter.id from GesPoDetail where poCode=? and soMatter.room.id=room.id) and  soMatter.gesOrder.id=? ");
        list.add(soMatter.getPoCode());
        list.add(soMatter.getSoId());
        soMatter.setStart(null);
        soMatter.setPageSize(null);
        return (List<GesSoMatterItem>) super.findByListCallBack(hql.toString(), "", list, null);
    }

    /**
     * 分页查询hql
     * 
     * @Description
     * @param soMatter
     * @param listSoMatter
     * @param falg
     * @return
     * @author gwb
     * @date 2015年12月31日 上午11:16:10
     */
    protected Query getHql(GesSoMatterVO soMatter, List<GesSoMatterItem> listSoMatter, Boolean falg, Integer start,
            Integer pageSize) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesSoMatterItem as  soMatter  where soMatter.invalid=0  ");

        if (StringUtil.notEmpty(soMatter.getBrandName())) {
            hql.append(" and soMatter.matter.brand.name like ?");
            list.add(super.getFuzzyCondition(soMatter.getBrandName()));
        }
        if (StringUtil.notEmpty(soMatter.getCode())) {
            hql.append(" and soMatter.matter.code like ?");
            list.add(super.getFuzzyCondition(soMatter.getCode()));
        }
        if (StringUtil.notEmpty(soMatter.getName())) {
            hql.append(" and soMatter.matter.name like ?");
            list.add(super.getFuzzyCondition(soMatter.getName()));
        }
        if (StringUtil.notEmpty(soMatter.getModel())) {
            hql.append(" and soMatter.matter.model like ?");
            list.add(super.getFuzzyCondition(soMatter.getModel()));
        }
        if (soMatter.getRoomId() > -1) {
            hql.append(" and soMatter.room.id = ?");
            list.add(soMatter.getRoomId());
        }

        if (soMatter.getSoId() != null) {
            hql.append(" and soMatter.gesOrder.id = ?");
            list.add(soMatter.getSoId());
        }
        hql.append(" and soMatter.id in( :ids )");
        String hqlStr = "";
        if (falg) {
            hqlStr = " select count(*) " + hql.toString();
        } else {
            hqlStr = hql.toString();
        }

        Query query = session.createQuery(hqlStr);

        if (listSoMatter.size() > 0) {
            List<Long> ls = new ArrayList<Long>();
            for (GesSoMatterItem matter : listSoMatter) {
                ls.add(matter.getId());
            }
            query.setParameterList("ids", ls);
        } else {
            query.setParameter("ids", -1l);
        }
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }

        if (falg) {

        } else {
            query.setFirstResult(start);
            query.setMaxResults(pageSize);
        }
        return query;

    }

    /**
     * 分页查询总数
     */
    @Override
    public Long count(GesSoMatterVO soMatter, List<GesSoMatterItem> listSoMatter) {
        Query query = this.getHql(soMatter, listSoMatter, true, null, null);
        return (Long) query.uniqueResult();
    }

    /**
     * 分页查询
     */
    @Override
    public List<GesSoMatterItem> pageSoMatter(GesSoMatterVO soMatter, List<GesSoMatterItem> listSoMatter,
            Integer start, Integer pageSize) {
        Query query = this.getHql(soMatter, listSoMatter, false, start, pageSize);
        return query.list();
    }

    @Override
    public void updateGesSoMatterItem(GesPoDetail poDetail) {
        // TODO Auto-generated method stub
        // update g_so_matter set PUR_QUANTITY = PUR_QUANTITY + #{quantity}
        // WHERE ID=#{soMatterId}
        String hql = " update GesSoMatterItem set purQuantity =IFNULL(purQuantity,0)+? where id =? ";
        List<Object> list = new ArrayList<Object>();
        list.add(poDetail.getQuantity());
        list.add(poDetail.getSoMatter().getId());
        super.updateByParam(hql, list);
    }

    @Override
    public List<GesSoMatterItem> ListSoMatterByGesGesRdRecords(GesSoMatterVO soMatter) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GesSoMatterItem soMatter inner join fetch soMatter.matter m where soMatter.invalid=0 and m.id not in ( select matter.id from GesRdRecords where recordCode=? and soMatter.room.id=room.id) and soMatter.gesOrder.id=?   ");
        list.add(soMatter.getStockOutCode());
        list.add(soMatter.getSoId());
        soMatter.setStart(null);
        soMatter.setPageSize(null);
        return (List<GesSoMatterItem>) super.findByListCallBack(hql.toString(), "", list, null);
    }

    @Override
    public void updateGesSoMatterItemByrdRecords(GesRdRecords rdRecords) {
        // update g_so_matter set
        // * STOCK_OUT_QUANTITY = STOCK_OUT_QUANTITY + #{quantity} WHERE
        // * ID=#{soMatterId}
        String hql = " update GesSoMatterItem set stockOutQuantity =IFNULL(stockOutQuantity,0)+? where id =? ";
        List<Object> list = new ArrayList<Object>();
        list.add(rdRecords.getQuantity());
        list.add(rdRecords.getSoMatter().getId());
        super.updateByParam(hql, list);
    }
}
