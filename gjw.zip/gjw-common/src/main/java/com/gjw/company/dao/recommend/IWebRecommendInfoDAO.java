package com.gjw.company.dao.recommend;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.recommend.WebRecommendInfo;

/**
 * 
* @Description: 问题dao接口类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:28:30
*
 */
public interface IWebRecommendInfoDAO extends IDAO {

	/**
	 * 
	* @Description  推荐信息详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:13:28
	 */
	public WebRecommendInfo getById(Long id);
	
	/**
	 * 
	* @Description  分页查询，推荐信息名字或者代码
	* @param info
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:13:44
	 */
	public List<WebRecommendInfo> pageByNameAndCode(WebRecommendInfo info);
	
	/**
	 * 
	* @Description  总数
	* @param info
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:14:06
	 */
	public Long countByNameAndCode(WebRecommendInfo info);
	
	/**
	 * 
	* @Description  修改
	* @param info
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月17日 上午11:14:18
	 */
	public boolean updateInfo(WebRecommendInfo info);
}
