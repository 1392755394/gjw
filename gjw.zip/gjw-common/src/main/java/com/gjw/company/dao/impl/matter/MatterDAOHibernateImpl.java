package com.gjw.company.dao.impl.matter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IMatterDAO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesSoMatterVO;

/**
 * 物料dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月16日
 * 
 */
@Component("matterDAOHibernateImpl")
public class MatterDAOHibernateImpl extends AbstractDAOHibernateImpl implements IMatterDAO {

    @Override
    protected Class<?> getEntityClass() {
        return Matter.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Matter> pageMatter(Matter matterCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Matter m left join fetch m.brand left join fetch m.shippingMethods ");
        hql.append("left join fetch m.categoryFirst left join fetch m.categorySecond left join fetch m.category ");
        hql.append("left join fetch m.image  ");
        hql.append("where m.invalid = false ");
        if (StringUtil.notEmpty(matterCriteria.getCode())) {
            hql.append("  and m.code like ?");
            ls.add(getFuzzyCondition(matterCriteria.getCode()));
        }
        if (StringUtil.notEmpty(matterCriteria.getName())) {
            hql.append("  and m.name like ?");
            ls.add(getFuzzyCondition(matterCriteria.getName()));
        }
        if (StringUtil.notEmpty(matterCriteria.getModel())) {
            hql.append("  and m.model like ?");
            ls.add(getFuzzyCondition(matterCriteria.getModel()));
        }
        if (matterCriteria.getBrand() != null && StringUtil.notEmpty(matterCriteria.getBrand().getName())) {
            ls.add(matterCriteria.getBrand().getName());
            hql.append("  and m.brand.name like ?");
        }
        if (matterCriteria.getCategoryFirst() != null) {
            ls.add(matterCriteria.getCategoryFirst().getId());
            hql.append("  and m.categoryFirst.id=?");
        }
        if (matterCriteria.getCategorySecond() != null) {
            ls.add(matterCriteria.getCategorySecond().getId());
            hql.append("  and m.categorySecond.id=?");
        }
        if (matterCriteria.getCategory() != null) {
            ls.add(matterCriteria.getCategory().getId());
            hql.append("  and m.category.id=?");
        }
        if (matterCriteria.getParent() != null) {
            ls.add(matterCriteria.getParent().getId());
            hql.append("  and m.parent.id=?");
        } else {
            hql.append("  and m.parent=null");
        }
        if (matterCriteria.getIsDiy() != null) {
            ls.add(matterCriteria.getIsDiy());
            hql.append("  and m.isDiy=?");
        }
        if (matterCriteria.getStatus() != null){
            ls.add(matterCriteria.getStatus());
            hql.append("  and m.status=?");
            
        }
        if (StringUtil.notEmpty(matterCriteria.getSortField())) {
            hql.append("  order by m.").append(matterCriteria.getSortField()).append(" ");
            hql.append(matterCriteria.getSortOrder()).append(" ,m.updatedDatetime desc");
        } else {
            hql.append("  order by m.updatedDatetime desc");
        }
        return (List<Matter>) super.findByPageCallBack(hql.toString(), "", ls, matterCriteria, null);
    }

    @Override
    public Long countMatter(Matter matterCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Matter m ");
        hql.append("where m.invalid = false ");
        if (StringUtil.notEmpty(matterCriteria.getCode())) {
            hql.append("  and m.code like ?");
            ls.add(getFuzzyCondition(matterCriteria.getCode()));
        }
        if (StringUtil.notEmpty(matterCriteria.getName())) {
            hql.append("  and m.name like ?");
            ls.add(getFuzzyCondition(matterCriteria.getName()));
        }
        if (StringUtil.notEmpty(matterCriteria.getModel())) {
            hql.append("  and m.model like ?");
            ls.add(getFuzzyCondition(matterCriteria.getModel()));
        }
        if (matterCriteria.getBrand() != null && StringUtil.notEmpty(matterCriteria.getBrand().getName())) {
            ls.add(matterCriteria.getBrand().getName());
            hql.append("  and m.brand.name like ?");
        }
        if (matterCriteria.getCategoryFirst() != null) {
            ls.add(matterCriteria.getCategoryFirst().getId());
            hql.append("  and m.categoryFirst.id=?");
        }
        if (matterCriteria.getCategorySecond() != null) {
            ls.add(matterCriteria.getCategoryFirst().getId());
            hql.append("  and m.categorySecond.id=?");
        }
        if (matterCriteria.getCategory() != null) {
            ls.add(matterCriteria.getCategory().getId());
            hql.append("  and m.category.id=?");
        }
        if (matterCriteria.getIsDiy() != null) {
            ls.add(matterCriteria.getIsDiy());
            hql.append("  and m.isDiy=?");
        }
        if (matterCriteria.getParent() != null) {
            ls.add(matterCriteria.getParent().getId());
            hql.append("  and m.parent.id=?");
        } else {
            hql.append("  and m.parent=null");
        }
        if (matterCriteria.getStatus() != null){
            ls.add(matterCriteria.getStatus());
            hql.append("  and m.status=?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public Matter queryByIDWithBrandAndCategory(Long id) {

        // 生成查询条件
        StringBuilder hql = new StringBuilder();
        hql.append("from Matter m left join fetch m.brand left join fetch m.category ");
        hql.append("left join fetch m.image left join fetch m.effectImage where m.id =?");

        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        query.setParameter(0, id);
        return (Matter) (query.uniqueResult());
    }

    @Override
    public Matter getIdByCode(String getcInvCode) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuilder hql = new StringBuilder();
        hql.append("from Matter m  where m.code =?");
        Query query = session.createQuery(hql.toString());
        query.setParameter(0, getcInvCode);
        return (Matter) (query.uniqueResult());
    }

    @Override
    public long create(Matter matter) {
        if (matter.getImage() != null && matter.getImage().getId() == null) {
            matter.setImage(null);
        }
        if (matter.getEffectImage() != null && matter.getEffectImage().getId() == null) {
            matter.setEffectImage(null);
        }
        if (matter.getIsDiy() == null) {
            matter.setIsDiy(false);
        }
        super.add(matter);
        return matter.getId();
    }

    @Override
    public boolean update(Matter matter) {
        Matter old = (Matter) super.get(matter.getId());
        if (matter.getImage() != null && matter.getImage().getId() == null) {
            matter.setImage(null);
        }
        if (matter.getEffectImage() != null && matter.getEffectImage().getId() == null) {
            matter.setEffectImage(null);
        }
        StringUtil.copyPropertiesAllowEmpty(matter, old);
        if (old.getSynchType() != null && old.getSynchType().getId() != null){
            Dictionary dictionary = new Dictionary(); 
            dictionary.setId(1130104L);
            old.setSynchType(dictionary);
        }
        
        return super.update(old) == 1;
    }
    
    @Override
    public boolean updateMatter4Syn(Matter matter) {
        Matter old = (Matter) super.get(matter.getId());
        if (matter.getImage() != null && matter.getImage().getId() == null) {
            matter.setImage(null);
        }
        if (matter.getEffectImage() != null && matter.getEffectImage().getId() == null) {
            matter.setEffectImage(null);
        }
        StringUtil.copyPropertiesAllowEmpty(matter, old);
        
        return super.update(old) == 1;
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }

        return super.delBatchByID(idList) > 0;
    }

    /**
     * 物料同步结果查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Matter> listMatter(Matter mater) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        String hql = "from Matter a  where  exists(select 1 from  MatterUnit b where a.unit = b.unitName ) and  a.invalid=0  and (a.synchType.id not in(1130102,1130105) or a.synchType.id is null) and a.isDiy=0";
        //a.matterUnit.id is not null
        Query query = session.createQuery(hql);
        query.setFirstResult(0);
        query.setMaxResults(100);
        return query.list();
    }

    @Override
    public Long countChildWithDelete(Long parentId) {
        List<Object> ls = new ArrayList<Object>();
        String hql = " from Matter m where m.parent.id=?";
        ls.add(parentId);

        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Matter> pageForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Matter m left join fetch m.brand where m.invalid = false and m.status = 1 ");
        hql.append("and m.id not in (select gm.matter.id from GoodsMatter gm where gm.goods.id = ? and gm.invalid = false ");
        ls.add(goodsRoomCriteria.getGoods().getId());
        if (goodsRoomCriteria.getId() != null && goodsRoomCriteria.getId() != 0) {
            ls.add(goodsRoomCriteria.getId());
            hql.append(" and gm.room.id = ?");
        }
        hql.append(" )");
        if (StringUtil.notEmpty(matterCriteria.getCode())) {
            hql.append("  and m.code like ?");
            ls.add(getFuzzyCondition(matterCriteria.getCode()));
        }
        if (StringUtil.notEmpty(matterCriteria.getName())) {
            hql.append("  and m.name like ?");
            ls.add(getFuzzyCondition(matterCriteria.getName()));
        }
        if (StringUtil.notEmpty(matterCriteria.getModel())) {
            hql.append("  and m.model like ?");
            ls.add(getFuzzyCondition(matterCriteria.getModel()));
        }
        if (matterCriteria.getBrand() != null && StringUtil.notEmpty(matterCriteria.getBrand().getName())) {
            ls.add(matterCriteria.getBrand().getName());
            hql.append("  and m.brand.name like ?");
        }
        hql.append(" group by m.id order by m.createdDatetime desc");
        return (List<Matter>) super.findByPageCallBack(hql.toString(), "", ls, matterCriteria, null);
    }

    @Override
    public Long countForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Matter m where m.invalid = false and m.status = 1 ");
        hql.append("and m.id not in (select gm.matter.id from GoodsMatter gm where gm.goods.id = ? and gm.invalid = false ");
        ls.add(goodsRoomCriteria.getGoods().getId());
        if (goodsRoomCriteria.getId() != null && goodsRoomCriteria.getId() != 0) {
            ls.add(goodsRoomCriteria.getId());
            hql.append(" and gm.room.id = ?");
        }
        hql.append(" )");
        if (StringUtil.notEmpty(matterCriteria.getCode())) {
            hql.append("  and m.code like ?");
            ls.add(getFuzzyCondition(matterCriteria.getCode()));
        }
        if (StringUtil.notEmpty(matterCriteria.getName())) {
            hql.append("  and m.name like ?");
            ls.add(getFuzzyCondition(matterCriteria.getName()));
        }
        if (StringUtil.notEmpty(matterCriteria.getModel())) {
            hql.append("  and m.model like ?");
            ls.add(getFuzzyCondition(matterCriteria.getModel()));
        }
        if (matterCriteria.getBrand() != null && StringUtil.notEmpty(matterCriteria.getBrand().getName())) {
            ls.add(matterCriteria.getBrand().getName());
            hql.append("  and m.brand.name like ?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long countNotInPoDetail(GesSoMatterVO soMatter) {
        Map<String, Object> map = this.getHQL(soMatter);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Matter> pageNotInPoDetail(GesSoMatterVO soMatter) {
        Map<String, Object> map = this.getHQL(soMatter);
        return (List<Matter>) super.findByPageCallBack(map.get("hql").toString(), null, (List<Object>) map.get("list"),
                soMatter, null);
    }

    @SuppressWarnings("unused")
    private Map<String, Object> getHQL(GesSoMatterVO soMatter) {
        Map<String, Object> map = new HashMap<String, Object>();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from Matter where invalid=0 and status=1 and id not in (select matter.id from GesPoDetail where poCode=? )");
        list.add(soMatter.getPoCode());
        if (StringUtil.notEmpty(soMatter.getCode())) {
            hql.append(" and code=?");
            list.add(soMatter.getCode());
        }
        if (StringUtil.notEmpty(soMatter.getModel())) {
            hql.append(" and model=?");
            list.add(soMatter.getModel());
        }
        if (StringUtil.notEmpty(soMatter.getName())) {
            hql.append(" and name=?");
            list.add(soMatter.getName());
        }
        if (StringUtil.notEmpty(soMatter.getBrandName())) {
            hql.append(" and brand.name=?");
            list.add(soMatter.getBrandName());
        }
        map.put("hql", hql);
        map.put("list", list);
        return map;

    }

    @Override
    public Long count(Matter mater) {
        String hql = " from Matter a  where a.invalid=0 and a.unit is not null and (a.synchType.id not in(1130102,1130105) or a.synchType.id is null) and a.isDiy=0";
        List<Object> list = new ArrayList<Object>();
        return super.countHql(hql, list);
    }

 
}
