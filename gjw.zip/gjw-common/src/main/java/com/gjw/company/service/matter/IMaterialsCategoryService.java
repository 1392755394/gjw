package com.gjw.company.service.matter;

import java.util.List;
import java.util.Map;

import com.gjw.base.service.IService;
import com.gjw.entity.matter.MaterialsCategory;

/**
 * 建材类目service接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月14日
 * 
 */
public interface IMaterialsCategoryService extends IService {

    /**
     * 查询建材分类列表
     * 
     * @Description
     * @param parentId
     *            父分类ID
     * @return 子分类列表
     * @author guojianbin
     * @date 2015年12月14日
     */
    public List<MaterialsCategory> listCategoryByParentId(long parentId);

    /**
     * 查询建材分类总数
     * 
     * @Description
     * @param parentId
     *            父分类ID
     * @return 建材分类总数
     * @author guojianbin
     * @date 2015年12月17日
     */
    public Long countCategoryByParentId(long parentId);

    /**
     * 建材库分类同步查询
     * 
     * @Description
     * @param materialsCategory
     * @return
     * @author gwb
     * @date 2015年12月19日 下午2:00:59
     */
    public List<Map<String, Object>> listMaterialsCategoryForSynch(MaterialsCategory materialsCategory);
    /**
     * 
    * @Description  获取建材分类详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月8日 上午11:30:26
     */
    public MaterialsCategory queryCategoryByID(Long id);
    
    /**
     * 
    * @Description  修改建材库类目信息
    * @param materialsCategory
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月8日 上午11:57:44
     */
    public boolean updateCategory(MaterialsCategory materialsCategory);
    
    /**
     * 
    * @Description  创建建材库类目信息
    * @param materialsCategory
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月8日 上午11:58:35
     */
    public boolean createCategory(MaterialsCategory materialsCategory);
    
    /**
     * 
    * @Description  是否有下级
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月11日 上午10:20:18
     */
    public boolean isChildNode(Long id);
    
    /**
     * 
    * @Description  删除分类
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月11日 上午10:29:27
     */
    public boolean deleteCategory(Long id);
}
