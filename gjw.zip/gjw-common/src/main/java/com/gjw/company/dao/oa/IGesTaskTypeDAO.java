package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.oa.GesTaskType;

/**
 * 任务列表DAO
 * @author jjw
 *
 */
public interface IGesTaskTypeDAO extends IDAO {
	
	/**
	 * 根据任务项目类别查询任务项目类型
	 * @param type
	 * @return
	 */
	public List<GesTaskType> listTaskTypeByType(GesTaskType taskType);
	
	/**
	 * 根据任务类别和父节点id 查询任务项目类型
	 * @param taskType
	 * @return
	 */
	public List<GesTaskType> listTaskTypeByTypeAndParentId(GesTaskType taskType);
	
    public GesTaskType getTaskTypeById(long id);
}
