package com.gjw.company.service.building;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.building.GesBuilding;
import com.gjw.entity.building.GesBuildingCityOperatorItem;
import com.gjw.entity.building.GesBuildingColorConfig;
import com.gjw.entity.building.GesBuildingPhotoItem;
import com.gjw.entity.building.House;

public interface IGesBuildingService extends IService{
    public GesBuilding listByID(Long id);

    public boolean updateGesBuilding(String ids);

    public boolean createGesBuilding(GesBuilding model);
    
    public List<GesBuilding> listByGesBuilding(GesBuilding building);
    
    public long count(GesBuilding building);
    
    public boolean updateBuildingAndBulingCityOperatorItem(GesBuilding building,Long buildingItemId);
    
    public boolean createBulingCityOperatorItem(GesBuildingCityOperatorItem model);
    
    public List<GesBuildingCityOperatorItem> listByGesBuildingCityOperatorItem(GesBuildingCityOperatorItem model);
    
    public Long listByGesBuildingCityOperatorItemCount(GesBuildingCityOperatorItem model);
    
    public boolean deleteGesBuildingCityOperatorItem(GesBuildingCityOperatorItem model);
    
    public GesBuildingPhotoItem listByGesBuildingPhotoItemID(Long id);

    public boolean updateGesBuildingPhotoItem(GesBuildingPhotoItem model);

    public boolean createGesBuildingPhotoItem(GesBuildingPhotoItem model);
    
    public long gesBuildingPhotoItemcount(GesBuildingPhotoItem model);
    
    public List<GesBuildingPhotoItem> listByGesBuildingPhotoItem(GesBuildingPhotoItem model);
    
    public House listByHouseID(Long id);

    public boolean updateHouse(House model);

    public boolean createHouse(House model);
    
    public long houseCount(House model);
    
    public List<House> listByHouse(House model);
    
    public boolean deleteHouse(String ids);
    
    public GesBuildingColorConfig listGesBuildingColorConfigByID(Long id);

    public boolean updateGesBuildingColorConfig(GesBuildingColorConfig model);

    public boolean createGesBuildingColorConfig(GesBuildingColorConfig model);
    
    public long countGesBuildingColorConfig(GesBuildingColorConfig model);
    
    public List<GesBuildingColorConfig> listByGesBuildingColorConfig(GesBuildingColorConfig model);
    
    public List<GesBuilding> listByGesBuildingForApp(GesBuilding building);
}
