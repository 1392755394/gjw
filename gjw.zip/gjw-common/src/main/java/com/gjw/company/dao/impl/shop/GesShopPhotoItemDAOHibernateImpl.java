package com.gjw.company.dao.impl.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.shop.IGesShopPhotoItemDAO;
import com.gjw.entity.shop.GesShopPhotoItem;

@Component("gesShopPhotoItemDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesShopPhotoItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesShopPhotoItemDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesShopPhotoItem.class;
    }

    @Override
    public GesShopPhotoItem listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesShopPhotoItem) super.get(id);
    }

    @Override
    public boolean updateGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopPhotoItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getShop() && null!=model.getShop().getId()){
            hql=hql+" and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesShopPhotoItem> listByGesShopOrderFeedback(
            GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopPhotoItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getShop() && null!=model.getShop().getId()){
            hql=hql+" and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesShopPhotoItem>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
