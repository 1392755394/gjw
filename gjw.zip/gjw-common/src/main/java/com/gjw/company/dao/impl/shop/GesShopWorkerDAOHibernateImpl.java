package com.gjw.company.dao.impl.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.shop.IGesShopWorkerDAO;
import com.gjw.entity.shop.GesShopWorker;
import com.gjw.utils.StringUtil;

@Component("gesShopWorkerDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesShopWorkerDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesShopWorkerDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesShopWorker.class;
    }

    @Override
    public GesShopWorker listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesShopWorker) super.get(id);
    }

    @Override
    public boolean updateGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesShopWorker model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopWorker item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getShop() && null!=model.getShop().getId()){
            hql=hql+" and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        if(StringUtil.notEmpty(model.getName())){
            hql=hql+" and item.name like ?";
            params.add(super.getFuzzyCondition(model.getName()));
        }
        if(StringUtil.notEmpty(model.getJob())){
            hql=hql+" and item.job like ?";
            params.add(super.getFuzzyCondition(model.getJob()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesShopWorker> listByGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesShopWorker item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getShop() && null!=model.getShop().getId()){
            hql=hql+" and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        if(StringUtil.notEmpty(model.getName())){
            hql=hql+" and item.name like ?";
            params.add(super.getFuzzyCondition(model.getName()));
        }
        if(StringUtil.notEmpty(model.getJob())){
            hql=hql+" and item.job like ?";
            params.add(super.getFuzzyCondition(model.getJob()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesShopWorker>) super.findByPageCallBack(hql, "", params, model, null);
    }
}
