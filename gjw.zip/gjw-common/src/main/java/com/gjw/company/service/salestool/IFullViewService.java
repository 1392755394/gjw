package com.gjw.company.service.salestool;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.salestool.FullView;

public interface IFullViewService extends IService{
    public FullView listByID(Long id);

    public boolean updateFullView(FullView model);

    public boolean createFullView(FullView model);
    
    public long count(FullView model);
    
    public List<FullView> listByFullView(FullView model);
    
    public Boolean updateFullViewByIds(String ids);
    
    /**
     * 
    * @Description  通过验证码查看全景列表
    * @param captcha
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月11日 上午11:31:03
     */
    public List<FullView> listByCaptcha(String captcha);
}
