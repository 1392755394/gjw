package com.gjw.company.dao.matter;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.matter.MatterSequence;

/**
 * 物料序列service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月17日 
 *
 */
public interface IMatterSequenceDAO extends IDAO {
    
    /**
     * 根据品牌ID获取物料序列
     * @Description  
     * @param id 品牌id
     * @return 物料序列
     * @author guojianbin   
     * @date 2015年12月17日
     */
    public MatterSequence queryByBrandID(Long brandId);

    /**
     * 修改物料序列
     * @Description  
     * @param matterSequence 物料序列
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月17日
     */
    public boolean update(MatterSequence matterSequence);
    

    /**
     * 保存物料序列
     * @Description  
     * @param matterSequence 物料序列
     * @return 物料序列ID
     * @author guojianbin   
     * @date 2015年12月17日
     */
    public long create(MatterSequence matterSequence);
}
