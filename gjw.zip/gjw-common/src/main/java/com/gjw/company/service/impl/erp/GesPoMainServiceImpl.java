package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesPoMainService;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.entity.erp.GesPoMain;
import com.gjw.vo.GesPoMainVO;

/**
 * 采购------------销售
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 下午2:37:48
 * 
 */
@Service("gesPoMainServiceImpl")
public class GesPoMainServiceImpl extends AbstractServiceImpl implements IGesPoMainService {

    /**
     * 销售订单分页查询
     */
    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public List<GesPoMain> pageByPoMain(GesPoMainVO poMain) {
        List<GesPoMain> list = super.getGesPoMainDAO().pageByPoMain(poMain);
        for (GesPoMain main : list) {
            if (main.getCityOperator() != null) {
                main.getCityOperator().getCompanyName();
            }
            if (main.getShop() != null) {
                main.getShop().getName();
            }
            if (main.getLocation() != null) {
                main.getLocation().getName();
            }
            if (main.getGesOrder() != null && main.getGesOrder().getBuyer() != null) {
                // main.getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
                main.getGesOrder().getBuyer().getUsername();
            }
            if (main.getWarehouse() != null) {
                main.getWarehouse().getName();
            }

        }
        return list;
    }

    /**
     * 销售订单 ---总数
     */
    @Override
    @Transactional(readOnly = true)
    public Long count(GesPoMainVO poMain) {
        return super.getGesPoMainDAO().count(poMain);
    }

    /**
     * 销售订单 ---------修改订单状态
     */
    @Override
    @Transactional
    public boolean updateByPoCode(GesPoMain poMain) {

        return super.getGesPoMainDAO().updateByPoCode(poMain);
    }

    /**
     * 
     */
    @Override
    @Transactional(readOnly = true)
    public GesPoMain getByGesPoMain(GesPoMain poMain) {
        GesPoMain gesPoMain = super.getGesPoMainDAO().getByGesPoMain(poMain);
        gesPoMain.getWarehouse().getName();
        if (gesPoMain.getLocation() != null) {
            gesPoMain.getLocation().getName();
        }
        return gesPoMain;
    }

    @Override
    @Transactional
    public void create(GesPoMain poMain) {
        // 保存采购订单g_po_main
        // poMain.setCreateUser(UserHelper.loginName());
        if (poMain.getLocation() == null || poMain.getLocation().getId() == null) {
            poMain.setLocation(null);
        }
        if (poMain.getShop() == null || poMain.getShop().getId() == null) {
            poMain.setShop(null);
        }
        if (poMain.getCityOperator() == null || poMain.getCityOperator().getId() == null) {
            poMain.setCityOperator(null);
        }
        super.getGesPoMainDAO().saveResultBoolean(poMain);
        // 更新采购清单表g_so_matter
        // 先根据poCode查出所有订单明细，再根据订单明细的so_matter_id,和quantity去修改g_so_matter表
        GesPoDetail poDetail = new GesPoDetail();
        poDetail.setPoCode(poMain.getPoCode());
        poDetail.setStart(null);
        poDetail.setPageSize(null);
        List<GesPoDetail> poDetailList = super.getGesPoDetailDAO().pagePoDetailByPoCode(poDetail);
        for (GesPoDetail detail : poDetailList) {
            super.getGesSoMatterItemDAO().updateGesSoMatterItem(detail);
        }

    }

    /**
     * 销售出库同步
     */
    @Override
    @Transactional(readOnly = true)
    public GesPoMain getByGesPoMainBySynch(GesPoMain po) {
        GesPoMain gesPoMain = super.getGesPoMainDAO().getByGesPoMainBySynch(po);
        if (gesPoMain != null) {
            if (gesPoMain.getWarehouse() != null) {
                gesPoMain.getWarehouse().getName();
            }
            if (gesPoMain.getLocation() != null) {
                gesPoMain.getLocation().getName();
            }

        }
        return gesPoMain;
    }
}
