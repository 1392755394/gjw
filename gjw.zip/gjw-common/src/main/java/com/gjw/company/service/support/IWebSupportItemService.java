package com.gjw.company.service.support;

import java.util.List;

import com.gjw.entity.support.WebSupportItem;

public interface IWebSupportItemService {
    /**
     * 新增点赞
     * 
     * @Description
     * @param webSupportItem
     * @return
     * @author gwb
     * @date 2016年2月25日 上午9:55:48
     */
    public boolean insert(WebSupportItem webSupportItem);

    /**
     * 删除点赞
     * 
     * @Description
     * @param webSupportItem
     * @return
     * @author gwb
     * @date 2016年2月25日 上午9:58:57
     */
    public boolean deleteWebSupportItem(Long id);

    /**
     * 软删除点赞
     * 
     * @Description
     * @param webSupportItem
     * @return
     * @author gwb
     * @date 2016年2月25日 上午10:00:21
     */
    public boolean deleteByContent(WebSupportItem webSupportItem);

    /**
     * 获取点赞列表
     * 
     * @Description
     * @param webSupportItem
     * @return
     * @author gwb
     * @date 2016年2月25日 上午10:01:13
     */
    public List<WebSupportItem> userSupportList(WebSupportItem webSupportItem);

    /**
     * 总数查询
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2016年2月26日 下午2:59:13
     */
    public long countByContent(WebSupportItem webSupportItem);

}
