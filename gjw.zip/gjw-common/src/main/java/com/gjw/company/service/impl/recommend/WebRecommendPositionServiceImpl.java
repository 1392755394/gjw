package com.gjw.company.service.impl.recommend;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.recommend.IWebRecommendPositionDAO;
import com.gjw.company.service.recommend.IWebRecommendPositionService;
import com.gjw.entity.recommend.WebRecommendPosition;
import com.gjw.utils.StringUtil;

@Component("webRecommendPositionServiceImpl")
public class WebRecommendPositionServiceImpl implements IWebRecommendPositionService {

    @Autowired
    private IWebRecommendPositionDAO dao;

    @Override
    @Transactional(readOnly = true)
    public WebRecommendPosition getById(Long id) {
        // TODO Auto-generated method stub
        WebRecommendPosition pos = dao.getById(id);
        if(null != pos && StringUtil.notEmpty(pos.getPropertyType().getId())){
            Hibernate.initialize(pos.getPropertyType());
        }
        return pos;
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebRecommendPosition> pageByNameAndCode(WebRecommendPosition position) {
        // TODO Auto-generated method stub
        List<WebRecommendPosition> list = dao.pageByNameAndCode(position);
        if(null != list && list.size()>0){
            for (WebRecommendPosition webRecommendPosition : list) {
                Hibernate.initialize(webRecommendPosition.getPropertyType());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByNameAndCode(WebRecommendPosition position) {
        // TODO Auto-generated method stub
        return dao.countByNameAndCode(position);
    }

    @Override
    @Transactional
    public boolean insert(WebRecommendPosition entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public boolean update(WebRecommendPosition entity) {
        // TODO Auto-generated method stub
        return dao.updatePosition(entity);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebRecommendPosition> listByInvalid(Integer invalid) {
        // TODO Auto-generated method stub
        return dao.listByInvalid(invalid);
    }

}
