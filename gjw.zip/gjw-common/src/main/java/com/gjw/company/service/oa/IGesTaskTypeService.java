package com.gjw.company.service.oa;

import java.util.List;
import java.util.Map;

import com.gjw.vo.oa.GesTaskTypeVO;

/**
 * 任务类型
 * @author jjw
 *
 */
public interface IGesTaskTypeService {
	
	List<GesTaskTypeVO> listTaskType(long parentId, int type,String orgType);
    
    /**
     * app 接口  查询所有任务类型
     * @param type
     * @return
     */
	List<Map<String,Object>> listType(int type,String orgType);

}
