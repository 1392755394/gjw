package com.gjw.company.service.oa;

import java.util.List;

import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.vo.oa.GesTaskParticipantVO;

public interface IGesTaskParticipantService {
	
	/**
	 * 根据任务的id查询成员列表
	 * @param taskId
	 * @return
	 */
	public List<GesTaskParticipantVO> queryMemberInfoByTaskId(Long taskId);
    
    /**
     * 任务成员删除
     * @param taskParticipant
     * @return
     */
    public boolean delMember(GesTaskParticipant taskParticipant);
    
    /**
     * 批量添加成员
     * @param taskId
     * @param userIds
     * @param type
     * @return
     */
    public int addBatchMember(long taskId,String userIds,int type,String loginUserName);
    
    /**
     * 查询登录用户是否是某一个任务的创建人或者负责人(项目任务)
     * @param taskId
     * @param userId
     * @return
     */
    public List<GesTaskParticipantVO> getMemberInfo(long taskId, long userId);
    
    /**
     * 通过任务id和用户id查询成员信息
     * @param taskId
     * @param userId
     * @return
     */
    public List<GesTaskParticipantVO> getMemberByIdAndUserid(long taskId, long userId);
    
    /**
     * 提升负责人
     * @param taskParticipant
     * @return
     */
    public boolean alterMemeberType(GesTaskParticipant taskParticipant);

    /**
     * 根据用户id 任务id 更新 已办 or 未办
     * @param taskId
     * @param isDeal
     * @param userId
     * @return
     */
    public boolean updateTaskDeal(Long taskId,Integer isDeal,Long userId);
	
}
