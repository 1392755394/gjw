package com.gjw.company.dao.customer;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.customer.GesCustomerMessageLog;

public interface IGesCustomerMessageLogDAO extends IDAO{
    public GesCustomerMessageLog listByID(Long id);

    public boolean updateGesCustomerMessageLog(GesCustomerMessageLog model);

    public boolean createGesCustomerMessageLog(GesCustomerMessageLog model);
    
    public List<GesCustomerMessageLog> listByGesCustomerMessageLog(GesCustomerMessageLog model);
    
    public long count(GesCustomerMessageLog model);
}
