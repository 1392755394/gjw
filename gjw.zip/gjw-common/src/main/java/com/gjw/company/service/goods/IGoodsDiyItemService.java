package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.dto.diy.GoodsDiyDTO;
import com.gjw.entity.goods.GoodsDiyItem;

/**
 * DIY方案service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月24日 
 *
 */
public interface IGoodsDiyItemService extends IService {

    /**
     * 根据产品包查询标准DIY方案
     * @Description  
     * @param goodsId 查询条件：产品包ID
     * @return 产品包房间列表
     * @author guojianbin   
     * @date 2015年12月24日
     */
    public GoodsDiyItem queryStandartDiyByGoodsId(Long goodsId);

    /**
     * 查询产品包的DIY方案列表
     * @Description  
     * @param goodsId 查询条件：产品包ID
     * @return DIY方案列表
     * @author guojianbin   
     * @date 2015年12月26日
     */
    public List<GoodsDiyItem> listDiyByGoodsId(Long goodsId);

    /**
     * 根据diy查询关联DIY方案
     * @Description  
     * @param diyId 查询条件：diy ID
     * @return 产品包房间列表
     * @author guojianbin   
     * @date 2015年12月28日
     */
    public GoodsDiyItem queryByDiyId(Long diyId);
    
    /**
     * 更新DIY方案
     * @param diyDTO
     * @return
     */
    public boolean update(GoodsDiyDTO diyDTO);
    
    /**
     * 新增DIY方案
     * @param diyDTO
     * @return
     */
    public Long create(GoodsDiyDTO diyDTO);
    
    /**
     * 
    * @Description  个人中心里我的diy分页
    * @param userId  用户id
    * @return
    * @author zhaoyonglian   
    * @date 2016年2月25日 上午9:33:59
     */
    public List<GoodsDiyItem> pageDiyByUser(GoodsDiyItem goodsDiyItem,Long userId);
    
    /**
     * 
    * @Description  个人中心我的diy数量
    * @param goodsDiyItem
    * @return
    * @author zhaoyonglian   
    * @date 2016年2月25日 下午1:21:54
     */
    public Long countDiyByUser(GoodsDiyItem goodsDiyItem,Long userId); 
}
