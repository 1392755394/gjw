package com.gjw.company.service.impl.order;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.order.IGesOrderPayMoneyService;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.vo.order.GesOrderVO;

@Service("gesOrderPayMoneyServiceImpl")
public class GesOrderPayMoneyServiceImpl extends AbstractServiceImpl implements IGesOrderPayMoneyService {

    /**
     * <p>
     * 采购管理
     * <p>
     * 采购清单分页查询
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderPayMoney> pageByGesOrderPayMoney(GesOrderVO order) {
        List<GesOrderPayMoney> list = super.getGesOrderPayMoney().pageByGesOrderPayMoney(order);
        for (GesOrderPayMoney gesOrderPayMoney : list) {
            gesOrderPayMoney.getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
            gesOrderPayMoney.getGesOrder().getShop().getName();
            gesOrderPayMoney.getGesOrder().getOperator().getCompanyName();
            gesOrderPayMoney.getGesOrder().getGoods().getName();
        }
        return list;
    }

    /**
     * 采购管理
     * <p>
     * 采购清单,分页查询总数
     */
    @Override
    @Transactional(readOnly = true)
    public Long count(GesOrderVO order) {

        return super.getGesOrderPayMoney().count(order);
    }

    /**
     * 根据订单id查询订单状态
     */
    @Override
    @Transactional(readOnly = true)
    public GesOrderPayMoney getGesOrderPayMoneyByOrderId(Long id) {
        GesOrderPayMoney orderPayMoney = super.getGesOrderPayMoney().getGesOrderPayMoneyByOrderId(id);
        orderPayMoney.getGesOrder().getShop().getName();
        orderPayMoney.getGesOrder().getOperator().getCompanyName();
        orderPayMoney.getGesOrder().getGoods().getName();
        // orderPayMoney.getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Website).getRealName();
        return orderPayMoney;
    }

}
