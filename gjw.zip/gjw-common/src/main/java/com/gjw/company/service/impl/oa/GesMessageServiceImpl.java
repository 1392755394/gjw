package com.gjw.company.service.impl.oa;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.oa.IGesMessageService;
import com.gjw.entity.oa.GesMessage;

/**
 * OA消息service实现
 * @Description: 
 * @author  guojianbin
 * @date 2016年1月16日 
 *
 */
@Component("gesMessageServiceImpl")
public class GesMessageServiceImpl extends AbstractServiceImpl implements IGesMessageService {

    @Override
    @Transactional(readOnly = true)
    public GesMessage queryNewMessage(Long userId) {
        return super.getGesMessageDAO().queryNewMessage(userId);
    }

    @Override
    @Transactional
    public boolean resetNewMessage(int type, Long userId) {
        return super.getGesMessageDAO().resetNewMessage(type, userId);
    }

    @Override
    @Transactional
    public boolean addNewMessage(int type, Long userId, int num) {
        return super.getGesMessageDAO().addNewMessage(type, userId, num);
    }

}
