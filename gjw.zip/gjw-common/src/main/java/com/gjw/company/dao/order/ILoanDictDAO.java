package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.LoanDict;

public interface ILoanDictDAO extends IDAO {
	
	/**
	 * 查询静态信息
	 * @param dict
	 * @return
	 */
	public List<LoanDict> queryByCIP(LoanDict dict);
	
	/**
	 * 查询利率
	 * @param dict
	 * @return
	 */
	public LoanDict queryRate(LoanDict dict);

}
