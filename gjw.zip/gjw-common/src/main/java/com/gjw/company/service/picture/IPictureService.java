package com.gjw.company.service.picture;

import com.gjw.entity.picture.Picture;


public interface IPictureService {
    public Picture get(Long id);
    public void add(Picture picture);
    public void remove(Picture picture);
}
