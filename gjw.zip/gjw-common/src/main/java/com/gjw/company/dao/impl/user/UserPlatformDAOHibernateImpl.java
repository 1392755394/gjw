package com.gjw.company.dao.impl.user;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IUserInfoDAO;
import com.gjw.company.dao.user.IUserPlatformDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserPlatformItem;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("userPlatformDAOHibernateImpl")
public class UserPlatformDAOHibernateImpl extends AbstractDAOHibernateImpl implements IUserPlatformDAO {

    @Override
    protected Class<? extends AbstractEntity> getEntityClass() {
        return UserPlatformItem.class;
    }

    @Override
    public void add(UserPlatformItem item) {
        super.add(item);
    }

}
