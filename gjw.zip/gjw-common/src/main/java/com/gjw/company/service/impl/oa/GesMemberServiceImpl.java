package com.gjw.company.service.impl.oa;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesMemberDAO;
import com.gjw.company.service.oa.IGesMemberService;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.vo.oa.UserVO;

@Component("gesMemberServiceImpl")
public class GesMemberServiceImpl extends AbstractServiceImpl implements
		IGesMemberService {
	
	@Resource(name="gesMemberHibernateImpl")
	private IGesMemberDAO gesMemberDAO;
	
	public IGesMemberDAO getGesMemberDAO() {
		return gesMemberDAO;
	}

	public void setGesMemberDAO(IGesMemberDAO gesMemberDAO) {
		this.gesMemberDAO = gesMemberDAO;
	}

	/**
	 * 后期移动位置
	 */
	@Override
	@Transactional(readOnly=true)
	public UserVO queryUserInfo(long id) {
		
		return getGesMemberDAO().queryUserInfo(id);
	}

	/**
	 * 会员详细(官网用户)
	 * @param id
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public UserVO queryMember(long id) {
		User user=getGesMemberDAO().queryMember(id);
		UserVO userVO=new UserVO();
		userVO.setId(user.getId());
		userVO.setUserName(user.getUsername());
		userVO.setEmail(user.getEmail());
		userVO.setPhone(user.getMobile());
		UserInfo tempUserInfo=user.getUserInfo(PlatformEnum.Website);
		if(tempUserInfo!=null){
			userVO.setRealName(tempUserInfo.getRealName());
		}
		
		return userVO;
	}

}
