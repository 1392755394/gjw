package com.gjw.company.service.impl.collection;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.collection.IWebCollectionItemService;
import com.gjw.entity.collection.WebCollectionItem;

/**
 * 收藏管理
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月25日 下午2:08:07
 * 
 */
@Service("webCollectionItemServiceImpl")
public class WebCollectionItemServiceImpl extends AbstractServiceImpl implements IWebCollectionItemService {

    @Override
    @Transactional
    public boolean delete(Long id) {
        return super.getWebCollectionItemDAO().delete(id) == 1;
    }

    @Override
    @Transactional
    public boolean insert(WebCollectionItem record) {
        return super.getWebCollectionItemDAO().insert(record);
    }

    @Override
    @Transactional(readOnly = true)
    public WebCollectionItem selectTopic(WebCollectionItem collection) {
        return super.getWebCollectionItemDAO().selectTopic(collection);
    }

    @Override
    @Transactional
    public boolean update(WebCollectionItem collection) {
        return super.getWebCollectionItemDAO().update(collection);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebCollectionItem> collectList(WebCollectionItem collection) {
        collection.setStart(null);
        collection.setPageSize(null);
        return super.getWebCollectionItemDAO().collectListWithPage(collection);
    }

    @Override
    @Transactional
    public boolean deleteByContent(WebCollectionItem collection) {
        return super.getWebCollectionItemDAO().deleteByContent(collection);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByContent(WebCollectionItem collection) {
        return super.getWebCollectionItemDAO().countByContent(collection);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebCollectionItem> collectListWithPage(WebCollectionItem collection) {
        return super.getWebCollectionItemDAO().collectListWithPage(collection);
    }

}
