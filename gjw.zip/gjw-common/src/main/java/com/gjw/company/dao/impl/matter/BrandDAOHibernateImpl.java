package com.gjw.company.dao.impl.matter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IBrandDAO;
import com.gjw.entity.matter.Brand;
import com.gjw.utils.StringUtil;


/**
 * 品牌dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月15日 
 *
 */
@Component("brandDAOHibernateImpl")
public class BrandDAOHibernateImpl extends AbstractDAOHibernateImpl implements IBrandDAO {

    @Override
    protected Class<?> getEntityClass() {
        return Brand.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Brand> pageBrandByNameAndType(Brand brandCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Brand b left join fetch b.type where b.invalid = false ");
        hql.append("and b.type.id in (select id from MaterialsCategory) ");
        if (StringUtil.notEmpty(brandCriteria.getCode())) {
            hql.append("  and b.code like ?");
            ls.add(getFuzzyCondition(brandCriteria.getCode()));
        }
        if (StringUtil.notEmpty(brandCriteria.getName())) {
            hql.append("  and b.name like ?");
            ls.add(getFuzzyCondition(brandCriteria.getName()));
        }
        if (brandCriteria.getType() != null) {
            ls.add(brandCriteria.getType().getId());
            hql.append("  and b.type.id=?");
        }
        hql.append("  order by b.code asc");
        return (List<Brand>) super.findByPageCallBack(hql.toString(), "", ls, brandCriteria, null);
    }

    @Override
    public Long countBrandByNameAndType(Brand brandCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Brand b where b.invalid = false ");
        hql.append("and b.type.id in (select id from MaterialsCategory) ");
        if (StringUtil.notEmpty(brandCriteria.getCode())) {
            hql.append("  and b.code like ?");
            ls.add(getFuzzyCondition(brandCriteria.getCode()));
        }
        if (StringUtil.notEmpty(brandCriteria.getName())) {
            hql.append("  and b.name like ?");
            ls.add(getFuzzyCondition(brandCriteria.getName()));
        }
        if (brandCriteria.getType() != null) {
            ls.add(brandCriteria.getType().getId());
            hql.append("  and b.type.id=?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
    
    @Override
    public Brand queryByID(Long id) {
        return (Brand) super.get(id);
    }

    @Override
    public void saveOrUpdate(Brand brand) {
        if (brand.getId() == null || brand.getId() == 0) {
            super.add(brand);
        } else {
            Brand old = (Brand)super.get(brand.getId());
            StringUtil.copyProperties(brand, old);
            super.update(old);
        }
    }

    @Override
    public Long countMaxByType(Brand brandCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Brand b where b.type.id=? ");
        ls.add(brandCriteria.getType().getId());
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

}
