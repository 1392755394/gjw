package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IPaymentRecordResponseDAO;
import com.gjw.entity.order.GesPaymentRecordResponse;

@Component("paymentRecordResponseDAOHibernateImpl")
public class PaymentRecordResponseDAOHibernateImpl extends
		AbstractDAOHibernateImpl implements IPaymentRecordResponseDAO {
	
	private static final Logger log=LoggerFactory.getLogger(PaymentRecordResponseDAOHibernateImpl.class);

	@Override
	protected Class getEntityClass() {
		return GesPaymentRecordResponse.class;
	}

	@Override
	public Integer batchAddPaymentRecordResponse(
			List<GesPaymentRecordResponse> list) {
		return super.batchAdd(list);
	}

	/**
	 * 根据支付流水号更新对账簿的状态为已核算
	 * @param response
	 * @return
	 */
	@Override
	public boolean updatePaymentRecordResponseStatusBySequenceId(
			GesPaymentRecordResponse response) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesPaymentRecordResponse r set r.hadSettled=? where r.cmpySequenceId=? ");
		param.add("y");
		param.add(response.getCmpySequenceId());
		log.info("更新对账簿的信息：hadsettled：y,流水号："+response.getCmpySequenceId());
		return super.updateByParam(hql.toString(), param);
	}
	
	
	
	
}
