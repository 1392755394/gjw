package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.store.GesStore;
import com.gjw.vo.RdRecordsVO;

/**
 * 仓库管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 上午10:48:29
 * 
 */
public interface IGesStoreDAO extends IDAO {

    public List<GesStore> listGesStore(GesStore storeCriteriat);

    public GesStore queryByID(Long id);

    public boolean updateGesStore(GesStore model);

    public boolean createGesStore(GesStore model);

    public Long count(GesStore storeCriteria);

    public List<GesStore> listStoreBySynchType(GesStore stoe);

    /**
     * 根据仓库id修改仓库修改同步结果
     * <p>
     * 仅用户修改仓库同步结果
     * 
     * @Description
     * @param store
     * @author gwb
     * @date 2015年12月17日 上午10:35:45
     */
    public void updateById(GesStore store);

    /**
     * 根据4s店id---or---城运商ID----or构家网查询仓库
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 上午9:36:33
     */
    public List<GesStore> listGesStoreByShopIdOrOperatorId(RdRecordsVO rdRecords);

}
