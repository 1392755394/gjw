package com.gjw.company.service.impl.app;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.app.IWebAdbiceService;
import com.gjw.entity.app.WebAdvice;
@Component("webAdviceServiceImpl")
public class WebAdviceServiceImpl extends AbstractServiceImpl implements IWebAdbiceService{

    @Override
    @Transactional(readOnly=true)
    public WebAdvice get(Long id) {
        // TODO Auto-generated method stub
        return super.getWebAdviceDAO().get(id);
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebAdvice> getList(Integer index, Integer size) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    @Transactional
    public boolean addWebAdvice(WebAdvice webAdvice){
        // TODO Auto-generated method stub
        return super.getWebAdviceDAO().addWebAdvice(webAdvice);
    }

    @Override
    @Transactional()
    public void updateWebAdvice(WebAdvice webAdvice) throws Exception {
        // TODO Auto-generated method stub
        
    }

}
