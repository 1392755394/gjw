package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorContractDAO;
import com.gjw.entity.cityoperator.GesCityOperatorContract;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorContractDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorContractDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorContractDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperatorContract.class;
    }

    @Override
    public GesCityOperatorContract listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperatorContract) super.get(id);
    }

    @Override
    public boolean updateGesCityOperatorContract(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCityOperatorContract(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorContract item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getCompanyName())){
            hql=hql+" and item.companyName like ?";
            params.add(super.getFuzzyCondition(model.getCompanyName()));
        }
        if(StringUtil.notEmpty(model.getAddress())){
            hql=hql+" and item.address like ?";
            params.add(super.getFuzzyCondition(model.getAddress()));
        }
        if(StringUtil.notEmpty(model.getZipCode())){
            hql=hql+" and item.zipCode like ?";
            params.add(super.getFuzzyCondition(model.getZipCode()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if(StringUtil.notEmpty(model.getFax())){
            hql=hql+" and item.fax like ?";
            params.add(super.getFuzzyCondition(model.getFax()));
        }
        if(StringUtil.notEmpty(model.getLegalName())){
            hql=hql+" and item.legalName like ?";
            params.add(super.getFuzzyCondition(model.getLegalName()));
        }
        if(null!=model.getMySignDate()){
            hql=hql+" and DATE_FORMAT(item.mySignDate,'%Y-%m-%d')=?";
            params.add(model.getMySignDate().toString());
        }
        if(null!=model.getCustomerSignDate()){
            hql=hql+" and DATE_FORMAT(item.customerSignDate,'%Y-%m-%d')=?";
            params.add(model.getCustomerSignDate().toString());
        }
        if(null!=model.getStartDate()){
            hql=hql+" and DATE_FORMAT(item.startDate,'%Y-%m-%d')=?";
            params.add(model.getStartDate().toString());
        }
        if(null!=model.getEndDate()){
            hql=hql+" and DATE_FORMAT(item.endDate,'%Y-%m-%d')=?";
            params.add(model.getEndDate().toString());
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperatorContract> listByGesCityOperatorContract(
            GesCityOperatorContract model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorContract item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getCompanyName())){
            hql=hql+" and item.companyName like ?";
            params.add(super.getFuzzyCondition(model.getCompanyName()));
        }
        if(StringUtil.notEmpty(model.getAddress())){
            hql=hql+" and item.address like ?";
            params.add(super.getFuzzyCondition(model.getAddress()));
        }
        if(StringUtil.notEmpty(model.getZipCode())){
            hql=hql+" and item.zipCode like ?";
            params.add(super.getFuzzyCondition(model.getZipCode()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if(StringUtil.notEmpty(model.getFax())){
            hql=hql+" and item.fax like ?";
            params.add(super.getFuzzyCondition(model.getFax()));
        }
        if(StringUtil.notEmpty(model.getLegalName())){
            hql=hql+" and item.legalName=?";
            params.add(super.getFuzzyCondition(model.getLegalName()));
        }
        if(null!=model.getMySignDate()){
            hql=hql+" and DATE_FORMAT(item.mySignDate,'%Y-%m-%d')=?";
            params.add(model.getMySignDate().toString());
        }
        if(null!=model.getCustomerSignDate()){
            hql=hql+" and DATE_FORMAT(item.customerSignDate,'%Y-%m-%d')=?";
            params.add(model.getCustomerSignDate().toString());
        }
        if(null!=model.getStartDate()){
            hql=hql+" and DATE_FORMAT(item.startDate,'%Y-%m-%d')=?";
            params.add(model.getStartDate().toString());
        }
        if(null!=model.getEndDate()){
            hql=hql+" and DATE_FORMAT(item.endDate,'%Y-%m-%d')=?";
            params.add(model.getEndDate().toString());
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCityOperatorContract>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
