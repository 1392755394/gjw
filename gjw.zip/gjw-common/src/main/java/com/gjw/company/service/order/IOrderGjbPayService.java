package com.gjw.company.service.order;

import java.util.Map;

import com.gjw.dto.order.CommitOrderPayDTO;

public interface IOrderGjbPayService {
	
	/**
	 * 网银10%支付处理service
	 * @param orderId
	 * @param userId
	 * @return
	 */
	public CommitOrderPayDTO dealOrderEarnestEbankPay(long orderId,long userId,Map<String, String> map);
	
	/**
	 * 网银90%支付
	 * @param orderId
	 * @param userId
	 * @return
	 */
	public CommitOrderPayDTO dealOrderDepositEbankPay(long orderId, long userId,Map<String, String> map);
	
	/**
	 * 30%确认支付
	 * @param orderId
	 * @param userId
	 * @return
	 */
	public String dealOrderConfirmPay(long orderId, long userId,Map<String, String> map);
	
	/**
	 * 10%和90%支付银行通知
	 * @return
	 */
	public boolean bankNoticeForTenAndNinety(String reqdata, String signature, String transtype,Map<String, String> map);
	
	/**
	 * 30%支付银行通知
	 * @param reqdata
	 * @param signature
	 * @return
	 */
	public String bankNoticeForThirty(String reqdata, String signature);

}
