package com.gjw.company.service.impl.menu;

import java.awt.Menu;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.menu.IGesMenuService;
import com.gjw.entity.menu.GesMenu;
import com.gjw.entity.menu.GesMenuPermissionItem;
import com.gjw.entity.user.Permission;
import com.gjw.entity.user.UserRoleItem;
import com.gjw.utils.StringUtil;
import com.gjw.vo.menu.GesMenuVO;

/**
 * 菜单service实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月10日 
 *
 */
@Component("gesMenuServiceImpl")
public class GesMenuServiceImpl extends AbstractServiceImpl implements IGesMenuService {
    
    @Override
    @Transactional(readOnly=true)
    public List<GesMenu> listMenusByParentId(long parentId) {
        return super.getGesMenuDAO().listMenusByParentId(parentId);
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesMenu> listMenus() {
        return super.getGesMenuDAO().listMenus();
    }
    
    @Override
    @Transactional
    public long create(GesMenu menu){
        return super.getGesMenuDAO().create(menu);
    }
    
    @Override
    @Transactional
    public boolean update(GesMenu menu){
        return super.getGesMenuDAO().update(menu);
    }
    
    @Override
    @Transactional
    public boolean delete(GesMenu menu){
        return super.getGesMenuDAO().delete(menu);
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesMenu> listMenusOfRole(long roleId) {
        List<GesMenu> list = super.getGesMenuDAO().listMenusOfRole(roleId);
        for(int i = 0; i < list.size() ; i++){
            GesMenu gesMenu = list.get(i);
            if (gesMenu.getId() != null){
                try {
                    GesMenu menu = super.getGesMenuDAO().getMenuWithParentById(gesMenu.getId());
                    gesMenu.setParent(menu.getParent());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesMenuVO> roletreeInitAll(int roleId, int parentId) {
        List<GesMenu> menuList4Role = listMenusOfRole(roleId);
        Set<Long> allMenuId4Role = new HashSet<Long>();
        for (GesMenu gesMenu : menuList4Role) {
            allMenuId4Role.add(gesMenu.getId());
        }
        
        List<GesMenu> allMenus = listMenus();
        Set<Long> allMenuParentIds = new HashSet<Long>();
        for (GesMenu gesMenu : allMenus) {
            allMenuParentIds.add(gesMenu.getParent().getId());
        }
        
        List<GesMenu> ls = listMenusByParentId(parentId);
        List<GesMenuVO> newls = new ArrayList<GesMenuVO>();
        for (GesMenu mu : ls) {
            GesMenuVO mvo = new GesMenuVO();
            mvo.setId(mu.getId());
            mvo.setName(mu.getName());
            mvo.setParent(mu.getParent());
            
            if (allMenuParentIds.contains(mu.getId())){
                mvo.setState("closed");
            }
            
            if (allMenuId4Role.contains(mu.getId())){
                mvo.setChecked("true");
            }

            newls.add(mvo);
        }
        return newls;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GesMenu> listMenusOfUser(long userId) {
        List<UserRoleItem> userRoleList = super.getUserRoleDAO().listRolesOfUser(userId);
        if (userRoleList != null && userRoleList.size() > 0){
             return this.listMenusOfRole(userRoleList.get(0).getRole().getId());
        }
        return null;
    }
    
    @Transactional
    public boolean generatePermission4Menu(String target, String permissionStr, boolean init){
        List<Menu2Permission> menu2PermissionList = new ArrayList<Menu2Permission>();
        if (init){
            menu2PermissionList = getDataSource4MenuPermission();
            super.getGesMenuPermissionItemDAO().deleteAll();
        }
        if (StringUtil.isNotEmpty(target) && StringUtil.isNotEmpty(permissionStr)){
            Menu2Permission mp1 = new Menu2Permission(menu2PermissionList, "",target); 
            mp1.addPer(permissionStr);
        }
        for (Menu2Permission menu2Permission : menu2PermissionList) {
            List<GesMenu> menuList = super.getGesMenuDAO().listMenusByTarget(menu2Permission.getTarget().trim());
            if (menuList != null && menuList.size() > 0){
                for (GesMenu gesMenu : menuList) {
                    for (String permission : menu2Permission.permissions) {
                        GesMenuPermissionItem item = new GesMenuPermissionItem();
                        item.setGesMenu(gesMenu);
                        
                        Permission perItem = super.getPermissionDAO().getByName(permission);
                        if (perItem == null){
                            perItem = new Permission();
                            perItem.setName(permission);
                            super.getPermissionDAO().add(perItem);
                            item.setPermission(perItem);
                        } 
                        item.setPermission(perItem);
                        super.getGesMenuPermissionItemDAO().add(item);
                    }
                }
            }
        }
        return true;
    }
    
    
    
    private List<Menu2Permission> getDataSource4MenuPermission(){
        List<Menu2Permission> menu2PermissionList = new ArrayList<Menu2Permission>();
        Menu2Permission mp1 = new Menu2Permission(menu2PermissionList, "客户档案管理","/customerView/customer_list"); 
        mp1.addPer("客户档案管理-查询");
        mp1.addPer("客户档案管理-明细");
        mp1.addPer("客户档案管理-新增修改");
        mp1.addPer("客户档案管理-删除");
        mp1.addPer("客户档案管理-添加日志");
        mp1.addPer("客户档案管理-查询预约");
        mp1.addPer("客户档案管理-查询订单");
        mp1.addPer("客户档案管理-添加预约");
        
        Menu2Permission mp2 = new Menu2Permission(menu2PermissionList, "客户预约管理","/customerView/reserve_list");
        mp2.addPer("客户预约管理-查询");
        mp2.addPer("客户预约管理-明细");
        mp2.addPer("客户预约管理-添加修改预约");
        mp2.addPer("客户预约管理-删除");
        
        Menu2Permission mp3 = new Menu2Permission(menu2PermissionList, "客户日清跟单","/customerView/day_order");
        mp3.addPer("客户日清跟单-查询");
        mp3.addPer("客户日清跟单-日志查询");
        mp3.addPer("客户日清跟单-订单跟踪");
        mp3.addPer("客户日清跟单-添加日志");
        mp3.addPer("客户日清跟单-更新订单");
        
        Menu2Permission mp4 = new Menu2Permission(menu2PermissionList, "城运商管理","/cityOperatorView/tabs");
        mp4.addPer("城运商管理-查询");
        mp4.addPer("城运商管理-明细");
        mp4.addPer("城运商管理-添加");
        mp4.addPer("城运商管理-新增仓库页面");
        mp4.addPer("城运商管理-保存仓库");
        mp4.addPer("城运商管理-合同信息");
        mp4.addPer("城运商管理-关联楼盘");
        mp4.addPer("城运商管理-关联楼盘查询");
        mp4.addPer("城运商管理-已合作楼盘");
        mp4.addPer("城运商管理-已合作楼盘查询");
        
        Menu2Permission mp5 = new Menu2Permission(menu2PermissionList, "4S店管理","/shopView/list");
        mp5.addPer("4S店管理-查询");
        mp5.addPer("4S店管理-明细");
        mp5.addPer("4S店管理-保存");
        mp5.addPer("4S店管理-工作人员查询");
        mp5.addPer("4S店管理-新增修改工作人员");
        mp5.addPer("4S店管理-删除工作人员");
        mp5.addPer("4S店管理-已施工产品包查询");
        mp5.addPer("4S店管理-关联产品查询");
        mp5.addPer("4S店管理-产品查询");
        
        Menu2Permission mp6 = new Menu2Permission(menu2PermissionList, "销售订单","/gesSaleView/so_list");
        mp6.addPer("销售订单-查询");
        mp6.addPer("销售订单-明细");
        mp6.addPer("销售订单-更新");
        
        Menu2Permission mp7 = new Menu2Permission(menu2PermissionList, "销售订单查询","/gesSaleView/so_list?type=query");
        mp7.addPer("销售订单-查询");
        mp7.addPer("销售订单-明细");
        
        Menu2Permission mp8 = new Menu2Permission(menu2PermissionList, "物料查询","/matter/index");
        mp8.addPer("物料查询-查询");
        
        Menu2Permission mp9 = new Menu2Permission(menu2PermissionList, "物料价格查询","/matter/matterprice_index");
        mp9.addPer("物料价格查询-查询");
        
        Menu2Permission mp10 = new Menu2Permission(menu2PermissionList, "仓库管理","/storeView/index");
        mp10.addPer("仓库管理-查询");
        mp10.addPer("仓库管理-添加修改仓库页面");
        mp10.addPer("仓库管理-新增修改仓库");
        mp10.addPer("仓库管理-删除仓库");
        mp10.addPer("仓库管理-库位列表页面");
        mp10.addPer("仓库管理-库位查询");
        mp10.addPer("仓库管理-新增修改库位");
        mp10.addPer("仓库管理-删除库位");
        
        Menu2Permission mp11 = new Menu2Permission(menu2PermissionList, "销售出库单","/gesRdRecordView/sale_out?flag=gjw");
        mp11.addPer("销售出库单-查询");
        mp11.addPer("销售出库单-明细");
        mp11.addPer("销售出库单-同步");
        mp11.addPer("销售出库单-修改");
        
        Menu2Permission mp12 = new Menu2Permission(menu2PermissionList, "销售出库单查询","/gesRdRecordView/sale_out?flag=gjw&type=query");
        mp12.addPer("销售出库单-查询");
        mp12.addPer("销售出库单-明细");
        
        Menu2Permission mp13 = new Menu2Permission(menu2PermissionList, "库存查询","/gesStockView/inventory");
        mp13.addPer("库存查询-查询");
        
        Menu2Permission mp14 = new Menu2Permission(menu2PermissionList, "物料查询","/matter/index");
        mp14.addPer("物料查询-查询");
        
        Menu2Permission mp15 = new Menu2Permission(menu2PermissionList, "仓库查询","/storeView/index?type=query");
        mp15.addPer("仓库管理-查询");
        mp15.addPer("库位列表页面");
        mp15.addPer("库位查询");
        
        Menu2Permission mp16 = new Menu2Permission(menu2PermissionList, "收款管理","/finance/payeelist");
        mp16.addPer("收款管理-查询");
        mp16.addPer("收款管理-明细");
        mp16.addPer("收款管理-添加");
        mp16.addPer("收款管理-更新");
        mp16.addPer("收款管理-同步");
        
        Menu2Permission mp17 = new Menu2Permission(menu2PermissionList, "付款管理","/finance/payerlist");
        mp17.addPer("付款管理-查询");
        mp17.addPer("付款管理-明细");
        mp17.addPer("付款管理-添加付款单");
        mp17.addPer("付款管理-更新付款单");
        
        Menu2Permission mp18 = new Menu2Permission(menu2PermissionList, "登记簿核对","/accountcheck/financechecklist");
        mp18.addPer("登记簿核对-查询");
        
        Menu2Permission mp19 = new Menu2Permission(menu2PermissionList, "4S店银行信息编辑","/finance/shop");
        mp19.addPer("4S店管理-查询");
        mp19.addPer("4S店管理-明细");
        mp19.addPer("4S店管理-保存");
        mp19.addPer("4S店管理-工作人员查询");
        mp19.addPer("4S店管理-新增修改工作人员");
        mp19.addPer("4S店管理-删除工作人员");
        mp19.addPer("4S店管理-已施工产品包查询");
        mp19.addPer("4S店管理-关联产品查询");
        mp19.addPer("4S店管理-产品查询");
        
        Menu2Permission mp20 = new Menu2Permission(menu2PermissionList, "订单线下支付","/gesOrderView/orderlist");
        mp20.addPer("订单线下支付-查询");
        mp20.addPer("订单线下支付-支付记录");
        mp20.addPer("订单线下支付-查询支付记录");
        mp20.addPer("订单线下支付-添加支付记录");
        
        Menu2Permission mp21 = new Menu2Permission(menu2PermissionList, "收款查询","/finance/payeelist?type=query");
        mp21.addPer("收款管理-查询");
        
        Menu2Permission mp22 = new Menu2Permission(menu2PermissionList, "付款查询","/finance/payerlist?type=query");
        mp22.addPer("付款管理-查询");
        
        Menu2Permission mp23 = new Menu2Permission(menu2PermissionList, "基础数据同步","/gesErpCodeView/erp_base_data_listView");
        mp23.addPer("基础数据同步-列表");
        mp23.addPer("基础数据同步-立即同步");
        mp23.addPer("基础数据同步-日志查询页面");
        mp23.addPer("基础数据同步-日志查询");
        
        Menu2Permission mp24 = new Menu2Permission(menu2PermissionList, "数据同步日志查询","/gesErpSynchLogView/erp_base_data_log_listView");
        mp24.addPer("数据同步日志查询-查询");
        
        Menu2Permission mp25 = new Menu2Permission(menu2PermissionList, "实时库存查询","/gesStockView/inventory");
        mp25.addPer("库存查询-查询");
        
        Menu2Permission mp26 = new Menu2Permission(menu2PermissionList, "施工项目管理","/gesOrderView/projectList");
        mp26.addPer("施工项目管理-查询");
        
        Menu2Permission mp27 = new Menu2Permission(menu2PermissionList, "部门管理","/dept/index");
        mp27.addPer("部门列表");
        mp27.addPer("添加部门");
        mp27.addPer("修改部门");
        mp27.addPer("删除部门");
        
        Menu2Permission mp28 = new Menu2Permission(menu2PermissionList, "员工管理","/dept/user_list");
        mp28.addPer("员工查询");
        mp28.addPer("添加员工");
        mp28.addPer("删除员工");
        mp28.addPer("修改员工");
        
        Menu2Permission mp29 = new Menu2Permission(menu2PermissionList, "菜单管理","/menu/edittreegrid");
        mp29.addPer("添加菜单");
        mp29.addPer("修改菜单");
        mp29.addPer("删除菜单");
        mp29.addPer("菜单数据");
        
        Menu2Permission mp30 = new Menu2Permission(menu2PermissionList, "角色管理","/role/list");
        mp30.addPer("角色数据");
        mp30.addPer("更新角色");
        mp30.addPer("添加角色");
        mp30.addPer("删除角色");
        
        Menu2Permission mp31 = new Menu2Permission(menu2PermissionList, "角色菜单","/role/treegrid");
        mp31.addPer("角色数据");
        mp31.addPer("菜单数据");
        mp31.addPer("增加角色菜单");
        mp31.addPer("删除角色菜单");
        
        Menu2Permission mp32 = new Menu2Permission(menu2PermissionList, "用户管理","/user/list");
        mp32.addPer("用户查询");
        mp32.addPer("修改用户");
        mp32.addPer("添加用户");
        mp32.addPer("删除用户");
        
        Menu2Permission mp33 = new Menu2Permission(menu2PermissionList, "房产App用户管理","/house_app/user_list");
        mp33.addPer("房产App用户-查询");
        mp33.addPer("房产App用户-添加");
        mp33.addPer("房产App用户-明细");
        mp33.addPer("房产App用户-修改");
        mp33.addPer("删除用户");
        
        Menu2Permission mp34 = new Menu2Permission(menu2PermissionList, "城市管理","/cityView/city/list");
        mp34.addPer("地市城市查询");
        mp34.addPer("县区城市查询");
        mp34.addPer("加入城市");
        mp34.addPer("移除城市");
        
        Menu2Permission mp35 = new Menu2Permission(menu2PermissionList, "楼盘","/buildingView/list");
        mp35.addPer("楼盘-查询");
        mp35.addPer("楼盘-明细");
        mp35.addPer("楼盘-更新");
        mp35.addPer("楼盘-删除");
        mp35.addPer("楼盘-添加");
        mp35.addPer("楼盘-添加运营商");
        mp35.addPer("楼盘-查询运营商");
        mp35.addPer("楼盘-添加运营商");
        
        Menu2Permission mp36 = new Menu2Permission(menu2PermissionList, "物料管理","/matter/admin_index");
        mp36.addPer("物料查询-查询");
        mp36.addPer("物料管理-添加修改物料");
        mp36.addPer("物料管理--删除物料");
        
        Menu2Permission mp37 = new Menu2Permission(menu2PermissionList, "品牌","/brand/index");
        mp37.addPer("品牌-查询");
        mp37.addPer("品牌-添加修改");
        
        Menu2Permission mp38 = new Menu2Permission(menu2PermissionList, "建材库类目","/materials/category/index");
        mp38.addPer("新增修改类目");
        
        Menu2Permission mp39 = new Menu2Permission(menu2PermissionList, "造型库类目","/materials/category/index");
        mp39.addPer("新增修改类目");
        
        Menu2Permission mp40 = new Menu2Permission(menu2PermissionList, "造型库","/modelling/index");
        mp40.addPer("造型库-查询");
        mp40.addPer("造型库-修改");
        mp40.addPer("造型库-删除");
        mp40.addPer("造型库-添加");
        
        Menu2Permission mp41 = new Menu2Permission(menu2PermissionList, "产品包资源管理","/dictionary/house/index");
        mp41.addPer("新增修改产品包资源");
        mp41.addPer("删除产品包资源");
        
        Menu2Permission mp42 = new Menu2Permission(menu2PermissionList, "产品包管理","/goods/index");
        mp42.addPer("产品包查询");
        mp42.addPer("产品包添加修改");
        mp42.addPer("删除产品包");
        
        Menu2Permission mp43 = new Menu2Permission(menu2PermissionList, "360全景图","/goods/index_3d");
        mp43.addPer("360全景图查询");
        
        Menu2Permission mp44 = new Menu2Permission(menu2PermissionList, "物料","/matter/nodeleteadmin_index");
        mp44.addPer("物料查询-查询");
        mp44.addPer("物料管理-添加修改物料");
        
        Menu2Permission mp45 = new Menu2Permission(menu2PermissionList, "ipad数据配置","/fullViewView/index");
        mp45.addPer("ipad数据配置-查询");
        mp45.addPer("ipad数据配置-添加修改");
        mp45.addPer("ipad数据配置-删除");
        
        Menu2Permission mp46 = new Menu2Permission(menu2PermissionList, "验证码管理","/captcha/index");
        mp46.addPer("验证码管理-查询");
        mp46.addPer("验证码管理-添加修改");
        mp46.addPer("验证码管理-删除");
        
        Menu2Permission mp47 = new Menu2Permission(menu2PermissionList, "接入指引表单","/cityOperatorView/guide_form");
        mp47.addPer("接入指引表单-查询");
        mp47.addPer("接入指引表单-更新");
        mp47.addPer("接入指引表单-删除");
        
        Menu2Permission mp48 = new Menu2Permission(menu2PermissionList, "产品管理","/shopView/manage_shop_goods");
        mp48.addPer("产品管理-查询");
        mp48.addPer("产品管理-上下架");
        
        Menu2Permission mp49 = new Menu2Permission(menu2PermissionList, "采购入库单","/gesStockView/stock_in_list");
        mp49.addPer("采购入库单-查询");
        mp49.addPer("采购入库单-明细");
        mp49.addPer("采购入库单-确认取消");
        
        Menu2Permission mp50 = new Menu2Permission(menu2PermissionList, "发货清单","/gesStockView/deliver_list");
        mp50.addPer("发货清单-查询");
        mp50.addPer("发货清单-明细");
        mp50.addPer("发货清单-发货");
        mp50.addPer("发货清单-发货保存");
        
        Menu2Permission mp51 = new Menu2Permission(menu2PermissionList, "销售出库单","/gesStockView/store_sale_out");
        mp51.addPer("销售出库单-查询");
        mp51.addPer("销售出库单-明细");
        mp51.addPer("销售出库单-修改");
        
        Menu2Permission mp52 = new Menu2Permission(menu2PermissionList, "采购清单","/gesPurchaseView/pur_list");
        mp52.addPer("采购清单-查询");
        mp52.addPer("采购清单-明细");
        mp52.addPer("采购清单-发起采购");
        mp52.addPer("仓库管理-查询");
        mp52.addPer("采购清单-保存采购订单");
        
        Menu2Permission mp53 = new Menu2Permission(menu2PermissionList, "采购订单","/gesPurchaseView/po");
        mp53.addPer("采购订单-查询");
        mp53.addPer("采购订单-明细");
        mp53.addPer("采购订单-手工采购");
        mp53.addPer("仓库管理-查询");
        mp53.addPer("采购订单-保存采购订单");
        
       Menu2Permission mp54 = new Menu2Permission(menu2PermissionList, "采购到货单","/gesPurchaseView/pur_arrival");
       mp54.addPer("采购到货单-查询");
       mp54.addPer("采购到货单-到货");
       mp54.addPer("采购到货单-到货保存");
       
        Menu2Permission mp55 = new Menu2Permission(menu2PermissionList, "客户消息管理","/customerMessageView/search");
        mp55.addPer("客户消息管理-查询");
        
        Menu2Permission mp56 = new Menu2Permission(menu2PermissionList, "消息类目管理","/customerMessageView/category");
        mp56.addPer("消息类目管理-数据列表");
        mp56.addPer("消息类目管理-添加修改");
        mp56.addPer("消息类目管理-删除");
        
        Menu2Permission mp57 = new Menu2Permission(menu2PermissionList, "城运商查询","/cityOperatorView/tabs?type=query");
        mp57.addPer("城运商管理-查询");
        
        Menu2Permission mp58 = new Menu2Permission(menu2PermissionList, "4S店查询","/shopView/list?type=query");
        mp58.addPer("4S店管理-查询");
        
        Menu2Permission mp59 = new Menu2Permission(menu2PermissionList, "销售订单","/gesOrderView/order_list");
        mp59.addPer("销售订单-查询");
        mp59.addPer("销售订单-刷卡");
        mp59.addPer("销售订单-刷卡确定");
        mp59.addPer("销售订单-订单操作");
        mp59.addPer("销售订单-支付记录");
        mp59.addPer("销售订单-查询支付记录");
        mp59.addPer("销售订单-添加支付记录");
        mp59.addPer("销售订单-修改支付记录");
        
        Menu2Permission mp60 = new Menu2Permission(menu2PermissionList, "销售订单查询","/gesOrderView/order_list?type=query");
        mp60.addPer("销售订单-查询");
        
        Menu2Permission mp61 = new Menu2Permission(menu2PermissionList, "销售出库查询","/gesRdRecordView/sale_out?flag=cys4s&type=query");
        mp61.addPer("销售出库单-查询");
        
        Menu2Permission mp62 = new Menu2Permission(menu2PermissionList, "消息录入","/customerMessageView/customer_message");
        mp62.addPer("消息录入-查询");
        mp62.addPer("消息录入-添加客户信息");
        mp62.addPer("消息录入-添加问题日志");
        mp62.addPer("消息录入-明细");
        
        Menu2Permission mp63 = new Menu2Permission(menu2PermissionList, "销售出库单","/gesStockView/store_sale_out?flag=cys4s");
        mp63.addPer("销售出库单-查询");
        mp63.addPer("销售出库单-明细");
        
        Menu2Permission mp64 = new Menu2Permission(menu2PermissionList, "员工管理","/shopView/workers");
        mp64.addPer("员工管理-查询");
        
        Menu2Permission mp65 = new Menu2Permission(menu2PermissionList, "业务反馈","/customerMessageView/customer_message");
        mp65.addPer("业务反馈-查询");
        mp65.addPer("业务反馈-添加客户信息");
        mp65.addPer("业务反馈-添加问题日志");
        mp65.addPer("业务反馈-明细");
        
        Menu2Permission mp66 = new Menu2Permission(menu2PermissionList, "选定目标楼盘","/cityOperatorView/guide?id=1020201");
        mp66.addPer("接入指引表单-查询");
        mp66.addPer("接入指引表单-更新");
        
        Menu2Permission mp67 = new Menu2Permission(menu2PermissionList, "业主装修需求调查及引进样板房意向客户","/cityOperatorView/guide?id=1020202");
        mp67.addPer("接入指引表单-查询");
        mp67.addPer("接入指引表单-更新");
        
        Menu2Permission mp68 = new Menu2Permission(menu2PermissionList, "4S店、仓储加工区、城运总部选址","/cityOperatorView/guide?id=1020203");
        mp68.addPer("接入指引表单-查询");
        mp68.addPer("接入指引表单-更新");
        
        Menu2Permission mp69 = new Menu2Permission(menu2PermissionList, "共建供应链","/cityOperatorView/guide?id=1020204");
        mp69.addPer("接入指引表单-查询");
        mp69.addPer("接入指引表单-更新");
        
        Menu2Permission mp70 = new Menu2Permission(menu2PermissionList, "产品包销售文件及产品包定价","/cityOperatorView/guide?id=1020205");
        mp70.addPer("接入指引表单-查询");
        mp70.addPer("接入指引表单-更新");
        
        Menu2Permission mp71 = new Menu2Permission(menu2PermissionList, "意向客户资源蓄水","/cityOperatorView/guide?id=1020206");
        mp71.addPer("接入指引表单-查询");
        mp71.addPer("接入指引表单-更新");
        
        Menu2Permission mp72 = new Menu2Permission(menu2PermissionList, "房产销售工具植入目标楼盘","/cityOperatorView/guide?id=1020207");
        mp72.addPer("接入指引表单-查询");
        mp72.addPer("接入指引表单-更新");
        
        Menu2Permission mp73 = new Menu2Permission(menu2PermissionList, "4S店、仓储加工区、城运总部标准建设","/cityOperatorView/guide?id=1020208");
        mp73.addPer("接入指引表单-查询");
        mp73.addPer("接入指引表单-更新");
        
        Menu2Permission mp74 = new Menu2Permission(menu2PermissionList, "城市运营团队组建","/cityOperatorView/guide?id=1020209");
        mp74.addPer("接入指引表单-查询");
        mp74.addPer("接入指引表单-更新");
        
        Menu2Permission mp75 = new Menu2Permission(menu2PermissionList, "打造体验房","/cityOperatorView/guide?id=1020210");
        mp75.addPer("接入指引表单-查询");
        mp75.addPer("接入指引表单-更新");
        
        Menu2Permission mp76 = new Menu2Permission(menu2PermissionList, "团队培训 ","/cityOperatorView/guide?id=1020211");
        mp76.addPer("接入指引表单-查询");
        mp76.addPer("接入指引表单-更新");
        
        Menu2Permission mp77 = new Menu2Permission(menu2PermissionList, "互联网装饰4S店开业","/cityOperatorView/guide?id=1020212");
        mp77.addPer("接入指引表单-查询");
        mp77.addPer("接入指引表单-更新");
        
        return menu2PermissionList;
    }
    
    
    class Menu2Permission{
        String menuName;
        String target;
        List<String> permissions = new ArrayList<String>();
        public Menu2Permission(List<Menu2Permission> list, String menuName, String target) {
            super();
            this.menuName = menuName;
            this.target = target;
            list.add(this);
        }
        public String getMenuName() {
            return menuName;
        }
        public void setMenuName(String menuName) {
            this.menuName = menuName;
        }
        public String getTarget() {
            return target;
        }
        public void setTarget(String target) {
            this.target = target;
        }
        public List<String> getPermissions() {
            return permissions;
        }
        public void setPermissions(List<String> permissions) {
            this.permissions = permissions;
        }
        public List<String> addPer(String permission){
            this.permissions.add(permission);
            return this.permissions;
        }
    }
    
    public static void main(String[] args){
        String target = "/cityOperatorView/guide?id=1020201";
        String permission = "接入指引表单-删除";
        System.out.println("http://rges.goujiawang.com/menu/generatePermission4Menu?target=" + java.net.URLEncoder.encode(target) + "&permission=" + java.net.URLEncoder.encode(permission));
    }

}
