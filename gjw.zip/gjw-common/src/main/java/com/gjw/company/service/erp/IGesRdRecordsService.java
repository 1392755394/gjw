package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.vo.RdRecordsVO;

/**
 * * 出入库单明细实体
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月18日 上午10:57:34
 * 
 */
public interface IGesRdRecordsService extends IService {

    /**
     * 新增出入库单明
     * 
     * @Description
     * @param rdRecords
     * @author gwb
     * @date 2015年12月18日 上午11:37:45
     */
    public void create(GesRdRecords rdRecords);

    /**
     * 根据Code查询出库明细
     * 
     * @Description
     * @param rCodes
     * @return
     * @author gwb
     * @date 2015年12月18日 上午11:37:49
     */
    public Long countByCode(GesRdRecords rCodes);

    /**
     * 销售出库单房间与物料分页查询
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月21日 下午4:48:42
     */
    public List<GesRdRecords> pageByRdRecords(RdRecordsVO rdRecords);

    public Long countByRdRecords(RdRecordsVO rdRecords);

    /**
     * 分页查询到货单明细(查询已入库数量不等于到货数量的到货单（销售出库单）)
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 下午4:17:41
     */
    public List<GesRdRecords> pageArrivalByRdRecords(RdRecordsVO rdRecords);

    /**
     * 分页查询到货单明细(查询已入库数量不等于到货数量的到货单（销售出库单）)
     * 
     * @Description
     * @param rdRecords
     * @return
     * @author gwb
     * @date 2015年12月22日 下午4:17:47
     */
    public Long countArrivalByRecords(RdRecordsVO rdRecords);

    /**
     * 保存采购入库单
     * 
     * @Description
     * @param rdRecord
     * @author gwb
     * @date 2015年12月24日 上午9:18:26
     */
    public Long addStockIn(GesRdRecord rdRecord);

    /**
     * <p>
     * 采购到货明细
     * <p>
     * 添加物料关系
     * 
     * @Description
     * @param prices
     * @param stockInCode
     * @param poDetailIds
     * @param goodsId
     * @param roomIds
     * @param amounts
     * @param matterIds
     * @param matterType
     * @return
     * @author gwb
     * @date 2015年12月24日 上午11:09:41
     */
    public boolean batchCreate(String prices, String stockInCode, String poDetailIds, Long goodsId, String roomIds,
            String amounts, String matterIds, String matterType);

    /**
     * <p>
     * 采购到货明细
     * <p>
     * 删除物料关系
     * 
     * @Description
     * @param ids
     * @return
     * @author gwb
     * @date 2015年12月24日 上午11:09:54
     */
    public boolean batchDel(String ids);

    /**
     * 采购到货单---到货
     * <p>
     * 修改删除关联入库数量
     * 
     * @Description
     * @param id
     * @param amount
     * @return
     * @author gwb
     * @date 2015年12月24日 下午5:35:01
     */
    public boolean updateAmountById(Long id, Long amount);

    public void batchCreateStockIn(String prices, String stockInCode, String matterIds, Long goodsId, String roomIds,
            String amounts, String poDetailIds, String matterType);

}
