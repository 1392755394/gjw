package com.gjw.company.service.impl.erp;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.erp.IGesReceiptOrderService;
import com.gjw.entity.erp.GesReceiptOrder;
import com.gjw.vo.GesReceiptOrderVO;

/**
 * 收款单service实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月30日 
 *
 */
@Component("gesReceiptOrderServiceImpl")
public class GesReceiptOrderServiceImpl extends AbstractServiceImpl implements IGesReceiptOrderService {

    @Override
    @Transactional(readOnly = true)
    public List<GesReceiptOrder> pageReceiptOrder(GesReceiptOrderVO receiptOrder) {
        List<GesReceiptOrder> list = super.getGesReceiptOrderDAO().pageReceiptOrder(receiptOrder);
        for (GesReceiptOrder r: list) {
            if (r.getAuditUser() != null) {
                Hibernate.initialize(r.getAuditUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
            }
        }
        
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countReceiptOrder(GesReceiptOrderVO receiptOrder) {
        return super.getGesReceiptOrderDAO().countReceiptOrder(receiptOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public GesReceiptOrder queryByID(Long id) {
        return super.getGesReceiptOrderDAO().queryByID(id);
    }

    @Override
    @Transactional
    public long create(GesReceiptOrder receiptOrder) {
        return super.getGesReceiptOrderDAO().create(receiptOrder);
    }

    @Override
    @Transactional
    public boolean update(GesReceiptOrder receiptOrder) {
        return super.getGesReceiptOrderDAO().update(receiptOrder);
    }

    @Override
    @Transactional
    public Integer batchCreate(List<GesReceiptOrder> receiptOrderList) {
        return super.getGesReceiptOrderDAO().batchCreate(receiptOrderList);
    }

    @Override
    @Transactional(readOnly = true)
    public GesReceiptOrder queryByUniqueID(Long uniqueId) {
        return super.getGesReceiptOrderDAO().queryByUniqueID(uniqueId);
    }

}
