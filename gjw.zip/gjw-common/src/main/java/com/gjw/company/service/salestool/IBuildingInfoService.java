package com.gjw.company.service.salestool;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.salestool.BuildingInfo;

public interface IBuildingInfoService extends IService{
	
	public List<BuildingInfo> pageBuildingInfo(BuildingInfo buildinginfo);
	
	public Long count(BuildingInfo buildinginfo);

	public long create(BuildingInfo buildinginfo);
	
	public boolean update(BuildingInfo buildinginfo);
			
	public BuildingInfo queryByID(Long id);
	
	public boolean deletes(String ids);
	
	public List<Goods> pageGoods4BuildingInfo(BuildingInfo buildingInfo);
    
    public Long countGoods4BuildingInfo(BuildingInfo buildingInfo);
}
