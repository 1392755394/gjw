/**
 * Project Name:ges-service-goujia
 * File Name:ERPBaseDataService.java
 * Package Name:com.goujia.ges.service
 * Date:2015年8月7日下午2:20:17
 * Copyright (c) 2015, chenzhou1025@126.com All Rights Reserved.
 *
 */

package com.gjw.company.service.erp;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.matter.MatterUnit;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;

/**
 * ClassName:ERPBaseDataService <br/>
 * Reason: ERP数据同步service <br/>
 * Date: 2015年8月7日 下午2:20:17 <br/>
 * 
 * @author 1
 * @version
 * @since JDK 1.6
 * @see
 */
public interface IERPBaseDataService {

    /**
     * 销售订单自动流转接 Insert
     * 
     * @author gwb
     * @param xml
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:22:26
     */
    public String SO_SOMainWsInsert(HttpServletRequest request, String xml, String cSerialnumber);

    public String SO_SOMainWsUpdate(HttpServletRequest request, String xml, String cSerialnumber);

    /**
     * 现存量情况表（城运商查询）接口 CurrentStockWsGetAll
     * 
     * @author gwb
     * @param cInvCode
     * @param cWhCode
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:23:43
     */
    public String CurrentStockWsGetAll(HttpServletRequest request, String cInvCode, String cWhCode, String cSerialnumber);

    public String CurrentStockWsGetAll2(HttpServletRequest request, String cInvCode, String cCusCode, String cDefine3,
            String dDateB, String dDateE, String cRollback, String cSerialnumber);

    public String CurrentStockWsUpdate(HttpServletRequest request, String cCode, int rows, String cSerialnumber);

    /**
     * 销售收款情况表(客户对帐单)接口 GL_accvouchWsGetAll
     * 
     * @author gwb
     * @param citem_id
     * @param ccus_id
     * @param cdefine3
     * @param dDateB
     * @param dDateE
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:27:26
     */
    public String GL_accvouchWsGetAll(HttpServletRequest request, String citem_id, String ccus_id, String cdefine3,
            String dDateB, String dDateE, String cSerialnumber);

    /**
     * 客户档案需要同步接口 CustomerWsInsert
     * 
     * @author gwb
     * @param cCusCode
     * @param cCusName
     * @param cCusAbbName
     * @param cCCCode
     * @param cSerialnumbe
     * @param listShop
     * @return 2015年8月7日 下午2:27:15
     */
    public String CustomerWsInsert(HttpServletRequest request, String cCusCode, String cCusName, String cCusAbbName,
            String cCCCode, String cSerialnumbe, List<GesShop> listShop);

    public String CustomerWsUpdate(HttpServletRequest request, String cCusCode, String cCusName, String cCusAbbName,
            String cCCCode, String cSerialnumbe, GesShop shop);

    /**
     * 存货分类档案需要同步接口
     */
    public String InventoryClassWsInsert(HttpServletRequest request, String cInvCCode, String cInvCName,
            String cSerialnumbe, List<Map<String, Object>> listMaterialsCategory, Long cuid);

    public String InventoryClassWsUpdate(HttpServletRequest request, String cInvCCode, String cInvCName,
            String cSerialnumbe, Map<String, Object> materialsCategory);

    /**
     * 存货档案需要同步接口
     */

    public String InventoryWsInsert(HttpServletRequest request, String cInvCode, String cInvName, String cInvCCode,
            String cComUnitCode, String cSerialnumbe, List<Matter> listMatter, Long cuid);

    public String InventoryWsUpdate(HttpServletRequest request, String cInvCode, String cInvName, String cInvCCode,
            String cComUnitCode, String cSerialnumbe, Matter matter);

    /**
     * 部门档案需要同步接口
     */
    public String DepartmentWsInsert(HttpServletRequest request, String cDepCode, String cDepName, String cSerialnumbe,
            List<Dept> list, Long cuid);

    public String DepartmentWsUpdate(HttpServletRequest request, String cDepCode, String cDepName, String cSerialnumbe,
            Dept dept);

    /**
     * 人员档案需要同步接口
     */
    public String PersonWsInsert(HttpServletRequest request, String cPersonCode, String cPersonName, String cDepCode,
            String rSex, String cSerialnumbe, List<DeptUser> listUserVO, Long cuid);

    public String PersonWsUpdate(HttpServletRequest request, String cPersonCode, String cPersonName, String cDepCode,
            String rSex, String cSerialnumbe, DeptUser userVO);

    /**
     * 仓库档案需要同步接口
     */
    public String WarehouseWsInsert(HttpServletRequest request, String cWhCode, String cWhName, String cSerialnumber,
            List<GesStore> listStoreVO, Long cuid);

    public String WarehouseWsUpdate(HttpServletRequest request, String cWhCode, String cWhName, String cSerialnumber,
            GesStore storeVO);

    /**
     * 项目档案需要同步 施工项目
     */

    public String Fitemss97WsInsert(HttpServletRequest request, String citemcode, String citemname,
            String cSerialnumber, List<GesOrder> listOrder, Long cuid);

    public String Fitemss97WsUpdate(HttpServletRequest request, String citemcode, String citemname,
            String cSerialnumber, GesOrder order);

    /**
     * 计量单位档案需要同步 单位
     */

    public String ComputationUnitWsInsert(HttpServletRequest request, String cComunitCode, String cComUnitName,
            String cSerialnumber, List<MatterUnit> listMatter, Long cuid);

    public String ComputationUnitWsUpdate(HttpServletRequest request, String cComunitCode, String cComUnitName,
            String cSerialnumber, MatterUnit matter);

    /**
     * 往来单位分类档案需要同步
     */
    public String CustomerClassWsInsert(HttpServletRequest request, String cCCCode, String cCCName, String cSerialnumber);

    public String CustomerClassWsUpdate(HttpServletRequest request, String cCCCode, String cCCName, String cSerialnumber);

    /**
     * 客户档案需要同步接口 成运商 CustomerWsInsert
     * 
     * @author gwb
     * @param cCusCode
     * @param cCusName
     * @param cCusAbbName
     * @param cCCCode
     * @param cSerialnumbe
     * @param listShop
     * @return 2015年8月7日 下午2:27:15
     */
    public String CustomerWsInsertCity(HttpServletRequest request, String cCusCode, String cCusName,
            String cCusAbbName, String cCCCode, String cSerialnumbe, List<GesCityOperator> listCityOperator, Long cuid);

    public String CustomerWsUpdateCity(HttpServletRequest request, String cCusCode, String cCusName,
            String cCusAbbName, String cCCCode, String cSerialnumbe, GesCityOperator cityOperator);

}
