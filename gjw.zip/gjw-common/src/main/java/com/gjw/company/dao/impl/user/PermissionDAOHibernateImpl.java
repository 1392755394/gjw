package com.gjw.company.dao.impl.user;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IPermissionDAO;
import com.gjw.entity.user.Permission;

import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Epee on 2016-03-03 13:44.
 */
@Component("com.gjw.company.dao.impl.user.PermissionDAOHibernateImpl")
public class PermissionDAOHibernateImpl extends AbstractDAOHibernateImpl implements IPermissionDAO {

    private static final String loadAllPermissionNamesHQL =
            "select P.name from UserPermissionItem UPI join fetch UPI.permission P where UPI.user.id = :userId";

    @Override
    protected Class getEntityClass() {
        return Permission.class;
    }

    @Override
    public List<String> loadAllPermissionNames(Long userId) {
        return (List<String>) getHibernateTemplate().findByNamedParam("loadAllPermissionNames", "userId", userId);
    }

    @Override
    public Permission getByName(String name) {
        List<Permission> list = (List<Permission>) getHibernateTemplate().find(" from Permission where name=?" ,name);
        if (list != null && list.size() > 0){
            return list.get(0);
        }
        return  null;
    }
    
    

}
