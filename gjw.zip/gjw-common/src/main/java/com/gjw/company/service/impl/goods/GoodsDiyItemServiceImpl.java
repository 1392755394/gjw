package com.gjw.company.service.impl.goods;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.common.error.BECode;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.service.goods.IGoodsDiyItemService;
import com.gjw.dto.diy.GoodsDiyDTO;
import com.gjw.dto.diy.GoodsMarkDTO;
import com.gjw.dto.diy.GoodsMatterDTO;
import com.gjw.dto.diy.GoodsRoomDTO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsDiyItem;
import com.gjw.entity.goods.GoodsDiyMatter;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.user.User;
import com.gjw.utils.StringUtil;

/**
 * DIY方案service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月24日
 * 
 */
@Component("goodsDiyItemServiceImpl")
public class GoodsDiyItemServiceImpl extends AbstractServiceImpl implements IGoodsDiyItemService {

    private Logger log = LoggerFactory.getLogger(GoodsDiyItemServiceImpl.class);

    @Override
    @Transactional(readOnly = true)
    public GoodsDiyItem queryStandartDiyByGoodsId(Long goodsId) {
        return super.getGoodsDiyItemDAO().queryStandartDiyByGoodsId(goodsId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsDiyItem> listDiyByGoodsId(Long goodsId) {
        List<GoodsDiyItem> list = super.getGoodsDiyItemDAO().listDiyByGoodsId(goodsId);
        for (GoodsDiyItem diyItem: list) {
            Hibernate.initialize(diyItem.getDiy().getPhoto());
            Hibernate.initialize(diyItem.getDiy().getDiyType());
            Hibernate.initialize(diyItem.getUser());
            Hibernate.initialize(diyItem.getUser().getType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public GoodsDiyItem queryByDiyId(Long diyId) {
        return super.getGoodsDiyItemDAO().queryByDiyId(diyId);
    }

    @Override
    @Transactional
    public Long create(GoodsDiyDTO diyDTO) {
        
        // DIY基础包ID、新建DIY方案ID
        long goodsId, diyId;
        // DIY基础类型
        long diyType = 0;
        // DIY配置检查
        boolean diyCheck = true;
        
        // 新旧空间、锚点对照
        Map<Long,GoodsRoom> roomIdMap = new HashMap<Long,GoodsRoom>();
        Map<Long,GoodsMark> markIdMap = new HashMap<Long,GoodsMark>();
        
        // 创建索引，便于后续查找
        // 房间锚点列表
        Map<Long,GoodsMarkDTO> markInfoMap = new HashMap<Long,GoodsMarkDTO>();
        // DIY增加项
        Map<Long,GoodsMatterDTO> addedMatterMap = new HashMap<Long,GoodsMatterDTO>();
        // DIY减少项
        Map<Long,GoodsMatterDTO> reducedMatterMap = new HashMap<Long,GoodsMatterDTO>();
        // DIY替换项
        Map<Long,GoodsMatterDTO> replacedToMatterMap = new HashMap<Long,GoodsMatterDTO>();
        Map<Long,GoodsMatterDTO> replacedFromMatterMap = new HashMap<Long,GoodsMatterDTO>();
        Map<Long,GoodsMatterDTO> replacedMarkMatterMap = new HashMap<Long,GoodsMatterDTO>();

        log.info("DIY方案数据传输对象，goodsId="+diyDTO.getGoodsId()+"，diyName="+diyDTO.getDiyName()+"，isBackend="+diyDTO.getIsBackend()
                +"，userId="+diyDTO.getUserId()+"，isModify="+diyDTO.getIsModify());
        
        // 登录用户
        User user =new User();
        user.setId(diyDTO.getUserId());
        
        // DIY基础包ID
        goodsId = diyDTO.getGoodsId();
        
        // 取得关联产品包的基本信息
        Goods goods = super.getGoodsDAO().queryById(goodsId);
        // DIY基础类型
        diyType = goods.getDiyType().getId();
        log.info("DIY基础类型，diyType="+diyType);

        //////////////////////////////////////////////////////////////////////////////
        // DIY配置检查
        //////////////////////////////////////////////////////////////////////////////
        // 生成标准DIY方案时，须将标配物料全部配置
        if (diyType == GoodsDiyConstant.IS_DIY_GOODS && diyCheck == true) {
            diyCheck(diyDTO);
        }
        log.info("DIY方案数据传输对象，roomList size="+diyDTO.getRoomList().size());
        
        // 新旧锚点、物料对照
        for (GoodsRoomDTO roomDTO: diyDTO.getRoomList()) {
            // 后台生成标准DIY方案时，可拖动位置，但不可减变动,可增
            // 其他DIY方案在标准DIY方案基础上生成，不可拖动，可增减变动
            if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
                // 房间锚点列表
                log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，markList size="+roomDTO.getMarkList().size());
                for (GoodsMarkDTO markDTO: roomDTO.getMarkList()) {
                    markInfoMap.put(markDTO.getMarkId(), markDTO);
                }
            } else {
                // DIY减少项
                if (roomDTO.getReduceList() != null) {
                    log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，reduceList size="+roomDTO.getReduceList().size());
                    for (GoodsMatterDTO matterDTO: roomDTO.getReduceList()) {
                        reducedMatterMap.put(matterDTO.getMatterId(), matterDTO);
                    }
                }
                // DIY替换项
                if (roomDTO.getReplaceList() != null) {
                    log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，replaceList size="+roomDTO.getReplaceList().size());
                    for (GoodsMatterDTO matterDTO: roomDTO.getReplaceList()) {
                        replacedToMatterMap.put(matterDTO.getMatterId(), matterDTO);
                        replacedFromMatterMap.put(matterDTO.getOriginalId(), matterDTO);
                        replacedMarkMatterMap.put(matterDTO.getMarkId(), matterDTO);
                    }
                }
            }
            // DIY增加项
            if (roomDTO.getAddList() != null) {
                log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，addList size="+roomDTO.getAddList().size());
                for (GoodsMatterDTO matterDTO: roomDTO.getAddList()) {
                    addedMatterMap.put(matterDTO.getMatterId(), matterDTO);
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案的产品包信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案的产品包信息    start");
        Goods diy;
        try {
            diy = (Goods) BeanUtils.cloneBean(goods);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException | NoSuchMethodException e) {
            throw new ErrorCodeException(SECode.s_100010);
        }
        diy.setId(null);
        // 标准DIY，不改名字；用户DIY可命名
        if (diyType != GoodsDiyConstant.IS_DIY_GOODS) {
            diy.setName(diyDTO.getDiyName());
        }
        // 状态:设计中
        diy.setStatus(GoodsDiyConstant.GOODS_STATUS_DESIGNING);
        diy.setUser(user);
        // 所有DIY方案均可再DIY
        diy.setCanDiy(true);
        // 是DIY
        Dictionary type = new Dictionary();
        if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
            // 标准DIY
            type.setId(GoodsDiyConstant.IS_DIY_STANDARD);
            diy.setDiyType(type);
        } else {
            // 用户DIY
            type.setId(GoodsDiyConstant.IS_DIY_USER);
            diy.setDiyType(type);
        }
        // 新建DIY方案，并取得其ID
        diyId = super.getGoodsDAO().create(diy);
        log.info("生成DIY方案的产品包信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案基本信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案基本信息    start");
        GoodsDiyItem goodsDiy = new GoodsDiyItem();
        // DIY方案的ID
        goodsDiy.setDiy(diy);
        // DIY方案的关联产品包的ID：统一为原产品包ID
        // DIY方案的关联DIY方案的ID：标准DIY为0，用户DIY统一为标准DIY
        if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
            // goodsId为原产品包ID
            goodsDiy.setRelationGoods(goods);
            goodsDiy.setRelationDiy(null);
        } else if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
            // goodsId为标准DIY ID
            GoodsDiyItem gd = super.getGoodsDiyItemDAO().queryByDiyId(goodsId);
            // 原产品包ID
            goodsDiy.setRelationGoods(gd.getRelationGoods());
            // 标准DIY ID
            goodsDiy.setRelationDiy(goods);
        } else {
            // goodsId为用户DIY ID
            GoodsDiyItem gd = super.getGoodsDiyItemDAO().queryByDiyId(goodsId);
            // 原产品包ID
            goodsDiy.setRelationGoods(gd.getRelationGoods());
            // 标准DIY ID
            goodsDiy.setRelationDiy(gd.getRelationDiy());
        }
        // 创建者ID
        goodsDiy.setUser(user);
        super.getGoodsDiyItemDAO().create(goodsDiy);
        log.info("生成DIY方案基本信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案空间信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案空间信息    start");
        long oldRoomId;
        List<GoodsRoom> roomList = super.getGoodsRoomDAO().listGoodsRoomByGoodsId(goodsId);
        for (GoodsRoom rm: roomList) {
            oldRoomId = rm.getId();
            GoodsRoom room;
            try {
                room = (GoodsRoom) BeanUtils.cloneBean(rm);
            } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                    | NoSuchMethodException e) {
                throw new ErrorCodeException(SECode.s_100010);
            }
            room.setId(null);
            // 设置DIY方案ID
            room.setGoods(diy);
            room.setUser(user);
            // 根空间ID：产品包为空，标准DIY存产品包空间，用户DIY统一存标准DIY空间
            if (diyType == GoodsDiyConstant.IS_DIY_USER) {
                // DIY基础为用户DIY，取得标准DIY
                room.setRootRoom(rm.getRootRoom());
            } else {
                // DIY基础为产品包、标准DIY，直接用之
                room.setRootRoom(rm);
            }
            super.getGoodsRoomDAO().create(room);
            // 新旧空间对照
            roomIdMap.put(oldRoomId, room);
        }
        log.info("生成DIY方案空间信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案锚点信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案锚点信息    start");
        long oldMarkId;
        List<GoodsMark> markList = super.getGoodsMarkDao().listMarkByGoodsId(goodsId);
        Map<Long,GoodsMark> markMap = new HashMap<Long,GoodsMark>();
        for (GoodsMark mk: markList) {
            markMap.put(mk.getId(), mk);
        }
        
        if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
            // 房间锚点列表:按前端传来的顺序生成
            for (GoodsRoomDTO roomDTO: diyDTO.getRoomList()) {
                for (GoodsMarkDTO markDTO: roomDTO.getMarkList()) {
                    GoodsMark mk = markMap.get(markDTO.getMarkId());
                    oldMarkId = mk.getId();
                    GoodsMark goodsMark;
                    try {
                        goodsMark = (GoodsMark) BeanUtils.cloneBean(mk);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                            | NoSuchMethodException e) {
                        throw new ErrorCodeException(SECode.s_100010);
                    }
                    goodsMark.setId(null);
                    // 设置新空间ID
                    goodsMark.setGoodsRoom(roomIdMap.get(mk.getGoodsRoom().getId()));
                    goodsMark.setUser(user);
                    // 生成标准DIY方案时，可拖动位置
                    if (markInfoMap.get(oldMarkId) != null) {
                        goodsMark.setEffectX(markInfoMap.get(oldMarkId).getRelativeX());
                        goodsMark.setEffectY(markInfoMap.get(oldMarkId).getRelativeY());
                        // TODO
                        //goodsMark.setEffectImage(markInfoMap.get(oldMarkId).getEffectPath());
                        goodsMark.setEffectStyle(markInfoMap.get(oldMarkId).getEffectStyle());
                        Matter matter = new Matter();
                        matter.setId(markInfoMap.get(oldMarkId).getMatterId());
                        goodsMark.setMatter(matter);
                    }
                    super.getGoodsMarkDao().create(goodsMark);
                    // 新旧锚点对照
                    markIdMap.put(oldMarkId, goodsMark);
                }
            }
            // 生成没有DIY的空间的锚点、不可DIY的物料的锚点
            for (GoodsMark mk: markList) {
                oldMarkId = mk.getId();
                if (!markIdMap.containsKey(oldMarkId) && !markIdMap.containsValue(oldMarkId)) {
                    GoodsMark goodsMark;
                    try {
                        goodsMark = (GoodsMark) BeanUtils.cloneBean(mk);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                            | NoSuchMethodException e) {
                        throw new ErrorCodeException(SECode.s_100010);
                    }
                    goodsMark.setId(null);
                    // 设置新空间ID
                    goodsMark.setGoodsRoom(roomIdMap.get(mk.getGoodsRoom().getId()));
                    goodsMark.setUser(user);
                    super.getGoodsMarkDao().create(goodsMark);
                    // 新旧锚点对照
                    markIdMap.put(oldMarkId, goodsMark);
                }
            }
        } else {
            for (GoodsMark mk: markList) {
                oldMarkId = mk.getId();
                GoodsMark goodsMark;
                try {
                    goodsMark = (GoodsMark) BeanUtils.cloneBean(mk);
                } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                        | NoSuchMethodException e) {
                    throw new ErrorCodeException(SECode.s_100010);
                }
                goodsMark.setId(null);
                // 设置新空间ID
                goodsMark.setGoodsRoom(roomIdMap.get(mk.getGoodsRoom().getId()));
                goodsMark.setUser(user);
                // DIY替换项：替换效果图路径、物料ID
                if (replacedMarkMatterMap.isEmpty() == false && replacedMarkMatterMap.containsKey(oldMarkId)) {
                    Matter matter = new Matter();
                    matter.setId(replacedMarkMatterMap.get(oldMarkId).getMatterId());
                    // TODO
                    //goodsMark.setEffectPath(matter.getEffectPath());
                    goodsMark.setMatter(matter);
                }
                super.getGoodsMarkDao().create(goodsMark);
                // 新旧锚点对照
                markIdMap.put(oldMarkId, goodsMark);
            }
        }
        log.info("生成DIY方案锚点信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案物料信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案物料信息    start");
        long matterId;
        // 房间物料列表
        GoodsMatter gmTemp = new GoodsMatter();
        Goods g = new Goods();
        g.setId(goodsId);
        gmTemp.setGoods(g);
        List<GoodsMatter> matterList = super.getGoodsMatterDao().listMatter(gmTemp);
        List<GoodsMatter> goodsMatterList = new ArrayList<GoodsMatter>();
        List<GoodsDiyMatter> diyMatterList = new ArrayList<GoodsDiyMatter>();
        for (GoodsMatter gm: matterList) {
            GoodsMatter goodsMatter = new GoodsMatter();
            GoodsDiyMatter diyMatter = new GoodsDiyMatter();
            matterId = gm.getMatter().getId();
            goodsMatter.setGoods(diy);
            goodsMatter.setMatter(gm.getMatter());
            // 设置新锚点ID
            if (gm.getMark() != null) {
                goodsMatter.setMark(markIdMap.get(gm.getMark().getId()));
            } else {
                goodsMatter.setMark(null);
            }
            // 后台生成标准DIY方案时，不可减变动，可增
            if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
                goodsMatter.setType(gm.getType());
            } else {
                Dictionary t = new Dictionary();
                // 其他DIY方案在标准DIY方案基础上生成，可增减变动
                if (replacedToMatterMap.isEmpty() == false && replacedToMatterMap.containsKey(matterId)) {
                    // DIY替换项：新物料设为标配
                    t.setId(GoodsDiyConstant.GOODS_MATTER_TYPE_STANDARD);
                    goodsMatter.setType(t);
                } else if (replacedFromMatterMap.isEmpty() == false && replacedFromMatterMap.containsKey(matterId)) {
                    // DIY替换项：原物料设为选配
                    t.setId(GoodsDiyConstant.GOODS_MATTER_TYPE_OPTIONAL);
                    goodsMatter.setType(t);
                } else {
                    // 其余不变
                    goodsMatter.setType(gm.getType());
                }
            }
            goodsMatter.setAmount(gm.getAmount());
            // 设置新空间ID
            goodsMatter.setRoom(roomIdMap.get(gm.getRoom().getId()));
            // 后台生成标准DIY方案时，不可减变动，可增
            if (diyType == GoodsDiyConstant.IS_DIY_GOODS) {
                goodsMatter.setIsStandard(gm.getIsStandard());
                if (addedMatterMap.isEmpty() == false && addedMatterMap.containsKey(matterId)) {
                    // DIY增加项：设为是标配
                    goodsMatter.setIsStandard(true);
                }
            } else {
                // 其他DIY方案在标准DIY方案基础上生成，可增减变动
                if (addedMatterMap.isEmpty() == false && addedMatterMap.containsKey(matterId)) {
                    // DIY增加项：设为是标配
                    goodsMatter.setIsStandard(true);
                } else if (reducedMatterMap.isEmpty() == false && reducedMatterMap.containsKey(matterId)) {
                    // DIY减少项：设为非标配
                    goodsMatter.setIsStandard(false);
                } else {
                    // 2015.10.27其余默认设为标配，其他DIY方案可减不可增
                    goodsMatter.setIsStandard(true);
                }
            }
            goodsMatterList.add(goodsMatter);
            
            // 后台生成标准DIY方案时，不可减变动，可增，有DIY清单
            // 其他DIY方案在标准DIY方案基础上生成，可增减变动，有DIY清单
            diyMatter.setGoods(diy);
            diyMatter.setMatter(gm.getMatter());
            if (gm.getMark() != null) {
                diyMatter.setMark(markIdMap.get(gm.getMark().getId()));
            } else {
                diyMatter.setMark(null);
            }
            diyMatter.setType(gm.getType());
            diyMatter.setAmount(gm.getAmount());
            diyMatter.setRoom(roomIdMap.get(gm.getRoom().getId()));
            diyMatter.setIsStandard(gm.getIsStandard());
            Dictionary oprateType = new Dictionary();
            if (addedMatterMap.isEmpty() == false && addedMatterMap.containsKey(matterId)) {
                // DIY增加项
                oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_ADD);
                diyMatter.setOprateType(oprateType);
                diyMatterList.add(diyMatter);
            } else if (reducedMatterMap.isEmpty() == false && reducedMatterMap.containsKey(matterId)) {
                // DIY减少项
                oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_REDUCE);
                diyMatter.setOprateType(oprateType);
                diyMatterList.add(diyMatter);
            } else if (replacedToMatterMap.isEmpty() == false && replacedToMatterMap.containsKey(matterId)) {
                // DIY替换项
                oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_REPLACE);
                diyMatter.setOprateType(oprateType);
                Matter matter = new Matter();
                matter.setId(replacedToMatterMap.get(matterId).getOriginalId());
                diyMatter.setOriginal(matter);
                diyMatterList.add(diyMatter);
            }

        }
        if (goodsMatterList.size() > 0) {
            super.getGoodsMatterDao().batchCreate(goodsMatterList);
        }
        log.info("生成DIY方案物料信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案清单信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案清单信息    start");
        if (diyMatterList.size() > 0) {
            super.getGoodsDiyMatterDAO().batchCreate(diyMatterList);
        }
        log.info("生成DIY方案清单信息    end");
        
        log.info("保存产品包成功，diyId="+diyId);
        return diyId;
    }

    /**
     * DIY配置检查：须将标配物料全部配置，且提示何空间何物料
     * @Description  
     * @param diyDTO 
     * @return 检查结果
     * @author guojianbin   
     * @date 2015年12月29日
     */
    private boolean diyCheck(GoodsDiyDTO diyDTO) {
        
        // 物料锚点列表
        Map<Long,GoodsMarkDTO> markInfoMap = new HashMap<Long,GoodsMarkDTO>();
        for (GoodsRoomDTO roomDTO: diyDTO.getRoomList()) {
            for (GoodsMarkDTO markDTO: roomDTO.getMarkList()) {
                markInfoMap.put(markDTO.getMatterId(), markDTO);
            }
        }

        // 房间物料列表
        GoodsMatter gmTemp = new GoodsMatter();
        Goods g = new Goods();
        g.setId(diyDTO.getGoodsId());
        gmTemp.setGoods(g);
        Dictionary type = new Dictionary();
        type.setId(GoodsDiyConstant.GOODS_MATTER_TYPE_STANDARD);
        gmTemp.setType(type);
        
        // 取得空间列表
        List<GoodsRoom> roomList = super.getGoodsRoomDAO().listGoodsRoomByGoodsId(diyDTO.getGoodsId());
        // 循环判断每个空间的有锚点标配物料是否全部配置
        for (GoodsRoom gr: roomList) {
            // 去除不可DIY的空间
            if (gr.getCanDiy()) {
                GoodsRoom goodsRoom = new GoodsRoom();
                goodsRoom.setId(gr.getId());
                gmTemp.setRoom(goodsRoom);
                // 房间物料列表
                List<GoodsMatter> matterList = super.getGoodsMatterDao().listMatter(gmTemp);
                for (GoodsMatter goodsMatter: matterList) {
                    // 硬装、软装
                    if (goodsMatter.getMatter().getClassification().getId() == GoodsDiyConstant.MATTER_CLASSIFICATION_HARD
                            || goodsMatter.getMatter().getClassification().getId() == GoodsDiyConstant.MATTER_CLASSIFICATION_SOFT) {
                        // 该物料有锚点但未被配置
                        if (goodsMatter.getMark() != null && !markInfoMap.containsKey(goodsMatter.getMatter().getId())) {
                            throw new ErrorCodeException(BECode.diy_300001, new Object[]{gr.getName(), goodsMatter.getMatter().getName()});
                        }
                    }
                }
            }
        }
        
        return true;
    }

    @Override
    @Transactional
    public boolean update(GoodsDiyDTO diyDTO) {

        // DIY方案ID
        long diyId;
        // DIY类型
        long diyType = 0;
        
        // 新旧锚点对照
        Map<Long,GoodsMark> markIdMap = new HashMap<Long,GoodsMark>();
        
        // 创建索引，便于后续查找
        // 房间锚点列表
        Map<Long,GoodsMarkDTO> markInfoMap = new HashMap<Long,GoodsMarkDTO>();
        // DIY增加项
        Map<Long,GoodsMatterDTO> addedMatterMap = new HashMap<Long,GoodsMatterDTO>();
        // DIY减少项
        Map<Long,GoodsMatterDTO> reducedMatterMap = new HashMap<Long,GoodsMatterDTO>();
        // DIY替换项
        Map<Long,GoodsMatterDTO> replacedToMatterMap = new HashMap<Long,GoodsMatterDTO>();
        Map<Long,GoodsMatterDTO> replacedFromMatterMap = new HashMap<Long,GoodsMatterDTO>();
        Map<Long,GoodsMatterDTO> replacedMarkMatterMap = new HashMap<Long,GoodsMatterDTO>();

        log.info("DIY方案数据传输对象，goodsId="+diyDTO.getGoodsId()+"，diyName="+diyDTO.getDiyName()+"，isBackend="+diyDTO.getIsBackend()
                +"，userId="+diyDTO.getUserId()+"，isModify="+diyDTO.getIsModify());
        
        // DIY方案ID
        diyId = diyDTO.getGoodsId();
        
        // 取得关联产品包的基本信息
        Goods goods = super.getGoodsDAO().queryById(diyId);
        // DIY类型
        diyType = goods.getDiyType().getId();
        log.info("DIY类型，isDiy="+diyType);

        // 新旧锚点对照
        for (GoodsRoomDTO roomDTO: diyDTO.getRoomList()) {
            // 后台编辑标准DIY方案时，可拖动位置；编辑用户DIY时，不可拖动位置，可增减变动
            if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
                // 房间锚点列表
                log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，markList size="+roomDTO.getMarkList().size());
                for (GoodsMarkDTO markDTO: roomDTO.getMarkList()) {
                    markInfoMap.put(markDTO.getMarkId(), markDTO);
                }
            } else {
                // DIY减少项
                if (roomDTO.getReduceList() != null) {
                    log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，reduceList size="+roomDTO.getReduceList().size());
                    for (GoodsMatterDTO matterDTO: roomDTO.getReduceList()) {
                        reducedMatterMap.put(matterDTO.getMatterId(), matterDTO);
                    }
                }
                // DIY替换项
                if (roomDTO.getReplaceList() != null) {
                    log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，replaceList size="+roomDTO.getReplaceList().size());
                    for (GoodsMatterDTO matterDTO: roomDTO.getReplaceList()) {
                        replacedToMatterMap.put(matterDTO.getMatterId(), matterDTO);
                        replacedFromMatterMap.put(matterDTO.getOriginalId(), matterDTO);
                        replacedMarkMatterMap.put(matterDTO.getMarkId(), matterDTO);
                    }
                }
                // DIY增加项
                if (roomDTO.getAddList() != null) {
                    log.info("DIY方案数据传输对象，roomId="+roomDTO.getRoomId()+"，addList size="+roomDTO.getAddList().size());
                    for (GoodsMatterDTO matterDTO: roomDTO.getAddList()) {
                        addedMatterMap.put(matterDTO.getMatterId(), matterDTO);
                    }
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////
        // 更新DIY方案的产品包信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("更新DIY方案的产品包信息    start");
        // 标准DIY，不改名字；用户DIY可改名
        if (diyType == GoodsDiyConstant.IS_DIY_USER && !goods.getName().equals(diyDTO.getDiyName())) {
            goods.setName(diyDTO.getDiyName());
            super.getGoodsDAO().update(goods);
        }
        log.info("更新DIY方案的产品包信息    end");

        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案锚点信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案锚点信息    start");
        long oldMarkId;
        List<GoodsMark> markList = super.getGoodsMarkDao().listMarkByGoodsId(diyId);
        Map<Long,GoodsMark> markMap = new HashMap<Long,GoodsMark>();
        for (GoodsMark mk: markList) {
            markMap.put(mk.getId(), mk);
        }
        // 后台编辑标准DIY方案时，可拖动位置；编辑用户DIY时，不可拖动位置，可增减变动
        if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
            // 房间锚点列表:按前端传来的顺序生成
            for (GoodsRoomDTO roomDTO: diyDTO.getRoomList()) {
                // 按空间删除原有锚点列表，重新生成
                super.getGoodsMarkDao().deleteByRoomId(roomDTO.getRoomId());
                for (GoodsMarkDTO markDTO: roomDTO.getMarkList()) {
                    GoodsMark mk = markMap.get(markDTO.getMarkId());
                    oldMarkId = mk.getId();
                    GoodsMark goodsMark;
                    try {
                        goodsMark = (GoodsMark) BeanUtils.cloneBean(mk);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                            | NoSuchMethodException e) {
                        throw new ErrorCodeException(SECode.s_100010);
                    }
                    goodsMark.setId(null);
                    if (markInfoMap.get(oldMarkId) != null) {
                        goodsMark.setEffectX(markInfoMap.get(oldMarkId).getRelativeX());
                        goodsMark.setEffectY(markInfoMap.get(oldMarkId).getRelativeY());
                        //goodsMark.setEffectImage(markInfoMap.get(oldMarkId).getEffectPath());
                        goodsMark.setEffectStyle(markInfoMap.get(oldMarkId).getEffectStyle());
                        Matter matter = new Matter();
                        matter.setId(markInfoMap.get(oldMarkId).getMatterId());
                        goodsMark.setMatter(matter);
                    }
                    super.getGoodsMarkDao().create(goodsMark);
                    // 新旧锚点对照
                    markIdMap.put(oldMarkId, goodsMark);
                }
                // 生成不可DIY的物料的锚点
                for (GoodsMark mk: markList) {
                    oldMarkId = mk.getId();
                    if (!markIdMap.containsKey(oldMarkId) && !markIdMap.containsValue(oldMarkId)
                            && mk.getGoodsRoom().getId() == roomDTO.getRoomId()) {
                        GoodsMark goodsMark;
                        try {
                            goodsMark = (GoodsMark) BeanUtils.cloneBean(mk);
                        } catch (IllegalAccessException | InstantiationException | InvocationTargetException
                                | NoSuchMethodException e) {
                            throw new ErrorCodeException(SECode.s_100010);
                        }
                        goodsMark.setId(null);
                        super.getGoodsMarkDao().create(goodsMark);
                        // 新旧锚点对照
                        markIdMap.put(oldMarkId, goodsMark);
                    }
                }
            }
        } else {
            for (GoodsMark mk: markList) {
                oldMarkId = mk.getId();
                // DIY替换项：物料
                if (replacedMarkMatterMap.isEmpty() == false && replacedMarkMatterMap.containsKey(oldMarkId)) {
                    Matter matter = new Matter();
                    matter.setId(replacedMarkMatterMap.get(oldMarkId).getMatterId());
                    mk.setMatter(matter);
                }
                super.getGoodsMarkDao().update(mk);
            }
        }
        log.info("生成DIY方案锚点信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案物料信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案物料信息    start");
        long matterId;
        GoodsMatter gmTemp = new GoodsMatter();
        Goods g = new Goods();
        g.setId(diyId);
        gmTemp.setGoods(g);
        List<GoodsMatter> matterList = super.getGoodsMatterDao().listMatter(gmTemp);
        List<GoodsDiyMatter> userDiyMatterList = new ArrayList<GoodsDiyMatter>();
        for (GoodsMatter gm: matterList) {
            GoodsMatter goodsMatter = new GoodsMatter();
            GoodsDiyMatter diyMatter = new GoodsDiyMatter();
            matterId = gm.getMatter().getId();
            goodsMatter.setId(gm.getId());
            //log.info("---------------------------------------------------------------------");
            //log.info("matter.markId:" + mvo.getMarkId());
            //log.info("markIdMap.newMarkId:" + markIdMap.get(mvo.getMarkId()));
            // 后台编辑标准DIY方案时，可拖动位置；编辑用户DIY时，不可拖动位置，可增减变动
            if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
                // 无锚点则不更新
                if (gm.getMark() != null && markIdMap.get(gm.getMark().getId()) != null ) {
                    // 设置新锚点ID
                    goodsMatter.setMark(markIdMap.get(gm.getMark().getId()));
                    // 后台编辑标准DIY方案
                    super.getGoodsMatterDao().update(goodsMatter);
                }
            } else {
                // 有无变化
                boolean isChanged = false;
                Dictionary t = new Dictionary();
                if (replacedToMatterMap.isEmpty() == false && replacedToMatterMap.containsKey(matterId)) {
                    isChanged = true;
                    // DIY替换项：新物料设为标配
                    t.setId(GoodsDiyConstant.GOODS_MATTER_TYPE_STANDARD);
                    goodsMatter.setType(t);
                } else if (replacedFromMatterMap.isEmpty() == false && replacedFromMatterMap.containsKey(matterId)) {
                    isChanged = true;
                    // DIY替换项：原物料设为选配
                    t.setId(GoodsDiyConstant.GOODS_MATTER_TYPE_OPTIONAL);
                    goodsMatter.setType(t);
                }
                
                if (addedMatterMap.isEmpty() == false && addedMatterMap.containsKey(matterId)) {
                    isChanged = true;
                    // DIY增加项：设为是标配
                    goodsMatter.setIsStandard(true);
                } else if (reducedMatterMap.isEmpty() == false && reducedMatterMap.containsKey(matterId)) {
                    isChanged = true;
                    // DIY减少项：设为非标配
                    goodsMatter.setIsStandard(false);
                } else {
                    isChanged = true;
                    // 2015.10.27其余默认设为标配，其他DIY方案可减不可增
                    goodsMatter.setIsStandard(true);
                }
                // 无变化则不更新
                if (isChanged) {
                    // 后台编辑用户DIY方案
                    super.getGoodsMatterDao().update(goodsMatter);
                }
                // 编辑用户DIY时，不可拖动位置，可增减变动，有DIY清单
                diyMatter.setGoods(goods);
                diyMatter.setMatter(gm.getMatter());
                if (gm.getMark() != null && markIdMap.get(gm.getMark().getId()) != null) {
                    diyMatter.setMark(markIdMap.get(gm.getMark().getId()));
                } else {
                    diyMatter.setMark(gm.getMark());
                }
                diyMatter.setType(gm.getType());
                diyMatter.setAmount(gm.getAmount());
                diyMatter.setRoom(gm.getRoom());
                diyMatter.setIsStandard(gm.getIsStandard());
                Dictionary oprateType = new Dictionary();
                if (addedMatterMap.isEmpty() == false && addedMatterMap.containsKey(matterId)) {
                    // DIY增加项
                    oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_ADD);
                    diyMatter.setOprateType(oprateType);
                    userDiyMatterList.add(diyMatter);
                } else if (reducedMatterMap.isEmpty() == false && reducedMatterMap.containsKey(matterId)) {
                    // DIY减少项
                    oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_REDUCE);
                    diyMatter.setOprateType(oprateType);
                    userDiyMatterList.add(diyMatter);
                } else if (replacedToMatterMap.isEmpty() == false && replacedToMatterMap.containsKey(matterId)) {
                    // DIY替换项
                    oprateType.setId(GoodsDiyConstant.DIY_OPRATE_TYPE_REPLACE);
                    diyMatter.setOprateType(oprateType);
                    Matter matter = new Matter();
                    matter.setId(replacedToMatterMap.get(matterId).getOriginalId());
                    diyMatter.setOriginal(matter);
                    userDiyMatterList.add(diyMatter);
                }
            }
        }
        log.info("生成DIY方案物料信息    end");
        
        //////////////////////////////////////////////////////////////////////////////
        // 生成DIY方案清单信息
        //////////////////////////////////////////////////////////////////////////////
        log.info("生成DIY方案清单信息    start");
        // 标准DIY，可拖动位置，不可减变动；
        if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
            List<GoodsDiyMatter> diyMatterList = super.getGoodsDiyMatterDAO().listByGoodsId(diyId);
            for (GoodsDiyMatter dm: diyMatterList) {
                //GoodsDiyMatter diyMatter = new GoodsDiyMatter();
                //diyMatter.setId(dm.getId());
                // 无锚点则不更新
                if (dm.getMark() != null && markIdMap.get(dm.getMark().getId()) != null) {
                    dm.setMark(markIdMap.get(dm.getMark().getId()));
                    // 后台编辑标准DIY方案
                    if (diyType == GoodsDiyConstant.IS_DIY_STANDARD) {
                        super.getGoodsDiyMatterDAO().update(dm);
                    }
                }
            }
        } else {
            if (userDiyMatterList.size() > 0) {
                super.getGoodsDiyMatterDAO().deleteByGoodsId(diyId);
                super.getGoodsDiyMatterDAO().batchCreate(userDiyMatterList);
            }
        }
        log.info("生成DIY方案清单信息    end");

        log.info("保存产品包成功，diyId="+diyId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsDiyItem> pageDiyByUser(GoodsDiyItem goodsDiyItem,Long userId) {
        // TODO Auto-generated method stub
        List<GoodsDiyItem> list = super.getGoodsDiyItemDAO().pageDiyByUser(goodsDiyItem,userId);
        if(null != list && list.size()>0){
            for (GoodsDiyItem diy : list) {
                if(StringUtil.notEmpty(diy)){
                    Hibernate.initialize(diy.getDiy().getStyle());
                    Hibernate.initialize(diy.getDiy().getPhoto());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countDiyByUser(GoodsDiyItem goodsDiyItem,Long userId) {
        // TODO Auto-generated method stub
        return super.getGoodsDiyItemDAO().countDiyByUser(goodsDiyItem,userId);
    }

}
