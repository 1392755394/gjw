package com.gjw.company.service.oa;

import java.util.List;
import java.util.Map;

import com.gjw.entity.oa.GesProjectTask;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesCommunicationVO;
import com.gjw.vo.oa.GesProjectTaskQueryVO;
import com.gjw.vo.oa.GesProjectTaskVO;
import com.gjw.vo.oa.UserVO;

/**
 * 任务
 * @author jjw
 *
 */
public interface IGesProjectTaskService {

	/**
	 * 查询用户的所有任务项目以及最新的交流信息
	 * @param 
	 * @return
	 */
	public Map<String, Object> queryAllProjectTaskCommunicationByUserId(GesProjectTaskQueryVO gesProjectTaskVO,UserInfoGES gesUser);
	
	/**
	 * 统计用户的所有任务项目以及最新的交流信息
	 * @param gesProjectTaskVO
	 * @return
	 */
	public Long countAllProjectTaskCommunicationByUserId(GesProjectTaskQueryVO gesProjectTaskVO);
	
	/**
	 * 添加任务和项目
	 * @param gesProjectTask
	 */
	public void createProjectTask(GesProjectTaskVO gesProjectTaskVO,UserVO gesUser,GesProjectTask gesProjectTask);
	
	public Map<String, Object> queryTaskByFeature(GesProjectTaskQueryVO gesProjectTaskVO,UserVO gesUser);
	
	public GesProjectTaskVO queryTaskById(Long taskId);
	
    /**
     * 创建施工项目
     * @Description  
     * @param gesProjectTaskVO 项目
     * @param gesUser 用户
     * @author guojianbin   
     * @date 2016年1月6日 
     */
    public void createConstructionProject(GesProjectTaskVO gesProjectTaskVO, UserVO gesUser);
    
    /**
     * 根据任务id查询该任务的阶段和子任务
     * @param taskId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId);
    
    /**
     * 根据订单ID获取项目
     * @Description  
     * @param orderId 订单ID
     * @author guojianbin   
     * @date 2016年1月6日 
     */
    public List<GesProjectTask> queryByOrderId(Long orderId);
    
    /**
     * 根据任务的id修改任务的状态
     * @param projectTask
     * @return
     */
    public boolean updateTaskStatusByTaskId(GesProjectTask projectTask);
    
    /**
     * 更具阶段id查询该阶段下的任务
     * @param periodId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskByTaskPeriod(Long periodId,String realName,Long cuid);
    
    /**
     * 根据任务的id获取任务的相关信息
     * @param taskId
     * @return
     */
    public GesProjectTaskVO queryNewTaskByTaskId(Long taskId);
    
    /**
     * 根据施工管理项目的id查询该任务的阶段和子任务
     * @param taskId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskIdForPM(Long taskId);
    
    /**
     * 根据施工管理项目阶段名称查询该阶段下的任务
     * @param periodId
     * @return
     */
    public List<GesProjectTaskVO>queryTaskByTaskPeriodForPM(Long taskId,String periodName,String realName,long cuid);
    
    /**
     * 根据任务id查询该任务的阶段和子任务
     * @param taskId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskIdForPM(long taskId);
    
    /**
     * 更新任务的验收状态
     * @param communication
     * @param projectTask
     * @return
     */
    public boolean updateTaskCheckInfo(GesCommunicationVO communication,long cuid,String realName);
    
    /**
    * @Description 根据订单ID查询对应客户的最新项目记录  
    * @param customer
    * @return
    * @author xiaoyang   
    * @date 2016年3月9日 下午2:45:08
     */
    public GesProjectTask projectTaskByCustomer(GesCustomerVO customer);

    public Map<String, Object> taskList(GesProjectTaskQueryVO gesProjectTaskVO,UserVO gesUser);
    
}
