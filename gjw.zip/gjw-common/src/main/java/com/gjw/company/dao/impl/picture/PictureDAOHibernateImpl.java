package com.gjw.company.dao.impl.picture;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.picture.IPictureDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.picture.Picture;

@Component("pictureDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class PictureDAOHibernateImpl extends AbstractDAOHibernateImpl implements IPictureDAO{

    @Override
    public Picture get(Long id){
        Picture picture=(Picture)super.get(id);
        if(picture==null)
            return null;
        List<Picture> thumbnailList=this.listByOrignal(id);
        picture.addThumbnailToMap(thumbnailList);
        return picture;
    }
    
    @Override
    public Picture getWithoutThumbnai(Long id) {
        return (Picture)super.get(id);
    }

    /**
     * 
    * @Description 通用原始图片ID得到所有缩略图  
    * @param orignal
    * @return
    * @author qingye   
    * @date Dec 9, 2015 2:08:19 PM
     */
    private List<Picture> listByOrignal(Long orignal) {
        return (List<Picture>)this.getHibernateTemplate().find("from Picture where original=?",orignal);
    }

    
    @Override
    protected Class<?> getEntityClass() {
        return Picture.class;
    }

    
    @Override
    public int remove(Long id){
        int a=super.remove(id);
        return this.removeByOrignal(id)+a;
    }
    
    @Override
    public void add(AbstractEntity abstractEntity) {
        Picture picture=(Picture)abstractEntity;
        super.add(picture);
        for(Picture thum:picture.getThumbnailSet()){
                thum.setOriginal(picture.getId());
                super.add(thum);
        }
    }
    /**
     * 
    * @Description  通用原始图片ID移除所有缩略图  
    * @param orignal
    * @return
    * @author qingye   
    * @date Dec 9, 2015 2:50:46 PM
     */
    private int removeByOrignal(Long orignal) {
        return this.getHibernateTemplate().bulkUpdate("update Picture set invalid=1 where original=?", orignal);
    }

    
    

}
