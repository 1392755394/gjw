package com.gjw.company.service.user;

import java.util.List;

import com.gjw.entity.user.UserRoleItem;

public interface IUserRoleService {
    
    List<UserRoleItem> listRolesOfUser(long userId);
}
