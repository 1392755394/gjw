package com.gjw.company.service.impl.salestool;


import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.IBuildingInfoService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.salestool.BuildingInfo;
import com.gjw.entity.salestool.BuildingInfoGoods;

@Component("buildingInfoServiceImpl")
public class BuildingInfoServiceImpl extends AbstractServiceImpl implements IBuildingInfoService {

    @Override
    @Transactional(readOnly = true)
    public List<BuildingInfo> pageBuildingInfo(BuildingInfo buildingInfo) {
        return super.getBuildingInfoDAO().pageBuildingInfo(buildingInfo);
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(BuildingInfo buildingInfo) {
        return super.getBuildingInfoDAO().count(buildingInfo);
    }

    @Override
    @Transactional
    public long create(BuildingInfo buildingInfo) {
        return super.getBuildingInfoDAO().create(buildingInfo);
    }

    @Override
    @Transactional
    public boolean update(BuildingInfo buildingInfo) {
        BuildingInfoGoods buildingInfoGoods = new BuildingInfoGoods();
        buildingInfoGoods.setBuildingInfo(buildingInfo);
        Long count = super.getBuildingInfoGoodsDAO().count(buildingInfoGoods);
        if (count > 0){
            buildingInfo.setContainsGoods(true);
        } else {
            buildingInfo.setContainsGoods(false);
        }
        return super.getBuildingInfoDAO().update(buildingInfo);
    }
	
	@Override
    @Transactional(readOnly = true)
    public BuildingInfo queryByID(Long id) {
        BuildingInfo buildingInfo = super.getBuildingInfoDAO().queryByID(id);
        return buildingInfo;
    }
    
    @Override
    @Transactional
    public boolean deletes(String ids) {
        return super.getBuildingInfoDAO().deletes(ids);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageGoods4BuildingInfo(BuildingInfo buildingInfo) {
        List<Goods> resultList = super.getBuildingInfoDAO().pageGoods4BuildingInfo(buildingInfo);
        for (Goods goods : resultList) {
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return resultList;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countGoods4BuildingInfo(BuildingInfo buildingInfo) {
        return super.getBuildingInfoDAO().countGoods4BuildingInfo(buildingInfo);
    }
}

