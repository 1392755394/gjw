package com.gjw.company.service.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesSoMatterItemService;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.user.User;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.RdRecordsVO;

/**
 * <P>
 * 构家网---- 产品包销售订单关联的物料(采购清单)实体
 * <P>
 * 城运商，4s店发起采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月30日 下午2:22:07
 * 
 */
@Service("gesSoMatterItemServiceImpl")
public class GesSoMatterItemServiceImpl extends AbstractServiceImpl implements IGesSoMatterItemService {

    @Override
    @Transactional(readOnly = true)
    public Long count(GesSoMatterVO soMatter) {
        List<GesSoMatterItem> listSoMatter = super.getGesSoMatterItemDAO().ListSoMatter(soMatter);
        return super.getGesSoMatterItemDAO().count(soMatter, listSoMatter);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesSoMatterItem> pageSoMatter(GesSoMatterVO soMatter) {
        RdRecordsVO rdRecords = new RdRecordsVO();
        if (soMatter.getShopId() != null) {
            rdRecords.setShopId(soMatter.getShopId());
        }
        Integer start = soMatter.getStart();
        Integer pageSize = soMatter.getPageSize();

        if (soMatter.getOperatorId() != null) {
            rdRecords.setOperatorId(soMatter.getOperatorId());
        }
        List<GesStore> listStore = super.getGesStoreDAO().listGesStoreByShopIdOrOperatorId(rdRecords);
        List<GesSoMatterItem> listSoMatter = super.getGesSoMatterItemDAO().ListSoMatter(soMatter);

        List<GesSoMatterItem> listGesSoMatterItem = super.getGesSoMatterItemDAO().pageSoMatter(soMatter, listSoMatter,
                start, pageSize);

        for (GesSoMatterItem soMatterItem : listGesSoMatterItem) {
            soMatterItem.getMatter().getName();
            soMatterItem.getMatter().getBrand().getName();
            if (soMatterItem.getRoom() != null) {
                soMatterItem.getRoom().getName();
            }
            rdRecords.setMatterId(soMatterItem.getMatter().getId());
            Long inventory = super.getGesStoreInventoryDAO().sumInventory(rdRecords, listStore);
            soMatterItem.setStockNum(inventory == null ? 0 : inventory.doubleValue());
        }
        return listGesSoMatterItem;
    }

    /**
     * 库存管理
     * 
     * 发货清单 xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 发货管理产品总数查询
     */
    @Override
    @Transactional(readOnly = true)
    public Long countRds(GesSoMatterVO soMatter) {
        List<GesSoMatterItem> listSoMatter = super.getGesSoMatterItemDAO().ListSoMatterByGesGesRdRecords(soMatter);
        return super.getGesSoMatterItemDAO().count(soMatter, listSoMatter);
    }

    /**
     * 库存管理
     * 
     * 发货清单
     * 
     * 发货管理产品总数查询
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesSoMatterItem> pageSoMatterRds(GesSoMatterVO soMatter) {
        RdRecordsVO rdRecords = new RdRecordsVO();
        Integer start = soMatter.getStart();
        Integer pageSize = soMatter.getPageSize();
        if (soMatter.getShopId() != null) {
            rdRecords.setShopId(soMatter.getShopId());
        }
        if (soMatter.getOperatorId() != null) {
            rdRecords.setOperatorId(soMatter.getOperatorId());
        }
        // List<GesStore> listStore =
        // super.getGesStoreDAO().listGesStoreByShopIdOrOperatorId(rdRecords);

        List<GesStore> listStore = new ArrayList<GesStore>();
        // GesStore store = new GesStore();
        // store.setId(soMatter.getId());
        // listStore.add(store);
        rdRecords.setStoreId(soMatter.getStoreId());
        List<GesSoMatterItem> listSoMatter = super.getGesSoMatterItemDAO().ListSoMatterByGesGesRdRecords(soMatter);

        List<GesSoMatterItem> listGesSoMatterItem = super.getGesSoMatterItemDAO().pageSoMatter(soMatter, listSoMatter,
                start, pageSize);

        for (GesSoMatterItem soMatterItem : listGesSoMatterItem) {
            soMatterItem.getMatter().getName();
            soMatterItem.getMatter().getBrand().getName();
            if (soMatterItem.getRoom() != null && soMatterItem.getRoom().getId() > 0) {
                soMatterItem.getRoom().getName();
            }

            rdRecords.setMatterId(soMatterItem.getMatter().getId());
            Long inventory = super.getGesStoreInventoryDAO().sumInventory(rdRecords, listStore);
            soMatterItem.setStockNum(inventory == null ? 0 : inventory.doubleValue());
        }
        return listGesSoMatterItem;
    }

    @Override
    @Transactional
    public boolean saveGesSoMatterItem(Long orderId, Long goodsId, Long cuid) {
        GoodsMatter matter = new GoodsMatter();
        Goods goods = new Goods();
        goods.setId(goodsId);
        matter.setGoods(goods);
        GesOrder order = new GesOrder();
        order.setId(orderId);
        User user = new User();
        user.setId(cuid);
        // 获取物料相关信息
        List<GoodsMatter> listMatter = super.getGoodsMatterDao().listMatter(matter);
        for (GoodsMatter goodsMatter : listMatter) {
            GesSoMatterItem soMatter = new GesSoMatterItem();
            soMatter.setGesOrder(order);
            soMatter.setMatter(goodsMatter.getMatter());
            soMatter.setRoom(goodsMatter.getRoom());
            soMatter.setMarketPrice(goodsMatter.getMatter().getPric());
            soMatter.setPurchasePrice(goodsMatter.getMatter().getGoujiaPrice());
            soMatter.setCostPrice(goodsMatter.getMatter().getBuyPrice());
            soMatter.setQuantity(goodsMatter.getAmount());
            soMatter.setType(goodsMatter.getType());
            soMatter.setStockInQuantity(0);
            soMatter.setStockOutQuantity(0);
            soMatter.setDeliveryQuantity(0);
            soMatter.setSalesPrice(0l);
            soMatter.setUser(user);
            super.getGesSoMatterItemDAO().saveResultBoolean(soMatter);
        }
        return true;
    }
}
