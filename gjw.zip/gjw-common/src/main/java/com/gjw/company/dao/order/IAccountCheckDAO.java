package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.vo.order.PaymentRecordResponseVO;

public interface IAccountCheckDAO extends IDAO {
	
	/**
	 * 根据条件统计支付的总额
	 * @param record
	 * @return
	 */
	public Long sumFinance(PaymentRecordResponseVO record);
	
	/**
	 * 统计符合条件的记录总数
	 * @param record
	 * @return
	 */
	public Long countFinance(PaymentRecordResponseVO record);
	
	/**
	 * 分页获取支付记录
	 * @param record
	 * @return
	 */
	public List<PaymentRecordResponseVO> pageFinance(PaymentRecordResponseVO record);

}
