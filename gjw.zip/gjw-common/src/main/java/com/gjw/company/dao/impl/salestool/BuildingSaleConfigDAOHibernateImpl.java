package com.gjw.company.dao.impl.salestool;

/**
 * @author dabai email:qp(a)goujiawang.com
 */

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.IBuildingSaleConfigDAO;
import com.gjw.entity.salestool.BuildingSaleConfig;
import com.gjw.utils.StringUtil;

@Component("buildingSaleConfigDAOHibernateImpl")
public class BuildingSaleConfigDAOHibernateImpl extends AbstractDAOHibernateImpl implements IBuildingSaleConfigDAO {

    @Override
    protected Class<?> getEntityClass() {
        return BuildingSaleConfig.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<BuildingSaleConfig> pageBuildingSaleConfig(BuildingSaleConfig buildingSaleConfig) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingSaleConfig m ");     
        hql.append("where m.invalid = false ");
        if (buildingSaleConfig.getStatus() != null){
            ls.add(buildingSaleConfig.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingSaleConfig.getBuilding() != null && StringUtil.isNotEmpty(buildingSaleConfig.getBuilding().getName())){
            ls.add(getFuzzyCondition(buildingSaleConfig.getBuilding().getName()));
            hql.append("  and m.building.name like ?");
            
        }
        if (StringUtil.notEmpty(buildingSaleConfig.getSortField())) {
            hql.append("  order by m.").append(buildingSaleConfig.getSortField()).append(" ");
            hql.append(buildingSaleConfig.getSortOrder()).append(" ,m.updatedDatetime desc");
        } else {
            hql.append("  order by m.updatedDatetime desc");
        }
        return (List<BuildingSaleConfig>) super.findByPageCallBack(hql.toString(), "", ls, buildingSaleConfig, null);
    }

    @Override
    public Long count(BuildingSaleConfig buildingSaleConfig) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingSaleConfig m ");
        hql.append("where m.invalid = false ");
        if (buildingSaleConfig.getStatus() != null){
            ls.add(buildingSaleConfig.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingSaleConfig.getBuilding() != null && StringUtil.isNotEmpty(buildingSaleConfig.getBuilding().getName())){
            ls.add(getFuzzyCondition(buildingSaleConfig.getBuilding().getName()));
            hql.append("  and m.building.name like ?");
            
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
   

    @Override
    public BuildingSaleConfig queryByID(long id) {
       return (BuildingSaleConfig)super.get(id);
    }

    @Override
    public long create(BuildingSaleConfig buildingSaleConfig) {
        super.add(buildingSaleConfig);
        return buildingSaleConfig.getId();
    }

    @Override
    public boolean update(BuildingSaleConfig buildingSaleConfig) {
        return super.update( buildingSaleConfig) == 1;
    }
    
    @Override
    public boolean deletes(String ids) {
        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }
    
}
