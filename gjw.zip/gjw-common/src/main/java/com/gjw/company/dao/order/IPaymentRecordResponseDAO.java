package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.GesPaymentRecordResponse;

public interface IPaymentRecordResponseDAO extends IDAO {

	/**
	 * 批量添加
	 * @param list
	 * @return
	 */
	public Integer batchAddPaymentRecordResponse(List<GesPaymentRecordResponse> list);
	
	/**
	 * 根据支付流水号更新对账簿的状态为已核算
	 * @param response
	 * @return
	 */
	public boolean updatePaymentRecordResponseStatusBySequenceId(GesPaymentRecordResponse response);
	
}
