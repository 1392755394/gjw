package com.gjw.company.service.impl.cooperator;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.cooperator.IWebCooperatorDAO;
import com.gjw.company.service.cooperator.IWebCooperatorService;
import com.gjw.entity.cooperator.WebCooperator;

@Component("webCooperatorServiceImpl")
public class WebCooperatorServiceImpl implements IWebCooperatorService {
    @Autowired
    private IWebCooperatorDAO dao;
  

    @Override
    @Transactional(readOnly=true)
    public List<WebCooperator> pageByCondition(WebCooperator cooperator) {
        // TODO Auto-generated method stub
        return dao.pageByCondition(cooperator);
    }

    @Override
    @Transactional(readOnly=true)
    public Long countByCondition(WebCooperator cooperator) {
        // TODO Auto-generated method stub
        return dao.countByCondition(cooperator);
    }

    @Override
    @Transactional
    public boolean save(WebCooperator cooperator) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(cooperator);
    }

}
