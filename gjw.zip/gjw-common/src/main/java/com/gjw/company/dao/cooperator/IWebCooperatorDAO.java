package com.gjw.company.dao.cooperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cooperator.WebCooperator;
import com.gjw.entity.question.WebQuestion;

/**
 * 
* @Description: 合作商（入驻）
* @author  zhaoyonglian
* @date 2015年12月16日 下午4:12:34
*
 */
public interface IWebCooperatorDAO extends IDAO {

	
	/**
	 * 
	* @Description  分页查询
	* @param cooperator
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月16日 下午4:15:47
	 */
	public List<WebCooperator> pageByCondition(WebCooperator cooperator);
	
	/**
	 * 
	* @Description  总算
	* @param cooperator
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月16日 下午4:16:20
	 */
	public Long countByCondition(WebCooperator cooperator);
}
