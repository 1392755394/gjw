package com.gjw.company.dao.impl.salestool;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.ICaptchaDAO;
import com.gjw.entity.salestool.Captcha;
import com.gjw.utils.StringUtil;

@Component("captchaDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class CaptchaDAOHibernateImpl extends AbstractDAOHibernateImpl implements ICaptchaDAO{

    @Override
    public Captcha listByID(Long id) {
        // TODO Auto-generated method stub
        return (Captcha) super.get(id);
    }

    @Override
    public boolean updateCaptcha(Captcha model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createCaptcha(Captcha model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(Captcha model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return Captcha.class;
    }

    @Override
    public Captcha listByBuildingId(Long buildingId) {
        // TODO Auto-generated method stub
        String hql = " from Captcha item where item.invalid=0 and item.building.id=?";
        List<Object> list=new ArrayList<Object>();
        list.add(buildingId);
        return (Captcha) super.queryByParam(hql, list);
    }

    @Override
    public List<Captcha> pageBycaptchaAndBuilding(Captcha cap) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from Captcha where invalid = 0");
        if(StringUtil.notEmpty(cap.getCaptcha())){
            hql.append(" and captcha like ?");
            ls.add("%"+cap.getCaptcha()+"%");
        }
        if(StringUtil.notEmpty(cap.getBuilding()) && StringUtil.notEmpty(cap.getBuilding().getName())){
            hql.append(" and building.name like ?");
            ls.add("%"+cap.getBuilding().getName()+"%");
        }
        hql.append("order by id desc");
         return (List<Captcha>) super.findByPageCallBack(hql.toString(), "", ls, cap, null);
    }

    @Override
    public Long countBycaptchaAndBuilding(Captcha cap) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from Captcha where invalid = 0");
        if(StringUtil.notEmpty(cap.getCaptcha())){
            hql.append(" and captcha like ?");
            ls.add("%"+cap.getCaptcha()+"%");
        }
        if(StringUtil.notEmpty(cap.getBuilding()) && StringUtil.notEmpty(cap.getBuilding().getName())){
            hql.append(" and building.name like ?");
            ls.add("%"+cap.getBuilding().getName()+"%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean batchDel(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            if (StringUtil.notEmpty(id))
                idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }

    @Override
    public List<Captcha> listByCaptcha(String captcha) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from Captcha item where item.invalid=0 and item.captcha ='"+captcha+"' ");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        return query.list();
    }

}
