package com.gjw.company.service.order;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.common.web.JsonResult;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.validation.SmsValidation;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.order.GesOrderVO;

public interface IGesOrderService extends IService {

    /**
     * 订单创建
     * 
     * @param gesOrder
     * @return
     */
    public Long createGesOrder(GesOrder gesOrder);

    /**
     * 订单删除
     * 
     * @param orderId
     * @return
     */
    public Integer deleteGesOrder(GesOrder gesOrder);

    /**
     * 官网 根据购买者ID分页获取订单信息
     * 
     * @param buyerId
     * @return
     */
    public List<GesOrderVO> pageOrderByBuyerIdForWeb(GesOrder gesOrder);

    /**
     * 官网 根据购买者id统计订单的总数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByBuyerIdForWeb(GesOrder gesOrder);

    /**
     * Ges 构家网用户 分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByGjwIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 构家网用户 统计订单数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByGjwIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 城运商用户 根据城运商ID分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByOperatorIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 城运商用户 根据城运商ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByOperatorIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 4S店用户 根据4s店的ID分页查询订单信息
     * 
     * @param gesOrder
     * @return
     */
    public List<GesOrderVO> pageOrderByShopIdForGes(GesOrderVO gesOrderVO);

    /**
     * Ges 4S店用户 根据4s店的ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    public Long countOrderByShopIdForGes(GesOrderVO gesOrderVO);

    /**
     * 根据订单的id更新订单的状态信息
     * 
     * @param gesOrder
     * @return
     */
    public Boolean updateOrderStatusByOrderId(GesOrder gesOrder);

    /**
     * 根据订单id更新订单信息 Ges中修改订单的价格、面积、备注等信息
     * 
     * @param gesOrder
     * @return
     */
    public Boolean updateOrderInfoByOrderId(GesOrder gesOrder);

    /**
     * 官网后台 分页查询订单信息
     * 
     * @param gesOrderVO
     * @return
     */
    public List<GesOrderVO> pageOrderForWebConsole(GesOrderVO gesOrderVO);

    /**
     * 官网后台 统计订单数量
     * 
     * @param gesOrderVO
     * @return
     */
    public Long countOrderForWebConsole(GesOrderVO gesOrderVO);

    /**
     * 根据订单id查询订单信息
     * 
     * @param orderId
     * @return
     */
    public GesOrder queryOrderByOrderId(Long orderId);

    /**
     * Ges 根据4S店ID分页查询该店已完成的订单
     * 
     * @param gesOrderVO
     * @return
     */
    public List<GesOrderVO> pageOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO);

    /**
     * Ges 根据4S店ID统计已完成订单的数量
     * 
     * @param gesOrderVO
     * @return
     */
    public Long countOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO);

    /**
     * 采购清单查询
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2016年1月5日 上午9:19:21
     */
    public List<GesOrder> pageByOrder(GesOrderVO model);

    /**
     * 采购清单总数查询
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2016年1月5日 上午9:19:30
     */
    public Long countByOrder(GesOrderVO model);

    /**
     * 销售订单列表中，查看订单详细信息使用
     * 
     * @param id
     * @return
     */
    public GesOrder queryOrderInfoById(long id);

    /**
     * 测试使用
     * 
     * @param orderId
     * @return
     */
    public int updateStatus(GesOrder order);
    
    /**
     * 更新订单信息
     * @param order
     * @return
     */
    public boolean updateOrder(GesOrder order);

    /**
     * 基础数据同步，项目档案需要同步
     * 
     * @Description
     * @param order
     * @return
     * @author gwb
     * @date 2016年1月16日 上午9:48:59
     */
    public List<GesOrder> baseProjectListPage(GesOrder order);
    
    /**
     * 签署合同
     * @param order
     * @return
     */
    public boolean signOrder(GesOrder order);
    
    /**
     * 订单操作
     * @param order
     * @param action
     * @return
     */
    public boolean doAction(GesOrder order,String action);
    
    /**
     * 统计订单关联产品包的物料
     * @param soMatter
     * @return
     */
    public Long countStandardMatter(GesSoMatterVO soMatter);
    
    /**
     * 分页获取订单关联的物料
     * @param soMatter
     * @return
     */
    public List<GesSoMatterVO> pageStandardMatter(GesSoMatterVO soMatter);

    /**
     * 官网前台 统计该产品包的订单总数
     * 
     * @param goods
     * @return
     */
    public Long countOrderByGoodsForWeb(Goods goods);
    
    /**
     * 官网直播家  获取订单信息
     * @param orderId
     * @return
     */
    public GesOrder queryOrderInfoForLiveHome(Long orderId); 
    
    /**
     * 通过订单id，查询订单信息，返回VO类型
     * @param orderId
     * @return
     */
    public GesOrderVO queryOrderByIdForGjb(Long orderId);
    
    /**
     * 官网上更新订单状态
     * @param orderId
     * @param action
     * @return
     */
    public String updateOrderStatusForWeb(long orderId,String action,Long userId);
    
    /**
     * 订单删除
     * @param orderId
     * @return
     */
    public JsonResult<Integer> deleteOrderByJudgePayment(GesOrder order);
    
    public List<GesOrderVO> queryOrderInfoForExcel(GesOrderVO gesOrderVO);
    
    /**
     * 核对合同校验
     * @param order
     * @param smsValidation
     * @return
     */
    public boolean checkValidateCode(GesOrder order,SmsValidation smsValidation);

}
