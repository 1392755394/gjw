package com.gjw.company.service.impl.menu;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.menu.IGesMenuRoleItemService;
import com.gjw.entity.menu.GesMenuRoleItem;

@Component("gesMenuRoleItemServiceImpl")
@Transactional
public class GesMenuRoleItemServiceImpl extends AbstractServiceImpl implements IGesMenuRoleItemService {

    @Override
    public boolean create(GesMenuRoleItem gesMenuRoleItem) {
        GesMenuRoleItem item = super.getGesMenuRoleItemDAO().getItemByMenuIdAndRoleID(gesMenuRoleItem);
        if (item == null){
            return super.getGesMenuRoleItemDAO().create(gesMenuRoleItem) > 0;
        }
        return true;
    }

    @Override
    public boolean delete(GesMenuRoleItem gesMenuRoleItem) {
        gesMenuRoleItem = super.getGesMenuRoleItemDAO().getItemByMenuIdAndRoleID(gesMenuRoleItem);
        if (gesMenuRoleItem != null){
            return super.getGesMenuRoleItemDAO().delete(gesMenuRoleItem);
        }
        return true;
    }

}
