package com.gjw.company.service.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.order.IWebOrderLogDAO;
import com.gjw.company.dao.order.IWebOrderLogImageDAO;
import com.gjw.company.service.order.IWebOrderLogService;
import com.gjw.entity.order.WebOrderLog;
import com.gjw.entity.order.WebOrderLogImage;
import com.gjw.entity.picture.Picture;
import com.gjw.utils.StringUtil;
import com.gjw.vo.WebOrderLogVO;

@Component("webOrderLogServiceImpl")
public class WebOrderLogServiceImpl implements IWebOrderLogService {

    @Autowired
    private IWebOrderLogDAO dao;

    @Autowired
    private IWebOrderLogImageDAO imageDao;

    @Override
    @Transactional(readOnly = true)
    public WebOrderLog getById(Long id) {
        // TODO Auto-generated method stub
        WebOrderLog lo = dao.getById(id);
        if (null != lo) {
            lo.getLabel().getName();
        }
        List<WebOrderLogImage> images = imageDao.listByLog(id);
        if (null != images && images.size() > 0) {
            for (WebOrderLogImage webOrderLogImage : images) {
                webOrderLogImage.getImage().getPath();
            }
        }
        lo.setImageList(images);
        return lo;
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebOrderLog> pageByContent(WebOrderLogVO log) {
        // TODO Auto-generated method stub
        List<WebOrderLog> list = dao.pageByContent(log);
        if (null != list && list.size() > 0) {
            for (WebOrderLog webOrderLog : list) {
                webOrderLog.getLabel().getName();
                List<WebOrderLogImage> orderLogImages = imageDao.listByLog(webOrderLog.getId());
                for (WebOrderLogImage webOrderLogImage : orderLogImages) {
                    Hibernate.initialize(webOrderLogImage.getImage());
                }
                webOrderLog.setImageList(orderLogImages);
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByContent(WebOrderLogVO log) {
        // TODO Auto-generated method stub
        return dao.countByContent(log);
    }

    @Override
    @Transactional
    public boolean insert(WebOrderLog entity) {
        // TODO Auto-generated method stub
        boolean ret = dao.saveResultBoolean(entity);
        String images = entity.getImageIds();
        if (StringUtil.notEmpty(images)) {
            String[] imageList = images.split(",");
            for (String id : imageList) {
                if (StringUtil.notEmpty(id)) {
                    WebOrderLogImage logImage = new WebOrderLogImage();
                    WebOrderLog orderLog = new WebOrderLog();
                    orderLog.setId(entity.getId());
                    logImage.setOrderLog(orderLog);
                    Picture image = new Picture();
                    image.setId(Long.valueOf(id));
                    logImage.setImage(image);
                    imageDao.add(logImage);
                }
            }
        }
        return ret;
    }

    @Override
    @Transactional
    public boolean update(WebOrderLog entity) {
        // TODO Auto-generated method stub
        boolean ret = dao.updateLog(entity);
        String images = entity.getImageIds();
        if (StringUtil.notEmpty(images)) {
            // 先废弃所有
            imageDao.deleteByLog(entity.getId());
            String[] imageList = images.split(",");
            for (String id : imageList) {
                if (StringUtil.notEmpty(id)) {
                    WebOrderLogImage logImage = new WebOrderLogImage();
                    WebOrderLog orderLog = new WebOrderLog();
                    orderLog.setId(entity.getId());
                    logImage.setOrderLog(orderLog);
                    Picture image = new Picture();
                    image.setId(Long.valueOf(id));
                    logImage.setImage(image);
                    imageDao.add(logImage);
                }
            }
        }
        return ret;
    }

    @Override
    @Transactional
    public int delete(Long id) {
        // TODO Auto-generated method stub
        return dao.delete(id);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = this.invalid(Long.valueOf(id));
                    // 废弃对应答案
                    if (row > 0) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                row = this.invalid(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        if (0 == success && 0 != error) {
            return "失败废弃" + error + "条日志！";
        } else if (0 == error && 0 != success) {
            return "成功废弃" + success + "条日志！";
        } else if (0 == success && 0 == error) {
            return "请选择废弃的日志！";
        } else {
            return "成功废弃" + success + "条日志,失败废弃" + error + "条日志！";
        }

    }

    @Override
    @Transactional(readOnly = true)
    public List<Long> findOrderByLabel(Long labelId, WebOrderLog log) {
        // TODO Auto-generated method stub
        List<WebOrderLog> list = dao.findOrderByLabel(labelId, log);
        List<Long> orderIds = new ArrayList<Long>();
        if (null != list && list.size() > 0) {
            for (WebOrderLog o : list) {
                if (StringUtil.notEmpty(o.getGesOrder())) {
                    orderIds.add(o.getGesOrder().getId());
                }
            }
        }
        return orderIds;
    }

    @Override
    @Transactional(readOnly = true)
    public WebOrderLog findLastByOrder(Long orderId) {
        // TODO Auto-generated method stub
        return dao.findLastByOrder(orderId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebOrderLog> findAllByOrder(Long orderId) {
        // TODO Auto-generated method stub
        return dao.findAllByOrder(orderId);
    }

    @Override
    @Transactional
    public boolean insertOrderLogImage(WebOrderLogImage logImage) {
        // TODO Auto-generated method stub
        return imageDao.saveResultBoolean(logImage);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebOrderLog> findLogByLabelAndOrder(Long labelId, Long orderId) {
        // TODO Auto-generated method stub
        return dao.findLogByLabelAndOrder(labelId, orderId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Long> getAllOrder() {
        // TODO Auto-generated method stub
        return dao.getAllOrder();
    }

}
