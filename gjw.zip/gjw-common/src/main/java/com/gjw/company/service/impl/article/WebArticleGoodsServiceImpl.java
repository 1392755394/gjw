package com.gjw.company.service.impl.article;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.article.IWebArticleGoodsService;
import com.gjw.entity.article.WebArticleGoods;

@Service("webArticleGoodsServiceImpl")
@Transactional
public class WebArticleGoodsServiceImpl extends AbstractServiceImpl implements IWebArticleGoodsService {

    @Override
    public List<WebArticleGoods> listByArticle(Long article) {
       List<WebArticleGoods> items = this.getWebArticleGoodsDAO().listByArticle(article);
       for(WebArticleGoods item:items){
           Hibernate.initialize(item.getArticle());
           Hibernate.initialize(item.getGoods());
       }
       return items;
    }

    @Override
    public void add(WebArticleGoods item) {
       this.getWebArticleGoodsDAO().add(item);
    }

    @Override
    public void deleteByArticleAndGoods(WebArticleGoods item) {
        this.getWebArticleGoodsDAO().deleteByArticleAndGoods(item);
    }
    
}
