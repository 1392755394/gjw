package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorPartnerDAO;
import com.gjw.entity.cityoperator.GesCityOperatorPartner;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorPartnerDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorPartnerDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorPartnerDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperatorPartner.class;
    }

    @Override
    public GesCityOperatorPartner listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperatorPartner) super.get(id);
    }

    @Override
    public boolean updateGesCityOperatorPartner(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCityOperatorPartner(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorPartner item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getContactName())){
            hql=hql+" and item.contactName like ?";
            params.add(super.getFuzzyCondition(model.getContactName()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if(StringUtil.notEmpty(model.getEmail())){
            hql=hql+" and item.email like ?";
            params.add(super.getFuzzyCondition(model.getEmail()));
        }
        if(StringUtil.notEmpty(model.getPosition())){
            hql=hql+" and item.position like ?";
            params.add(super.getFuzzyCondition(model.getPosition()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperatorPartner> listByGesCityOperatorPartner(
            GesCityOperatorPartner model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorPartner item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getContactName())){
            hql=hql+" and item.contactName like ?";
            params.add(super.getFuzzyCondition(model.getContactName()));
        }
        if(StringUtil.notEmpty(model.getPhone())){
            hql=hql+" and item.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if(StringUtil.notEmpty(model.getEmail())){
            hql=hql+" and item.email like ?";
            params.add(super.getFuzzyCondition(model.getEmail()));
        }
        if(StringUtil.notEmpty(model.getPosition())){
            hql=hql+" and item.position like ?";
            params.add(super.getFuzzyCondition(model.getPosition()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCityOperatorPartner>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
