package com.gjw.company.dao.menu;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.menu.GesMenu;

/**
 * 菜单dao接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月10日 
 *
 */
public interface IGesMenuDAO extends IDAO {
    
    /**
     * 根据角色获得相关联的菜单
    * @Description  
    * @param roleId
    * @return
    * @author dabai   
    * @date 2016年3月8日 上午10:02:49
     */
    public List<GesMenu> listMenusOfRole(long roleId);

    /**
     * 根据父菜单取得的子菜单列表
     * @Description  
     * @param parentId 父菜单ID
     * @return 子菜单列表
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public List<GesMenu> listMenusByParentId(long parentId);
    
    /**
     * 新增菜单
     * @Description  
     * @param menu 菜单
     * @return 菜单ID
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public long create(GesMenu menu);
    
    /**
     * 修改菜单
     * @Description  
     * @param menu 菜单
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public boolean update(GesMenu menu);
    
    /**
     * 删除菜单
     * @Description  
     * @param menu 菜单
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public boolean delete(GesMenu menu);

    /**
     * 取得全体菜单列表
     * @Description  
     * @return 菜单列表
     * @author guojianbin   
     * @date 2015年12月10日
     */
    public List<GesMenu> listMenus();
    
    public GesMenu getMenuWithParentById(long id);
    
    public List<GesMenu> listMenusByTarget(String target);
}
