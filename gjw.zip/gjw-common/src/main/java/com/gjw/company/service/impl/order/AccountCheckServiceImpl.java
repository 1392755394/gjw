package com.gjw.company.service.impl.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.company.dao.order.IAccountCheckDAO;
import com.gjw.company.service.order.IAccountCheckService;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.entity.order.GesPaymentRecordResponse;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.utils.DateUtil;
import com.gjw.vo.order.PaymentRecordResponseVO;

@Component("accountCheckServiceImpl")
public class AccountCheckServiceImpl extends AbstractServiceImpl implements IAccountCheckService {

	private final static Logger log=LoggerFactory.getLogger(AccountCheckServiceImpl.class);
	
	public final String CREDIT_CODE_PREFIX ="CRET"; // 90%支付  
    public final String EARNEST_CODE_PREFIX ="EART";//定金支付        
    public final String STAGES_CODE_PREFIX ="STAG";//三次30%支付 
    public final String REFUND_CODE_PREFIX="REFU";//退货
    
    public final String PAY_TYPE_EART="0";
    public final String PAY_TYPE_CRET="1";
    public final String OPERATOR_TYPE_CONSUME="20270";
    public final String OPERATOR_TYPE_CONFIRM="20281";
    public final String OPERATOR_TYPE_STAGE="20290";
    public final String OPERATOR_TYPE_PAGE="20284";
    public final String OPERATOR_TYPE_REFUND="20282";
    
    @Resource(name="accountCheckDAOHibernateImpl")
    private IAccountCheckDAO accountCheckDAO;
	
	public IAccountCheckDAO getAccountCheckDAO() {
		return accountCheckDAO;
	}

	public void setAccountCheckDAO(IAccountCheckDAO accountCheckDAO) {
		this.accountCheckDAO = accountCheckDAO;
	}

	/**
	 * 分页获取对账信息
	 */
	@Override
	@Transactional(readOnly=true)
	public Map<String, Object> pageFinance(PaymentRecordResponseVO record) {
		log.info("查询金额为："+record.getTotalAmount()+",查询资金类型为："+record.getType()+",核算类型："+record.getHadSettled());//可以新建一个属性代表总额，此处借用totalAmount代替
        log.info("日期范围："+record.getStartDate()+"~~~"+record.getEndDate()+"订单编号"+record.getOrderCode());
        Date date=new Date(DateUtil.parseDate(record.getEndDate()).getTime()+86400000l);
        record.setEndDate(DateUtil.formatYYYYMMDD(date));
        log.info("查询结束时间为："+record.getEndDate());
        Map<String,Object> map=new HashMap<String, Object>();
        BigDecimal sumAmount=new BigDecimal(0);
        long total=0;
        List<PaymentRecordResponseVO> list=new ArrayList<PaymentRecordResponseVO>();
        List<String> paramList=new ArrayList<String>();
      //根据查询资金的类型设置查询条件    注意：此处是通过pay_type和operator_type两个字段来区分的，之后可以通过pay_period来区分，目前没有这个字段
        if(record.getType()!=null&&record.getType().equals(this.EARNEST_CODE_PREFIX)){//10%
            record.setPayType(this.PAY_TYPE_EART);
            record.setOperateType(this.OPERATOR_TYPE_CONSUME);
            paramList.add(OPERATOR_TYPE_CONSUME);paramList.add(OPERATOR_TYPE_STAGE);
        }else if(record.getType()!=null&&record.getType().equals(this.CREDIT_CODE_PREFIX)){//90%
            record.setPayType(this.PAY_TYPE_CRET);
            paramList.add(OPERATOR_TYPE_CONSUME);paramList.add(OPERATOR_TYPE_STAGE);
        }else if(record.getType()!=null&&record.getType().equals(this.STAGES_CODE_PREFIX)){//30%
            record.setPayType(this.PAY_TYPE_EART);
            record.setOperateType(this.OPERATOR_TYPE_CONFIRM);
            paramList.add(OPERATOR_TYPE_CONFIRM);paramList.add(OPERATOR_TYPE_PAGE);
        }else if(record.getType()!=null&&record.getType().equals(this.REFUND_CODE_PREFIX)){//退货
            record.setPayType(this.PAY_TYPE_EART);
            paramList.add(OPERATOR_TYPE_REFUND);
        }else{
            log.error("查询资金类型参数传递错误！");
            map.put("total", total);
            map.put("rows", list);
            map.put("sumAmount",sumAmount);
            return map;
        }
        record.setOperateList(paramList);
        //区分是否按照总额查询
        if(record.getTotalAmount()!=null && !record.getTotalAmount().equals("")){
            //此处采用的方法是，判断该时间段内是否有总额等于给定值的数据，若有则获取相关数据，若没有，返回空数据
            Long sumAmountInLong=getAccountCheckDAO().sumFinance(record);
            log.info("查询结果总额为："+sumAmountInLong);
            //比较要查询的总额是否等于查询到的值
            sumAmount=new BigDecimal(sumAmountInLong).divide(new BigDecimal(100));
            if(sumAmount.compareTo(new BigDecimal(record.getTotalAmount()))==0){
                total=getAccountCheckDAO().countFinance(record);
                list=getAccountCheckDAO().pageFinance(record);
            }else{
                //不等
                sumAmount=new BigDecimal(0);
            }            
        }else{
            //直接返回相关信息
        	Long sumAmountInLong=getAccountCheckDAO().sumFinance(record);
        	log.info("查询结果总额为："+sumAmountInLong);
        	sumAmount=new BigDecimal(sumAmountInLong).divide(new BigDecimal(100));
            total=getAccountCheckDAO().countFinance(record);
            list=getAccountCheckDAO().pageFinance(record);
        }
        log.info("返回值：--total："+total+"总额："+sumAmount);
        //组装返回值
        map.put("total", total);
        map.put("rows", list);
        map.put("sumAmount",sumAmount);
        return map;
	}

	/**
	 * 对账簿核算
	 */
	@Override
	@Transactional
	public boolean updateOrderStatus(PaymentRecordResponseVO record) {
		//删除无用数据
		GesPaymentRecord paymentRecord=new GesPaymentRecord();
		paymentRecord.setCode(record.getCmpySequenceId());
		paymentRecord.setOrderStatus(record.getOrderStatus());
		GesOrder gesOrder=new GesOrder();
		gesOrder.setId(record.getOrderId());
		paymentRecord.setGesOrder(gesOrder);
		getGesPaymentRecordDAO().deleteRedundantData(paymentRecord);
		
        //更新对账簿记录为已核算
		GesPaymentRecordResponse response=new GesPaymentRecordResponse();
		response.setCmpySequenceId(record.getCmpySequenceId());
        getPaymentRecordResponseDAO().updatePaymentRecordResponseStatusBySequenceId(response);
        
        //更新交易记录为已到账
        getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
        
        //更新多次支付记录表的数据为已到账
        MultiplePayment mp=new MultiplePayment();
        mp.setPayStatus(PaymentConstant.PAY_STATUS_THREE);
        mp.setGesOrder(gesOrder);
        mp.setSerialPayNo(record.getCmpySequenceId());
        getMultiplePaymentDAO().updateMultiplePayStatus(mp);
        
        GesOrder order=getGesOrderDAO().queryOrderByOrderId(record.getOrderId());
        //判断当前订单已支付的金额与应该支付的金额，如果相等，则判断是否有支付的状态是“已支付待到账”，若是，则订单状态修改为“已支付待到账”，若全部是“已到账”，则改为“已到账”
        //若支付的金额与应支付金额不等，订单状态不变
        return updateOrderStatusByPayMoney(record, order);
	}
	
	/**
     * 根据订单支付的金额来判断是否需要更新订单状态
     * @param record
     * @param order
     */
    public boolean updateOrderStatusByPayMoney(PaymentRecordResponseVO record,GesOrder order){
        long totalAmount=0l;
        MultiplePayment mp=new MultiplePayment();
        mp.setGesOrder(order);
        if(PaymentConstant.STATUS_TEN.equals(order.getOrderStatus())||PaymentConstant.STATUS_TEN_WAIT.equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
            totalAmount=order.getTotalAmount().longValue()/10;
        }else if(PaymentConstant.STATUS_NINETY.equals(order.getOrderStatus())||OrderStatus.arriving_credit.name().equals(order.getOrderStatus())){
            mp.setPeriod(PaymentConstant.PAY_PERIOD_NINETY);
            totalAmount=(order.getTotalAmount().longValue()/10)*9;
        }else if(PaymentConstant.STATUS_BOOKED.equals(order.getOrderStatus())||PaymentConstant.STATUS_AUDITING.equals(order.getOrderStatus())){
            return true;
        }
        log.info("订单状态为："+order.getOrderStatus());
        //查询目前已经到账的金额
        long payedMoney=getMultiplePaymentDAO().queryCompletePay(mp);
        log.info("已支付到账的金额为："+payedMoney+",总额为："+totalAmount);
        if(payedMoney==totalAmount){
            //更新订单状态
        	if(order.getOrderStatus().equals(OrderStatus.booked.name())){
        		order.setOrderStatus(OrderStatus.booked.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.prepaying.name())){
        		order.setOrderStatus(OrderStatus.starting_AZZC.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.arriving_earnest.name())){
        		order.setOrderStatus(OrderStatus.starting_AZZC.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.accepted_AZZC.name())){
        		order.setOrderStatus(OrderStatus.arriving_credit.name());
        	}else if(order.getOrderStatus().equals(OrderStatus.arriving_credit.name())){
        		order.setOrderStatus(OrderStatus.paying_AZZC.name());
        	}
        	log.info("订单的状态为："+order.getOrderStatus()+",订单的id为："+order.getId());
            int num=getGesOrderDAO().updateOrderStatusBySystem(order);
            log.info("更新订单状态的结果"+num);
        }
        return true;
    }

	@Override
	@Transactional
	public boolean updateClear(PaymentRecordResponseVO record) {
		//删除无用数据
		GesPaymentRecord paymentRecord = new GesPaymentRecord();
		paymentRecord.setCode(record.getCmpySequenceId());
		paymentRecord.setOrderStatus(record.getOrderStatus());
		GesOrder gesOrder = new GesOrder();
		gesOrder.setId(record.getOrderId());
		paymentRecord.setGesOrder(gesOrder);
		getGesPaymentRecordDAO().deleteRedundantData(paymentRecord);
        //更新交易记录为已到账
        getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
        //更新对账簿记录为已核算
      //更新对账簿记录为已核算
		GesPaymentRecordResponse response = new GesPaymentRecordResponse();
		response.setCmpySequenceId(record.getCmpySequenceId());
		return getPaymentRecordResponseDAO().updatePaymentRecordResponseStatusBySequenceId(response);
	}

	@Override
	@Transactional
	public boolean updateModify(PaymentRecordResponseVO record) {
		//更新支付记录的状态为已收到银行通知
        log.info("支付流水号为："+record.getCmpySequenceId());
        GesPaymentRecord paymentRecord = new GesPaymentRecord();
		paymentRecord.setCode(record.getCmpySequenceId());
		getGesPaymentRecordDAO().updateRecordStatus(paymentRecord);
        //查询当前的订单状态
		GesOrder order=getGesOrderDAO().queryOrderByOrderId(record.getOrderId());
		//更新订单状态
		if (record.getOrderStatus().equals(OrderStatus.prepaying.name())) {
			order.setOrderStatus(OrderStatus.arriving_earnest.name());
		} else if (record.getOrderStatus().equals(
				OrderStatus.accepted_AZZC.name())) {
			order.setOrderStatus(OrderStatus.arriving_credit.name());
		} else if (record.getOrderStatus().equals(
				OrderStatus.paying_AZZC.name())) {
			order.setOrderStatus(OrderStatus.starting_JZFZ.name());
		} else if (record.getOrderStatus().equals(
				OrderStatus.accepted_JZFZ.name())) {
			order.setOrderStatus(OrderStatus.starting_YSCS.name());
		} else if (record.getOrderStatus().equals(
				OrderStatus.accepted_YSCS.name())) {
			order.setOrderStatus(OrderStatus.completed.name());
		}
        return getGesOrderDAO().updateOrderStatusBySystem(order)>0;
	}

	/**
     * 退款核算处理，目前只是更新对账簿记录为已核算
     */
	@Override
	@Transactional
	public boolean updateRefund(PaymentRecordResponseVO record) {
		GesPaymentRecordResponse response=new GesPaymentRecordResponse();
		response.setCmpySequenceId(record.getCmpySequenceId());
        return getPaymentRecordResponseDAO().updatePaymentRecordResponseStatusBySequenceId(response);
	}
	

}
