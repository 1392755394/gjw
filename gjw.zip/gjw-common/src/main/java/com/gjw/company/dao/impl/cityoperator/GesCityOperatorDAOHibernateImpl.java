package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorDAO;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperator.class;
    }

    @Override
    public GesCityOperator listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperator) super.get(id);
    }

    @Override
    public boolean updateGesCityOperator(GesCityOperator model) {
        // TODO Auto-generated method stub
        return super.update(model) == 1;
    }

    @Override
    public boolean createGesCityOperator(GesCityOperator model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperator model, Integer... stars) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from GesCityOperator cityOperator where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and cityOperator.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and cityOperator.status=?";
            params.add(model.getStatus());
        }
        if (StringUtil.notEmpty(model.getContactName())) {
            hql = hql + " and cityOperator.contactName like ?";
            params.add(super.getFuzzyCondition(model.getContactName()));
        }
        if (StringUtil.notEmpty(model.getCompanyName())) {
            hql = hql + " and cityOperator.companyName like ?";
            params.add(super.getFuzzyCondition(model.getCompanyName()));
        }
        if (StringUtil.notEmpty(model.getLegalName())) {
            hql = hql + " and cityOperator.legalName like ?";
            params.add(super.getFuzzyCondition(model.getLegalName()));
        }
        if (StringUtil.notEmpty(model.getPhone())) {
            hql = hql + " and cityOperator.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if (StringUtil.notEmpty(model.getEmail())) {
            hql = hql + " and cityOperator.email like ?";
            params.add(super.getFuzzyCondition(model.getEmail()));
        }
        // 城运商星级,1代表签约2观察3解约
        if (null != stars && stars.length > 0) {
            int flag = stars[0];
            if (1 == flag) {
                hql = hql + " and cityOperator.star>=5";
            }
            if (2 == flag) {
                hql = hql + " and cityOperator.star<5";
                hql = hql + " and cityOperator.star>=3";
            }
            if (3 == flag) {
                hql = hql + " and cityOperator.star<=2";
            }
        } else {
            if (null != model.getStar()) {
                hql = hql + " and cityOperator.star=?";
                params.add(model.getStar());
            }
        }
        if (null != model.getProvince() && null != model.getProvince().getId()) {
            hql = hql + " and cityOperator.province.id=?";
            params.add(model.getProvince().getId());
        }
        if (null != model.getCity() && null != model.getCity().getId() && 0<model.getCity().getId()) {
            hql = hql + " and cityOperator.city.id=?";
            params.add(model.getCity().getId());
        }
        if (null != model.getCountry() && null != model.getCountry().getId()) {
            hql = hql + " and cityOperator.country.id=?";
            params.add(model.getCountry().getId());
        }
        if (StringUtil.notEmpty(model.getAddress())) {
            hql = hql + " and cityOperator.address like ?";
            params.add(super.getFuzzyCondition(model.getAddress()));
        }
        if (StringUtil.notEmpty(model.getAccountNum())) {
            hql = hql + " and cityOperator.accountNum like ?";
            params.add(super.getFuzzyCondition(model.getAccountNum()));
        }
        if (StringUtil.notEmpty(model.getAccountName())) {
            hql = hql + " and cityOperator.accountName like ?";
            params.add(super.getFuzzyCondition(model.getAccountName()));
        }
        if (StringUtil.notEmpty(model.getCode())) {
            hql = hql + " and cityOperator.code like ?";
            params.add(super.getFuzzyCondition(model.getCode()));
        }
        if (StringUtil.notEmpty(model.getUfCode())) {
            hql = hql + " and cityOperator.ufCode like ?";
            params.add(super.getFuzzyCondition(model.getUfCode()));
        }
        if (null != model.getDictionary() && null != model.getDictionary().getId()) {
            hql = hql + " and cityOperator.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        hql = hql + " order by cityOperator.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperator> listByGesCityOperator(GesCityOperator model, Integer... stars) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from GesCityOperator cityOperator where 1=1 ";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and cityOperator.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and cityOperator.status=?";
            params.add(model.getStatus());
        }
        if( null != model.getId()) {
            hql = hql + " and cityOperator.id=?";
            params.add(model.getId());
        }
        if (StringUtil.notEmpty(model.getContactName())) {
            hql = hql + " and cityOperator.contactName like ?";
            params.add(super.getFuzzyCondition(model.getContactName()));
        }
        if (StringUtil.notEmpty(model.getCompanyName())) {
            hql = hql + " and cityOperator.companyName like ?";
            params.add(super.getFuzzyCondition(model.getCompanyName()));
        }
        if (StringUtil.notEmpty(model.getLegalName())) {
            hql = hql + " and cityOperator.legalName like ?";
            params.add(super.getFuzzyCondition(model.getLegalName()));
        }
        if (StringUtil.notEmpty(model.getPhone())) {
            hql = hql + " and cityOperator.phone like ?";
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if (StringUtil.notEmpty(model.getEmail())) {
            hql = hql + " and cityOperator.email like ?";
            params.add(super.getFuzzyCondition(model.getEmail()));
        }
        // 城运商星级,1代表签约2观察3解约
        if (null != stars && stars.length > 0) {
            int flag = stars[0];
            if (1 == flag) {
                hql = hql + " and cityOperator.star>=5";
            }
            if (2 == flag) {
                hql = hql + " and cityOperator.star<5";
                hql = hql + " and cityOperator.star>=3";
            }
            if (3 == flag) {
                hql = hql + " and cityOperator.star<=2";
            }
        } else {
            if (null != model.getStar()) {
                hql = hql + " and cityOperator.star=?";
                params.add(model.getStar());
            }
        }
        if (null != model.getProvince() && null != model.getProvince().getId()) {
            hql = hql + " and cityOperator.province.id=?";
            params.add(model.getProvince().getId());
        }
        if (null != model.getCity() && null != model.getCity().getId() && 0<model.getCity().getId()) {
            hql = hql + " and cityOperator.city.id=?";
            params.add(model.getCity().getId());
        }
        if (null != model.getCountry() && null != model.getCountry().getId()) {
            hql = hql + " and cityOperator.country.id=?";
            params.add(model.getCountry().getId());
        }
        if (StringUtil.notEmpty(model.getAddress())) {
            hql = hql + " and cityOperator.address like ?";
            params.add(super.getFuzzyCondition(model.getAddress()));
        }
        if (StringUtil.notEmpty(model.getAccountNum())) {
            hql = hql + " and cityOperator.accountNum like ?";
            params.add(super.getFuzzyCondition(model.getAccountNum()));
        }
        if (StringUtil.notEmpty(model.getAccountName())) {
            hql = hql + " and cityOperator.accountName like ?";
            params.add(super.getFuzzyCondition(model.getAccountName()));
        }
        if (StringUtil.notEmpty(model.getCode())) {
            hql = hql + " and cityOperator.code like ?";
            params.add(super.getFuzzyCondition(model.getCode()));
        }
        if (StringUtil.notEmpty(model.getUfCode())) {
            hql = hql + " and cityOperator.ufCode like ?";
            params.add(super.getFuzzyCondition(model.getUfCode()));
        }
        if (null != model.getDictionary() && null != model.getDictionary().getId()) {
            hql = hql + " and cityOperator.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }

        if (model.getSynchType() != null && model.getSynchType().getId() == 680l) {
            hql += "and ( cityOperator.synchType.id not in (1130102,1130105) or cityOperator.synchType.id  is null )";
        }

        hql = hql + " order by cityOperator.createdDatetime desc";
        return (List<GesCityOperator>) super.findByPageCallBack(hql, "", params, model, null);
    }
}
