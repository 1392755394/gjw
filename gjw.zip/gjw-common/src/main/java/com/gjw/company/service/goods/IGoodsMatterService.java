package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.vo.GoodsMatterVO;

/**
 * 
 * @Description: 产品包物料关系service接口
 * @author zhaoyonglian
 * @date 2015年12月29日 上午11:43:36
 * 
 */
public interface IGoodsMatterService extends IService {

    /**
     * 
     * @Description 分页标配物料
     * @param matterVO
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:04:07
     */
    public List<GoodsMatter> pageStandardMatter(GoodsMatterVO goodsMatter);

    /**
     * 
     * @Description 查询标配物料总数
     * @param matterVO
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:05:33
     */
    public Long countStandardMatter(GoodsMatterVO goodsMatter);

    /**
     * 
     * @Description 查看详情
     * @param id
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:34:16
     */
    public GoodsMatter queryById(Long id);

    /**
     * 
     * @Description 删除关系
     * @param ids
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:35:36
     */
    public boolean delBatchByID(String ids);

    /**
     * 修改关系
     * 
     * @Description
     * @param goodsMatter
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:35:58
     */
    public boolean update(Long id, Integer amount, Boolean isStandard);

    /**
     * 
     * @Description 新增产品包物料关系
     * @param goodsMatter
     * @return
     * @author zhaoyonglian
     * @date 2015年12月29日 上午10:36:38
     */
    public boolean createBatchGoodsMatter(String matterIds, String amounts, Long goodsId, Long roomId);

    /**
     * 
     * @Description 根据锚点id及物料类型查看物料列表
     * @param markId
     *            锚点id
     * @param type
     *            物料类型（是否标配）
     * @return
     * @author zhaoyonglian
     * @date 2016年1月4日 下午4:31:05
     */
    public List<GoodsMatter> listMatterWithType(Long markId, Long type);

    /**
     * 
     * @Description 批量删除选配物料
     * @param goodsId
     * @param roomId
     * @param matterIds
     * @return
     * @author zhaoyonglian
     * @date 2016年1月6日 下午2:51:11
     */
    public boolean batchDelOptMatter(Long goodsId, Long roomId, String matterIds);

    // DIY 接口 start

    /**
     * 
     * @Description 获取产品包物料列表
     * @param matter
     * @return
     * @author zhaoyonglian
     * @date 2016年1月11日 下午4:16:25
     */
    public List<GoodsMatter> listMatter(GoodsMatter goodsMatter);

    /**
     * 
     * @Description 批量增加
     * @param list
     * @return
     * @author zhaoyonglian
     * @date 2016年1月11日 下午4:41:05
     */
    public boolean batchCreate(List<GoodsMatter> list);
    
    /**
     * 
    * @Description  根据id更新
    * @param goodsMatter
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月13日 下午1:36:49
     */
    public boolean update(GoodsMatter goodsMatter);

    /**
     * 
     * @Description 根据物料分类分页查询产品包物料
     * @param goodsMatter
     * @return
     * @author guojianbin
     * @date 2016年2月27日
     */
    public List<GoodsMatter> pageMatterByGoodsAndCategory(GoodsMatter goodsMatter);

    /**
     * 
     * @Description 根据物料分类查询产品包物料总数
     * @param goodsMatter
     * @author guojianbin
     * @date 2016年2月27日
     */
    public Long countMatterByGoodsAndCategory(GoodsMatter goodsMatter);
    
    /**
     * 
    * @Description  ges 锚点列表
    * @param roomId
    * @param type  标配/选配
    * @return
    * @author zhaoyonglian   
    * @date 2016年4月8日 上午9:43:03
     */
    public List<GoodsMatter> listMarkForGes(Long roomId,Long type);
    
    /**
     * 
     * @Description  ges APP锚点列表
     * @param roomId
     * @param type  标配/选配
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public List<GoodsMatter> listAppMarkForGes(Long roomId,Long type);

    /**
     * 
     * @Description 分页标配物料(APP)
     * @param matterVO
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public List<GoodsMatter> pageAppStandardMatter(GoodsMatterVO goodsMatter);

    /**
     * 
     * @Description 查询标配物料总数(APP)
     * @param matterVO
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public Long countAppStandardMatter(GoodsMatterVO goodsMatter);

    /**
     * 
     * @Description 根据app锚点id及物料类型查看物料列表
     * @param markId
     *            锚点id
     * @param type
     *            物料类型（是否标配）
     * @return
     * @author guojianbin   
     * @date 2016年04月20日 
     */
    public List<GoodsMatter> listMatterWithAppMark(Long markId, Long type);

}
