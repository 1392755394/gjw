package com.gjw.company.service.impl.app;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.app.IWebDesignerService;
import com.gjw.entity.app.WebDesigner;

@Component("webDesignerServiceImpl")
public class WebDesignerServiceImpl extends AbstractServiceImpl implements IWebDesignerService{

    @Override
    @Transactional(readOnly=true)
    public WebDesigner get(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    @Transactional(readOnly=true)
    public List<WebDesigner> getList(WebDesigner model) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    @Transactional()
    public boolean addWebDesigner(WebDesigner model) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    @Transactional()
    public void updateWebDesigner(WebDesigner model) {
        // TODO Auto-generated method stub
        
    }

    @Override
    @Transactional(readOnly=true)
    public WebDesigner getTopic(Long topicId) {
        // TODO Auto-generated method stub
        WebDesigner designer=super.getWebDesignerDAO().getTopic(topicId);
        return designer;
    }

}
