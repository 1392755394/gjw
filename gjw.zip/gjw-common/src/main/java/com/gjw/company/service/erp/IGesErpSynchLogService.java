package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.erp.GesErpSynchLog;

/**
 * 基础数据同步日志
 * 
 * @Description:
 * @author gwb
 * @date 2016年1月7日 上午10:11:37
 * 
 */
public interface IGesErpSynchLogService extends IService {
    /**
     * 分页查询
     * 
     * @Description
     * @param gesErpSynchLog
     * @return
     * @author gwb
     * @date 2016年1月7日 上午10:13:18
     */
    public List<GesErpSynchLog> pageByGesErpSynchLog(GesErpSynchLog gesErpSynchLog);

    /**
     * 分页查询 z总数
     * 
     * @Description
     * @param gesErpSynchLog
     * @return
     * @author gwb
     * @date 2016年1月7日 上午10:13:25
     */
    public Long count(GesErpSynchLog gesErpSynchLog);

    /**
     * 新增
     * 
     * @Description
     * @param gesErpSynchLog
     * @return
     * @author gwb
     * @date 2016年1月7日 上午10:13:33
     */
    public Boolean addGesErpSynchLog(GesErpSynchLog gesErpSynchLog);
}
