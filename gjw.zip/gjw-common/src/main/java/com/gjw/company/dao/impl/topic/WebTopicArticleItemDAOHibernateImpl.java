package com.gjw.company.dao.impl.topic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.topic.IWebTopicArticleItemDAO;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.topic.WebTopic;
import com.gjw.entity.topic.WebTopicArticleItem;

/**
 * dao的Hibernate实现
 */
@Component("webTopicArticleItemDAOHibernateImpl")
public class WebTopicArticleItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebTopicArticleItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebTopicArticleItem.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebTopicArticleItem> listByTopic(Long topicId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        if (null == topicId) {
            return null;
        }
        hql.append(" from WebTopicArticleItem where invalid = 0 and  topic_id = :topic_id");
        Query query = session.createQuery(hql.toString());
        query.setLong("topic_id", topicId);
        return query.list();
    }

    /**
     * @author qingye
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<WebTopicArticleItem> listByArticle(Long articleId) {
        String hql=" from WebTopicArticleItem where invalid = 0 and  article.id=?";
        return (List<WebTopicArticleItem>)this.getHibernateTemplate().find(hql, articleId);
    }

    @Override
    public void deleteByArticle(WebArticle article) {
        String hql="delete from WebTopicArticleItem where article.id=? ";
        this.getHibernateTemplate().bulkUpdate(hql, article.getId());
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebTopicArticleItem> countGroupByTopic() {
        String hql="select topic.id,count(1) as joinNum from WebTopicArticleItem group by topic.id";
        List<Object[]> result = (List<Object[]>)this.getHibernateTemplate().find(hql, null);
        List<WebTopicArticleItem> itemList=new ArrayList<WebTopicArticleItem>();
        WebTopicArticleItem item=null;
        for(Object[] a:result){
            item=new WebTopicArticleItem();
            item.setTopic(new WebTopic());
            item.getTopic().setId((Long)a[0]);
            item.setJoinNum((Long)a[1]);
            itemList.add(item);
        }
        return itemList;
    }
}
