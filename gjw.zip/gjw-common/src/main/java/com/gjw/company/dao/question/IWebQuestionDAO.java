package com.gjw.company.dao.question;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.question.WebQuestion;

/**
 * 
* @Description: 问题dao接口类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:28:30
*
 */
public interface IWebQuestionDAO extends IDAO {

	/**
	 * 
	* @Description  获取问题详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月10日 下午2:31:48
	 */
	public WebQuestion getById(Long id);
	
	/**
	 * 
	* @Description  分页列表，搜索条件：问题标题
	* @param subject
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月10日 下午2:34:10
	 */
	public List<WebQuestion> pageBySubjectAndInvalid(WebQuestion question);
	
	/**
	 * 
	* @Description  总数
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月14日 下午1:51:20
	 */
	public Long countBySubjectAndInvalid(WebQuestion question);
	
	/**
	 * 
	* @Description  修改记录
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月15日 下午2:15:33
	 */
	public boolean updateQuestion(WebQuestion question);
	
	/**
	 * 
	* @Description  个人中心我的问题列表
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2016年3月1日 上午10:45:46
	 */
	public List<WebQuestion> pageByUserAndState(WebQuestion question);
	
	/**
	 * 
	* @Description  个人中心我的问题总数
	* @param question
	* @return
	* @author zhaoyonglian   
	* @date 2016年3月1日 上午10:46:04
	 */
	public Long countByUserAndState(WebQuestion question);
	
	/**
	 * 
	* @Description  状态确认 3
	* @param questionId
	* @return
	* @author zhaoyonglian   
	* @date 2016年3月1日 下午3:26:45
	 */
	public void isConfirm(Long questionId);
}
