package com.gjw.company.service.impl.salestool;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.IFullViewService;
import com.gjw.entity.salestool.FullView;
import com.gjw.utils.StringUtil;

@Service("fullViewServiceImpl")
public class FullViewServiceImpl extends AbstractServiceImpl implements IFullViewService{

    @Override
    @Transactional(readOnly=true)
    public FullView listByID(Long id) {
        // TODO Auto-generated method stub
        FullView model=super.getFullViewDAOHibernateImpl().listByID(id);
        Hibernate.initialize(model.getBuilding());
        Hibernate.initialize(model.getAbbreviationUrl());
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            model.setCaptcha(super.getCaptchaDAOHibernateImpl().listByBuildingId(model.getBuilding().getId()));
        }
        return model;
    }

    @Override
    @Transactional()
    public boolean updateFullView(FullView model) {
        // TODO Auto-generated method stub
        FullView modelFlag=super.getFullViewDAOHibernateImpl().listByID(model.getId());
        StringUtil.copyProperties(model, modelFlag);
        return super.getFullViewDAOHibernateImpl().updateFullView(modelFlag);
    }

    @Override
    @Transactional()
    public boolean createFullView(FullView model) {
        // TODO Auto-generated method stub
        if(null!=model.getId()){
            FullView modelFlag=super.getFullViewDAOHibernateImpl().listByID(model.getId());
            Hibernate.initialize(modelFlag.getBuilding());
            Hibernate.initialize(modelFlag.getAbbreviationUrl());
            StringUtil.copyProperties(model, modelFlag);
            if(null!=model.getZipUrl() && !"".equals(model.getZipUrl()) && 0<model.getZipUrl().lastIndexOf(".zip")){
                modelFlag.setIndexUrl(model.getZipUrl().substring(0,model.getZipUrl().lastIndexOf("."))+"/index.html");
            }
            return super.getFullViewDAOHibernateImpl().updateFullView(modelFlag);
        }
        if(null!=model.getZipUrl() && !"".equals(model.getZipUrl()) && 0<model.getZipUrl().lastIndexOf(".zip")){
            model.setIndexUrl(model.getZipUrl().substring(0,model.getZipUrl().lastIndexOf("."))+"/index.html");
        }
        if (model.getAbbreviationUrl() != null && model.getAbbreviationUrl().getId() == null){
            model.setAbbreviationUrl(null);
        }
        return super.getFullViewDAOHibernateImpl().createFullView(model);
    }
    
    @Override
    @Transactional(readOnly=true)
    public long count(FullView model) {
        // TODO Auto-generated method stub
        return super.getFullViewDAOHibernateImpl().count(model);
    }

    @Override
    @Transactional(readOnly=true)
    public List<FullView> listByFullView(FullView model) {
        // TODO Auto-generated method stub
        List<FullView> list=super.getFullViewDAOHibernateImpl().listByFullView(model);
        for (FullView fullView : list) {
            Hibernate.initialize(fullView.getBuilding());
            Hibernate.initialize(fullView.getAbbreviationUrl());
            if(null!=fullView.getBuilding() && null!=fullView.getBuilding().getId()){
                fullView.setCaptcha(super.getCaptchaDAOHibernateImpl().listByBuildingId(fullView.getBuilding().getId()));
            }
        }
        return list;
    }
    
    @Override
    @Transactional()
    public Boolean updateFullViewByIds(String ids){
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            FullView model=super.getFullViewDAOHibernateImpl().listByID(Long.valueOf(id));
            model.setInvalid(true);
            super.getFullViewDAOHibernateImpl().updateFullView(model);
        }
        return true;
    }

    @Override
    @Transactional(readOnly=true)
    public List<FullView> listByCaptcha(String captcha) {
        // TODO Auto-generated method stub
        List<FullView> list = super.getFullViewDAOHibernateImpl().listByCaptcha(captcha);
        if(null != list && list.size()>0){
            for (FullView fullView : list) {
                Hibernate.initialize(fullView.getAbbreviationUrl());
            }
        }
        return list;
    }
}
