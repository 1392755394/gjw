package com.gjw.company.dao.impl.modelling;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.modelling.IModellingMatterItemDAO;
import com.gjw.entity.modelling.ModellingMatterItem;
import com.gjw.utils.StringUtil;

/**
 * 
* @Description: 造型库物料关系dao实现
* @author  zhaoyonglian
* @date 2016年1月11日 下午5:21:06
*
 */
@Component("modellingMatterItemDAOHibernateImpl")
public class ModellingMatterItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IModellingMatterItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        return ModellingMatterItem.class;
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }


    @SuppressWarnings("unchecked")
    @Override
    public List<ModellingMatterItem> pageByCodeAndName(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from ModellingMatterItem where invalid = 0");
        if(StringUtil.notEmpty(item.getModelling()) && StringUtil.notEmpty(item.getModelling().getId())){
            hql.append(" and modelling.id = ?");
            ls.add(item.getModelling().getId());
        }
        if(StringUtil.notEmpty(item.getMatter()) && StringUtil.notEmpty(item.getMatter().getCode())){
            hql.append(" and matter.code = ?");
            ls.add(item.getMatter().getCode());
        }
        if(StringUtil.notEmpty(item.getMatter()) && StringUtil.notEmpty(item.getMatter().getName())){
            hql.append(" and matter.name like ?");
            ls.add("%"+item.getMatter().getName()+"%");
        }
        hql.append(" and matter.invalid = 0");
        hql.append(" order by id desc");
        return (List<ModellingMatterItem>) super.findByListCallBack(hql.toString(), "", ls, null);
    }


    @Override
    public Long countByCodeAndName(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from ModellingMatterItem where invalid = 0");
        if(StringUtil.notEmpty(item.getModelling()) && StringUtil.notEmpty(item.getModelling().getId())){
            hql.append(" and modelling.id = ?");
            ls.add(item.getModelling().getId());
        }
        if(StringUtil.notEmpty(item.getMatter()) && StringUtil.notEmpty(item.getMatter().getCode())){
            hql.append(" and matter.code = ?");
            ls.add(item.getMatter().getCode());
        }
        if(StringUtil.notEmpty(item.getMatter()) && StringUtil.notEmpty(item.getMatter().getName())){
            hql.append(" and matter.name like ?");
            ls.add("%"+item.getMatter().getName()+"%");
        }
        hql.append(" and matter.invalid = 0");
        return super.findByPageCallBackCount(hql.toString(), ls);
    }


    @Override
    public boolean updateItem(ModellingMatterItem item) {
        // TODO Auto-generated method stub
        return false;
    }

}
