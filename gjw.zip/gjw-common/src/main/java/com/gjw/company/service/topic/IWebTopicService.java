package com.gjw.company.service.topic;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.question.WebQuestion;
import com.gjw.entity.topic.WebTopic;

/**
 * 
* @Description: 话题service接口
* @author  zhaoyonglian
* @date 2015年12月24日 上午11:15:04
*
 */
public interface IWebTopicService extends IService {
    /**
     * 
    * @Description  话题详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 上午10:41:46
     */
    public WebTopic getById(Long id);
    
    /**
     * 
    * @Description  分页列表，搜索条件：话题标题
    * @param topic
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 上午10:58:11
     */
    public List<WebTopic> pageByNameAndInvalid(WebTopic topic);
    
    /**
     * 
    * @Description  总数
    * @param topic
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 上午10:56:56
     */
    public Long countByNameAndInvalid(WebTopic topic);
    
    /**
     * 
    * @Description  批量删除话题
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 上午11:15:50
     */
    public String invalidByIds(String ids);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebTopic entity);
    /**
     * 
    * @Description  修改数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:45
     */
    public boolean update(WebTopic entity);
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);

    
}
