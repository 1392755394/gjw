package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesErpCode;

/**
 * 基础数据同步
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月16日 下午3:49:34
 * 
 */
public interface IGesErpCodeDAO extends IDAO {

    /**
     * 基础数据同步－－－－－－－－－－　分页
     * 
     * @Description
     * @param gesErpCode
     * @return
     * @author gwb
     * @date 2015年12月16日 下午4:02:42
     */
    public List<GesErpCode> pageByGesErpCode(GesErpCode gesErpCode);

    /**
     * 基础数据分页-------总数
     * 
     * @Description
     * @param gesErpCode
     * @return
     * @author gwb
     * @date 2015年12月16日 下午4:03:00
     */
    public Long count(GesErpCode gesErpCode);

    /**
     * 根据 ProcjectCode修改---GesErpCode
     * 
     * @Description
     * @param gesErpCode
     * @author gwb
     * @date 2015年12月17日 上午10:19:27
     */
    public void updateByProcjectCode(GesErpCode gesErpCode);

}
