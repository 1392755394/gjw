package com.gjw.company.service.impl.erp;

import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.erp.IGesRdRecordService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.vo.RdRecordVO;

/**
 * 销售出库单管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月15日 下午3:34:19
 * 
 */
@Service("gesRdRecordServiceImpl")
public class GesRdRecordServiceImpl extends AbstractServiceImpl implements IGesRdRecordService {

    @Override
    @Transactional(readOnly = true)
    public List<GesRdRecord> pageByRdRecord(RdRecordVO rdRecord) {

        List<GesRdRecord> list = super.getGesRdRecordDAO().pageByRdRecord(rdRecord);
        for (GesRdRecord record : list) {

            if (record.getGesPoMain() != null) {
                record.getGesPoMain().getSoCode();

                // Hibernate.initialize(record.getCityOperator().getCompanyName());
                // Hibernate.initialize(record.getShop().getName());
                if (record.getGesPoMain().getGesOrder() != null) {
                    record.getGesPoMain().getGesOrder().getShop().getName();
                    record.getGesPoMain().getGesOrder().getOperator().getCompanyName();
                    // record.getGesPoMain().getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Website).getRealName();
                    record.getGesPoMain().getGesOrder().getBuyer().getUsername();
                    record.getGesPoMain().getGesOrder().getGoods().getName();
                    record.getGesPoMain().getGesOrder().getTotalAmount();
                }
            }
            // record.getGesOrder().getShop().getName();
            // record.getGesOrder().getOperator().getCompanyName();
            // record.getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
            // record.getGesOrder().getGoods().getName();
            // record.getGesOrder().getTotalAmount();
            if (record.getStorageLocationDestination() != null) {
                record.getStorageLocationDestination().getName();
            }
            if (record.getWhDestination() != null) {
                record.getWhDestination().getName();
            }

        }

        return list;
    }

    /**
     * 分页总数查询
     */
    @Override
    @Transactional(readOnly = true)
    public Long count(RdRecordVO rdRecord) {
        return super.getGesRdRecordDAO().count(rdRecord);
    }

    /**
     * 根据单据编号 --修改销售出库单状态
     */
    @Override
    @Transactional
    public boolean updateByRecordCode(GesRdRecord rdRecord) {
        return super.getGesRdRecordDAO().updateByRecordCode(rdRecord);
    }

    @Override
    @Transactional(readOnly = true)
    public GesRdRecord getByGesRdRecord(GesRdRecord rdRecord) {

        GesRdRecord rdRd = super.getGesRdRecordDAO().getByGesRdRecord(rdRecord);
        if (rdRd != null && rdRd.getWhDestination() != null) {
            rdRd.getWhDestination().getName();
        }

        if (rdRd != null && rdRd.getStorageLocationDestination() != null) {
            rdRd.getStorageLocationDestination().getName();
        }
        if (rdRd != null && rdRd.getCreateUser() != null
                && rdRd.getCreateUser().initPlatformUserInfo(PlatformEnum.Ges) != null) {
            Hibernate.initialize(rdRd.getCreateUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
        }
        if (rdRd != null && rdRd.getOperateUser() != null
                && rdRd.getOperateUser().initPlatformUserInfo(PlatformEnum.Ges) != null) {
            Hibernate.initialize(rdRd.getOperateUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName());
        }
        return rdRd;
    }

    @Override
    @Transactional
    public void create(GesRdRecord rdRecord) {
        super.getGesRdRecordDAO().create(rdRecord);

    }

    /**
     * 采购入库单分页查询
     */
    @SuppressWarnings("rawtypes")
    @Override
    @Transactional(readOnly = true)
    public List<Map> pageStockByRdRecord(RdRecordVO rdRecord) {
        // 分步查询---先查出构家网销售出库单
        // List<GesRdRecord> list =
        // super.getGesRdRecordDAO().ListByRdRecord(rdRecord);
        List<Map> list = super.getGesRdRecordDAO().pageStockByRdRecord(rdRecord);
        // for (GesRdRecord record : list) {
        // if (record.getGesPoMain() != null && record.getGesPoMain().getId() >
        // 0) {
        // record.getGesPoMain().getPoCode();
        // //
        // record.getGesPoMain().getGesOrder().getBuyer().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
        // if (record.getGesPoMain().getGesOrder() != null &&
        // record.getGesPoMain().getGesOrder().getId() > 0) {
        // record.getGesPoMain().getGesOrder().getBuyer().getUsername();
        // record.getGesPoMain().getGesOrder().getShop().getName();
        // record.getGesPoMain().getGesOrder().getOperator().getCompanyName();
        // }
        // }
        // // if (record.getShop() != null) {
        // // record.getShop().getName();
        // // }
        // // if (record.getCityOperator() != null) {
        // // record.getCityOperator().getCompanyName();
        // // }
        // if (record.getWhDestination() != null) {
        // record.getWhDestination().getName();
        // }
        // if (record.getStorageLocationDestination() != null) {
        // record.getStorageLocationDestination().getName();
        // }
        // }
        return list;
    }

    /**
     * 采购入库单分页总数查询
     */
    @Override
    @Transactional(readOnly = true)
    public Long countStock(RdRecordVO rdRecord) {

        return super.getGesRdRecordDAO().countStock(rdRecord);
    }

    @SuppressWarnings("null")
    @Override
    @Transactional
    public void saveGesRdRecord(GesRdRecord rdRecord) {
        // 取得出库明细
        List<GesRdRecords> list = super.getGesRdRecordsDAO().listGesRdRecord(rdRecord);
        // rdRecordsDao.listRdRecords(rdRecord.getRecordCode());

        // 根据出库明细更新源库存、目标库存
        for (GesRdRecords rds : list) {
            if (rds.getStockIn() == null) {
                rds.setStockIn(0d);
            }
            // 源仓库出库
            GesStoreInventory conditionS = new GesStoreInventory();
            // 设置matter id
            Matter matter = new Matter();
            matter.setId(rds.getMatter().getId());
            conditionS.setMatter(matter);
            GesStore WhSource = new GesStore();
            // 设置store id
            WhSource.setId(rdRecord.getWhSource().getId());
            if (rdRecord.getWhSource().getId() == null) {
                WhSource = null;
            }
            conditionS.setStore(WhSource);
            // conditionS.setMatter(rds.getMatter());
            // conditionS.setStore(rdRecord.getWhSource());
            // 暂不考虑库位
            // conditionS.setStoreLocationId(rdRecord.getStorageLocationSource());

            // 同一物料ID、仓库ID、库位ID的库存存在时更新，否则创建
            // GesStoreInventory storeInventoryS = new GesStoreInventory();
            // GesStoreInventory resultS = null;
            // resultS =
            // super.getGesStoreInventoryDAO().getGesStoreInventoryByMatterIdAndStoreId(conditionS);
            GesStoreInventory storeInventoryS = super.getGesStoreInventoryDAO()
                    .getGesStoreInventoryByMatterIdAndStoreId(conditionS);
            // storeInventoryDao.query(conditionS);
            if (storeInventoryS == null) {
                storeInventoryS = new GesStoreInventory();
                storeInventoryS.setMatter(matter);
                storeInventoryS.setStore(WhSource);
                // 暂不考虑库位
                // storeInventoryS.setStoreLocationId(rdRecord.getStorageLocationSource());
                storeInventoryS.setInventoryAmount(0);
                super.getGesStoreInventoryDAO().add(storeInventoryS);
                // storeInventoryDao.create(storeInventoryS);
            } else {
                // storeInventoryS.setId(resultS.getId());
                storeInventoryS.setInventoryAmount(storeInventoryS.getInventoryAmount() - rds.getQuantity().intValue());
                super.getGesStoreInventoryDAO().updateInventoryAmountById(storeInventoryS);
                // storeInventoryDao.update(storeInventoryS);
            }

            // 目标仓库入库
            GesStoreInventory condition = new GesStoreInventory();
            condition.setMatter(matter);
            GesStore WhDestination = new GesStore();
            WhDestination.setId(rdRecord.getWhDestination().getId());
            if (rdRecord.getWhDestination().getId() == null) {
                WhDestination = null;
            }
            condition.setStore(WhDestination);
            // condition.setMatterId(rds.getMatterId());
            // condition.setStoreId(rdRecord.getWhDestinationId());
            // 暂不考虑库位
            // condition.setStoreLocationId(rdRecord.getStorageLocationDestination());

            // 同一物料ID、仓库ID、库位ID的库存存在时更新，否则创建
            // GesStoreInventory storeInventory = new GesStoreInventory();
            // GesStoreInventory result = null;
            // result =
            // super.getGesStoreInventoryDAO().getGesStoreInventoryByMatterIdAndStoreId(condition);

            GesStoreInventory storeInventory = super.getGesStoreInventoryDAO()
                    .getGesStoreInventoryByMatterIdAndStoreId(condition);

            if (storeInventory == null) {
                storeInventory = new GesStoreInventory();
                storeInventory.setMatter(matter);
                storeInventory.setStore(WhDestination);
                // 暂不考虑库位
                // storeInventory.setStoreLocationId(rdRecord.getStorageLocationDestination());
                storeInventory.setInventoryAmount(rds.getQuantity().intValue());
                // storeInventoryDao.create(storeInventory);
                super.getGesStoreInventoryDAO().add(storeInventory);

            } else {
                // storeInventory.setId(result.getId());
                storeInventory.setInventoryAmount(storeInventory.getInventoryAmount() + rds.getQuantity().intValue());
                super.getGesStoreInventoryDAO().updateInventoryAmountById(storeInventory);
            }
        }

        // 生成出库单
        // rdRecord.setCreateUser(UserHelper.loginName());
        Dictionary type = new Dictionary();
        type.setId(1130601l);
        rdRecord.setType(type);
        // 设置发出方4s店id、城运商id
        GesShop shop = new GesShop();
        if (rdRecord.getShop().getId() != null) {
            shop.setId(rdRecord.getShop().getId());
        } else {
            shop = null;
            rdRecord.setShop(null);
        }

        if (rdRecord.getWhSource().getId() == null) {
            rdRecord.setWhSource(null);
        }
        if (rdRecord.getWhDestination().getId() == null) {
            rdRecord.setWhDestination(null);
        }

        if (rdRecord.getStorageLocationDestination().getId() == null) {
            rdRecord.setStorageLocationDestination(null);
        }

        if (rdRecord.getStorageLocationSource().getId() == null) {
            rdRecord.setStorageLocationSource(null);
        }
        rdRecord.setShipperShop(shop);
        GesCityOperator operator = new GesCityOperator();
        if (rdRecord.getCityOperator().getId() != null) {
            operator.setId(rdRecord.getCityOperator().getId());
        } else {
            operator = null;
            rdRecord.setCityOperator(null);
        }
        rdRecord.setShipperOperator(operator);
        create(rdRecord);

        /******************************************/

        List<GesRdRecords> rdRecordsList = super.getGesRdRecordsDAO().listGesRdRecord(rdRecord);
        for (GesRdRecords rdRecords : rdRecordsList) {
            // soMatterService.updateQuantityByRdRecords(rdRecords);
            super.getGesSoMatterItemDAO().updateGesSoMatterItemByrdRecords(rdRecords);
        }
        // rdRecordsService.listRdRecords(rdRecord .getRecordCode());
        // // 出库
        // rdRecordService.stockOut(rdRecord);
        // // 更新采购清单表g_so_matter
        // // 先根据recordCode查出所有出库单，再根据出库单的so_matter_id,和quantity去修改g_so_matter表
        // List<RdRecords> rdRecordsList =
        // rdRecordsService.listRdRecords(rdRecord.getRecordCode());
        // for (RdRecords rdRecords : rdRecordsList) {
        // soMatterService.updateQuantityByRdRecords(rdRecords);
        // }

    }

    @Override
    @Transactional(readOnly = true)
    public List<GesRdRecord> pageStockOutByRdRecord(RdRecordVO rdRecord) {
        List<GesRdRecord> list = super.getGesRdRecordDAO().pageStockOutByRdRecord(rdRecord);
        for (GesRdRecord record : list) {
            record.getGesOrder().getGoods().getName();
            record.getGesOrder().getShop().getName();
            record.getGesOrder().getOperator().getCompanyName();
            // record.getGesOrder().getUser().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
            record.getGesOrder().getBuyer().getUsername();

            if (record.getStorageLocationDestination() != null) {
                record.getStorageLocationDestination().getName();
            }
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countStockOut(RdRecordVO rdRecord) {

        return super.getGesRdRecordDAO().countStockOut(rdRecord);
    }

    @Override
    @Transactional
    public boolean batchDel(String ids) {
        super.getGesRdRecordDAO().deleteGesRdRecord(ids);
        return true;
    }

    @Override
    @Transactional
    public boolean updateAmount(Long id, Integer amount) {
        super.getGesRdRecordDAO().updateAmount(id, amount);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesRdRecord> pageByRdRecordOpMat(RdRecordVO rdRecord) {
        List<GesRdRecord> list = super.getGesRdRecordDAO().pageByRdRecordOpMat(rdRecord);
        for (GesRdRecord rd : list) {
            rd.getGesOrder().getShop().getName();
            rd.getGesOrder().getOperator().getCompanyName();
            rd.getGesOrder().getGoods().getName();
            rd.getGesOrder().getBuyer().getUsername();
            if (rd.getStorageLocationDestination() != null) {
                rd.getStorageLocationDestination().getName();
            }
            if (rd.getWhDestination() != null) {
                rd.getWhDestination().getName();
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countOpMat(RdRecordVO rdRecord) {
        return super.getGesRdRecordDAO().countOpMat(rdRecord);
    }

}
