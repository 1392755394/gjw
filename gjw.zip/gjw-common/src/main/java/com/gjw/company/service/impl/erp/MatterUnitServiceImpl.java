package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IMatterUnitService;
import com.gjw.entity.matter.MatterUnit;

/**
 * 物料单位
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月21日 上午9:16:07
 * 
 */
@Service("matterUnitServiceImpl")
public class MatterUnitServiceImpl extends AbstractServiceImpl implements IMatterUnitService {

    @Override
    @Transactional(readOnly = true)
    public List<MatterUnit> listByMatterUnitSynch(MatterUnit matterUnit) {
        List<MatterUnit> list = super.getMatterUnitDAO().listByMatterUnitSynch(matterUnit);
        for (MatterUnit obj : list) {
            obj.getSynchType().getText();
        }

        return list;
    }

    @Override
    @Transactional
    public boolean updateMatterUnitSynch(MatterUnit matterUnit) {
        return super.getMatterUnitDAO().updateMatterUnitSynch(matterUnit);
    }

}
