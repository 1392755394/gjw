package com.gjw.company.dao.shop;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.shop.GesShopPhotoItem;

public interface IGesShopPhotoItemDAO extends IDAO{
    public GesShopPhotoItem listByID(Long id);

    public boolean updateGesShopPhotoItem(GesShopPhotoItem model);

    public boolean createGesShopPhotoItem(GesShopPhotoItem model);
    
    public long count(GesShopPhotoItem model);
    
    public List<GesShopPhotoItem> listByGesShopOrderFeedback(GesShopPhotoItem model);
}
