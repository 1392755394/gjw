package com.gjw.company.dao.salestool;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.salestool.BuildingInfo;

public interface IBuildingInfoDAO extends IDAO{
	public List<BuildingInfo> pageBuildingInfo(BuildingInfo buildinginfo);
	
	public Long count(BuildingInfo buildinginfo);

	public long create(BuildingInfo buildinginfo);
	
	public boolean update(BuildingInfo buildinginfo);
			
	public BuildingInfo queryByID(long id);
	
	public boolean deletes(String ids);
	
	public List<Goods> pageGoods4BuildingInfo(BuildingInfo buildingInfo);
    
    public Long countGoods4BuildingInfo(BuildingInfo buildingInfo);
}

