package com.gjw.company.service.impl.goods;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.service.goods.IGoodsMarkService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.entity.matter.Matter;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsMarkVO;

/**
 * 产品包房间service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("goodsMarkServiceImpl")
public class GoodsMarkServiceImpl extends AbstractServiceImpl implements IGoodsMarkService {

    @Override
    @Transactional(readOnly = true)
    public GoodsMark queryById(Long id) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().queryById(id);
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().delBatchByID(ids);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsMark> listMarkByRoomIdAndType(Long roomId, Long type) {
        // TODO Auto-generated method stub
        List<GoodsMark> list = super.getGoodsMarkDao().listMarkByRoomIdAndType(roomId, type);
        if (null != list && list.size() > 0) {
            for (GoodsMark mark : list) {
                Hibernate.initialize(mark.getMatter());
                if (mark.getMatter() != null) {
                    Hibernate.initialize(mark.getMatter().getEffectImage());
                    if (mark.getMatter().getEffectImage() != null) {
                        Hibernate.initialize(mark.getMatter().getEffectImage().getPath());
                    }
                }else if(StringUtil.notEmpty(type)){//获取标配物料，针对普通产品包
                    List<GoodsMatter>  ls =super.getGoodsMatterDao().listMatterWithType(mark.getId(),DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
                    if(null != ls && ls.size()>0){
                        Hibernate.initialize(ls.get(0).getMatter());
                        Matter mat = ls.get(0).getMatter();
                        mark.setMatter(mat);
                        Hibernate.initialize(mark.getMatter().getEffectImage());
                        if (mark.getMatter().getEffectImage() != null) {
                            Hibernate.initialize(mark.getMatter().getEffectImage().getPath());
                        }
                    }
                }
                Hibernate.initialize(mark.getType());
            }
        }
        return list;
    }

    @Override
    @Transactional
    public boolean update(GoodsMark mark) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().update(mark);
    }

    @Override
    @Transactional
    public long create(GoodsMark mark) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().create(mark);
    }

    @Override
    @Transactional
    public boolean createMarkAndMatter(GoodsMarkVO markVO) {
        // TODO Auto-generated method stub
        try {
            GoodsMark goodsMark = new GoodsMark();
            // 赋值给父类
            PropertyUtils.copyProperties(goodsMark, markVO);
            // 新增锚点类型为物料锚点
            Dictionary type = new Dictionary();
            type.setId(DictionaryConstants.DICTIONARY_GOODS_MARK_ONE);
            goodsMark.setType(type);
            // 新增锚点
            this.create(goodsMark);

            // 修改标配物料（标配，及锚点id） 根据goodsId，matterId,roomId,修改
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包信息
            Goods goods = new Goods();
            goods.setId(markVO.getGoodsId());
            goodsMatter.setGoods(goods);
            // 物料信息
            goodsMatter.setMatter(markVO.getMatter());
            // 房间信息
            goodsMatter.setRoom(markVO.getGoodsRoom());
            // 锚点信息
            goodsMatter.setMark(goodsMark);
            // 设置为标配
            Dictionary dic = new Dictionary();
            dic.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
            goodsMatter.setType(dic);
            super.getGoodsMatterDao().updateMatter(goodsMatter);

            /* 新增选配物料 */
            if (StringUtil.notEmpty(markVO.getOptIds())) {
                String[] ids = markVO.getOptIds().split(",");
                for (String optId : ids) {
                    GoodsMatter optMatter = new GoodsMatter();
//                    int index = optId.indexOf("|");
//
//                    String id = optId.substring(0, index);
//                    optMatter.setId(Long.valueOf(id));
                    optMatter.setId(Long.valueOf(optId));
                    // 产品包信息
                    optMatter.setGoods(goods);
                    // 锚点信息
                    optMatter.setMark(goodsMark);
                    // 房间信息
                    optMatter.setRoom(markVO.getGoodsRoom());
                    // 设置物料信息
                    // String[] matterIds = optId.split("\\|");
                    // Matter mat = new Matter();
                    // mat.setId(Long.valueOf(matterIds[1]));
                    // optMatter.setMatter(mat);
                    // 设置为选配
                    Dictionary di = new Dictionary();
                    di.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_N);
                    optMatter.setType(di);
                    // 不为标配
                    optMatter.setIsStandard(false);
                    super.getGoodsMatterDao().updateMatter(optMatter);
                }
            }
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    @Transactional
    public boolean updateMarkAndMatter(GoodsMarkVO markVO) {
        // TODO Auto-generated method stub
        try {
            GoodsMark goodsMark = new GoodsMark();
            // 赋值给父类
            PropertyUtils.copyProperties(goodsMark, markVO);
            // 修改锚点信息
            this.update(goodsMark);
            // 修改标配物料id 根据goodsId，markId,roomId,修改
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包信息
            Goods goods = new Goods();
            goods.setId(markVO.getGoodsId());
            goodsMatter.setGoods(goods);
            // 房间信息
            goodsMatter.setRoom(markVO.getGoodsRoom());
            // 锚点信息
            goodsMatter.setMark(goodsMark);
            // 修改锚点标配 前把原来锚点对应的标配物料锚点置空
            // 设置为标配
            Dictionary dic = new Dictionary();
            dic.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
            goodsMatter.setType(dic);
            super.getGoodsMatterDao().updateMatterByMark(goodsMatter);
            // 物料信息
            goodsMatter.setMatter(markVO.getMatter());
            // 标配信息插入mark值
            super.getGoodsMatterDao().updateMatter(goodsMatter);

            // 删除选配 根据markId，选配
            // super.getGoodsMatterDao().deleteOpByMark(markVO.getId());
            /* 新增选配物料 */
            if (StringUtil.notEmpty(markVO.getOptIds())) {
                String[] ids = markVO.getOptIds().split(",");
                for (String optId : ids) {
                    GoodsMatter optMatter = new GoodsMatter();
//                    int index = optId.indexOf("|");
//
//                    String id = optId.substring(0, index);
//                    optMatter.setId(Long.valueOf(id));
                    optMatter.setId(Long.valueOf(optId));
                    // 产品包信息
                    optMatter.setGoods(goods);
                    // 锚点信息
                    optMatter.setMark(goodsMark);
                    // 房间信息
                    optMatter.setRoom(markVO.getGoodsRoom());
                    // 设置物料信息
//                    String[] matterIds = optId.split("\\|");
//                    Matter mat = new Matter();
//                    mat.setId(Long.valueOf(matterIds[1]));
//                    optMatter.setMatter(mat);
                    // 设置为选配
                    Dictionary di = new Dictionary();
                    di.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_N);
                    optMatter.setType(di);
                    // 不为标配
                    optMatter.setIsStandard(false);
                    super.getGoodsMatterDao().updateMatter(optMatter);
                }
            }
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    @Transactional
    public boolean deleteById(Long markId) {
        // TODO Auto-generated method stub
        // 软删除锚点
        super.getGoodsMarkDao().remove(markId);
        GoodsMatter goodsMatter = new GoodsMatter();
        GoodsMark mark = new GoodsMark();
        mark.setId(markId);
        goodsMatter.setMark(mark);
        // 相关goods_matter物料锚点置空
        return super.getGoodsMatterDao().updateMatterByMark(goodsMatter);
    }

    // DIY 接口start
    @Override
    @Transactional(readOnly = true)
    public List<GoodsMark> listMarkByGoodsId(Long goodsId) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().listMarkByGoodsId(goodsId);
    }

    @Transactional
    @Override
    public boolean deleteByRoomId(Long roomId) {
        // TODO Auto-generated method stub
        return super.getGoodsMarkDao().deleteByRoomId(roomId);
    }
}
