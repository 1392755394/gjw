package com.gjw.company.service.cityoperator;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.cityoperator.GesCityOperatorCompare;
import com.gjw.entity.cityoperator.GesCityOperatorCompareConclusion;
import com.gjw.entity.cityoperator.GesCityOperatorContract;
import com.gjw.entity.cityoperator.GesCityOperatorPartner;
import com.gjw.entity.cityoperator.GesCityOperatorTracking;
import com.gjw.entity.cityoperator.GesGuide;
import com.gjw.vo.oa.GesCityOperatorVO;

public interface IGesCityOperatorService extends IService {
    //城运商
    public GesCityOperator listByID(Long id);

    public boolean updateGesCityOperator(GesCityOperator model);

    public boolean createGesCityOperator(GesCityOperator model);
    
    public long count(GesCityOperator model,Integer... stars);
    
    public List<GesCityOperator> listByGesCityOperator(GesCityOperator model,Integer... stars);
    
    public List<GesCityOperatorVO> listByGesCityOperator4Export(GesCityOperator model,Integer... stars);
    //城运商4维度对比总结
    public GesCityOperatorCompareConclusion listByGesCityOperatorCompareConclusionID(Long id);

    public boolean updateGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);

    public boolean createGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);
    
    public long gesCityOperatorCompareConclusionCount(GesCityOperatorCompareConclusion model);
    
    public List<GesCityOperatorCompareConclusion> listByGesCityOperatorCompareConclusion(GesCityOperatorCompareConclusion model);
    //城运商4维度对比
    public GesCityOperatorCompare listByGesCityOperatorCompareID(Long id);

    public boolean updateGesCityOperatorCompare(GesCityOperatorCompare model);

    public boolean createGesCityOperatorCompare(GesCityOperatorCompare model);
    
    public long gesCityOperatorCompareCount(GesCityOperatorCompare model);
    
    public List<GesCityOperatorCompare> listByGesCityOperatorCompare(GesCityOperatorCompare model);
    //城运商合同信息
    public GesCityOperatorContract listByGesCityOperatorContractID(Long id);

    public boolean updateGesCityOperatorContract(GesCityOperatorContract model);

    public boolean createGesCityOperatorContract(GesCityOperatorContract model);
    
    public long gesCityOperatorContractCount(GesCityOperatorContract model);
    
    public List<GesCityOperatorContract> listByGesCityOperatorContract(GesCityOperatorContract model);
    //城运商合伙人
    public GesCityOperatorPartner listByGesCityOperatorPartnerID(Long id);

    public boolean updateGesCityOperatorPartner(GesCityOperatorPartner model);

    public boolean createGesCityOperatorPartner(GesCityOperatorPartner model);
    
    public long gesCityOperatorPartnerCount(GesCityOperatorPartner model);
    
    public List<GesCityOperatorPartner> listByGesCityOperatorPartner(GesCityOperatorPartner model);
    
    public boolean deleteGesCityOperatorPartner(GesCityOperatorPartner model);
    //城运商跟踪信息
    public GesCityOperatorTracking listByGesCityOperatorTrackingID(Long id);

    public boolean updateGesCityOperatorTracking(GesCityOperatorTracking model);

    public boolean createGesCityOperatorTracking(GesCityOperatorTracking model);
    
    public long gesCityOperatorTrackingCount(GesCityOperatorTracking model);
    
    public List<GesCityOperatorTracking> listByGesCityOperatorTracking(GesCityOperatorTracking model);
    //接引表单
    public GesGuide listByGesGuideID(Long id);

    public boolean updateGesGuide(GesGuide model);

    public boolean createGesGuide(GesGuide model);
    
    public long gesGuideCount(GesGuide model);
    
    public List<GesGuide> listByGesGuide(GesGuide model);
    
    public boolean deleteGuide(String ids);
}
