package com.gjw.company.service.recommend;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.recommend.WebRecommendPosition;

/**
 * 
* @Description: 推荐位service接口类
* @author  zhaoyonglian
* @date 2015年12月17日 上午11:47:36
*
 */
public interface IWebRecommendPositionService extends IService {
    /**
     * 
    * @Description  推荐位详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月17日 上午11:13:28
     */
    public WebRecommendPosition getById(Long id);
    
    /**
     * 
    * @Description  分页查询，推荐位名字或者代码
    * @param position
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月17日 上午11:13:44
     */
    public List<WebRecommendPosition> pageByNameAndCode(WebRecommendPosition position);
    
    /**
     * 
    * @Description  总数
    * @param position
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月17日 上午11:14:06
     */
    public Long countByNameAndCode(WebRecommendPosition position);
    
    /**
     * 
    * @Description  修改
    * @param position
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月17日 上午11:14:18
     */
    public boolean update(WebRecommendPosition position);
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebRecommendPosition entity);

    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    /**
     * 
    * @Description  有效推荐位列表
    * @param invalid
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月18日 下午1:32:45
     */
    public List<WebRecommendPosition> listByInvalid(Integer invalid);
}
