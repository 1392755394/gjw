package com.gjw.company.service.impl.goods;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.goods.IGoodsRoomService;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.vo.GoodsVO;

/**
 * 产品包房间service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("goodsRoomServiceImpl")
public class GoodsRoomServiceImpl extends AbstractServiceImpl implements IGoodsRoomService {

    @Override
    @Transactional(readOnly = true)
    public List<GoodsRoom> listGoodsRoomByGoodsId(Long goodsId) {
        List<GoodsRoom> list = super.getGoodsRoomDAO().listGoodsRoomByGoodsId(goodsId);
        for (GoodsRoom gr : list) {
            Hibernate.initialize(gr.getPhoto2D());
            Hibernate.initialize(gr.getEffectImage());
            Hibernate.initialize(gr.getRoomAttribute());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public GoodsRoom queryById(Long id) {
        GoodsRoom goodsRoom = super.getGoodsRoomDAO().queryById(id);
        Hibernate.initialize(goodsRoom.getPhoto2D());
        Hibernate.initialize(goodsRoom.getEffectImage());
        Hibernate.initialize(goodsRoom.getPhotoApp());
        return goodsRoom;
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        return super.getGoodsRoomDAO().delBatchByID(ids);
    }

    @Override
    @Transactional
    public boolean update(GoodsRoom goodsRoom) {
        return super.getGoodsRoomDAO().update(goodsRoom);
    }

    @Override
    @Transactional
    public long create(GoodsRoom goodsRoom) {
        return super.getGoodsRoomDAO().create(goodsRoom);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsRoom> pageList(GoodsVO goodsVO) {
        List<GoodsRoom> list = super.getGoodsRoomDAO().pageList(goodsVO);

        for (GoodsRoom room : list) {
            room.getPhoto2D().getPath();
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public long pageListCount(GoodsVO goodsVO) {
        return super.getGoodsRoomDAO().pageListCount(goodsVO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Long> getAllId() {
        return super.getGoodsRoomDAO().getAllId();
    }

}
