package com.gjw.company.service.user;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;

/**
 * 部门service接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月9日
 * 
 */
public interface IDeptService extends IService {

    /**
     * 新增部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 部门ID
     * @author guojianbin
     * @date 2016年1月9日
     */
    public long create(Dept dept);

    /**
     * 修改部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月9日
     */
    public boolean update(Dept dept);

    /**
     * 删除部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月9日
     */
    public boolean delete(Dept dept);

    /**
     * 根据上级部门取得的下级部门列表
     * 
     * @Description
     * @param parentId
     *            上级部门ID
     * @return 下级部门列表
     * @author guojianbin
     * @date 2016年1月9日
     */
    public List<Dept> listDeptByParentId(long parentId);

    /**
     * 取得全体部门列表
     * 
     * @Description
     * @return 部门列表
     * @author guojianbin
     * @date 2016年1月9日
     */
    public List<Dept> listDepts();

    /**
     * @Description
     * @param dept
     * @return
     * @author qingye
     * @date Jan 15, 2016 4:19:16 PM
     */

    public void createDeptUser(DeptUser dept);

    /**
     * @Description
     * @param dept
     * @return
     * @author qingye
     * @date Jan 15, 2016 4:19:25 PM
     */

    public void updateDeptUser(DeptUser dept);

    /**
     * @Description
     * @param dept
     * @return
     * @author qingye
     * @date Jan 15, 2016 4:19:33 PM
     */

    public void deleteDeptUser(DeptUser dept);

    /**
     * 基础数据同步--部门同步
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2016年1月16日 上午10:37:10
     */
    public List<Dept> listDeptForSynch();

    public List<DeptUser> listDeptUserForSynch();

}
