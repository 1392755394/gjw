package com.gjw.company.service.oa;

import java.util.List;

import com.gjw.entity.oa.GesTaskPeriod;
import com.gjw.vo.oa.GesTaskPeriodVO;

public interface IGesTaskPeriodService {
	
	/**
	 * 通过任务的id查询任务阶段以及阶段下的任务数目
	 * @param taskId
	 * @return
	 */
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskId(Long taskId);
    
    /**
     * 通过任务的id查询任务阶段的列表信息
     * @param taskId
     * @return
     */
    public List<GesTaskPeriodVO> queryTaskPeriodByTaskId(Long taskId);
    
    /**
     * 添加一条记录
     * @param taskPeriod
     * @return
     */
    public long addTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 更新一条记录
     * @param taskPeriod
     * @return
     */
    public boolean updateTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 删除一条记录
     * @param taskPeriod
     * @return
     */
    public boolean delTaskPeriod(GesTaskPeriod taskPeriod);
    
    /**
     * 任务阶段的向上、向下移动
     * @param taskPeriodVO
     * @return
     */
    public boolean updateTaskPeriodForMove(GesTaskPeriodVO taskPeriodVO);
    
    /**
     * 施工管理项目
     * @param taskId
     * @return
     */
    public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskIdForPM(Long taskId);
    
    

}
