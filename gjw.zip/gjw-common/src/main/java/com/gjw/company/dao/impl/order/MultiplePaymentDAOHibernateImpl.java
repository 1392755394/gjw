package com.gjw.company.dao.impl.order;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.order.IMultiplePaymentDAO;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.utils.StringUtil;
import com.gjw.vo.order.MultiplePaymentVO;

@Component("multiplePaymentDAOHibernateImpl")
public class MultiplePaymentDAOHibernateImpl extends AbstractDAOHibernateImpl
		implements IMultiplePaymentDAO {
	
	private final static Logger log=LoggerFactory.getLogger(MultiplePaymentDAOHibernateImpl.class);

	@Override
	protected Class getEntityClass() {
		return MultiplePayment.class;
	}

	@Override
	public Map<String, Object> queryPaymentRecord(MultiplePayment multiplePayment) {
		Map<String, Object> map=new HashMap<String, Object>();
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select m.id as id,m.gesOrder.id as orderId,m.money as money,m.period as period,m.payWay as payWay,"
				+ "m.payStatus as payStatus,m.paySuccessTime as paySuccessTime,i.realName as realName ");
		hql.append(" from MultiplePayment m left join m.user u left join u.userInfoMap i with i.type=? ");
		hql.append(" where m.invalid=?  and m.period=? and m.gesOrder.id=? ");
		hql.append(" order by m.createdDatetime desc ");
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		param.add(false);
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getGesOrder().getId());
		List<MultiplePaymentVO> list=(List<MultiplePaymentVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(MultiplePaymentVO.class));
		return transformStatus(map, list);
	}

	protected Map<String, Object> transformStatus(Map<String, Object> map,
			List<MultiplePaymentVO> list) {
		long payedMoney=0l;
        for(int i=0;i<list.size();i++){
            MultiplePaymentVO l=list.get(i);
            if(l.getPayWay()==PaymentConstant.PayWay.POS.ordinal()){
                l.setPayWayName(PaymentConstant.PayWay.POS.getText());
            }else if(l.getPayWay()==PaymentConstant.PayWay.EBANK.ordinal()){
                l.setPayWayName(PaymentConstant.PayWay.EBANK.getText());
            }else if(l.getPayWay()==PaymentConstant.PayWay.OFFLINE.ordinal()){
                l.setPayWayName(PaymentConstant.PayWay.OFFLINE.getText());
            }else if(l.getPayWay()==PaymentConstant.PayWay.GJB.ordinal()){
                l.setPayWayName(PaymentConstant.PayWay.GJB.getText());
            }
            if(l.getPayStatus()==PaymentConstant.PayStatus.NOPAY.ordinal()){
                l.setPayStatusName(PaymentConstant.PayStatus.NOPAY.getText());
            }else if(l.getPayStatus()==PaymentConstant.PayStatus.PAYFAIL.ordinal()){
                l.setPayStatusName(PaymentConstant.PayStatus.PAYFAIL.getText());
            }else if(l.getPayStatus()==PaymentConstant.PayStatus.PAYEDWAIT.ordinal()){
                l.setPayStatusName(PaymentConstant.PayStatus.PAYEDWAIT.getText());
                payedMoney=payedMoney+l.getMoney();
            }else if(l.getPayStatus()==PaymentConstant.PayStatus.PAYED.ordinal()){
                l.setPayStatusName(PaymentConstant.PayStatus.PAYED.getText());
                payedMoney=payedMoney+l.getMoney();
            }
            l.setPayMoney(new BigDecimal(l.getMoney()).divide(new BigDecimal(100)));
        }
        map.put("list", list);
        map.put("payedMoney", payedMoney);
		return map;
	}

	/**
     * 查询某一个阶段是否有未支付的记录
     * @param multiplePayment
     * @return
     */
	@Override
	public List<MultiplePayment> queryRecordNoPay(MultiplePaymentVO multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
//		hql.append(" select m.id as id,m.gesOrder.id as orderId,m.money as money,m.period as period ");
		hql.append(" from MultiplePayment m ");
		hql.append(" where m.invalid=? and m.payStatus <=1 and m.period=? and m.gesOrder.id=? ");
		param.add(false);
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getOrderId());
		return (List<MultiplePayment>) super.findByListCallBack(hql.toString(), null, param, null);
	}

	/**
     * 查询已支付的金额(待到账和已到账)
     * @param multiplePayment
     * @return
     */
	@Override
	public long queryPayedMoney(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select coalesce(sum(m.money),0) ");
		hql.append(" from MultiplePayment m where m.invalid =? ");
		param.add(false);
		hql.append(" and m.payStatus >=2 and m.period=? and m.gesOrder.id=? ");
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getGesOrder().getId());
		return (long) queryByParam(hql.toString(), param);
	}

	@Override
	public void addMultiplePayment(MultiplePayment multiplePayment) {
		super.add(multiplePayment);
	}

	/**
	 * 查询已到账的金额
	 */
	@Override
	public long queryCompletePay(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select coalesce(sum(m.money),0) ");
		hql.append(" from MultiplePayment m where m.invalid =? ");
		param.add(false);
		hql.append(" and m.payStatus=3 and m.period=? and m.gesOrder.id=? ");
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getGesOrder().getId());
		return (long) queryByParam(hql.toString(), param);
	}

	/**
     * 官网个人中心 查询支付记录
     * @param orderId
     * @return
     */
	@Override
	public List<MultiplePaymentVO> queryPersonalPaymentRecord(long orderId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select m.id as id,m.money as money,m.period as period,m.payWay as payWay,m.paySuccessTime as paySuccessTime ");
		hql.append(" from MultiplePayment m where m.invalid=? and m.payStatus>=2 and m.gesOrder.id=? ");
		param.add(false);
		param.add(orderId);
		return (List<MultiplePaymentVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(MultiplePaymentVO.class));
	}

	/**
	 * 更新多次支付记录的支付状态
	 */
	@Override
	public boolean updateMultiplePayStatus(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update MultiplePayment m set m.systemUpdateTime=?, m.payStatus=? "
				+ "where m.gesOrder.id=? and m.serialPayNo=? order by m.id desc ");
		param.add(new Timestamp(System.currentTimeMillis()));
		param.add(multiplePayment.getPayStatus());
		param.add(multiplePayment.getGesOrder().getId());
		param.add(multiplePayment.getSerialPayNo());
		log.info("参数：payStatus："+multiplePayment.getPayStatus()+",orderId:"+multiplePayment.getGesOrder().getId()+",serial:"+multiplePayment.getSerialPayNo());
		return super.updateByParam(hql.toString(), param);
	}

	/**
     * 查询某一个阶段的最新的未支付的记录
     * @param multiplePayment
     * @return
     */
	@Override
	public MultiplePayment queryLatestRecordNoPay(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
//		hql.append(" select m.id as id,m.gesOrder.id as orderId,m.money as money,m.period as period ");
		hql.append(" from MultiplePayment m ");
		hql.append(" where m.invalid=? and m.payStatus <=1 and m.period=? and m.gesOrder.id=? ");
		hql.append(" order by m.createdDatetime desc ");
		param.add(false);
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getGesOrder().getId());
		return (MultiplePayment) queryByParam(hql.toString(), param);
	}
	
	@Override
	public Object queryByParam(String hql, List<Object> list) {
		List<Object> result = (List<Object>) super.findByListCallBack(hql,null, list, null);
		if (result != null && result.size() > 0) {
			return result.get(0);
		} else {
			return null;
		}
    }

	/**
     * 更新多次支付记录的支付流水号
     * @param multiplePayment
     * @return
     */
	@Override
	public int updateSerialPayNo(MultiplePayment multiplePayment) {
		StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("update MultiplePayment m set m.serialPayNo=? "
        		+ "where m.invalid=? and m.payStatus <=1 and m.period=? and m.gesOrder.id=? ");
        hql.append(" order by m.createdDatetime desc ");
        param.add(multiplePayment.getSerialPayNo());
        param.add(false);
        param.add(multiplePayment.getPeriod());
        param.add(multiplePayment.getGesOrder().getId());
        return updateByParamReturnInt(hql.toString(),param);
	}
	
	protected int updateByParamReturnInt(String hql,List<Object> list) {
		Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql).setMaxResults(1);
        for (int i = 0; i < list.size(); i++) {
            query.setParameter(i, list.get(i));
        }
        return query.executeUpdate();
	}

	/**
	 * 查询90%保证金支付记录
	 */
	@Override
	public List<MultiplePayment> queryDepositMultiplePayRecord(
			MultiplePayment multiplePayment) {
		StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("from MultiplePayment m where m.invalid=? and m.period=? and m.payStatus=? and m.gesOrder.id=? ");
		param.add(false);
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getPayStatus());
		param.add(multiplePayment.getGesOrder().getId());
		if(StringUtil.notEmpty(multiplePayment.getSerialPayNo())){
			hql.append(" and m.serialPayNo=? ");
			param.add(multiplePayment.getSerialPayNo());
		}
		return (List<MultiplePayment>) super.findByListCallBack(hql.toString(), null, param, null);
	}

	/**
	 * 更新支付信息
	 */
	@Override
	public int updateMultiplePay(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update MultiplePayment m set m.systemUpdateTime=?, m.payStatus=?,m.payWay=?,m.paySuccessTime=? "
				+ "where m.invalid=? and m.payStatus<=1 and m.period=? and m.gesOrder.id=? and m.serialPayNo=? ");
		param.add(new Timestamp(System.currentTimeMillis()));
		param.add(multiplePayment.getPayStatus());
		param.add(multiplePayment.getPayWay());
		param.add(new Timestamp(System.currentTimeMillis()));
		param.add(false);
		param.add(multiplePayment.getPeriod());
		param.add(multiplePayment.getGesOrder().getId());
		param.add(multiplePayment.getSerialPayNo());
		return updateByParamReturnInt(hql.toString(), param);
	}

	@Override
	public boolean updateRecordById(MultiplePayment multiplePayment) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update MultiplePayment m set m.money=?,m.updatedDatetime=?,m.user.id=?,m.recordSource=? ");
		hql.append("where id=? ");
		param.add(multiplePayment.getMoney());
		param.add(new Date());
		param.add(multiplePayment.getUser().getId());
		param.add(multiplePayment.getRecordSource());
		param.add(multiplePayment.getId());
		return super.updateByParam(hql.toString(), param);
	}

	@Override
	public List<MultiplePayment> queryMultiplePaymentByCodeOrId(MultiplePayment multiplePayment) {
		StringBuffer hql = new StringBuffer();
        List<Object> param = new ArrayList<Object>();
        hql.append("from MultiplePayment m where m.invalid=? ");
		param.add(false);
		if(multiplePayment.getGesOrder()!=null && multiplePayment.getGesOrder().getId()>0){
			hql.append(" and m.gesOrder.id=? ");
			param.add(multiplePayment.getGesOrder().getId());
		}
		if(StringUtil.notEmpty(multiplePayment.getSerialPayNo())){
			hql.append(" and m.serialPayNo=? ");
			param.add(multiplePayment.getSerialPayNo());
		}
		return (List<MultiplePayment>) super.findByListCallBack(hql.toString(), null, param, null);
	}

}
