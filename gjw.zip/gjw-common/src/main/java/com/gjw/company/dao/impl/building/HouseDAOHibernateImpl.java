package com.gjw.company.dao.impl.building;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.building.IHouseDAO;
import com.gjw.entity.building.House;
import com.gjw.utils.StringUtil;

@Component("houseDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class HouseDAOHibernateImpl extends AbstractDAOHibernateImpl implements IHouseDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return House.class;
    }

    @Override
    public House listByID(Long id) {
        // TODO Auto-generated method stub
        return (House) super.get(id);
    }

    @Override
    public boolean updateHouse(House model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createHouse(House model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(House model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from House item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        if(null!=model.getBuilding() && StringUtil.notEmpty(model.getBuilding().getName())){
            hql=hql+" and item.building.name like ?";
            params.add(super.getFuzzyCondition(model.getBuilding().getName()));
        }
        if(null!=model.getType() && null!=model.getType().getId()){
            hql=hql+" and item.type.id=?";
            params.add(model.getType().getId());
        }
        if(StringUtil.notEmpty(model.getCode())){
            hql=hql+" and item.code=?";
            params.add(model.getCode());
        }
        hql=hql+" order by item.createdDatetime";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<House> listByHouse(House model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from House item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            hql=hql+" and item.building.id=?";
            params.add(model.getBuilding().getId());
        }
        if(null!=model.getBuilding() && StringUtil.notEmpty(model.getBuilding().getName())){
            hql=hql+" and item.building.name like ?";
            params.add(super.getFuzzyCondition(model.getBuilding().getName()));
        }
        if(null!=model.getType() && null!=model.getType().getId()){
            hql=hql+" and item.type.id=?";
            params.add(model.getType().getId());
        }
        if(StringUtil.notEmpty(model.getCode())){
            hql=hql+" and item.code=?";
            params.add(model.getCode());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<House>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
