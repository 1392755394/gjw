package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesStoreDAO;
import com.gjw.entity.store.GesStore;
import com.gjw.utils.StringUtil;
import com.gjw.vo.RdRecordsVO;

/**
 * 仓库管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 上午10:48:55
 * 
 */
@Component("gesStoreDAOHibernateImpl")
public class GesStoreDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesStoreDAO {

    @Override
    protected Class getEntityClass() {
        return GesStore.class;
    }

    /**
     * 查询总数
     */
    @Override
    public Long count(GesStore storeCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesStore where invalid=0 ");
        if (StringUtil.notEmpty(storeCriteria.getName())) {
            hql.append("  and name=?");
            ls.add(storeCriteria.getName());
        }
        if (StringUtil.notEmpty(storeCriteria.getCode())) {
            ls.add(storeCriteria.getCode());
            hql.append("  and code=?");
        }
        if (storeCriteria.getShop() != null && StringUtil.notEmpty(storeCriteria.getShop().getId().toString())) {
            hql.append("  and shop.id=?");
            ls.add(storeCriteria.getShop().getId());
        }
        if (storeCriteria.getCityOperator() != null
                && StringUtil.notEmpty(storeCriteria.getCityOperator().getId().toString())) {
            hql.append("  and cityOperator.id=?");
            ls.add(storeCriteria.getCityOperator().getId());
        }
        return super.countHql(hql.toString(), ls);
    }

    /**
     * 仓库分页查询
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<GesStore> listGesStore(GesStore storeCriteria) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesStore where invalid=0 ");
        if (StringUtil.notEmpty(storeCriteria.getName())) {
            hql.append("  and name like ?");
            ls.add(super.getFuzzyCondition(storeCriteria.getName()));
        }
        if (StringUtil.notEmpty(storeCriteria.getCode())) {
            ls.add(storeCriteria.getCode());
            hql.append("  and code=?");
        }
        if (storeCriteria.getShop() != null && StringUtil.notEmpty(storeCriteria.getShop().getId().toString())) {
            hql.append("  and shop.id=?");
            ls.add(storeCriteria.getShop().getId());
        }
        if (storeCriteria.getCityOperator() != null
                && StringUtil.notEmpty(storeCriteria.getCityOperator().getId().toString())) {
            hql.append("  and cityOperator.id=?");
            ls.add(storeCriteria.getCityOperator().getId());
        }
        hql.append(" order by createdDatetime desc");
        // Transformers.aliasToBean(GesStoreVO.class)
        // Transformers.ALIAS_TO_ENTITY_MAP;
        // null
        return (List<GesStore>) super.findByPageCallBack(hql.toString(), "", ls, storeCriteria, null);
    }

    /**
     * 根据仓库id查询仓库信息
     */
    @Override
    public GesStore queryByID(Long id) {

        return (GesStore) super.get(id);
    }

    /**
     * 修改仓库信息
     */
    @Override
    public boolean updateGesStore(GesStore model) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" update GesStore set status=status");
        if (model.getCity() != null && model.getCity().getId() != null) {
            hql.append(" , city.id=?");
            list.add(model.getCity().getId());
        }
        if (model.getCounty() != null && model.getCounty().getId() != null) {
            hql.append(" , county.id=?");
            list.add(model.getCounty().getId());
        }
        if (model.getProvince() != null && model.getProvince().getId() != null) {
            hql.append(" , province.id=?");
            list.add(model.getProvince().getId());
        }
        if (model.getCityOperator() != null && model.getCityOperator().getId() != null && model.getCityOperator().getId()>0) {
            hql.append(" , cityOperator.id=?");
            list.add(model.getCityOperator().getId());
        }
        if (model.getShop() != null && model.getShop().getId() != null) {
            hql.append(" , shop.id=?");
            list.add(model.getShop().getId());
        }
        if (model.getContact() != null) {
            hql.append(" , contact=?");
            list.add(model.getContact());
        }
        if (model.getContactMobile() != null) {
            hql.append(" , contactMobile=?");
            list.add(model.getContactMobile());
        }
        if (model.getCode() != null) {
            hql.append(" , code=?");
            list.add(model.getCode());
        }
        if (model.getName() != null) {
            hql.append(" , name=?");
            list.add(model.getName());
        }
        if (model.getAddress() != null) {
            hql.append(" , address=?");
            list.add(model.getAddress());
        }
        if (model.getStoreType() != null && model.getStoreType().getId() != null) {
            hql.append(" , storeType.id=?");
            list.add(model.getStoreType().getId());
        }
        if (model.getGesOrder() != null && model.getGesOrder().getId() != null) {
            hql.append(" , gesOrder.id=?");
            list.add(model.getGesOrder().getId());
        }
        if (model.getSynchType() != null && model.getSynchType().getId() != null) {
            hql.append(" , synchType.id=?");
            list.add(model.getSynchType().getId());
        }
        if (model.getInvalid() != null) {
            hql.append(" , invalid=?");
            list.add(model.getInvalid());
        }
        hql.append(" where id=?");
        list.add(model.getId());

        return super.updateByParam(hql.toString(), list);
    }

    /**
     * 新增仓库
     */
    @Override
    public boolean createGesStore(GesStore model) {
        return super.saveResultBoolean(model);
    }

    /**
     * 查询仓库列表
     */
    @Override
    public List<GesStore> listStoreBySynchType(GesStore stoe) {
        String hql = " from GesStore store  where store.invalid=0 and store.synchType.id not in(1130102,1130105)";
        return (List<GesStore>) super.findByListCallBack(hql, "", null, null);
    }

    /**
     * 根据仓库id修改仓库修改同步结果
     * <p>
     * 仅用户修改仓库同步结果
     */
    @Override
    public void updateById(GesStore store) {
        String hql = " update GesStore set synchType.id =? where id=?";
        List<Object> list = new ArrayList<Object>();
        list.add(store.getSynchType().getId());
        list.add(store.getId());
        super.updateByParam(hql, list);

    }

    /**
     * 销售出库单明细查询----查询仓库
     */
    @Override
    public List<GesStore> listGesStoreByShopIdOrOperatorId(RdRecordsVO rdRecords) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesStore where invalid=0 ");

        if (rdRecords.getShopId() != null) {
            hql.append("  and shop.id=?");
            ls.add(rdRecords.getShopId());
        }
        if (rdRecords.getOperatorId() != null) {
            hql.append("  and cityOperator.id=?");
            ls.add(rdRecords.getOperatorId());
        }
        return (List<GesStore>) super.findByPageCallBack(hql.toString(), "", ls, rdRecords, null);
    }
}
