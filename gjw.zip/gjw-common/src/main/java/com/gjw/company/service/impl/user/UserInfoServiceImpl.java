package com.gjw.company.service.impl.user;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.company.service.user.IUserInfoService;
import com.gjw.entity.building.GesBuilding;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.AuthenticationEmail;
import com.gjw.entity.user.AuthenticationMobile;
import com.gjw.entity.user.AuthenticationUsername;
import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.Role;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.entity.user.UserPlatformItem;
import com.gjw.entity.user.UserRoleItem;
import com.gjw.utils.PasswordUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.user.UserVO;

@Service("userInfoServiceImpl")
@Transactional
public class UserInfoServiceImpl extends AbstractServiceImpl implements IUserInfoService {
    @Override
    public void registerApp(UserInfo userInfo) {
        this.getUserDAO().add(userInfo.getUser());
        this.getUserPlatformDAO().add(
                new UserPlatformItem(userInfo.getUser(), PlatformEnum.valueOfUserInfo(userInfo.getClass()).getObj()));
        this.getAuthenticationDAO().add(new AuthenticationUsername(userInfo.getUser(),null));
        if (userInfo.getAvatar() != null && userInfo.getAvatar().getId() == null)
            userInfo.setAvatar(null);
        if (userInfo instanceof UserInfoGES) {
            UserInfoGES u = (UserInfoGES) userInfo;
            if (u.getQrCode() != null && u.getQrCode().getId() == null)
                u.setQrCode(null);
        }
        this.getUserInfoDAO().add(userInfo);
    }
    @Override
    public void register(UserInfo userInfo) {
        this.getUserDAO().add(userInfo.getUser());
        this.getUserPlatformDAO().add(
                new UserPlatformItem(userInfo.getUser(), PlatformEnum.valueOfUserInfo(userInfo.getClass()).getObj()));
        this.getAuthenticationDAO().add(new AuthenticationUsername(userInfo.getUser()));
        if (userInfo.getUser().getEmail() != null && !userInfo.getUser().getEmail().equals(""))
            this.getAuthenticationDAO().add(new AuthenticationEmail(userInfo.getUser()));
        if (userInfo.getUser().getMobile() != null && !userInfo.getUser().getMobile().equals(""))
            this.getAuthenticationDAO().add(new AuthenticationMobile(userInfo.getUser()));
        if (userInfo.getAvatar() != null && userInfo.getAvatar().getId() == null)
            userInfo.setAvatar(null);
        if (userInfo instanceof UserInfoGES) {
            UserInfoGES u = (UserInfoGES) userInfo;
            if (u.getQrCode() != null && u.getQrCode().getId() == null)
                u.setQrCode(null);
        }
        this.getUserInfoDAO().add(userInfo);
    }

    @Override
    public void registerWithRoldId(UserInfo userInfo, String roleId) {
        register(userInfo);

        if (StringUtil.isNotEmpty(roleId)) {
            UserRoleItem userRole = new UserRoleItem();
            userRole.setGesUser(userInfo.getUser());
            Role role = new Role();
            role.setId(Long.parseLong(roleId));
            userRole.setRole(role);
            super.getUserRoleDAO().add(userRole);
        }
    }

    @Override
    public void update(UserInfo userInfo) {
        UserInfo tmp = this.getUserInfoDAO().get(userInfo.getId());
        StringUtil.copyProperties(userInfo, tmp);
        this.getUserInfoDAO().update(tmp);
    }

    @Override
    public void add(UserInfo userInfo) {
        if (userInfo.getUser() == null || userInfo.getUser().getId() == null)
            throw new ErrorCodeException(SECode.u_100004);
        this.getUserPlatformDAO().add(
                new UserPlatformItem(userInfo.getUser(), PlatformEnum.valueOfUserInfo(userInfo.getClass()).getObj()));
        this.getUserInfoDAO().add(userInfo);
    }

    @Override
    public List<User> pageUserByOwnerForGes(UserInfo owner) {
        if (!(owner instanceof UserInfoGES)) {
            throw new ErrorCodeException(SECode.s_100010);
        }
        return this.getUserInfoDAO().pageUserInfoByOwnerForGes(owner);

    }

    @Override
    public long countUserByOwnerForGes(UserInfo owner) {
        if (!(owner instanceof UserInfoGES)) {
            throw new ErrorCodeException(SECode.s_100010);
        }
        return this.getUserInfoDAO().countUserInfoByOwnerForGes(owner);
    }

    @Override
    public List<User> getByOrgIdAndTypeForGes(Long orgId, String orgType) {
        List<UserInfo> infoList = this.getUserInfoDAO().getByOrgIdAndTypeForGes(orgId, orgType);
        List<User> userList = new ArrayList<User>();
        for (UserInfo info : infoList)
            userList.add(info.getUser());
        return userList;
    }

    @Override
    public Long countForGes(UserInfoGES userInfo) {
        return this.getUserInfoDAO().countForGes(userInfo);
    }

    @Override
    public List<User> pageForGes(UserInfoGES userInfo) {
        List<User> page = this.getUserInfoDAO().pageForGes(userInfo);
        for (User user : page) {
            UserInfoGES info = (UserInfoGES) user.getPlatformUserInfo();
            List<UserRoleItem> userRoleItemList = this.getUserRoleDAO().listRolesOfUser(user.getId());
            if (userRoleItemList != null && userRoleItemList.size() > 0) {
                info.setRoles(userRoleItemList.get(0).getRole().getName());
            }
            if (info.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)) {
                if (null != info.getOperator() && StringUtil.notEmpty(info.getOperator().getCompanyName())) {
                    info.setOrgName(info.getOperator().getCompanyName());
                }
            } else if (info.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)) {
                if (null != info.getShop() && StringUtil.notEmpty(info.getShop().getName())) {
                    info.setOrgName(info.getShop().getName());
                }
            }
        }
        return page;
    }

    @Override
    public boolean remove(long id) {
        int r = this.getUserInfoDAO().remove(id);
        return r > 0;
    }

    @Override
    public void updateForGes(UserInfoGES userInfo) {
        if (userInfo.getAvatar() != null && userInfo.getAvatar().getId() == null)
            userInfo.setAvatar(null);
        if (userInfo instanceof UserInfoGES) {
            UserInfoGES u = (UserInfoGES) userInfo;
            if (u.getQrCode() != null && u.getQrCode().getId() == null)
                u.setQrCode(null);
        }
        UserInfoGES tmp = (UserInfoGES) this.getUserInfoDAO().get(userInfo.getId());
        StringUtil.copyProperties(userInfo, tmp);
        tmp.setAvatar(userInfo.getAvatar());
        tmp.setQrCode(userInfo.getQrCode());

        if (userInfo.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)) {
            GesCityOperator operator = new GesCityOperator();
            operator.setId(userInfo.getOrgId());
            tmp.setOperator(operator);
            tmp.setShop(null);
        } else if (userInfo.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)) {
            GesShop shop = new GesShop();
            shop.setId(userInfo.getOrgId());
            tmp.setShop(shop);
            tmp.setOperator(null);
        } else {
            tmp.setShop(null);
            tmp.setOperator(null);
        }

        this.getUserInfoDAO().update(tmp);
        if (userInfo.getUser().getPassword() != null && !"".equals(userInfo.getUser().getPassword())) {
            List<Authentication> list = this.getAuthenticationDAO().findByUser(userInfo.getUser());
            for (Authentication au : list) {
                au.setPassword(PasswordUtil.genPassword(userInfo.getUser().getPassword(), au.getSalt()));
                this.getAuthenticationDAO().update(au);
            }
        }

    }

    public void updateForGesWithRoleId(UserInfoGES userInfo, String roleId) {
        updateForGes(userInfo);

        // 目前系统里对应于单一角色
        Long preRoleId = null;
        Long userRoleID = null;
        List<UserRoleItem> userRoleList = super.getUserRoleDAO().listRolesOfUser(userInfo.getUser().getId());
        if (userRoleList != null && userRoleList.size() > 0) {
            preRoleId = userRoleList.get(0).getRole().getId();
            userRoleID = userRoleList.get(0).getId();
        }

        if (StringUtil.isNotEmpty(roleId)) {
            long currentRoleId = Long.parseLong(roleId);
            if (preRoleId != null && preRoleId == currentRoleId) {
                return;
            } else {
                if (userRoleID != null) {
                    super.getUserRoleDAO().delete(userRoleID);
                }
                UserRoleItem userRole = new UserRoleItem();
                userRole.setGesUser(userInfo.getUser());
                Role role = new Role();
                role.setId(currentRoleId);
                userRole.setRole(role);
                super.getUserRoleDAO().add(userRole);
            }
        }

    }

    @Override
    public Long countByDept(DeptUser deptUser) {
        return this.getDeptUserDAO().countByDept(deptUser);
    }

    @Override
    public List<DeptUser> pageByDept(DeptUser deptUser) {
        return this.getDeptUserDAO().pageByDept(deptUser);
    }

    @Override
    public Long countUncheckByDept(DeptUser deptUser) {
        return this.getDeptUserDAO().countUncheckByDept(deptUser);
    }

    @Override
    public List<User> pageUncheckByDept(DeptUser deptUser) {
        return this.getDeptUserDAO().pageUncheckByDept(deptUser);
    }

    @Override
    public UserInfoGES userInfoForGes(UserInfoGES userInfo) {
        // TODO Auto-generated method stub
        return this.getUserInfoDAO().userInfoForGes(userInfo);
    }

    @Override
    public List<UserVO> pageForSalesTool(UserInfoGES userInfo) {
        List<User> page = this.getUserInfoDAO().pageForGes(userInfo);
        List<UserVO> pageVO = new ArrayList<UserVO>();
        for (User user : page) {
            UserInfoGES info = (UserInfoGES) user.getPlatformUserInfo();
            if (info.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)) {
                if (null != info.getOperator() && StringUtil.notEmpty(info.getOperator().getCompanyName())) {
                    info.setOrgName(info.getOperator().getCompanyName());
                }
            } else if (info.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)) {
                if (null != info.getShop() && StringUtil.notEmpty(info.getShop().getName())) {
                    info.setOrgName(info.getShop().getName());
                }
            }
            UserVO userVO = new UserVO(user);
            UserBuildingItem item = super.getUserBuildingItemDAO().queryByUser(user);
            if (item != null) {
                userVO.setBuildingId(item.getBuilding().getId());
                userVO.setBuildingName(item.getBuilding().getName());
            }
            pageVO.add(userVO);
        }
        return pageVO;
    }

    @Override
    public void updateForSalesTool(UserVO user, UserInfoGES userinfo) {

        updateForGes(userinfo);

        UserBuildingItem item = new UserBuildingItem();
        item.setUser(user);
        GesBuilding building = new GesBuilding();
        building.setId(user.getBuildingId());
        item.setBuilding(building);
        super.getUserBuildingItemDAO().update(item);
    }

    @Override
    public void registerForSalesTool(UserVO user, UserInfo userInfo) {

        register(userInfo);

        UserBuildingItem item = new UserBuildingItem();
        item.setUser(userInfo.getUser());
        GesBuilding building = new GesBuilding();
        building.setId(user.getBuildingId());
        item.setBuilding(building);
        super.getUserBuildingItemDAO().create(item);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public UserInfo userInfo(Long id) {
        UserInfo userInfo = super.getUserInfoDAO().get(id);
        if(null!=userInfo){
            Hibernate.initialize(userInfo.getAvatar());
        }
        return userInfo;
    }
}
