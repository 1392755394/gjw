package com.gjw.company.service.impl.goods;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.company.service.goods.IGoodsService;
import com.gjw.entity.building.House;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.vo.GoodsVO;

/**
 * 产品包service实现
 */
@Component("goodsServiceImpl")
public class GoodsServiceImpl extends AbstractServiceImpl implements IGoodsService {

    @Override
    @Transactional(readOnly = true)
    public List<Goods> listGoods(Goods goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().listGoods(goodsCriteria);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouseType());
            Hibernate.initialize(goods.getHouse());
        }
        return list;
    }

    @Override
    @Transactional
    public long create(Goods goods) {
        // 产品包不可DIY
        goods.setCanDiy(false);
        // 产品包而非DIY方案
        Dictionary dictionary = new Dictionary();
        dictionary.setId((long) GoodsDiyConstant.IS_DIY_GOODS);
        goods.setDiyType(dictionary);
        return super.getGoodsDAO().create(goods);
    }

    @Override
    @Transactional
    public boolean update(Goods goods) {

        super.getGoodsDAO().update(goods);
        if (goods.getAveragePrice() == null) {
            return super.getGoodsDAO().updateAveragePrice(goods);
        }
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public Goods queryById(Long id) {
        Goods goods = super.getGoodsDAO().queryById(id);
        Hibernate.initialize(goods.getPhoto());
        Hibernate.initialize(goods.getFloorPlanImage());
        Hibernate.initialize(goods.getHouse());
        Hibernate.initialize(goods.getHouse().getBuilding());
        Hibernate.initialize(goods.getStyle());
        Hibernate.initialize(goods.getHouseType());
        // *************************效果图--开始
        Hibernate.initialize(goods.getHouse().getPhoto());
        Hibernate.initialize(goods.getHouse().getFloorPlan());
        Hibernate.initialize(goods.getHouse().getBuilding());
        Hibernate.initialize(goods.getHouseType());
        Hibernate.initialize(goods.getStyle());
        // *************************效果图--结束
        System.out.println(goods.getPhoto().getPath());
        return goods;
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        return super.getGoodsDAO().delBatchByID(ids);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> page(Goods goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().page(goodsCriteria);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(Goods goodsCriteria) {
        return super.getGoodsDAO().count(goodsCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public long houseCount(House model) {
        return super.getHouseDAO().count(model);
    }

    @Override
    @Transactional(readOnly = true)
    public List<House> listByHouse(House model) {
        List<House> list = super.getHouseDAO().listByHouse(model);
        for (House house : list) {
            Hibernate.initialize(house.getType());
            Hibernate.initialize(house.getBuilding());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public long countByCityAndName(Goods goods, Long cityId) {
        return this.getGoodsDAO().countByCityAndName(goods, cityId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageByCityAndName(Goods goods, Long cityId) {
        List<Goods> items = this.getGoodsDAO().pageByCityAndName(goods, cityId);
        for (Goods item : items) {
            Hibernate.initialize(item.getStyle());
            Hibernate.initialize(item.getHouseType());
        }
        return items;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageForWebSite(GoodsVO goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().pageForWebSite(goodsCriteria);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getFloorPlanImage());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getPhoto());
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countForWebSite(GoodsVO goodsCriteria) {
        return super.getGoodsDAO().countForWebSite(goodsCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> standardDiyList() {
        List<Goods> list = super.getGoodsDAO().standardDiyList();
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> listGoodsByBuilding(long buildingId) {
        List<Goods> list = super.getGoodsDAO().listGoodsByBuilding(buildingId);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional
    public boolean updateStatus(Goods goods) {

        super.getGoodsDAO().update(goods);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageForWebSiteH5(GoodsVO goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().pageForWebSiteH5(goodsCriteria);
        for (Goods goods : list) {
            goods.setAveragePrice(goods.getAveragePrice() / 100);
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getFloorPlanImage());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getPhoto());
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countForWebSiteH5(GoodsVO goodsCriteria) {
        return super.getGoodsDAO().countForWebSiteH5(goodsCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageForWebApp(GoodsVO goodsCriteria, String type) {
        List<Goods> list = super.getGoodsDAO().pageForWebApp(goodsCriteria, type);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getFloorPlanImage());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getPhoto());
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> listGoodsByCollectionItem(List<WebCollectionItem> list) {
        List<Goods> goodsList = super.getGoodsDAO().listGoodsByCollectionItem(list);
        for (Goods goods : goodsList) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getHouse());
            Hibernate.initialize(goods.getHouseType());
        }
        return goodsList;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageNoSelect(Goods goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().pageNoSelect(goodsCriteria);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countNoSelect(Goods goodsCriteria) {
        return super.getGoodsDAO().countNoSelect(goodsCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Goods> pageForSales(GoodsVO goodsCriteria) {
        List<Goods> list = super.getGoodsDAO().pageForSales(goodsCriteria);
        for (Goods goods : list) {
            Hibernate.initialize(goods.getPhoto());
            Hibernate.initialize(goods.getFloorPlanImage());
            Hibernate.initialize(goods.getStyle());
            Hibernate.initialize(goods.getHouse());
            if (null != goods.getHouse()) {
                Hibernate.initialize(goods.getHouse().getPhoto());
                Hibernate.initialize(goods.getHouse().getBuilding());
            }
            Hibernate.initialize(goods.getHouseType());
        }
        return list;
    }
}
