package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Service;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesStoreLocationDAO;
import com.gjw.entity.store.GesStoreLocation;
import com.gjw.utils.StringUtil;

/**
 * 库位管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 上午9:27:50
 * 
 */
@Service("gesStoreLocationDAOHibernateImpl")
public class GesStoreLocationDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesStoreLocationDAO {

    @Override
    protected Class getEntityClass() {
        return GesStoreLocation.class;
    }

    /**
     * 库位总数
     */
    @Override
    public Long count(GesStoreLocation model) {
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();

        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        hql.append(" from GesStoreLocation where invalid=0 ");
        if (StringUtil.notEmpty(model.getName())) {
            hql.append("  and name=?");
            ls.add(model.getName());
        }
        if (StringUtil.notEmpty(model.getCode())) {
            ls.add(model.getCode());
            hql.append("  and code=?");
        }

        Query queryCount = session.createQuery("select count(*) " + hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            queryCount.setString(i, ls.get(i) + "");
        }

        // Long count = (Long) queryCount.uniqueResult();
        // map.put("count", count);
        Query query = session.createQuery(hql.toString());

        for (int i = 0; i < ls.size(); i++) {
            query.setString(i, ls.get(i) + "");
        }
        query.setFirstResult(model.getStart());
        query.setMaxResults(model.getPageSize());

        return 1l;
    }

    /**
     * 库位列表
     */
    @Override
    public List<?> pageByStoreLocation(GesStoreLocation model) {

        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        hql.append(" from GesStoreLocation where invalid=0 ");
        if (StringUtil.notEmpty(model.getName())) {
            hql.append("  and name=?");
            ls.add(model.getName());
        }
        if (StringUtil.notEmpty(model.getCode())) {
            ls.add(model.getCode());
            hql.append("  and code=?");
        }
        if (model.getStore() != null && model.getStore().getId() != null) {
            ls.add(model.getStore().getId());
            hql.append("  and store.id=?");
        }
        return super.findByPageCallBack(hql.toString(), null, ls, model, null);
    }

    /**
     * 根据ID查询库位信息
     */
    @Override
    public GesStoreLocation getById(Long id) {
        return (GesStoreLocation) super.get(id);
    }
}
