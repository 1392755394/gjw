package com.gjw.company.dao.building;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.building.GesBuildingPhotoItem;

public interface IGesBuildingPhotoItemDAO extends IDAO{
    
    public GesBuildingPhotoItem listByID(Long id);

    public boolean updateGesBuildingPhotoItem(GesBuildingPhotoItem model);

    public boolean createGesBuildingPhotoItem(GesBuildingPhotoItem model);
    
    public long count(GesBuildingPhotoItem model);
    
    public List<GesBuildingPhotoItem> listByGesBuildingPhotoItem(GesBuildingPhotoItem model);
}
