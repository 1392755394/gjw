package com.gjw.company.dao.customer;

import java.util.List;
import java.util.Map;
import java.util.Set;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.customer.GesCustomerQuestion;
import com.gjw.entity.customer.GesCustomerReserve;
import com.gjw.entity.user.Platform;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserPlatformItem;
import com.gjw.vo.customer.GesCustomerReserveVO;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.customer.UserVO;

public interface IGesCustomerDAO extends IDAO {

    public List<User> ListUser(long id);
   
    public Set<UserPlatformItem> SetPlatForm(Platform platForm);

    public Map<Object, Object> pageGesCustomer(GesCustomerVO gesCustomerVO);
    
    public List<GesCustomer> getGesCustomerByGesCustomer(GesCustomer gesCustomer);
    
    public long updateGesCustomerByGesCustomer(GesCustomer gesCustomer);
    
    public GesCustomer getGesCustomerById(long id);
    
    public long saveGesCustomer(GesCustomer gesCustomer);
    
    public GesCustomer customerValidate(GesCustomer gesCustomer);
    
    public GesCustomer customerByPhone(GesCustomer gesCustomer);
  
    public long updateGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
    public long saveGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
    public GesCustomerQuestion getGesCustomerQuestionById(long id);

    public Map<Object, Object> pageGesCustomerReserve(GesCustomerReserveVO gesCustomerReserveVO);
     
    public GesCustomerReserve getGesCustomerReserveById(long id);

    public long saveGesCustomerReserve(GesCustomerReserve gesCustomerReserve);
    
    public long updateGesCustomerReserve(GesCustomerReserve gesCustomerReserve) ;
    
    public List<GesCustomerReserve> pageByGesCustomerReserve(GesCustomerReserve model);
    
    /**
     *批量删除
     */
    public boolean delBatchByID(String ids, Class<?> clazz);

    public Map<Object, Object> pageUserByUser(UserVO user);
    
    /**
    * @Description 获取客户最新预约信息  
    * @return
    * @author xiaoyang   
    * @date 2016年3月4日 下午1:08:34
     */
    public GesCustomerReserve getCustomerReserveLatest(GesCustomer customer);
    
    /**
     * @Description 客户问题分页  
     * @param gesCustomerQuestion
     * @return
     * @author yanghaiyang   
     * @date 2016年3月12日 下午3:55:20
      */
     public Map<Object, Object> pageGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
}
