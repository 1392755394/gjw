package com.gjw.company.dao.impl.customer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.customer.IGesCustomerMessageLogDAO;
import com.gjw.entity.customer.GesCustomerMessageLog;
import com.gjw.utils.StringUtil;
@Component("gesCustomerMessageLogDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCustomerMessageLogDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCustomerMessageLogDAO{
    @Override
    protected Class<?> getEntityClass() {
        return GesCustomerMessageLog.class;
    }

    @Override
    public GesCustomerMessageLog listByID(Long id) {
        
        return (GesCustomerMessageLog) super.get(id);
    }

    @Override
    public boolean updateGesCustomerMessageLog(GesCustomerMessageLog model) {
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCustomerMessageLog(GesCustomerMessageLog model) {
        return super.saveResultBoolean(model);
    }

    @Override
    public List<GesCustomerMessageLog> listByGesCustomerMessageLog(
            GesCustomerMessageLog model) {
        String hql=" from GesCustomerMessageLog item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getEvent() && null!=model.getEvent().getId()){
            hql=hql+" and item.event.id=?";
            params.add(model.getEvent().getId());
        }
        if(null!=model.getCustomer()){
            if(null!=model.getCustomer().getId()){
                hql=hql+" and item.customer.id=?";
                params.add(model.getCustomer().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getName())){
                hql=hql+" and item.customer.name like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getName()));
            }
            if(null!=model.getCustomer().getAccount() && null!=model.getCustomer().getAccount().getId()){
                hql=hql+" and item.customer.account.id=?";
                params.add(model.getCustomer().getAccount().getId());
            }
            if(null!=model.getCustomer().getDictionaryAccount() && null!=model.getCustomer().getDictionaryAccount().getId()){
                hql=hql+" and item.customer.dictionaryAccount.id=?";
                params.add(model.getCustomer().getDictionaryAccount().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getGender())){
                hql=hql+" and item.customer.gender=?";
                params.add(model.getCustomer().getGender());
            }
            if(StringUtil.notEmpty(model.getCustomer().getPhone())){
                hql=hql+" and item.customer.phone like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getPhone()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getEmail())){
                hql=hql+" and item.customer.email like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getEmail()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getBuildingName())){
                hql=hql+" and item.customer.buildingName=?";
                params.add(super.getFuzzyCondition(model.getCustomer().getBuildingName()));
            }
            if(null!=model.getCustomer().getProvince() && null!=model.getCustomer().getProvince().getId()){
                hql=hql+" and item.customer.province.id=?";
                params.add(model.getCustomer().getProvince().getId());
            }
            if(null!=model.getCustomer().getCity() && null!=model.getCustomer().getCity().getId()){
                hql=hql+" and item.customer.city.id=?";
                params.add(model.getCustomer().getCity().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getAddress())){
                hql=hql+" and item.customer.address like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getAddress()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getCompany())){
                hql=hql+" and item.customer.company like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getCompany()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getIdNo())){
                hql=hql+" and item.customer.idNo like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getIdNo()));
            }
            if(null!=model.getCustomer().getShop() && null!=model.getCustomer().getShop().getId()){
                hql=hql+" and item.customer.shop.id=?";
                params.add(model.getCustomer().getShop().getId());
            }
            if(null!=model.getCustomer().getOperator() && null!=model.getCustomer().getOperator().getId()){
                hql=hql+" and item.customer.operator=?";
                params.add(model.getCustomer().getOperator().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getRemark())){
                hql=hql+" and item.customer.remark like ?";
                params.add(model.getCustomer().getRemark());
            }
        }
        if(null!=model.getMessage()){
            if(null!=model.getMessage().getId()){
                hql=hql+" and item.message.id=?";
                params.add(model.getMessage().getId());
            }
            if(null!=model.getMessage().getStatus()){
                hql=hql+" and item.status=?";
                params.add(model.getMessage().getStatus());
            }
            if(null!=model.getMessage().getDictionary() && null!=model.getMessage().getDictionary().getId()){
                hql=hql+" and item.message.dictionary.id=?";
                params.add(model.getMessage().getDictionary().getId());
            }
            if(null!=model.getMessage().getDictionary().getParent() && null!=model.getMessage().getDictionary().getParent().getId()){
                hql=hql+" and item.message.dictionary.parent.id=?";
                params.add(model.getMessage().getDictionary().getParent().getId());
            }
            if(StringUtil.notEmpty(model.getMessage().getContent())){
                hql=hql+" and item.message.content like ?";
                params.add(super.getFuzzyCondition(model.getMessage().getContent()));
            }
            if(StringUtil.notEmpty(model.getMessage().getRemark())){
                hql=hql+" and item.message.remark like ?";
                params.add(super.getFuzzyCondition(model.getMessage().getRemark()));
            }
        }
        if(null!=model.getUser() && StringUtil.notEmpty(model.getUser().getUsername())){
            hql=hql+" and item.user.username like ?";
            params.add(super.getFuzzyCondition(model.getUser().getUsername()));
        }
        if(StringUtil.notEmpty(model.getGmtCreateFrom())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtCreateFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateTo())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtCreateTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCustomerMessageLog>) super.findByPageCallBack(hql,"",params,model,null);
    }

    @Override
    public long count(GesCustomerMessageLog model) {
        String hql=" from GesCustomerMessageLog item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getEvent() && null!=model.getEvent().getId()){
            hql=hql+" and item.event.id=?";
            params.add(model.getEvent().getId());
        }
        if(null!=model.getCustomer()){
            if(null!=model.getCustomer().getId()){
                hql=hql+" and item.customer.id=?";
                params.add(model.getCustomer().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getName())){
                hql=hql+" and item.customer.name like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getName()));
            }
            if(null!=model.getCustomer().getAccount() && null!=model.getCustomer().getAccount().getId()){
                hql=hql+" and item.customer.account.id=?";
                params.add(model.getCustomer().getAccount().getId());
            }
            if(null!=model.getCustomer().getDictionaryAccount() && null!=model.getCustomer().getDictionaryAccount().getId()){
                hql=hql+" and item.customer.dictionaryAccount.id=?";
                params.add(model.getCustomer().getDictionaryAccount().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getGender())){
                hql=hql+" and item.customer.gender=?";
                params.add(model.getCustomer().getGender());
            }
            if(StringUtil.notEmpty(model.getCustomer().getPhone())){
                hql=hql+" and item.customer.phone like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getPhone()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getEmail())){
                hql=hql+" and item.customer.email like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getEmail()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getBuildingName())){
                hql=hql+" and item.customer.buildingName=?";
                params.add(super.getFuzzyCondition(model.getCustomer().getBuildingName()));
            }
            if(null!=model.getCustomer().getProvince() && null!=model.getCustomer().getProvince().getId()){
                hql=hql+" and item.customer.province.id=?";
                params.add(model.getCustomer().getProvince().getId());
            }
            if(null!=model.getCustomer().getCity() && null!=model.getCustomer().getCity().getId()){
                hql=hql+" and item.customer.city.id=?";
                params.add(model.getCustomer().getCity().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getAddress())){
                hql=hql+" and item.customer.address like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getAddress()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getCompany())){
                hql=hql+" and item.customer.company like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getCompany()));
            }
            if(StringUtil.notEmpty(model.getCustomer().getIdNo())){
                hql=hql+" and item.customer.idNo like ?";
                params.add(super.getFuzzyCondition(model.getCustomer().getIdNo()));
            }
            if(null!=model.getCustomer().getShop() && null!=model.getCustomer().getShop().getId()){
                hql=hql+" and item.customer.shop.id=?";
                params.add(model.getCustomer().getShop().getId());
            }
            if(null!=model.getCustomer().getOperator() && null!=model.getCustomer().getOperator().getId()){
                hql=hql+" and item.customer.operator=?";
                params.add(model.getCustomer().getOperator().getId());
            }
            if(StringUtil.notEmpty(model.getCustomer().getRemark())){
                hql=hql+" and item.customer.remark like ?";
                params.add(model.getCustomer().getRemark());
            }
        }
        if(null!=model.getMessage()){
            if(null!=model.getMessage().getId()){
                hql=hql+" and item.message.id=?";
                params.add(model.getMessage().getId());
            }
            if(null!=model.getMessage().getStatus()){
                hql=hql+" and item.status=?";
                params.add(model.getMessage().getStatus());
            }
            if(null!=model.getMessage().getDictionary() && null!=model.getMessage().getDictionary().getId()){
                hql=hql+" and item.message.dictionary.id=?";
                params.add(model.getMessage().getDictionary().getId());
            }
            if(null!=model.getMessage().getDictionary().getParent() && null!=model.getMessage().getDictionary().getParent().getId()){
                hql=hql+" and item.message.dictionary.parent.id=?";
                params.add(model.getMessage().getDictionary().getParent().getId());
            }
            if(StringUtil.notEmpty(model.getMessage().getContent())){
                hql=hql+" and item.message.content like ?";
                params.add(super.getFuzzyCondition(model.getMessage().getContent()));
            }
            if(StringUtil.notEmpty(model.getMessage().getRemark())){
                hql=hql+" and item.message.remark like ?";
                params.add(super.getFuzzyCondition(model.getMessage().getRemark()));
            }
        }
        if(null!=model.getUser() && StringUtil.notEmpty(model.getUser().getUsername())){
            hql=hql+" and item.user.username like ?";
            params.add(super.getFuzzyCondition(model.getUser().getUsername()));
        }
        if(StringUtil.notEmpty(model.getGmtCreateFrom())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtCreateFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtCreateTo())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtCreateTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }
}
