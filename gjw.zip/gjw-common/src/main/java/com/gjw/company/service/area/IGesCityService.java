package com.gjw.company.service.area;

import com.gjw.entity.area.GesArea;
import com.gjw.entity.area.GesCity;
import com.gjw.vo.GesAreaVO;

public interface IGesCityService {

    /**
    * @Description 根据城市Id获取城市详情  
    * @param cityId
    * @return
    * @author haiyang   
    * @date 2015年12月17日 下午3:55:36
     */
    public GesCity getCityByCityId(long cityId);
    
    /**
    * @Description 添加城市信息  
    * @param gesCity
    * @return
    * @author xiaoyang   
    * @date 2015年12月18日 下午2:37:02
     */
    public long addCityDetail(GesCity gesCity);
    
    /**
    * @Description 开通城市  
    * @param area
    * @return
    * @author xiaoyang   
    * @date 2015年12月21日 下午1:25:16
     */
    public long addDredgeCity(GesAreaVO areaVO);
    
    /**
    * @Description  移除已开通的城市
    * @param areaVO
    * @return
    * @author xiaoyang   
    * @date 2015年12月21日 下午3:13:44
     */
    public long deleteDredgeCity(GesAreaVO areaVO);
    
    /**
    * @Description 根据主键查询区域对象  
    * @param id
    * @return
    * @author xiaoyang   
    * @date 2015年12月21日 下午4:15:17
     */
    public GesArea getGesAreaById(long id);

    /**
     * @Description 修改城市信息  
     * @param gesCity
     * @return
     * @author xiaoyang   
     * @date 2015年12月18日 下午2:37:02
      */
     public long updateCityDetail(GesCity gesCity);
     
     public GesCity getGesCityById(long id);
}
