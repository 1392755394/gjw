package com.gjw.company.dao.user;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Role;

import java.util.List;

/**
 * Created by Epee on 2016-03-03 13:42.
 */
public interface IRoleDAO extends IDAO {

    List<String> loadAllRoleNames(Long userId);
    
    List<Role> listChildRoles(long parentID);
    
    List<Role> listRoles();
    
    Role getRoleById(long id);
  
    boolean update(Role role);
    
    boolean delete(Role role);
    
    long create(Role role);
}
