package com.gjw.company.dao.menu;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.menu.GesMenuRoleItem;

/**
 * 角色菜单
* @Description: 
* @author  dabai
* @date 2016年3月8日 下午3:14:05
*
 */
public interface IGesMenuRoleItemDAO extends IDAO {
    
    boolean update(GesMenuRoleItem menuRoleItem);
    
    boolean delete(GesMenuRoleItem menuRoleItem);
    
    long create(GesMenuRoleItem menuRoleItem);
    
    GesMenuRoleItem getItemByMenuIdAndRoleID(GesMenuRoleItem menuRoleItem);

}
