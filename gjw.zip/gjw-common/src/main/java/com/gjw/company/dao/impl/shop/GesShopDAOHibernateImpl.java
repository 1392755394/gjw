package com.gjw.company.dao.impl.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.impl.order.CustomBeanTransform;
import com.gjw.company.dao.shop.IGesShopDAO;
import com.gjw.entity.shop.GesShop;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesShopVO;
import com.gjw.vo.order.GesOrderVO;

@Component("gesShopDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesShopDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesShopDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesShop.class;
    }

    @Override
    public GesShop listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesShop) super.get(id);
    }

    @Override
    public boolean updateGesShop(GesShop model) {
        // TODO Auto-generated method stub
        return super.update(model) == 1;
    }

    @Override
    public boolean createGesShop(GesShop model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesShop model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesShop item where 1=1");
        List<Object> params = new ArrayList<Object>();
        assembleShopQueryCriteria(model, hql, params);
        return super.findByPageCallBackCount(hql.toString(), params);
    }

    @Override
    public List<GesShop> listByGesShop(GesShop model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesShop item where 1=1");
        List<Object> params = new ArrayList<Object>();
        assembleShopQueryCriteria(model, hql, params);
        return (List<GesShop>) super.findByPageCallBack(hql.toString(), "", params, model, null);
    }
    
    @Override
    public List<GesShopVO> listByGesShop4Export(GesShop model) {
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        StringBuffer hql = new StringBuffer();
        hql.append("select item.name as name, d.text as shopTypeStr, o.companyName as operatorName, b.username as bdManagerName, item.contactName as contactName, item.phone as phone, item.address as address, province.name as provinceName, ");
        hql.append(" city.name as cityName,  country.name as countyName, item.foundDate as foundDate ");
        hql.append(" from GesShop item left join  item.dictionary d left join  item.operator o left join  item.bdManager b left join  item.province province left join  item.city city left join  item.county country ");
        hql.append(" where 1=1  ");
        List<Object> param = new ArrayList<Object>();
        assembleShopQueryCriteria(model, hql, param);
        List<GesShopVO> list = (List<GesShopVO>) super.findByListCallBack(hql.toString(), null, param,
                new CustomBeanTransform(GesShopVO.class, false));
        return list;
    }
    
    protected void assembleShopQueryCriteria(GesShop model, StringBuffer hql, List<Object> params) {
        if (null != model.getInvalid()) {
            hql.append(" and item.invalid=?");
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql.append(" and item.status=?");
            params.add(model.getStatus());
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql.append(" and item.name like ?");
            params.add(super.getFuzzyCondition(model.getName()));
        }
        if (null != model.getId()) {
            hql.append(" and item.id=?");
            params.add(model.getId());
        }
        if (null != model.getOperator() && null != model.getOperator().getId()
                && !"".equals(model.getOperator().getId())) {
            hql.append(" and item.operator.id=?");
            params.add(model.getOperator().getId());
        }
        if (null != model.getOperator() && StringUtil.notEmpty(model.getOperator().getCompanyName())) {
            hql.append(" and item.operator.companyName like ?");
            params.add(super.getFuzzyCondition(model.getOperator().getCompanyName()));
        }
        if (StringUtil.notEmpty(model.getName())) {
            hql.append(" and item.name like ?");
            params.add(super.getFuzzyCondition(model.getName()));
        }
        if (null != model.getDictionary() && null != model.getDictionary().getId()) {
            hql.append(" and item.dictionary.id=?");
            params.add(model.getDictionary().getId());
        }
        if (StringUtil.notEmpty(model.getSummary())) {
            hql.append(" and item.summary like ?");
            params.add(super.getFuzzyCondition(model.getSummary()));
        }
        if (StringUtil.notEmpty(model.getContactName())) {
            hql.append(" and item.contactName like ?");
            params.add(super.getFuzzyCondition(model.getContactName()));
        }
        if (StringUtil.notEmpty(model.getPhone())) {
            hql.append(" and item.phone like ?");
            params.add(super.getFuzzyCondition(model.getPhone()));
        }
        if (StringUtil.notEmpty(model.getAddress())) {
            hql.append(" and item.address like ?");
            params.add(super.getFuzzyCondition(model.getAddress()));
        }
        if (null != model.getProvince() && null != model.getProvince().getId()) {
            hql.append(" and item.province.id=?");
            params.add(model.getProvince().getId());
        }
        if (null != model.getCity() && null != model.getCity().getId()) {
            hql.append(" and item.city.id=?");
            params.add(model.getCity().getId());
        }
        if (null != model.getCounty() && null != model.getCounty().getId()) {
            hql.append(" and item.county.id=?");
            params.add(model.getCounty().getId());
        }
        if (StringUtil.notEmpty(model.getAccountName())) {
            hql.append(" and item.accountName like ?");
            params.add(super.getFuzzyCondition(model.getAccountName()));
        }
        if (StringUtil.notEmpty(model.getAccountBranchName())) {
            hql.append(" and item.accountBranchName like ?");
            params.add(super.getFuzzyCondition(model.getAccountBranchName()));
        }
        if (StringUtil.notEmpty(model.getAccountUserName())) {
            hql.append(" and item.accountUserName like ?");
            params.add(super.getFuzzyCondition(model.getAccountUserName()));
        }
        if (StringUtil.notEmpty(model.getAccountNo())) {
            hql.append(" and item.accountNo like ?");
            params.add(super.getFuzzyCondition(model.getAccountNo()));
        }
        if (StringUtil.notEmpty(model.getPosSN())) {
            hql.append(" and item.posSN like ?");
            params.add(super.getFuzzyCondition(model.getPosSN()));
        }
        if(null!=model.getBdManager() && StringUtil.notEmpty(model.getBdManager().getUsername())){
            hql.append(" and (select info.realName from UserInfoGES info where item.bdManager.id=info.user.id) like ?");
            params.add(super.getFuzzyCondition(model.getBdManager().getUsername()));
        }
        hql.append(" order by item.createdDatetime desc");
    }

    @Override
    public GesShop getShopCityIdByUserId(Long id) {

        StringBuffer hql = new StringBuffer();
        hql.append(" from GesShop item where invalid=0");
        hql.append(" and orgId =?");
        List<Object> list = new ArrayList<Object>();
        list.add(id);
        return (GesShop) super.queryByParam(hql.toString(), list);
    }

   
}
