package com.gjw.company.service.impl.oa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.TaskConstant;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesAttachmentDAO;
import com.gjw.company.dao.oa.IGesCommunicationDAO;
import com.gjw.company.dao.oa.IGesTaskParticipantDAO;
import com.gjw.company.service.oa.IGesCommunicationService;
import com.gjw.entity.oa.GesCommunication;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.entity.user.User;
import com.gjw.event.base.BaseEventPublisher;
import com.gjw.event.oa.GesCommunicationEvent;
import com.gjw.utils.StringUtil;
import com.gjw.vo.oa.GesAttachmentVO;
import com.gjw.vo.oa.GesCommunicationVO;
import com.gjw.vo.oa.GesTaskParticipantVO;

@Component("gesCommunicationServiceImpl")
public class GesCommunicationServiceImpl extends AbstractServiceImpl implements IGesCommunicationService {
	
	private static final Logger log=LoggerFactory.getLogger(GesCommunicationServiceImpl.class);
	
	@Resource(name="gesCommunicationHibernateImpl")
	private IGesCommunicationDAO gesCommunicationDAO;
	
	@Resource(name="gesAttachmentHibernateImpl")
	private IGesAttachmentDAO gesAttachmentDAO;
	
	@Resource(name="gesTaskParticipantHibernateImpl")
	private IGesTaskParticipantDAO gesTaskParticipantDAO;

    @Resource(name="baseEventPublisher")
    private BaseEventPublisher baseEventPublisher;

	public IGesCommunicationDAO getGesCommunicationDAO() {
		return gesCommunicationDAO;
	}

	public void setGesCommunicationDAO(IGesCommunicationDAO gesCommunicationDAO) {
		this.gesCommunicationDAO = gesCommunicationDAO;
	}

	public IGesAttachmentDAO getGesAttachmentDAO() {
		return gesAttachmentDAO;
	}

	public void setGesAttachmentDAO(IGesAttachmentDAO gesAttachmentDAO) {
		this.gesAttachmentDAO = gesAttachmentDAO;
	}
	
	public IGesTaskParticipantDAO getGesTaskParticipantDAO() {
		return gesTaskParticipantDAO;
	}

	public void setGesTaskParticipantDAO(
			IGesTaskParticipantDAO gesTaskParticipantDAO) {
		this.gesTaskParticipantDAO = gesTaskParticipantDAO;
	}

	/**
	 * 获取任务的交流列表
	 * @param gesCommunication
	 * @return
	 */
	@Override
	@Transactional
	public Map<String, Object> listCommunication(GesCommunicationVO gesCommunication,User user, String mobileLogin) {
		//新建map
		Map<String, Object> map=new HashMap<String, Object>();
		Long total=getGesCommunicationDAO().countCommunicationByTaskId(gesCommunication);
		gesCommunication.setStart(gesCommunication.getNumber()/gesCommunication.getPageSize()+1);
		log.info("前台传入的number值为："+gesCommunication.getNumber());
		//  获取列表
		List<GesCommunicationVO> list=getGesCommunicationDAO().queryCommunicationByTaskId(gesCommunication);
		
		// 取得各交流的附件列表
		List<GesAttachmentVO> attachmentList;
		GesAttachmentVO attachment = new GesAttachmentVO();
		// 附件所属节点的类型:交流记录
		attachment.setRelationType(TaskConstant.RELATION_TYPE_COMMUNICATION);

		for (int i = 0; i < list.size(); i++) {
			// 附件所属节点:交流ID
			attachment.setRelationId(list.get(i).getId());
			attachmentList = getGesAttachmentDAO().listAttachmentByRelationId(attachment);
			// 设置各交流的附件列表
			list.get(i).setAttachments(attachmentList);
		}
		log.info("以下更新交流的id,交流的列表大小为："+list.size()+",开始的交流数为："+gesCommunication.getStart());
		// 交流列表第1页的时候更新参与人表的已读交流ID
		if (gesCommunication.getStart().intValue() == 0) {
			GesTaskParticipant taskParticipant = new GesTaskParticipant();
			// 设置任务id、参与成员的id做为更新条件
			GesProjectTask tempTask=new GesProjectTask();
			tempTask.setId(gesCommunication.getTaskId());
			taskParticipant.setTask(tempTask);
			taskParticipant.setParticipant(user);
			taskParticipant.setUser(user);
			// 设置已读交流ID为交流列表最大ID
			if (list.size() > 0) {
				GesCommunication tempCommunication=new GesCommunication();
				tempCommunication.setId(list.get(0).getId());
				taskParticipant.setCommunication(tempCommunication);
			}else{
				GesCommunication tempCommunication=new GesCommunication();
				taskParticipant.setCommunication(tempCommunication);
			}
			getGesTaskParticipantDAO().updateParticipantCommunicationId(taskParticipant);
			log.info("更新交流的id成功！");
		}
		
		List<GesTaskParticipantVO> peoplelist=getGesTaskParticipantDAO().getMemberByIdAndUserid(gesCommunication.getTaskId(),user.getId());
		//判断用户是不是该项目成员
		for(int i = 0;i<list.size();i++){
			if(peoplelist!=null&&peoplelist.size()>0&&peoplelist.get(0).getIsCreator()){
				list.get(i).setIfDelete("true");
			}else if(peoplelist!=null&&peoplelist.size()>0&&peoplelist.get(0).getType()==1){
				//判断这条是否是发起人发言
				List<GesTaskParticipantVO> memberlist=getGesTaskParticipantDAO().getMemberByIdAndUserid(gesCommunication.getTaskId(),list.get(i).getUserId());
				if(memberlist.get(0).getIsCreator()){
					list.get(i).setIfDelete("false");
				}else{
					list.get(i).setIfDelete("true");
				}
			}else{
				if(list.get(i).getUserId().equals(user.getId())){
					list.get(i).setIfDelete("true");
				}else{
					list.get(i).setIfDelete("false");
				}
			}
		}
		//加入交流总数
		map.put("total", total);
		map.put("rows", list);
        
        //如果是移动端的请求，只返回必要的数据
        if ("1".equals(mobileLogin)) {
            List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
            for (GesCommunicationVO communicationVO : list) {
                Map<String,Object> dto = new HashMap<String, Object>();
                dto.put("id", communicationVO.getId());
                dto.put("commitUser", communicationVO.getCommitUser());
                dto.put("content", communicationVO.getContent());
                dto.put("gmtCreate", communicationVO.getGmtCreate());
                dto.put("headPortrait", communicationVO.getHeadPortrait());
                dto.put("ifDelete", communicationVO.getIfDelete());
                List<Map<String,Object>> attachments = new ArrayList<Map<String,Object>>();
                for (GesAttachmentVO attachmentVO :communicationVO.getAttachments()) {
                    Map<String,Object> attachmentTemp = new HashMap<String, Object>();
                    attachmentTemp.put("fileName", attachmentVO.getFileName());
                    attachmentTemp.put("filePath", attachmentVO.getFilePath());
                    attachments.add(attachmentTemp);
                }
                dto.put("attachments", attachments);
                result.add(dto);
            }
            map.put("rows", result);
        }
		return map;
	}

	/**
	 * 发布交流
	 * @param communication
	 * @return
	 */
	@Override
	@Transactional
	public GesCommunicationVO creatCommunication(GesCommunicationVO communication) {
		GesCommunication gesCommunication=new GesCommunication();
		gesCommunication.setParent(null);
		gesCommunication.setRoot(null);
		gesCommunication.setUser(communication.getUser());
		gesCommunication.setContent(communication.getContent());
		GesProjectTask projectTask=new GesProjectTask();
		projectTask.setId(communication.getTaskId());
		gesCommunication.setTask(projectTask);
		
        // 父交流记录的id
		Long parentId = communication.getParentId();
		if (parentId != null && parentId != 0) {
	        GesCommunication tempCommunication = getGesCommunicationDAO().queryById(parentId);
            gesCommunication.setParent(tempCommunication);
            gesCommunication.setContent("回复"
                    + tempCommunication.getUser().getUserInfo(PlatformEnum.Ges).getRealName() + ":"
                    + communication.getContent());
            communication.setContent(gesCommunication.getContent());
		}

        getGesCommunicationDAO().add(gesCommunication);
		communication.setId(gesCommunication.getId());
		communication.setGmtCreate(gesCommunication.getCreatedDatetime());
		//更新任务表的交流id
		getGesCommunicationDAO().updateTaskCommunicationIdById(gesCommunication);
		
		// 以下更新附件所属节点的id
		if (!StringUtil.isBlank(communication.getAttachmentIds())) {
			String[] ids=communication.getAttachmentIds().split(",");
			List<Long> idList=new ArrayList<Long>();
			for(String id:ids){
				idList.add(Long.parseLong(id));
			}
			Map<String, Object> attachment = new HashMap<String, Object>();
			// 附件所属节点的id设置为交流ID
			attachment.put("relationId", gesCommunication.getId());
			// 附件所属节点的类型:交流记录
			attachment.put("relationType",TaskConstant.RELATION_TYPE_COMMUNICATION);
			// 附件ID列表，用于批量更新附件所属节点的id
			attachment.put("attachmentIds", idList);
			// 批量更新附件所属节点的id
			getGesAttachmentDAO().updateAttachmentRelation(attachment);		
		}
		
		// 以下更新参与人表
		// 发布交流时勾选已办
		GesTaskParticipant taskParticipant = new GesTaskParticipant();
		// 设置任务id、参与成员的id做为更新条件
		taskParticipant.setTask(projectTask);
		taskParticipant.setParticipant(communication.getUser());
		if (communication.getIsHandle()!=null&&communication.getIsHandle()==1) {
			// 设置是否已办
			taskParticipant.setIsHandle(1);
		}else{
			taskParticipant.setIsHandle(0);
		}
		//设置交流id
		taskParticipant.setCommunication(gesCommunication);
		// 更新参与人表
		getGesTaskParticipantDAO().updateGesTaskParticipantByIsHandle(taskParticipant);
		
		//获取交流关联的附件列表
		//发布后直接显示交流内容及附件
		GesAttachmentVO attachment = new GesAttachmentVO();
		//附件所属节点的类型:交流记录
		attachment.setRelationType(TaskConstant.RELATION_TYPE_COMMUNICATION);
		//附件所属节点:交流ID
		attachment.setRelationId(communication.getId());
		//取得各交流的附件列表
		List<GesAttachmentVO> attachmentListlist = getGesAttachmentDAO().listAttachmentByRelationId(attachment);
		communication.setAttachments(attachmentListlist);
		communication.setIfDelete("true");
		
        // 发布交流事件
		GesCommunicationEvent event = new GesCommunicationEvent(gesCommunication);
        event.setOprateName(communication.getCommitUser());
        baseEventPublisher.publishEvent(event);

        return communication;
	}

	/**
	 * 根据交流的id删除交流信息
	 * @param communicationId
	 */
	@Override
	@Transactional
	public boolean deleteCommunicationById(GesCommunication communication) {
		//删除交流
		getGesCommunicationDAO().deleteCommunicationById(communication);
		//更新项目任务的关联的交流id
		if (communication.getTask() != null) {
	        log.info("任务的id为："+communication.getTask().getId());
	        getGesCommunicationDAO().updateTaskCommunicationIdToMax(communication);
		}
		
		return true;
	}

	@Override
	@Transactional(readOnly=true)
	public List<Long> queryCommunicationIdByTaskId(Long taskId) {
		
		return getGesCommunicationDAO().queryCommunicationIdByTaskId(taskId);
	}
	
	
	
	

}
