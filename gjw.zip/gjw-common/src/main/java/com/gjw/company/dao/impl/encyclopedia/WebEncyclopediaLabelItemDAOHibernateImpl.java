package com.gjw.company.dao.impl.encyclopedia;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.encyclopedia.IWebEncyclopediaLabelItemDAO;
import com.gjw.entity.building.GesBuildingCityOperatorItem;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;

/**
 * dao的Hibernate实现
 */
@Component("webEncyclopediaLabelItemDAOHibernateImpl")
public class WebEncyclopediaLabelItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements
        IWebEncyclopediaLabelItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebEncyclopediaLabelItemDAOHibernateImpl.class;
    }

    @SuppressWarnings({ "unchecked" })
    @Override
    public List<WebEncyclopediaLabelItem> listByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebEncyclopediaLabelItem where invalid = 0");
        if (null != item.getInfo() && 0 != item.getInfo()) {
            hql.append(" and info = ?");
            ls.add(item.getInfo());
        }
        if (null != item.getPropertyType() && 0 != item.getPropertyType().getId()) {
            hql.append(" and propertyType = ?");
            ls.add(item.getPropertyType());
        }
        if(null!=item.getLabel() && null!=item.getLabel().getId()){
            hql.append(" and label.id=?");
            ls.add(item.getLabel().getId());
        }
        hql.append(" order by createdDatetime desc,info desc");
        return (List<WebEncyclopediaLabelItem>) super.findByPageCallBack(hql.toString(),"",ls,item,null);
    }

    @Override
    public boolean invalidByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        hql.append(" update  WebEncyclopediaLabelItem set invalid = 1  where id != 0");
        if (null != item.getInfo() && 0 != item.getInfo()) {
            hql.append(" and info = ?");
            ls.add(item.getInfo());
        }
        if (null != item.getPropertyType() && 0 != item.getPropertyType().getId()) {
            hql.append(" and propertyType = ?");
            ls.add(item.getPropertyType());
        }
        Query query = session.createQuery(hql.toString());
        if (null != ls && ls.size() > 0) {
            for (int i = 0; i < ls.size(); i++) {
                query.setParameter(i, ls.get(i));
            }
        }
        query.executeUpdate();
        return true;
    }

    /**
     * @author qingye
     */
    @Override
    public void deleteByPropertyAndInfo(Dictionary property, Long id) {
        String hql="delete from WebEncyclopediaLabelItem where info=? and propertyType.id=?";
        this.getHibernateTemplate().bulkUpdate(hql, id,property.getId());
    }

    @Override
    public Long countByInfoAndDictionary(WebEncyclopediaLabelItem item) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("select count(*) from WebEncyclopediaLabelItem where invalid = 0");
        if (null != item.getInfo() && 0 != item.getInfo()) {
            hql.append(" and info = ?");
            ls.add(item.getInfo());
        }
        if (null != item.getPropertyType() && 0 != item.getPropertyType().getId()) {
            hql.append(" and propertyType = ?");
            ls.add(item.getPropertyType());
        }
        if(null!=item.getLabel() && null!=item.getLabel().getId()){
            hql.append(" and label.id=?");
            ls.add(item.getLabel().getId());
        }
        hql.append(" order by createdDatetime desc,info desc");
        Query query = session.createQuery(hql.toString());
        if (null != ls && ls.size() > 0) {
            for (int i = 0; i < ls.size(); i++) {
                query.setParameter(i, ls.get(i));
            }
        }
        return (Long) query.uniqueResult();
    }

}
