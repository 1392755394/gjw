package com.gjw.company.service.customer;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.customer.GesAppointment;

public interface IGesAppointmentService extends IService{
    
    /**
     * 
    * @Description  预约详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:31:51
     */
    public GesAppointment getById(Long id);
    
    /**
     * 
    * @Description  更改预约信息
    * @param record
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:31:59
     */
    public boolean updateAppointment(GesAppointment record);
    
    /**
     * 
    * @Description  提交预约
    * @param record
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:32:11
     */
    public boolean createAppointment(GesAppointment record);
    
    /**
     * 
    * @Description  查看楼盘预约列表
    * @param buildingId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月7日 下午3:32:19
     */
    public List<GesAppointment> listByBuildingId(Long buildingId);
    
}
