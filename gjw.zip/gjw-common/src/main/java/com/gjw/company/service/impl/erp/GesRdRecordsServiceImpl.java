package com.gjw.company.service.impl.erp;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesRdRecordsService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.entity.erp.GesRdRecords;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.store.GesStoreInventory;
import com.gjw.utils.StringUtil;
import com.gjw.vo.RdRecordsVO;

/**
 * 出入库单明细实体
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月18日 上午10:58:32
 * 
 */
@Service("gesRdRecordsServiceImpl")
public class GesRdRecordsServiceImpl extends AbstractServiceImpl implements IGesRdRecordsService {

    @Override
    @Transactional
    public void create(GesRdRecords rdRecords) {
        super.getGesRdRecordsDAO().create(rdRecords);

    }

    @Override
    @Transactional(readOnly = true)
    public Long countByCode(GesRdRecords rCodes) {
        return super.getGesRdRecordsDAO().countByCode(rCodes);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesRdRecords> pageByRdRecords(RdRecordsVO rdRecords) {
        // GesStore store = new GesStore();
        List<GesStore> listStore = super.getGesStoreDAO().listGesStoreByShopIdOrOperatorId(rdRecords);
        List<GesRdRecords> recordsList = super.getGesRdRecordsDAO().pageByRdRecord(rdRecords);

        for (GesRdRecords records : recordsList) {
            records.getMatter().getCode();
            records.getMatter().getBrand().getName();
            if (records.getSoMatter() != null) {
                records.getSoMatter().getPurchasePrice();
            }
            // records.getPoDetail().getQuantity();
            if (records.getRoom() != null) {
                records.getRoom().getName();
            }
            // rdRecords.setMatter(matter);
            rdRecords.setMatterId(records.getMatter().getId());
            Long inventory = super.getGesStoreInventoryDAO().sumInventory(rdRecords, listStore);
            records.setStockNum(inventory == null ? 0 : inventory.doubleValue());
        }

        return recordsList;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByRdRecords(RdRecordsVO rdRecords) {
        return super.getGesRdRecordsDAO().countByRdRecords(rdRecords);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesRdRecords> pageArrivalByRdRecords(RdRecordsVO rdRecords) {
        RdRecordsVO rds = new RdRecordsVO();
        rds.setPageSize(rdRecords.getPageSize());
        rds.setStart(rdRecords.getStart());
        rds.setStockInCode(rdRecords.getStockInCode());
        rds.setRecordCode(rdRecords.getRecordCode());
        List<GesRdRecords> list = super.getGesRdRecordsDAO().listArrivalByRdRecords(rds);

        List<GesRdRecords> listRds = super.getGesRdRecordsDAO().pageArrivalByRdRecords(rdRecords, list);
        for (GesRdRecords rd : listRds) {
            Hibernate.initialize(rd.getMatter().getName());
            Hibernate.initialize(rd.getMatter().getBrand().getName());
            Hibernate.initialize(rd.getRoom());
            // rd.getSoMatter().getPurchasePrice();
            Hibernate.initialize(rd.getPoDetail());
        }
        return listRds;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countArrivalByRecords(RdRecordsVO rdRecords) {

        List<GesRdRecords> list = super.getGesRdRecordsDAO().listArrivalByRdRecords(rdRecords);
        return super.getGesRdRecordsDAO().countArrivalByRecords(rdRecords, list);
    }

    /**
     * 保存采购入库单
     */
    @Override
    @Transactional
    public Long addStockIn(GesRdRecord rdRecord) {
        // 取得入库明细
        List<GesRdRecords> list = super.getGesRdRecordsDAO().listGesRdRecord(rdRecord);
        // GesPoMain ss=new GesPoMain();
        // GesPoMain gesPoMain =
        // super.getGesPoMainDAO().getByGesPoMain(rdRecord.getGesPoMain());
        // 根据入库明细更新库存
        for (GesRdRecords rds : list) {
            GesStoreInventory condition = new GesStoreInventory();
            condition.setMatter(rds.getMatter());
            condition.setStore(rdRecord.getWhDestination());
            // 暂不考虑库位
            // condition.setStoreLocation(rdRecord.getStorageLocationDestination());
            // 同一物料ID、仓库ID、库位ID的库存存在时更新，否则创建
            GesStoreInventory storeInventory = new GesStoreInventory();
            GesStoreInventory result = null;
            // 查询库存是否存在
            result = super.getGesStoreInventoryDAO().getGesStoreInventoryByMatterIdAndStoreId(condition);
            if (result == null) {
                storeInventory.setMatter(rds.getMatter());
                storeInventory.setStore(rdRecord.getWhDestination());
                // 暂不考虑库位
                // storeInventory.setStoreLocationId(rdRecord.getStorageLocationDestination());
                storeInventory.setInventoryAmount(rds.getQuantity() == null ? 0 : rds.getQuantity().intValue());
                // 创建库存
                super.getGesStoreInventoryDAO().add(storeInventory);
            } else {
                storeInventory.setId(result.getId());
                if (rds.getQuantity() == null) {
                    rds.setQuantity(0d);
                }
                storeInventory.setInventoryAmount(result.getInventoryAmount() + rds.getQuantity().intValue());
                // 修改库存
                super.getGesStoreInventoryDAO().updateInventoryAmountById(storeInventory);
            }
            GesRdRecords rdRecords = new GesRdRecords();
            rdRecords.setRecordCode(rdRecord.getGesPoMain().getSoCode());
            rdRecords.setPoDetail(rds.getPoDetail());
            rdRecords.setQuantity(rds.getQuantity());

            super.getGesRdRecordsDAO().updateStockIn(rdRecords);
        }
        // 生成出库
        // rdRecord.setCreateUser(new User());
        Dictionary type = new Dictionary();
        type.setId(1130602l);
        rdRecord.setType(type);
        rdRecord.setRecordDate(new Timestamp(System.currentTimeMillis()));
        rdRecord.setInvalid(false);
        rdRecord.setStatus(1);
        rdRecord.setSourceCode(rdRecord.getSourceCode());
        // rdRecord.setGesPoMain(gesPoMain);
        if (rdRecord.getReceiverShop() == null || rdRecord.getReceiverShop().getId() == null) {
            rdRecord.setReceiverShop(null);
        } else {
            rdRecord.setReceiverShop(rdRecord.getReceiverShop());
        }
        rdRecord.setReceiverOperator(rdRecord.getReceiverOperator());
        // GesPoMain poMain = new GesPoMain();
        // gesPoMain.setId(rdRecord.getGesPoMain().getId());
        // rdRecord.setGesPoMain(poMain);
        if (rdRecord.getStorageLocationDestination() == null
                || rdRecord.getStorageLocationDestination().getId() == null) {
            rdRecord.setStorageLocationDestination(null);
        }
        if (rdRecord.getStorageLocationSource() == null || rdRecord.getStorageLocationSource().getId() == null) {
            rdRecord.setStorageLocationSource(null);
        }
        if (rdRecord.getGesOrder().getId() == null) {
            rdRecord.setGesOrder(null);
        }
        if (rdRecord.getShop() == null || rdRecord.getShop().getId() == null) {
            rdRecord.setShop(null);
        }
        super.getGesRdRecordDAO().create(rdRecord);
        return rdRecord.getId();
    }

    /**
     * 
     */
    @Override
    @Transactional
    public boolean batchCreate(String prices, String saleOutCode, String smIds, Long goodsId, String roomIds,
            String amounts, String matterIds, String type) {
        String[] matterIdArray = matterIds.split(",");
        String[] amount = amounts.split(",");
        String[] smIdArray = smIds.split(",");// 物料id
        String[] price = prices.split(",");
        String[] roomIdArray = roomIds.split(",");
        String[] matterIdsArray = matterIds.split(",");// poDeatai

        int index = 0;

        for (String matterId : matterIdArray) {

            GesRdRecords rdRecords = new GesRdRecords();
            Matter matter = new Matter();
            GoodsRoom room = new GoodsRoom();
            room.setId(Long.parseLong(roomIdArray[index]));

            matter.setId(Long.parseLong(matterId));
            rdRecords.setMatter(matter);

            rdRecords.setRoom(room);
            if (StringUtil.notEmpty(amounts) && amount.length > 0) {

                rdRecords.setQuantity(Double.valueOf(amount[index]));
            }
            rdRecords.setRecordCode(saleOutCode);
            GesSoMatterItem soMatter = new GesSoMatterItem();
            soMatter.setId(Long.parseLong(smIdArray[index]));
            rdRecords.setSoMatter(soMatter);
            GesPoDetail poDetail = new GesPoDetail();
            poDetail.setId(Long.parseLong(matterIdsArray[index]));
            rdRecords.setPoDetail(poDetail);

            if (StringUtil.notEmpty(prices) && StringUtil.notEmpty(prices.replace(",", ""))) {
                // LOG.info("prices:{}",prices);
                rdRecords.setPrice(Long.valueOf(price[index]));
            }
            rdRecords.setInvalid(false);
            rdRecords.setStockIn(0d);
            super.getGesRdRecordsDAO().create(rdRecords);
            index++;
        }
        return true;
    }

    /**
     * 
     */
    @Override
    @Transactional
    public boolean batchDel(String ids) {
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            // GesRdRecords rdRecords = new GesRdRecords();
            // rdRecords.setId(Long.parseLong(id));
            super.getGesRdRecordsDAO().delete(Long.parseLong(id));
        }
        return true;
    }

    /**
     * 采购到货单---到货
     * <p>
     * 修改删除关联入库数量
     */
    @Override
    @Transactional
    public boolean updateAmountById(Long id, Long amount) {
        return super.getGesRdRecordsDAO().updateAmountById(id, amount);
    }

    /**
     * 采购到货
     */
    @Override
    @Transactional
    public void batchCreateStockIn(String prices, String stockInCode, String matterIds, Long goodsId, String roomIds,
            String amounts, String poDetailIds, String matterType) {

        String[] matterIdArray = matterIds.split(",");// 物料id
        String[] amount = amounts.split(",");
        String[] price = prices.split(",");
        String[] roomIdArray = roomIds.split(",");
        String[] poDetailIdArray = poDetailIds.split(",");// 物料id

        int index = 0;
        for (String matterId : matterIdArray) {
            GesRdRecords rdRecords = new GesRdRecords();
            Matter matter = new Matter();
            GoodsRoom room = new GoodsRoom();

            if (roomIdArray[0].length() > 0 && roomIdArray[index].length() > 0) {
                room.setId(Long.parseLong(roomIdArray[index]));
            } else {
                room = null;
            }
            matter.setId(Long.parseLong(matterId));
            rdRecords.setMatter(matter);
            rdRecords.setRoom(room);
            if (StringUtil.notEmpty(amounts) && amount.length > 0) {
                rdRecords.setQuantity(Double.valueOf(amount[index]));
            }
            rdRecords.setRecordCode(stockInCode);
            // GesSoMatterItem soMatter = new GesSoMatterItem();
            // soMatter.setId(Long.parseLong(smIdArray[index]));
            // rdRecords.setSoMatter(soMatter);
            GesPoDetail poDetail = new GesPoDetail();
            poDetail.setId(Long.parseLong(poDetailIdArray[index]));
            rdRecords.setPoDetail(poDetail);

            if (StringUtil.notEmpty(prices) && StringUtil.notEmpty(prices.replace(",", ""))) {
                // LOG.info("prices:{}",prices);
                rdRecords.setPrice(Long.valueOf(price[index]));
            }
            rdRecords.setInvalid(false);
            rdRecords.setStockIn(0d);
            super.getGesRdRecordsDAO().create(rdRecords);
            index++;
        }

    }
}