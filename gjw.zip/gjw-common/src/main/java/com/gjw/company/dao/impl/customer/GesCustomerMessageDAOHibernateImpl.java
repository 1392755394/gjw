package com.gjw.company.dao.impl.customer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.customer.IGesCustomerMessageDAO;
import com.gjw.entity.customer.GesCustomerMessage;
import com.gjw.utils.StringUtil;
@Component("gesCustomerMessagesDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCustomerMessageDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCustomerMessageDAO{
    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCustomerMessage.class;
    }

    @Override
    public GesCustomerMessage listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCustomerMessage) super.get(id);
    }

    @Override
    public boolean updateGesCustomerMessage(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCustomerMessage(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public List<GesCustomerMessage> listByGesCustomerMessage(
            GesCustomerMessage model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCustomerMessage item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCustomerMessage>) super.findByPageCallBack(hql,"",params,model,null);
    }

    @Override
    public long count(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCustomerMessage item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        if(StringUtil.notEmpty(model.getContent())){
            hql=hql+" and item.content like ?";
            params.add(super.getFuzzyCondition(model.getContent()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }
}
