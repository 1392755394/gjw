package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.store.GesStore;

/**
 * 仓库管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月9日 上午10:22:18
 * 
 */
public interface IGesStoreService extends IService {

    /**
     * 仓库总数查询
     * 
     * @Description
     * @param storeCriteria
     * @return
     * @author gwb
     * @date 2015年12月9日 下午12:41:46
     */
    public Long count(GesStore storeCriteria);

    /**
     * 仓库分页查询
     * 
     * @Description
     * @param storeCriteria
     * @return
     * @author gwb
     * @date 2015年12月9日 下午12:42:03
     */
    public List<GesStore> listGesStore(GesStore storeCriteria);

    /**
     * 根据
     * 
     * @Description
     * @param id
     * @return
     * @author gwb
     * @date 2015年12月9日 下午12:42:18
     */
    public GesStore getById(Long id);

    /**
     * 修改仓库
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月17日 上午9:57:23
     */
    public boolean updateGesStore(GesStore model);

    /**
     * 创建仓库
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月17日 上午9:57:00
     */
    public boolean createGesStore(GesStore model);

    /**
     * 根据ids删除仓库
     * 
     * @Description
     * @param ids
     * @return
     * @author gwb
     * @date 2015年12月17日 上午9:56:45
     */
    public boolean deleteGesStoreByIds(String ids);

    /**
     * 仓库列表查询
     * 
     * @Description
     * @param stoe
     * @return
     * @author gwb
     * @date 2015年12月17日 上午9:56:33
     */
    public List<GesStore> listStoreBySynchType(GesStore stoe);

}
