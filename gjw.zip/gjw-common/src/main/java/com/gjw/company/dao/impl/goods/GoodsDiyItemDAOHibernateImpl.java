package com.gjw.company.dao.impl.goods;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.dao.goods.IGoodsDiyItemDAO;
import com.gjw.entity.goods.GoodsDiyItem;
import com.gjw.entity.goods.GoodsMatter;

/**
 * DIY方案dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月24日 
 *
 */
@Component("goodsDiyItemDAOHibernateImpl")
public class GoodsDiyItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsDiyItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsDiyItem.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public GoodsDiyItem queryStandartDiyByGoodsId(Long goodsId) {

        String hql = "from GoodsDiyItem g where g.relationGoods.id = ? and (g.relationDiy = null or g.relationDiy.id = 0)";
        
        List<GoodsDiyItem> list = (List<GoodsDiyItem>) super.getHibernateTemplate().find(hql, goodsId);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsDiyItem> listDiyByGoodsId(Long goodsId) {

        String hql = "from GoodsDiyItem g where g.relationGoods.id = ? ";
        
        return (List<GoodsDiyItem>) super.getHibernateTemplate().find(hql, goodsId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public GoodsDiyItem queryByDiyId(Long diyId) {

        String hql = "from GoodsDiyItem g where g.diy.id = ? ";
        
        List<GoodsDiyItem> list = (List<GoodsDiyItem>) super.getHibernateTemplate().find(hql, diyId);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public Long create(GoodsDiyItem goodsDiyItem) {
        super.add(goodsDiyItem);
        return goodsDiyItem.getId();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsDiyItem> pageDiyByUser(GoodsDiyItem goodsDiyItem,Long userId) {
        // TODO Auto-generated method stub
        String hql = " from GoodsDiyItem item where item.diy.invalid = 0 and item.diy.diyType= "+DictionaryConstants.DICTIONARY_GOODS_DIY_USER+
                " and item.user.id = "+userId;
        return (List<GoodsDiyItem>) super.findByPageCallBack(hql, "", null, goodsDiyItem, null);
    }

    @Override
    public Long countDiyByUser(GoodsDiyItem goodsDiyItem,Long userId) {
        // TODO Auto-generated method stub
        String hql = " from GoodsDiyItem item where item.diy.invalid = 0 and item.diy.diyType= "+DictionaryConstants.DICTIONARY_GOODS_DIY_USER+
                " and item.user.id = "+userId;
        return super.findByPageCallBackCount(hql, null);
    }

}
