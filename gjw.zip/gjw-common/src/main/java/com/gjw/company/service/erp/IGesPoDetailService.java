package com.gjw.company.service.erp;

import java.util.List;

import com.gjw.entity.erp.GesPoDetail;

/**
 * 采购订单明细实体
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月17日 下午2:55:12
 * 
 */
public interface IGesPoDetailService {
    /**
     * 物料分页查询
     * 
     * @Description
     * @param poCode
     * @return
     * @author gwb
     * @date 2015年12月21日 下午2:48:33
     */
    public List<GesPoDetail> pagePoDetailByPoCode(GesPoDetail poCode);

    public GesPoDetail getRoomIdById(Long iorderseq);

    /**
     * 物料总数查询
     * 
     * @Description
     * @param poDetail
     * @return
     * @author gwb
     * @date 2015年12月21日 下午2:49:29
     */
    public Long count(GesPoDetail poDetail);

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 批量插入
     * 
     * @Description
     * @param matterCodes
     * @param prices
     * @param poCode
     * @param smIds
     * @param goodsId
     * @param roomIds
     * @param amounts
     * @param matterIds
     * @param matterType
     * @return
     * @author gwb
     * @date 2015年12月30日 下午5:04:40
     */
    public boolean batchCreate(String matterCodes, String prices, String poCode, String smIds, Long goodsId,
            String roomIds, String amounts, String matterIds, String matterType);

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 批量删除
     * 
     * @Description
     * @param ids
     * @return
     * @author gwb
     * @date 2015年12月31日 下午1:15:36
     */
    public boolean batchDel(String ids);

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 修改采购数量
     * 
     * @Description
     * @param id
     * @param amount
     * @return
     * @author gwb
     * @date 2015年12月31日 下午1:45:53
     */
    public boolean updateAmount(Long id, Double amount);

}
