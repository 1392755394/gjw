package com.gjw.company.service.impl.validation;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.validation.IEmailValidationService;
import com.gjw.entity.validation.EmailValidation;

@Service("emailValidationServiceImpl")
public class EmailValidationServiceImpl extends AbstractServiceImpl implements IEmailValidationService {

    @Override
    @Transactional
    public void create(EmailValidation smsValidation) {
         super.getEmailValidationDAO().create(smsValidation);
    }

    @Override
    @Transactional(readOnly=true)
    public EmailValidation findLastByEmail(String email) {
        return super.getEmailValidationDAO().findLastByEmail(email);
    }

}
