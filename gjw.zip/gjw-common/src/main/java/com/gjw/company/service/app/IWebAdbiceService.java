package com.gjw.company.service.app;

import java.util.List;

import com.gjw.entity.app.WebAdvice;

public interface IWebAdbiceService {
    public WebAdvice get(Long id);

    public List<WebAdvice> getList(Integer index,Integer size);
    
    public boolean addWebAdvice(WebAdvice webAdvice) throws Exception;
    
    public void updateWebAdvice(WebAdvice webAdvice) throws Exception;
}
