package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesTaskParticipantDAO;
import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.vo.oa.GesTaskParticipantVO;
import com.gjw.vo.oa.UserVO;

/**
 * 参与人操作DAO实现类
 * @author jjw
 *
 */
@Component("gesTaskParticipantHibernateImpl")
public class GesTaskParticipantHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesTaskParticipantDAO {

	@Override
	protected Class<?> getEntityClass() {
		return GesTaskParticipant.class;
	}

	/**
	 * 插入多条参与人信息
	 * @param list
	 */
	@Override
	public int createGesTaskParticipant(List<GesTaskParticipant> list) {
		return super.batchAdd(list);
	}

	/**
	 * 查询用户的真实姓名
	 */
	@SuppressWarnings("unchecked")
    @Override
	public UserVO queryUserByUserId(Long id) {
		String hql="select u.realName as realName,u.user.email as email from UserInfoGES u where u.user.id=? ";
		List<Object> param=new ArrayList<Object>();
		param.add(id);
		List<UserVO> list=(List<UserVO>) super.findByListCallBack(hql, null, param, Transformers.aliasToBean(UserVO.class));
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	/**
	 * 根据任务id查询成员列表
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskParticipantVO> queryMemberInfoByTaskId(Long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.task.id as taskId,a.participant.id as userId,a.participantType as type"
				+ ",a.isCreator as isCreator,a.isHandle as isHandle,m.realName as userName,m.avatar.path as headPortrait ");
		hql.append(" from GesTaskParticipant a ,UserInfo m left join m.avatar t ");
		hql.append(" where a.invalid=? and m.type=? and m.user.id=a.participant.id and a.task.id=?");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		param.add(taskId);
		hql.append(" order by a.isCreator desc ");
		return (List<GesTaskParticipantVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskParticipantVO.class));
	}

	@Override
	public int updateGesTaskParticipantByIsHandle(GesTaskParticipant taskParticipant) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesTaskParticipant p ");
		hql.append(" set p.isHandle=? ,p.updatedDatetime=? ");
		param.add(taskParticipant.getIsHandle());
		param.add(taskParticipant.getUpdatedDatetime());
		if(taskParticipant.getCommunication()!=null && taskParticipant.getCommunication().getId()!=null){
			hql.append(" ,p.communication=? ");
			param.add(taskParticipant.getCommunication());
		}
		hql.append("where p.participant.id=? and p.task.id=? ");
		param.add(taskParticipant.getParticipant().getId());
		param.add(taskParticipant.getTask().getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

	/**
	 * 更新参与人的交流id
	 */
	@Override
	public int updateParticipantCommunicationId(GesTaskParticipant taskParticipant) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesTaskParticipant p ");
		hql.append(" set p.communication.id=? ");
		hql.append(" where p.participant.id=? and p.task.id=? ");
		param.add(taskParticipant.getCommunication().getId());
		param.add(taskParticipant.getParticipant().getId());
		param.add(taskParticipant.getTask().getId());
		super.updateByParam(hql.toString(), param);
		return 1;
	}

    @Override
    public boolean delMember(GesTaskParticipant taskParticipant) {
        return super.remove(taskParticipant.getId()) > 0;
    }

    @Override
    public int batchSaveTaskParticipant(List<GesTaskParticipant> list) {
        return super.batchAdd(list);
    }

    /**
     * 查询登录用户是否是某一个任务的创建人或者负责人
     * @param taskId
     * @param userId
     * @return
     */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskParticipantVO> getMemberInfo(long taskId, long userId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select p.id as id ");
		hql.append(" from GesTaskParticipant p join p.participant u ");
		hql.append(" where p.invalid=? and (p.participantType=1 or p.isCreator=? ) and p.task.id=? and u.id=? ");
		param.add(false);
		param.add(true);
		param.add(taskId);
		param.add(userId);
		
		return (List<GesTaskParticipantVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskParticipantVO.class));
	}

	/**
     * 通过任务id和用户id查询成员信息
     * @param taskId
     * @param userId
     * @return
     */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskParticipantVO> getMemberByIdAndUserid(long taskId,long userId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select p.id as id,p.participantType as type,p.isCreator as isCreator ");
		hql.append(" from GesTaskParticipant p join p.participant u ");
		hql.append(" where p.invalid=? and p.task.id=? and u.id=? ");
		param.add(false);
		param.add(taskId);
		param.add(userId);
		
		return (List<GesTaskParticipantVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskParticipantVO.class));
	}

	@Override
	public GesTaskParticipant getTaskParticipant(Long id) {
		return (GesTaskParticipant) super.get(id);
	}

    @Override
    public boolean updateTaskDeal(Long taskId, Integer isDeal, Long userId) {

        StringBuilder hql = new StringBuilder();
        List<Object> params=new ArrayList<Object>();
        hql.append("update GesTaskParticipant g set g.isHandle = ? ");
        params.add(isDeal);
        hql.append(" where g.task.id = ? ");
        params.add(taskId);
        hql.append(" and g.participant.id = ? ");
        params.add(userId);
        return super.updateByParam(hql.toString(), params);
    }
	
	
	
}
