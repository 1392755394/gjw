package com.gjw.company.dao.impl.area;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.area.IGesCityDAO;
import com.gjw.entity.area.GesArea;
import com.gjw.entity.area.GesCity;
import com.gjw.entity.area.GesCityDredge;

@Component("gesCityDAOHibernateImpl")
public class GesCityDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityDAO {

    @Override
    protected Class<?> getEntityClass() {

        return GesCity.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public GesCity getCityByCityId(long cityId) {

        List<GesCity> list = (List<GesCity>)getHibernateTemplate().find("from GesCity where city.id =?",cityId);
         return list.isEmpty()?null:list.get(0);
    }

    @Override
    public long addCityDetail(GesCity gesCity) {
        
        getHibernateTemplate().save(gesCity);
        return gesCity.getId();
    }

    @Override
    public long addDredgeCity(GesCityDredge cityDredge) {

        getHibernateTemplate().save(cityDredge);
        return cityDredge.getId()>0?1:0;
    }

    @Override
    public long deleteDredgeCity(GesCityDredge cityDredge, GesArea gesArea) {

        getHibernateTemplate().delete(cityDredge);
        getHibernateTemplate().update(gesArea);
        return cityDredge.getId();
    }

    @Override
    public GesArea getGesAreaById(long id) {
        
        GesArea gesArea = getHibernateTemplate().get(GesArea.class, id);
        return gesArea;
    }

    @Override
    public long updateGesAreaById(GesArea gesArea) {
        
        getHibernateTemplate().update(gesArea);
        return gesArea.getId();
    }

    @Override
    public long updateCityDetail(GesCity gesCity) {
        
        getHibernateTemplate().update(gesCity);
        return gesCity.getId();
    }

    @Override
    public GesCity getGesCityById(long id) {
        
        return (GesCity) get(id);
    }
}
