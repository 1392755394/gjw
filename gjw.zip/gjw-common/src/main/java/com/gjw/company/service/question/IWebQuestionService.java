package com.gjw.company.service.question;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.question.WebQuestion;

/**
 * 
* @Description: 问题service类
* @author  zhaoyonglian
* @date 2015年12月10日 下午2:22:44
*
 */
public interface IWebQuestionService extends IService {
    /**
     * 
    * @Description  获取问题详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:31:48
     */
    public WebQuestion getById(Long id);
    
    /**
     * 
    * @Description  分页列表，搜索条件：问题标题
    * @param subject
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:34:10
     */
    public List<WebQuestion> pageBySubjectAndInvalid(WebQuestion question);
    
    /**
     * 
    * @Description  总数
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午1:51:20
     */
    public Long countBySubjectAndInvalid(WebQuestion question);
    /**
     * 
    * @Description  批量废弃问题
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午4:53:34
     */
    public String invalidByIds(String ids);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebQuestion entity);
    /**
     * 
    * @Description  修改数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:45
     */
    public boolean update(WebQuestion entity);
    /**
     * 
    * @Description  删除数据（物理删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:54
     */
    public int delete(Long id);
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    /**
     * 
    * @Description  个人中心我的问题列表
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月1日 上午10:45:46
     */
    public List<WebQuestion> pageByUserAndState(WebQuestion question);
    
    /**
     * 
    * @Description  个人中心我的问题总数
    * @param question
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月1日 上午10:46:04
     */
    public Long countByUserAndState(WebQuestion question);
    
    /**
     * 
    * @Description  确认答案
    * @param questionId
    * @param answerId
    * @author zhaoyonglian   
    * @date 2016年3月1日 下午3:24:46
     */
    public void setConfirm(Long questionId,Long answerId);
}
