package com.gjw.company.dao.impl.user;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IUserBuildingItemDAO;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;
import com.gjw.utils.StringUtil;

@Component("userBuildingItemDAOHibernateImpl")
public class UserBuildingItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IUserBuildingItemDAO  {

    @Override
    protected Class<?> getEntityClass() {
        return UserBuildingItem.class;
    }

    @Override
    public void create(UserBuildingItem item) {
        super.add(item);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void update(UserBuildingItem item) {

        String hql = "from UserBuildingItem where user.id = ? ";
        List<UserBuildingItem> list = (List<UserBuildingItem>) super.getHibernateTemplate().find(hql, item.getUser().getId());
        if (list.size() > 0) {
            UserBuildingItem old = list.get(0);
            StringUtil.copyProperties(item, old);
            super.update(old);
        } else {
            super.add(item);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public UserBuildingItem queryByUser(User user) {

        String hql = "from UserBuildingItem b left join fetch b.building where b.user.id = ? ";
        List<UserBuildingItem> list = (List<UserBuildingItem>) super.getHibernateTemplate().find(hql, user.getId());
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

}
