package com.gjw.company.dao.impl.user;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IUserDAO;
import com.gjw.entity.base.AbstractEntity;
import com.gjw.entity.user.User;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("userDAOHibernateImpl")
public class UserDAOHibernateImpl extends AbstractDAOHibernateImpl implements IUserDAO {

    @Override
    protected Class<? extends AbstractEntity> getEntityClass() {
        return User.class;
    }

    @Override
    public User getByUsername(String username) {
       List<?> list=this.getHibernateTemplate().find("from User where username=?",username.toLowerCase());
       if(list.size()>0)
           return (User)list.get(0);
       else
           return null;
    }
    @Override
    public User getByEmail(String email) {
        List<?> list=this.getHibernateTemplate().find("from User where email=?",email);
        if(list.size()>0)
            return (User)list.get(0);
        else
            return null;
    }
    @Override
    public User getByMobile(String mobile) {
        List<?> list=this.getHibernateTemplate().find("from User where mobile=?",mobile);
        if(list.size()>0)
            return (User)list.get(0);
        else
            return null;
    }
    @Override
    public User get(Long id){
        return (User)super.get(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<User> test(){
        String hql="from User user left join user.userInfoMap where ges.id=infos.id";
        return (List<User>)this.getHibernateTemplate().find(hql);
    }

    @Override
    public User getByUserNameAndPassWord(User user) {
        // TODO Auto-generated method stub
        List<?> list=this.getHibernateTemplate().find("from User where username=? and password=?",user.getUsername().toLowerCase(),user.getPassword());
        if(list.size()>0)
            return (User)list.get(0);
        else
            return null;
    }

    @Override
    public User getByAccount(String account) {
        List<?> list=this.getHibernateTemplate().find("from User where username=? or email=? or mobile=?",account.toLowerCase(),account,account);
        if(list.size()>0)
            return (User)list.get(0);
        else
            return null;
    }
}
