package com.gjw.company.dao.validation;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.validation.EmailValidation;

public interface IEmailValidationDAO extends IDAO{
    void create(EmailValidation smsValidation);
    EmailValidation findLastByEmail(String email);
}
