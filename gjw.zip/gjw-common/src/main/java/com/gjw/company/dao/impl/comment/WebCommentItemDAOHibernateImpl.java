package com.gjw.company.dao.impl.comment;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.comment.IWebCommentItemDAO;
import com.gjw.entity.comment.WebCommentItem;
import com.gjw.utils.StringUtil;

/**
 * 产品包dao的Hibernate实现
 */
@Component("webCommentItemDAOHibernateImpl")
public class WebCommentItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements
IWebCommentItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebCommentItem.class;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<WebCommentItem> pageByCondition(WebCommentItem item) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if(null!=item.getInvalid() && true==item.getInvalid()){
            hql.append(" from WebCommentItem where invalid = 1");
        }else{
            hql.append(" from WebCommentItem where invalid = 0");
        }
        if(StringUtil.notEmpty(item.getContent())){
            hql.append(" and content like ?");
            ls.add(super.getFuzzyCondition(item.getContent()));
        }
        if(null != item.getPropertyType() && 0 != item.getPropertyType().getId()){
            hql.append(" and propertyType.id = ?");
            ls.add(item.getPropertyType().getId());
        }
        if(null != item.getUser() && StringUtil.notEmpty(item.getUser().getUsername())){
            hql.append(" and user.username like ?");
            ls.add(super.getFuzzyCondition(item.getUser().getUsername()));
        }
        if(null != item.getInfo()){
            hql.append(" and info = ?");
            ls.add(item.getInfo());
        }
        hql.append("order by createdDatetime desc");
         return (List<WebCommentItem>) super.findByPageCallBack(hql.toString(), "", ls, item, null);
    }

    @Override
    public Long countByCondition(WebCommentItem item) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if(null!=item.getInvalid() && true==item.getInvalid()){
            hql.append(" from WebCommentItem where invalid = 1");
        }else{
            hql.append(" from WebCommentItem where invalid = 0");
        }
        if(StringUtil.notEmpty(item.getContent())){
            hql.append(" and content like ?");
            ls.add(super.getFuzzyCondition(item.getContent()));
        }
        if(null != item.getPropertyType() && 0 != item.getPropertyType().getId()){
            hql.append(" and propertyType.id = ?");
            ls.add(item.getPropertyType().getId());
        }
        if(null != item.getUser() && StringUtil.notEmpty(item.getUser().getUsername())){
            hql.append(" and user.username like ?");
            ls.add(super.getFuzzyCondition(item.getUser().getUsername()));
        }
        if(null != item.getInfo()){
            hql.append(" and info = ?");
            ls.add(item.getInfo());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
}
