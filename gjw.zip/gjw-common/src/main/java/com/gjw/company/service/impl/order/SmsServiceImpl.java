package com.gjw.company.service.impl.order;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.order.ISmsService;
import com.gjw.entity.validation.SmsValidation;
import com.gjw.utils.RandomCode;
import com.gjw.utils.SMSUtil;

@Component("smsServiceImpl")
public class SmsServiceImpl extends AbstractServiceImpl implements ISmsService {
	
	private final static Logger log=LoggerFactory.getLogger(SmsServiceImpl.class);

	@Override
	@Transactional
	public boolean sendValidationMessage(SmsValidation smsValidation) {
		if(smsValidation.getEvent().endsWith("order")){
			smsValidation.setEvent("2");
		}else if(smsValidation.getEvent().endsWith("3")){
			smsValidation.setEvent("3");
		}else {
			smsValidation.setEvent("1");
		}
		log.info("接收到的信息为："+smsValidation.getMobile());
		//将该手机的其他验证码置为失效
		getSmsValidationDAO().updateSmsValidationInvalidForOrder(smsValidation);
		//生成验证码
	    String code =RandomCode.getValidationCode();//生成验证码
        smsValidation.setValidateCode(code);
        //保存
        getSmsValidationDAO().add(smsValidation);
        String message=SMSUtil.getNewMessage(smsValidation);
        return SMSUtil.send(smsValidation.getMobile(), message);
	}

	
	
}
