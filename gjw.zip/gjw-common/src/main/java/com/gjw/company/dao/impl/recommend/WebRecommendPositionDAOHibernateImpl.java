package com.gjw.company.dao.impl.recommend;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.recommend.IWebRecommendPositionDAO;
import com.gjw.entity.recommend.WebRecommendPosition;
import com.gjw.utils.StringUtil;

/**
 * dao的Hibernate实现
 */
@Component("webRecommendPositionDAOHibernateImpl")
public class WebRecommendPositionDAOHibernateImpl extends AbstractDAOHibernateImpl implements
IWebRecommendPositionDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebRecommendPosition.class;
    }

    @Override
    public WebRecommendPosition getById(Long id) {
        // TODO Auto-generated method stub
        return (WebRecommendPosition) super.get(id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<WebRecommendPosition> pageByNameAndCode(WebRecommendPosition position) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
            hql.append(" from WebRecommendPosition wrp where wrp.id !=0 ");
        if(StringUtil.notEmpty(position.getPosName())){
            hql.append(" and wrp.posName like ?");
            ls.add("%"+position.getPosName()+"%");
        }
        if(StringUtil.notEmpty(position.getPosCode())){
            hql.append(" and wrp.posCode = ?");
            ls.add(position.getPosCode());
        }
        hql.append("order by wrp.id desc");
         return (List<WebRecommendPosition>) super.findByPageCallBack(hql.toString(), "", ls, position, null);
    }

    @Override
    public Long countByNameAndCode(WebRecommendPosition position) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
            hql.append(" from WebRecommendPosition wrp where wrp.id !=0 ");
        if(StringUtil.notEmpty(position.getPosName())){
            hql.append(" and wrp.posName like ?");
            ls.add("%"+position.getPosName()+"%");
        }
        if(StringUtil.notEmpty(position.getPosCode())){
            hql.append(" and wrp.posCode = ?");
            ls.add(position.getPosCode());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updatePosition(WebRecommendPosition position) {
        // TODO Auto-generated method stub
        WebRecommendPosition pos = (WebRecommendPosition) super.get(position.getId());
        StringUtil.copyProperties(position, pos);
        super.update(pos);
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebRecommendPosition> listByInvalid(Integer invalid) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
            hql.append(" from WebRecommendPosition wrp where wrp.invalid = :invalid");
            Query query = session.createQuery(hql.toString());
            query.setInteger("invalid", invalid);
            return query.list();
    }
    
}
