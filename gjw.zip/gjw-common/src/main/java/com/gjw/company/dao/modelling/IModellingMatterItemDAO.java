package com.gjw.company.dao.modelling;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.modelling.ModellingMatterItem;

/**
 * 
* @Description: 造型物料关系dao接口
* @author  zhaoyonglian
* @date 2016年1月11日 下午5:18:36
*
 */
public interface IModellingMatterItemDAO extends IDAO {

    /**
    * @Description  造型库物料列表
    * @param item
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月11日 下午5:19:15
     */
    public List<ModellingMatterItem> pageByCodeAndName(ModellingMatterItem item);

    /**
     * 
    * @Description  总数
    * @param item
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月11日 下午5:19:47
     */
    public Long countByCodeAndName(ModellingMatterItem item);


    /**
     * 
    * @Description  更新
    * @param modelling
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:13
     */
    public boolean updateItem(ModellingMatterItem item);

    /**
     * 
    * @Description  批量删除
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月9日 下午2:56:29
     */
    public boolean delBatchByID(String ids);
    
}
