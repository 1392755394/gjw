package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;

/**
 * 部门dao接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2016年1月9日
 * 
 */
public interface IDeptDAO extends IDAO {

    /**
     * 新增部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 部门ID
     * @author guojianbin
     * @date 2016年1月9日
     */
    public long create(Dept dept);

    /**
     * 修改部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月9日
     */
    public boolean update(Dept dept);

    /**
     * 删除部门
     * 
     * @Description
     * @param menu
     *            部门
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月9日
     */
    public boolean delete(Dept dept);

    /**
     * 根据上级部门取得的下级部门列表
     * 
     * @Description
     * @param parentId
     *            上级部门ID
     * @return 下级部门列表
     * @author guojianbin
     * @date 2016年1月9日
     */
    public List<Dept> listDeptByParentId(long parentId);

    /**
     * 取得全体部门列表
     * 
     * @Description
     * @return 部门列表
     * @author guojianbin
     * @date 2016年1月9日
     */
    public List<Dept> listDepts();

    /**
     * 基础数据同步--部门同步
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2016年1月16日 上午10:38:01
     */
    public List<Dept> listDeptForSynch();

    /**
     * 基础数据同步--结果
     * 
     * @Description
     * @param dept
     * @author gwb
     * @date 2016年1月16日 上午10:54:32
     */
    public void updateDeptForSynch(Dept dept);

    /**
     * 基础数据同步-- 部门人员查询
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2016年1月16日 下午1:17:14
     */
    public List<DeptUser> listDeptUserForSynch();

    /**
     * 接触数据同步---部门人员结果同步修改
     * 
     * @Description
     * @param dept
     * @author gwb
     * @date 2016年1月16日 下午1:17:34
     */
    public void updateDeptUserForSynch(DeptUser dept);

}
