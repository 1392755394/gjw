package com.gjw.company.dao.salestool;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.salestool.BuildingInfoGoods;


public interface IBuildingInfoGoodsDAO extends IDAO{
	public List<BuildingInfoGoods> pageBuildingInfoGoods(BuildingInfoGoods buildinginfogoods);
	
	public Long count(BuildingInfoGoods buildinginfogoods);

	public long create(BuildingInfoGoods buildinginfogoods);
	
	public boolean update(BuildingInfoGoods buildinginfogoods);
			
	public BuildingInfoGoods queryByID(long id);
	
	public boolean deletes(String ids);
}

