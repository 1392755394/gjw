package com.gjw.company.dao.impl.question;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.question.IWebQuestionDAO;
import com.gjw.entity.question.WebQuestion;
import com.gjw.utils.StringUtil;

/**
 * 产品包dao的Hibernate实现
 */
@Component("webQuestionDAOHibernateImpl")
public class WebQuestionDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebQuestionDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebQuestion.class;
    }

    @Override
    public WebQuestion getById(Long id) {
        // TODO Auto-generated method stub
        return (WebQuestion) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebQuestion> pageBySubjectAndInvalid(WebQuestion question) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if (question.getInvalid()) {
            hql.append(" from WebQuestion where invalid = 1");
        } else {
            hql.append(" from WebQuestion where invalid = 0");
        }
        if (StringUtil.notEmpty(question.getSubject())) {
            hql.append(" and subject like ?");
            ls.add("%" + question.getSubject() + "%");
        }
        hql.append("order by id desc");
        return (List<WebQuestion>) super.findByPageCallBack(hql.toString(), "", ls, question, null);
    }

    @Override
    public Long countBySubjectAndInvalid(WebQuestion question) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if (question.getInvalid()) {
            hql.append(" from WebQuestion where invalid = 1");
        } else {
            hql.append(" from WebQuestion where invalid = 0");
        }
        if (StringUtil.notEmpty(question.getSubject())) {
            hql.append(" and subject like ?");
            ls.add("%" + question.getSubject() + "%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updateQuestion(WebQuestion question) {
        // TODO Auto-generated method stub
        WebQuestion que = (WebQuestion) super.get(question.getId());
        StringUtil.copyProperties(question, que);
        super.update(que);
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebQuestion> pageByUserAndState(WebQuestion question) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebQuestion where user = ?");
        ls.add(question.getUser());
        if (StringUtil.notEmpty(question.getStatus())) {
            if (1 == question.getStatus()) {
                hql.append(" and status =?");
                ls.add(question.getStatus());
                hql.append("a nd anwserAmount = 0 and invalid = 0");
            }
            if (2 == question.getStatus()) {
                hql.append(" and status =?");
                ls.add(question.getStatus());
                hql.append(" and anwserAmount != 0 and invalid = 0");
            }
            if (3 == question.getStatus()) {
                hql.append(" and status =?");
                ls.add(question.getStatus());
                hql.append(" and invalid = 0");
            }
            if (4 == question.getStatus()) {
                hql.append(" and invalid = 1");
            }
        }
        hql.append("order by id desc");
        return (List<WebQuestion>) super.findByPageCallBack(hql.toString(), "", ls, question, null);
    }

    @Override
    public Long countByUserAndState(WebQuestion question) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebQuestion where user = ?");
        ls.add(question.getUser());
        if (StringUtil.notEmpty(question.getStatus())) {
            hql.append(" and status =?");
            ls.add(question.getStatus());
            if (1 == question.getStatus()) {
                hql.append("a nd anwserAmount = 0 and invalid = 0");
            }
            if (2 == question.getStatus()) {
                hql.append(" and anwserAmount != 0 and invalid = 0");
            }
            if (3 == question.getStatus()) {
                hql.append(" and invalid = 0");
            }
            if (4 == question.getStatus()) {
                hql.append(" and invalid = 1");
            }
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public void isConfirm(Long questionId) {
        // TODO Auto-generated method stub
        String hql = " update WebQuestion set status = 3 where id = "+questionId;
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        query.executeUpdate();
    }

}
