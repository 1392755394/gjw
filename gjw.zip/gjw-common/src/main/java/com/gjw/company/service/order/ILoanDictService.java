package com.gjw.company.service.order;

import java.util.List;

import com.gjw.entity.order.LoanDict;

public interface ILoanDictService {
	
	/**
	 * 查询贷款静态信息
	 * @param dict
	 * @return
	 */
	public List<LoanDict> queryByCIP(LoanDict dict);

}
