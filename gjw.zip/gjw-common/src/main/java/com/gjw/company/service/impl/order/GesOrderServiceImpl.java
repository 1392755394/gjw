package com.gjw.company.service.impl.order;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.OrderConstant;
import com.gjw.common.constants.PaymentConstant;
import com.gjw.common.enumeration.OrderAction;
import com.gjw.common.enumeration.OrderStatus;
import com.gjw.common.enumeration.OrderStatusCopy;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.web.JsonResult;
import com.gjw.company.dao.order.IGesOrderPayMoneyDAO;
import com.gjw.company.service.erp.IGesSoMatterItemService;
import com.gjw.company.service.order.IGesOrderService;
import com.gjw.company.service.order.IMultiplePaymentService;
import com.gjw.dto.order.OrderActionDTO;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesOrderPayMoney;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.entity.picture.Picture;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.validation.SmsValidation;
import com.gjw.utils.CounterUtil;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.order.GesOrderVO;

/**
 * 订单操作相关的service
 * 
 * @author jjw
 * 
 */
@Component("gesOrderServiceImpl")
public class GesOrderServiceImpl extends AbstractServiceImpl implements IGesOrderService {

    private static final Logger log = LoggerFactory.getLogger(GesOrderServiceImpl.class);

    @Resource(name = "gesOrderPayMoneyDAOHibernateImpl")
    private IGesOrderPayMoneyDAO gesOrderPayMoneyDAO;

    public IGesOrderPayMoneyDAO getGesOrderPayMoneyDAO() {
        return gesOrderPayMoneyDAO;
    }

    public void setGesOrderPayMoneyDAO(IGesOrderPayMoneyDAO gesOrderPayMoneyDAO) {
        this.gesOrderPayMoneyDAO = gesOrderPayMoneyDAO;
    }

    @Resource(name = "gesSoMatterItemServiceImpl")
    private IGesSoMatterItemService gesSoMatterItemService;
    @Resource(name = "multiplePaymentServiceImpl")
    private IMultiplePaymentService multiplePaymentService;

    /**
     * 订单创建
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional
    public Long createGesOrder(GesOrder gesOrder) {
        gesOrder.setOrderStatus(OrderStatus.booked.name());
        gesOrder.setInvalid(false);
        if (gesOrder.getShop() == null) {
            GesShop tempShop = new GesShop();
            tempShop.setId(1l);
            gesOrder.setShop(tempShop);
        }
        if (gesOrder.getOperator() == null) {
            GesCityOperator tempOperator = new GesCityOperator();
            tempOperator.setId(1l);
            gesOrder.setOperator(tempOperator);
        }
        if (gesOrder.getGoods() == null) {
            Goods tempGoods = new Goods();
            tempGoods.setId(1l);
            gesOrder.setGoods(tempGoods);
        }
        if (gesOrder.getTotalAmount() == null) {
            gesOrder.setTotalAmount(((long) (Math.random() * 10000000)) * 10);
        }
        // code
        // String code = System.currentTimeMillis() + "" + (int) (Math.random()
        // * 1000);
        String code = System.currentTimeMillis() + "" + CounterUtil.incrementAndGet();
        log.info("生成的code为：" + code);
        gesOrder.setCode(code);
        gesOrder.setUseType(1);
        this.getGesOrderDAO().add(gesOrder);
        // 测试使用 批量插入 正式的订单生成时，重新写此方法
        gesSoMatterItemService.saveGesSoMatterItem(gesOrder.getId(), gesOrder.getGoods().getId(), gesOrder.getBuyer()
                .getId());

        GesOrderPayMoney payMoney = new GesOrderPayMoney();
        payMoney.setInvalid(false);
        payMoney.setGesOrder(gesOrder);
        getGesOrderPayMoneyDAO().add(payMoney);

        return gesOrder.getId();
    }

    /**
     * 订单删除
     * 
     * @param orderId
     * @return
     */
    @Override
    public Integer deleteGesOrder(GesOrder gesOrder) {
        return this.getGesOrderDAO().deleteGesOrder(gesOrder);
    }

    /**
     * 官网 根据购买者ID分页获取订单信息
     * 
     * @param buyerId
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> pageOrderByBuyerIdForWeb(GesOrder gesOrder) {
        // 根据购买者的id查询该用户的订单列表
        List<GesOrderVO> list = this.getGesOrderDAO().pageOrderByBuyerIdForWeb(gesOrder);
        if (list != null && list.size() > 0) {
            for (GesOrderVO order : list) {
                List<OrderActionDTO> dtoList = new ArrayList<OrderActionDTO>();
                List<OrderAction> orderAction = OrderStatusCopy.valueOf(order.getOrderStatus()).getActionsForWeb();
                if (null != orderAction && orderAction.size() > 0) {
                    for (OrderAction action : orderAction) {
                        OrderActionDTO orderActionDTO = new OrderActionDTO();
                        orderActionDTO.setName(action.name());
                        orderActionDTO.setText(action.getText());
                        dtoList.add(orderActionDTO);
                    }
                }
                order.setAction(dtoList);
            }
        }
        return list;
    }

    /**
     * Ges 构家网用户 分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> pageOrderByGjwIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().pageOrderByGjwIdForGes(gesOrderVO);
    }

    /**
     * Ges 城运商用户 根据城运商ID分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> pageOrderByOperatorIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().pageOrderByOperatorIdForGes(gesOrderVO);
    }

    /**
     * Ges 4S店用户 根据4s店的ID分页查询订单信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> pageOrderByShopIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().pageOrderByShopIdForGes(gesOrderVO);
    }

    /**
     * 官网 根据购买者id统计订单的总数量
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countOrderByBuyerIdForWeb(GesOrder gesOrder) {
        return this.getGesOrderDAO().countOrderByBuyerIdForWeb(gesOrder);
    }

    /**
     * Ges 构家网用户 统计订单数量
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countOrderByGjwIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().countOrderByGjwIdForGes(gesOrderVO);
    }

    /**
     * Ges 城运商用户 根据城运商ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countOrderByOperatorIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().countOrderByOperatorIdForGes(gesOrderVO);
    }

    /**
     * Ges 4S店用户 根据4s店的ID统计订单的数量
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countOrderByShopIdForGes(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().countOrderByShopIdForGes(gesOrderVO);
    }

    /**
     * 根据订单的id更新订单的状态信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    public Boolean updateOrderStatusByOrderId(GesOrder gesOrder) {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * 根据订单id更新订单信息 Ges中修改订单的价格、面积、备注等信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional
    public Boolean updateOrderInfoByOrderId(GesOrder gesOrder) {

        return super.getGesOrderDAO().updateOrderInfoByOrderId(gesOrder);
    }

    /**
     * 官网后台 分页查询订单信息
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> pageOrderForWebConsole(GesOrderVO gesOrderVO) {
        return (List<GesOrderVO>) this.getGesOrderDAO().pageOrderForWebConsole(gesOrderVO);
    }

    /**
     * 官网后台 统计订单数量
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countOrderForWebConsole(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().countOrderByGjwIdForGes(gesOrderVO);
    }

    /**
     * 根据订单id查询订单信息
     * 
     * @param orderId
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public GesOrder queryOrderByOrderId(Long orderId) {
        GesOrder order = this.getGesOrderDAO().queryOrderByOrderId(orderId);
        if (order != null) {
            Hibernate.initialize(order.getBuyer());
            Hibernate.initialize(order.getGoods());
            if (order.getGoods().getId() != null) {
                Hibernate.initialize(order.getGoods().getPhoto());
                Hibernate.initialize(order.getGoods().getFloorPlanImage());
                Hibernate.initialize(order.getGoods().getGoodsType());
                Hibernate.initialize(order.getGoods().getHouseType());
                Hibernate.initialize(order.getGoods().getStyle());
                if (order.getGoods().getHouse().getId() != null) {
                    Hibernate.initialize(order.getGoods().getHouse().getPhoto());
                    Hibernate.initialize(order.getGoods().getHouse().getBuilding());
                }

            }

            Hibernate.initialize(order.getShop());
            Hibernate.initialize(order.getOperator());
        }
        return order;
    }

    /**
     * Ges 根据4S店ID分页查询该店已完成的订单
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public List<GesOrderVO> pageOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO) {
        // 设置订单状态为已完成
        gesOrderVO.setOrderStatus(OrderStatus.completed.name());
        return this.getGesOrderDAO().pageOrderByShopIdAndOrderStatus(gesOrderVO);
    }

    /**
     * Ges 根据4S店ID统计已完成订单的数量
     * 
     * @param gesOrderVO
     * @return
     */
    @Override
    public Long countOrderByShopIdAndOrderStatus(GesOrderVO gesOrderVO) {
        // 设置订单状态为已完成
        gesOrderVO.setOrderStatus(OrderStatus.completed.name());
        return this.getGesOrderDAO().countOrderByShopIdAndOrderStatus(gesOrderVO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesOrder> pageByOrder(GesOrderVO model) {
        List<GesOrder> list = super.getGesOrderDAO().pageByOrder(model);
        for (GesOrder order : list) {
            order.getOperator().getCompanyName();
            order.getShop().getName();
            order.getGoods().getName();
            order.getBuyer().getUsername();
            if (order.getGesOrderPayMoney() != null) {
                order.getGesOrderPayMoney().getEarnestPay();
            }
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByOrder(GesOrderVO model) {
        return super.getGesOrderDAO().countByOrder(model);
    }

    /**
     * 销售订单列表中，查看订单详细信息使用
     * 
     * @param id
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public GesOrder queryOrderInfoById(long id) {
        GesOrder order = getGesOrderDAO().queryOrderByOrderId(id);
        order.getOperator().getCompanyName();
        order.getShop().getName();
        order.getGoods().getName();
        order.getBuyer().getUsername();
        order.getGesOrderPayMoney();

        return order;
    }

    /**
     * 测试使用
     */
    @Override
    @Transactional
    public int updateStatus(GesOrder order) {
        GesOrder gesOrder = getGesOrderDAO().queryOrderByOrderId(order.getId());
        String status = OrderStatus.valueOf(OrderStatus.valueOf(gesOrder.getOrderStatus()).ordinal()).name();
        order.setOrderStatus(status);
        getGesOrderDAO().updateOrderStatusByOrderId(order);
        return 1;
    }

    /**
     * 更新订单信息
     */
    @Override
    @Transactional
    public boolean updateOrder(GesOrder order) {
        if(null!=order.getUser() && null!=order.getUser().getId()){
            log.info("登录用户为：" + order.getUser().getId());
        }
        GesOrder gesOrder = getGesOrderDAO().queryOrderByOrderId(order.getId());
        log.info("更新前的数据为：" + gesOrder.getRemark() + ",area:" + gesOrder.getArea() + ",totalAmount："
                + gesOrder.getTotalAmount() + "合同的路径：" + gesOrder.getBargainPath() + "是否有效：" + gesOrder.getUseType());
        getGesOrderDAO().updateOrder(order);
        return true;
    }

    /**
     * 基础数据同步项目同步
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrder> baseProjectListPage(GesOrder order) {
        List<GesOrder> list = getGesOrderDAO().baseProjectListPage(order);
        for (GesOrder gesOrder : list) {
            gesOrder.getGoods().getName();
            gesOrder.getShop().getName();
        }
        return list;
    }

    /**
     * 合同签署 更新订单的状态
     */
    @Override
    @Transactional
    public boolean signOrder(GesOrder order) {
        log.info("登录用户为：" + order.getUser().getId());
        // 获取订单信息
        GesOrder gesOrder = getGesOrderDAO().queryOrderByOrderId(order.getId());
        log.info("当前的订单状态为：" + gesOrder.getOrderStatus());
        // 判断是否是已预订状态，是更新订单状态，否，直接返回
        if (gesOrder.getOrderStatus().equals(OrderStatus.booked.name())) {
            order.setOrderStatus(OrderStatus.auditing.name());
            order.setProjectStatus(OrderConstant.ORDER_PROJECT_STATUS);
            // 更新
            getGesOrderDAO().updateOrderStatusByOrderId(order);
            // 更新4s店产品包销售数量 先获取记录，再更新
            updateShopGoodSaleNum(gesOrder);

            return true;
        } else {
            // 返回
            return false;
        }

    }

    /**
     * 订单操作
     */
    @Override
    @Transactional
    public boolean doAction(GesOrder order, String action) {
        // 获取订单信息
        GesOrder gesOrder = getGesOrderDAO().queryOrderByOrderId(order.getId());
        log.info("当前的订单状态为：" + gesOrder.getOrderStatus());
        // 获取当前订单状态存在的动作，判断是否包含当前的动作
        boolean flag = OrderStatusCopy.valueOf(gesOrder.getOrderStatus()).getActionsForGes()
                .contains(OrderAction.valueOf(action));
        log.info("订单状态是否包含当前操作" + flag);
        if (flag) {
            // 判断当前状态是否是已预订状态
            if (OrderStatusCopy.booked.equals(gesOrder.getOrderStatus())) {
                order.setProjectStatus(OrderConstant.ORDER_PROJECT_STATUS);
                updateShopGoodSaleNum(gesOrder);
            }
            // 获取下一个订单状态
            String status = OrderStatusCopy.valueOf(gesOrder.getOrderStatus()).doAction(OrderAction.valueOf(action))
                    .name();
            log.info("下一个订单的状态为：" + status);
            // 更新订单的状态
            order.setOrderStatus(status);
            // 更新
            getGesOrderDAO().updateOrderStatusByOrderId(order);
            return true;
        } else {
            return false;
        }

    }

    protected void updateShopGoodSaleNum(GesOrder gesOrder) {
        log.info("更新4s店的产品包销售数量");
        GesShopGoodsItem tempGsgi = new GesShopGoodsItem();
        tempGsgi.setGoods(gesOrder.getGoods());
        tempGsgi.setShop(gesOrder.getShop());
        tempGsgi.setStatus(0);
        tempGsgi.setInvalid(false);
        GesShopGoodsItem gsgi = getGesShopGoodsItemDAO().listByShopAndGood(tempGsgi);
        if (gsgi == null) {
            return;
        }
        log.info("当前销售数量为：" + gsgi.getSaleNum());
        if (gsgi.getSaleNum() != null) {
            gsgi.setSaleNum(gsgi.getSaleNum() + 1);
        } else {
            gsgi.setSaleNum(1);
        }
        gsgi.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        getGesShopGoodsItemDAO().updateGesShopGoodsItem(gsgi);
    }

    /**
     * 统计订单关联产品包的物料
     * 
     * @param soMatter
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Long countStandardMatter(GesSoMatterVO soMatter) {

        return getGesOrderDAO().countStandardMatter(soMatter);
    }

    /**
     * 分页获取订单关联的物料
     * 
     * @param soMatter
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesSoMatterVO> pageStandardMatter(GesSoMatterVO soMatter) {

        return getGesOrderDAO().pageStandardMatter(soMatter);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countOrderByGoodsForWeb(Goods goods) {
        return getGesOrderDAO().countOrderByGoodsForWeb(goods);
    }

    /**
     * 直播家 获取订单信息
     */
    @Override
    @Transactional(readOnly = true)
    public GesOrder queryOrderInfoForLiveHome(Long orderId) {
        // 获取订单信息
        GesOrder gesOrder = getGesOrderDAO().queryOrderByOrderId(orderId);
        // Hibernate.initialize(gesOrder.getBuyer().getUsername());
        gesOrder.getBuyer().getUsername();
        UserInfo userInfo = gesOrder.getBuyer().initPlatformUserInfo(PlatformEnum.Website);
        if (userInfo == null) {
            gesOrder.getBuyer().initPlatformUserInfo(PlatformEnum.Ges);
        }
        Picture picture = gesOrder.getBuyer().getPlatformUserInfo().getAvatar();
        if (picture != null) {
            gesOrder.getBuyer().getPlatformUserInfo().getAvatar().getPath();
        }
        // 加载产品包信息
        Hibernate.initialize(gesOrder.getGoods());
        // 加载户型，系列
        Hibernate.initialize(gesOrder.getGoods().getStyle());
        Hibernate.initialize(gesOrder.getGoods().getHouseType());
        // 加载房屋及楼盘信息
        if (StringUtil.notEmpty(gesOrder.getGoods().getHouse())) {
            Hibernate.initialize(gesOrder.getGoods().getHouse());
            Hibernate.initialize(gesOrder.getGoods().getHouse().getBuilding());
        }
        Hibernate.initialize(gesOrder.getGoods().getPhoto());
        gesOrder.getShop().getCity().getName();

        return gesOrder;
    }

    @Override
    @Transactional(readOnly = true)
    public GesOrderVO queryOrderByIdForGjb(Long orderId) {
        GesOrderVO order = getGesOrderDAO().queryOrderByIdForGjb(orderId);

        return order;
    }

    @Override
    @Transactional
    public String updateOrderStatusForWeb(long orderId, String action, Long userId) {
        JSONObject json = new JSONObject();
        // 查询订单
        GesOrder order = getGesOrderDAO().queryOrderByOrderId(orderId);
        if (order == null) {
            return null;
        } else if (order.getBuyer().getId().longValue() != userId.longValue()) {
            return null;
        }
        // 订金10%，保证金90%，确认支付30% 不做处理
        if (OrderStatus.prepaying.equals(order.getOrderStatus())// 10%
                || OrderStatus.accepted_AZZC.equals(order.getOrderStatus())// 90%
                || OrderStatus.paying_AZZC.equals(order.getOrderStatus())// 30%
                || OrderStatus.accepted_JZFZ.equals(order.getOrderStatus())// 30%
                || OrderStatus.accepted_YSCS.equals(order.getOrderStatus())) {// 30%

            return null; // 待冻结不作处理,待确认支付不作处理,待支付保证金不作处理
        }
        // 当前订单状态的下一个状态
        OrderStatusCopy nextStatus = OrderStatusCopy.valueOf(order.getOrderStatus()).doAction(
                OrderAction.valueOf(action));
        // 验收通过 不通过，同意
        // 确保支付状态不循环
        if (nextStatus.name().equals(order.getOrderStatus())) {
            return null;
        }
        GesOrder gesOrder = new GesOrder();
        gesOrder.setId(orderId);
        gesOrder.setOrderStatus(nextStatus.name());
        User tempUser = new User();
        tempUser.setId(userId);
        gesOrder.setUser(tempUser);
        boolean flag = getGesOrderDAO().updateOrderStatusByOrderId(gesOrder);
        if (flag) {
            json.put("result", flag);
            return json.toString();
        } else {
            return null;
        }
    }

    /**
     * 订单删除
     */
    @Override
    @Transactional
    public JsonResult<Integer> deleteOrderByJudgePayment(GesOrder order) {
        JsonResult<Integer> jsonResult = new JsonResult<Integer>();
        MultiplePayment mp = new MultiplePayment();
        mp.setPeriod(PaymentConstant.PAY_PERIOD_TEN);
        mp.setGesOrder(order);
        Long payedMoney = getMultiplePaymentDAO().queryPayedMoney(mp);
        if (payedMoney.longValue() > 0) {
            jsonResult.setRet("1");
            jsonResult.setMsg("已支付，不能删除！");
            jsonResult.setResult(1);
            return jsonResult;
        } else {
            int num = getGesOrderDAO().deleteGesOrder(order);
            if (num > 0) {
                jsonResult.setRet("0");
                jsonResult.setMsg("删除成功！");
                jsonResult.setResult(0);
            } else {
                jsonResult.setRet("2");
                jsonResult.setMsg("删除失败！");
                jsonResult.setResult(1);
            }
            return jsonResult;
        }
    }

    /**
     * Ges 构家网用户 分页获取订单信息
     * 
     * @param gesOrder
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesOrderVO> queryOrderInfoForExcel(GesOrderVO gesOrderVO) {
        return this.getGesOrderDAO().queryOrderInfoForExcel(gesOrderVO);
    }

    /**
     * 核对合同
     */
    @Override
    @Transactional
    public boolean checkValidateCode(GesOrder order, SmsValidation smsValidation) {
        if (StringUtil.isBlank(smsValidation.getMobile()) || StringUtil.isBlank(smsValidation.getValidateCode())
                || StringUtil.isBlank(smsValidation.getEvent())) {
            return false;
        }
        // 1绑定手机 2下单 3核对合同
        if (smsValidation.getEvent().endsWith("order")) {
            smsValidation.setEvent(2 + "");
        } else if (smsValidation.getEvent().endsWith("3")) {
            smsValidation.setEvent(3 + "");
        } else {
            smsValidation.setEvent("1");
        }
        List<SmsValidation> list = getSmsValidationDAO().querySmsValidationByMobileAndCode(smsValidation);
        if (list == null || list.size() < 1) {
            return false;
        }
        multiplePaymentService.checkContractUpdateStatus(order.getUser().getId(), order.getId(),
                smsValidation.getMobile());
        long time = list.get(0).getCreatedDatetime().getTime();
        long now = new Date().getTime();
        log.info("当前时间为：" + now + ",验证码为：" + smsValidation.getValidateCode() + ",手机号为：" + smsValidation.getMobile());
        if (time + 30 * 60 * 1000 > now) {
            return true;
        } else {
            return false;
        }

    }

}
