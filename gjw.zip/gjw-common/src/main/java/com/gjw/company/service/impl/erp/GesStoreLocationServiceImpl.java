package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesStoreLocationService;
import com.gjw.entity.store.GesStoreLocation;
import com.gjw.utils.StringUtil;

/**
 * 库位管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 上午9:25:28
 * 
 */
@Service("gesStoreLocationServiceImpl")
public class GesStoreLocationServiceImpl extends AbstractServiceImpl implements IGesStoreLocationService {

    /**
     * 库位分页总数
     */
    @Override
    @Transactional(readOnly = true)
    public Long count(GesStoreLocation model) {
        return super.getGesStoreLocationDAO().count(model);
    }

    /**
     * 库位分页查询
     */
    @Override
    @Transactional(readOnly = true)
    public List<?> pageByStoreLocation(GesStoreLocation model) {
        return super.getGesStoreLocationDAO().pageByStoreLocation(model);
    }

    /**
     * 根据Id查询库位信息
     */
    @Override
    @Transactional(readOnly = true)
    public GesStoreLocation getByID(Long id) {

        return super.getGesStoreLocationDAO().getById(id);
    }

    /**
     * 修改库位信息
     */
    @Override
    @Transactional
    public boolean update(GesStoreLocation model) {
        GesStoreLocation model1 = (GesStoreLocation) super.getGesStoreLocationDAO().getById(model.getId());
        StringUtil.copyProperties(model, model1);
        // model1.setInvalid(model.getInvalid());
        int i = super.getGesStoreLocationDAO().update(model1);
        return i == 1;
    }

    /**
     * 新增库位信息
     */
    @Override
    @Transactional
    public boolean create(GesStoreLocation model) {
        return super.getGesStoreLocationDAO().saveResultBoolean(model);
    }

    /**
     * 删除库位
     */
    @Override
    @Transactional
    public boolean delBatchById(String ids) {
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesStoreLocation StoreLocation = new GesStoreLocation();
            StoreLocation.setId(Long.parseLong(id));
            StoreLocation.setInvalid(true);
            update(StoreLocation);
        }
        return true;
    }

}
