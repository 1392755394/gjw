package com.gjw.company.service.user;

import com.gjw.entity.user.User;


public interface IValidateService {
    public void validateEmail(String email);
    public void validateMobile(String mobile);
    public void validateUsername(String username);
    public void validate(User user);
}
