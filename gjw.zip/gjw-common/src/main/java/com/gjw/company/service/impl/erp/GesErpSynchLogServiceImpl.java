package com.gjw.company.service.impl.erp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.erp.IGesErpSynchLogService;
import com.gjw.entity.erp.GesErpSynchLog;

@Service("gesErpSynchLogServiceImpl")
public class GesErpSynchLogServiceImpl extends AbstractServiceImpl implements IGesErpSynchLogService {

    @Override
    @Transactional(readOnly = true)
    public List<GesErpSynchLog> pageByGesErpSynchLog(GesErpSynchLog gesErpSynchLog) {

        List<GesErpSynchLog> list = super.getGesErpSynchLogDAO().pageByGesErpSynchLog(gesErpSynchLog);
        for (GesErpSynchLog model : list) {
            model.getOperaterId().initPlatformUserInfo(PlatformEnum.Ges).getRealName();
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(GesErpSynchLog gesErpSynchLog) {

        return super.getGesErpSynchLogDAO().count(gesErpSynchLog);
    }

    @Override
    @Transactional
    public Boolean addGesErpSynchLog(GesErpSynchLog gesErpSynchLog) {
        return super.getGesErpSynchLogDAO().addGesErpSynchLog(gesErpSynchLog);
    }

}
