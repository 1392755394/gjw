package com.gjw.company.service.impl.modelling;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.modelling.IModellingService;
import com.gjw.entity.modelling.Modelling;
import com.gjw.utils.StringUtil;

/**
 * 
* @Description: 造型库service实现类
* @author  zhaoyonglian
* @date 2016年1月9日 下午3:32:53
*
 */
@Component("modellingServiceImpl")
public class ModellingServiceImpl extends AbstractServiceImpl implements IModellingService {

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        return super.getModellingDao().delBatchByID(ids);
    }


    @Override
    @Transactional(readOnly = true)
    public List<Modelling> pageByCondition(Modelling modelling) {
        // TODO Auto-generated method stub
        List<Modelling> list =  super.getModellingDao().pageByCondition(modelling);
        if(null != list && list.size()>0){
            for (Modelling mod : list) {
                Hibernate.initialize(mod.getStyle());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByCondition(Modelling modelling) {
        // TODO Auto-generated method stub
        return super.getModellingDao().countByCondition(modelling);
    }

    @Override
    @Transactional(readOnly = true)
    public Modelling queryByID(Long id) {
        // TODO Auto-generated method stub
        Modelling model = super.getModellingDao().queryByID(id);
        if(StringUtil.notEmpty(model) && StringUtil.notEmpty(model.getStyle())){
            Hibernate.initialize(model.getStyle());
        }
        if(StringUtil.notEmpty(model) && StringUtil.notEmpty(model.getPhoto())){
            Hibernate.initialize(model.getPhoto());
        }
        return model;
    }

    @Override
    @Transactional
    public boolean update(Modelling modelling) {
        // TODO Auto-generated method stub
        return super.getModellingDao().updateModelling(modelling);
    }


    @Override
    @Transactional
    public boolean create(Modelling modelling) {
        // TODO Auto-generated method stub
        return super.getModellingDao().saveResultBoolean(modelling);
    }
}