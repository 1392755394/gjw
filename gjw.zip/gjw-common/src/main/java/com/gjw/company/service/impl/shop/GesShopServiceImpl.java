package com.gjw.company.service.impl.shop;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.service.shop.IGesShopService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.entity.shop.GesShopOrderFeedback;
import com.gjw.entity.shop.GesShopPhotoItem;
import com.gjw.entity.shop.GesShopWorker;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesShopVO;

@Service("gesShopServiceImpl")
public class GesShopServiceImpl extends AbstractServiceImpl implements IGesShopService {
    /**
     * 根据ID查询4S店
     */
    @Override
    @Transactional(readOnly = true)
    public GesShop listByID(Long id) {
        // TODO Auto-generated method stub
        GesShop model = super.getGesShopDAO().listByID(id);
        if (null != model) {
            if (null != model.getOperator()) {
                Hibernate.initialize(model.getOperator());
            }
            if (null != model.getUser()) {
                Hibernate.initialize(model.getUser());
            }
            if (null != model.getDictionary()) {
                Hibernate.initialize(model.getDictionary());
            }
            if (null != model.getBanner()) {
                Hibernate.initialize(model.getBanner());
            }
            if (null != model.getPhoto()) {
                Hibernate.initialize(model.getPhoto());
            }
            if (null != model.getProvince()) {
                Hibernate.initialize(model.getProvince());
            }
            if (null != model.getCity()) {
                Hibernate.initialize(model.getCity());
            }
            if (null != model.getCounty()) {
                Hibernate.initialize(model.getCounty());
            }
            if (null != model.getBdManager()) {
                Hibernate.initialize(model.getBdManager());
                model.getBdManager().initPlatformUserInfo(PlatformEnum.Ges);
            }
            if (null != model.getService()) {
                Hibernate.initialize(model.getService());
                model.getService().initPlatformUserInfo(PlatformEnum.Ges);
            }
            if(null!=model.getShopType()){
                Hibernate.initialize(model.getShopType());
            }
        }
        return model;
    }

    /**
     * 更新4S店信息
     */
    @Override
    @Transactional()
    public boolean updateGesShop(GesShop model) {
        // TODO Auto-generated method stub
        GesShop item = super.getGesShopDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        if(null==model.getFoundDate() || "".equals(model.getFoundDate())){
            item.setFoundDate(null);
        }
        if(null==model.getShopType() || null==model.getShopType().getId()){
            item.setShopType(null);
        }
        if(null==model.getCounty() || null==model.getCounty().getId()){
            item.setCounty(null);
        }
        return super.getGesShopDAO().updateGesShop(item);
    }

    /**
     * 创建4S店
     */
    @Override
    @Transactional()
    public boolean createGesShop(GesShop model) {
        // TODO Auto-generated method stub
        model.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        model.setStatus(1);
        model.setType(null);
        model.setCode("15" + String.valueOf(System.currentTimeMillis()).substring(5));
        if(null==model.getShopType() || null==model.getShopType().getId()){
            model.setShopType(null);
        }
        if(null==model.getCounty() || null==model.getCounty().getId()){
            model.setCounty(null);
        }
        return super.getGesShopDAO().createGesShop(model);
    }

    /**
     * 统计4S店总数
     */
    @Override
    @Transactional(readOnly = true)
    public long count(GesShop model) {
        // TODO Auto-generated method stub
        return super.getGesShopDAO().count(model);
    }

    /**
     * 4S店列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesShop> listByGesShop(GesShop model) {
        // TODO Auto-generated method stub
        List<GesShop> list = super.getGesShopDAO().listByGesShop(model);
        for (GesShop gesShop : list) {
            Hibernate.initialize(gesShop.getDictionary());
            Hibernate.initialize(gesShop.getOperator());
            Hibernate.initialize(gesShop.getProvince());
            Hibernate.initialize(gesShop.getCity());
            Hibernate.initialize(gesShop.getCounty());
            Hibernate.initialize(gesShop.getPhoto());
            Hibernate.initialize(gesShop.getBanner());
            Hibernate.initialize(gesShop.getBdManager());
            Hibernate.initialize(gesShop.getService());
            Hibernate.initialize(gesShop.getUser());
            if(null!=gesShop.getBdManager()){
                gesShop.getBdManager().initPlatformUserInfo(PlatformEnum.Ges);
            }
        }
        return list;
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<GesShopVO> listByGesShop4Export(GesShop model) {
       return  super.getGesShopDAO().listByGesShop4Export(model);
    }

    /**
     * 4S店与产品包
     */
    @Override
    @Transactional(readOnly = true)
    public GesShopGoodsItem listByGesShopGoodsItemID(Long id) {
        // TODO Auto-generated method stub
        GesShopGoodsItem model = super.getGesShopGoodsItemDAO().listByID(id);

        return model;
    }

    /**
     * 更新4S店与产品包中间关系
     */
    @Override
    @Transactional()
    public boolean updateGesShopGoodsItem(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        GesShopGoodsItem item = super.getGesShopGoodsItemDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        Hibernate.initialize(item.getGoods());
        // if(null!=item.getStatus()){
        // item.getGoods().setStatus(item.getStatus());
        // super.getGoodsDAO().update(item.getGoods());
        // }
        return super.getGesShopGoodsItemDAO().updateGesShopGoodsItem(item);
    }

    /**
     * 批量删除4S店与产品包的关系
     */
    @Override
    @Transactional()
    public boolean deleteGesShopGoodsItem(String ids) {
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesShopGoodsItem item = super.getGesShopGoodsItemDAO().listByID(Long.valueOf(id));
            item.setInvalid(true);
            super.getGesShopGoodsItemDAO().updateGesShopGoodsItem(item);
        }
        return true;
    }

    /**
     * 创建4S店与产品包的关系
     */
    @Override
    @Transactional()
    public boolean createGesShopGoodsItem(String ids, Long shopId) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        List<GesShopGoodsItem> list = new ArrayList<GesShopGoodsItem>();
        for (String id : idArray) {
            GesShopGoodsItem model = new GesShopGoodsItem();
            GesShop shop = new GesShop();
            shop.setId(shopId);
            model.setShop(shop);
            Goods goods = new Goods();
            goods.setId(Long.valueOf(id));
            model.setGoods(goods);
            model.setInvalid(false);
            GesShopGoodsItem item = this.listByShopAndGood(model);
            if (null == item) {
                list.add(model);
            } else {
                return false;
            }
        }
        for (GesShopGoodsItem gesShopGoodsItem : list) {
            super.getGesShopGoodsItemDAO().createGesShopGoodsItem(gesShopGoodsItem);
        }
        return true;
    }

    /**
     * 统计4S店与产品包的总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesShopGoodsItemCount(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        return super.getGesShopGoodsItemDAO().count(model);
    }

    /**
     * 4S店与产品包的列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        List<GesShopGoodsItem> list = super.getGesShopGoodsItemDAO().listByGesShopGoodsItem(model);
        for (GesShopGoodsItem gesShopGoodsItem : list) {
            Hibernate.initialize(gesShopGoodsItem.getShop());
            if (null != gesShopGoodsItem.getShop()) {
                Hibernate.initialize(gesShopGoodsItem.getShop().getOperator());
            }
            Hibernate.initialize(gesShopGoodsItem.getGoods());
            if (null != gesShopGoodsItem.getGoods() && null != gesShopGoodsItem.getGoods().getHouse()
                    && null != gesShopGoodsItem.getGoods().getHouse().getBuilding()) {
                Hibernate.initialize(gesShopGoodsItem.getGoods().getHouse().getBuilding());
            }
            if (null != gesShopGoodsItem.getGoods() && null != gesShopGoodsItem.getGoods().getPhoto()) {
                Hibernate.initialize(gesShopGoodsItem.getGoods().getPhoto());
            }
            if (null != gesShopGoodsItem.getGoods()) {
                Hibernate.initialize(gesShopGoodsItem.getGoods().getStyle());
                Hibernate.initialize(gesShopGoodsItem.getGoods().getHouse());
                Hibernate.initialize(gesShopGoodsItem.getGoods().getHouseType());
            }
        }
        return list;
    }

    /**
     * 4S店与订单
     */
    @Override
    @Transactional(readOnly = true)
    public GesShopOrderFeedback listByGesShopOrderFeedbackID(Long id) {
        // TODO Auto-generated method stub
        GesShopOrderFeedback model = super.getGesShopOrderFeedbackDAO().listByID(id);
        Hibernate.initialize(model.getGesOrder());
        if (null != model.getGesOrder()) {
            Hibernate.initialize(model.getGesOrder().getGoods());
            Hibernate.initialize(model.getDictionary());
        }
        return model;
    }

    /**
     * 更新4S店与订单关系
     */
    @Override
    @Transactional()
    public boolean updateGesShopOrderFeedback(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        GesShopOrderFeedback item = super.getGesShopOrderFeedbackDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesShopOrderFeedbackDAO().updateGesShopOrderFeedback(item);
    }

    /**
     * 创建4S店与订单关系
     */
    @Override
    @Transactional()
    public boolean createGesShopOrderFeedback(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        return super.getGesShopOrderFeedbackDAO().createGesShopOrderFeedback(model);
    }

    /**
     * 统计4S店与订单总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesShopOrderFeedbackCount(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        return super.getGesShopOrderFeedbackDAO().count(model);
    }

    /**
     * 4S店与订单列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesShopOrderFeedback> listByGesShopOrderFeedback(GesShopOrderFeedback model) {
        // TODO Auto-generated method stub
        List<GesShopOrderFeedback> list = super.getGesShopOrderFeedbackDAO().listByGesShopOrderFeedback(model);
        for (GesShopOrderFeedback gesShopOrderFeedback : list) {
            Hibernate.initialize(gesShopOrderFeedback.getGesOrder());
            Hibernate.initialize(gesShopOrderFeedback.getDictionary());
            Hibernate.initialize(gesShopOrderFeedback.getUser());
            if (null != gesShopOrderFeedback.getGesOrder()) {
                Hibernate.initialize(gesShopOrderFeedback.getGesOrder().getShop());
                Hibernate.initialize(gesShopOrderFeedback.getGesOrder().getUser());
                Hibernate.initialize(gesShopOrderFeedback.getGesOrder().getGoods());
            }
        }
        return list;
    }

    /**
     * 根据ID查询4S店与相册关系
     */
    @Override
    @Transactional(readOnly = true)
    public GesShopPhotoItem listByGesShopPhotoItemID(Long id) {
        // TODO Auto-generated method stub
        GesShopPhotoItem model = super.getGesShopPhotoItemDAO().listByID(id);
        return model;
    }

    /**
     * 更新4S店与相册
     */
    @Override
    @Transactional()
    public boolean updateGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        GesShopPhotoItem item = super.getGesShopPhotoItemDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesShopPhotoItemDAO().updateGesShopPhotoItem(item);
    }

    /**
     * 删除4S店与相册
     */
    @Override
    @Transactional()
    public boolean deleteGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        GesShopPhotoItem item = super.getGesShopPhotoItemDAO().listByID(model.getId());
        item.setInvalid(true);
        return super.getGesShopPhotoItemDAO().updateGesShopPhotoItem(item);
    }

    /**
     * 创建4S店与相册关系
     */
    @Override
    @Transactional()
    public boolean createGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        if (null != model) {
            model.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        }
        if (null != model.getPhoto()) {
            model.getPhoto().setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        }
        return super.getGesShopPhotoItemDAO().createGesShopPhotoItem(model);
    }

    /**
     * 统计4S店与相册总数
     */
    @Override
    @Transactional(readOnly = true)
    public long GesShopPhotoItemCount(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        return super.getGesShopPhotoItemDAO().count(model);
    }

    /**
     * 4S店与相册列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesShopPhotoItem> listByGesShopPhotoItem(GesShopPhotoItem model) {
        // TODO Auto-generated method stub
        List<GesShopPhotoItem> list = super.getGesShopPhotoItemDAO().listByGesShopOrderFeedback(model);
        for (GesShopPhotoItem gesShopPhotoItem : list) {
            Hibernate.initialize(gesShopPhotoItem.getPhoto());
        }
        return list;
    }

    /**
     * 根据ID查询4S店与员工
     */
    @Override
    @Transactional(readOnly = true)
    public GesShopWorker listByGesShopWorkerID(Long id) {
        // TODO Auto-generated method stub
        GesShopWorker model = super.getGesShopWorkerDAO().listByID(id);
        Hibernate.initialize(model.getShop());
        return model;
    }

    /**
     * 更新4S店员工信息
     */
    @Override
    @Transactional()
    public boolean updateGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        GesShopWorker item = super.getGesShopWorkerDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesShopWorkerDAO().updateGesShopWorker(item);
    }

    /**
     * 批量删除4S店员工
     */
    @Transactional
    @Override
    public boolean delelteGesShopWorker(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesShopWorker item = super.getGesShopWorkerDAO().listByID(Long.valueOf(id));
            item.setInvalid(true);
            super.getGesShopWorkerDAO().updateGesShopWorker(item);
        }
        return true;
    }

    /**
     * 创建4S店员工
     */
    @Override
    @Transactional()
    public boolean createGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        model.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        return super.getGesShopWorkerDAO().createGesShopWorker(model);
    }

    /**
     * 获取4S店员工总数
     */
    @Override
    @Transactional(readOnly = true)
    public long gesShopWorkerCount(GesShopWorker model) {
        // TODO Auto-generated method stub
        return super.getGesShopWorkerDAO().count(model);
    }

    /**
     * 获取4S店员工列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<GesShopWorker> listByGesShopWorker(GesShopWorker model) {
        // TODO Auto-generated method stub
        List<GesShopWorker> list = super.getGesShopWorkerDAO().listByGesShopWorker(model);
        for (GesShopWorker gesShopWorker : list) {
            Hibernate.initialize(gesShopWorker.getShop());
        }
        return list;
    }

    /**
     * 添加4S店产品包关系之前判断之前是否添加过相同的
     */
    @Override
    @Transactional(readOnly = true)
    public GesShopGoodsItem listByShopAndGood(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        return super.getGesShopGoodsItemDAO().listByShopAndGood(model);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GesShop> listShopByGoods(Goods goods) {
        List<GesShop> list = super.getGesShopGoodsItemDAO().listShopByGoods(goods);
        for (GesShop shop : list) {
            Hibernate.initialize(shop.getPhoto());
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public String getShopGoodsIds(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        String flag = "";
        GesShopGoodsItem mode = new GesShopGoodsItem();
        mode.setPageNo(null);
        mode.setPageSize(null);
        GesShop shop = new GesShop();
        if (null != model.getShop() && null != model.getShop().getId()) {
            shop.setId(model.getShop().getId());
            mode.setShop(shop);
        }
        List<GesShopGoodsItem> list = super.getGesShopGoodsItemDAO().listByGesShopGoodsItem(mode);
        for (GesShopGoodsItem gesShopGoodsItem : list) {
            flag = flag + gesShopGoodsItem.getGoods().getId() + ",";
        }
        if (null != flag && !"".equals(flag)) {
            flag = flag.substring(0, flag.length() - 1);
        }
        return flag;
    }

    @Override
    @Transactional(readOnly = true)
    public GesShop getShopCityIdByUserId(Long id) {

        GesShop shop = super.getGesShopDAO().getShopCityIdByUserId(id);
        if (shop != null) {
            Hibernate.initialize(shop.getCity());
        }
        return shop;
    }

}
