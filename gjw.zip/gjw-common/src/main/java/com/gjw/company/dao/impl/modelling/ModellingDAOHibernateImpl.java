package com.gjw.company.dao.impl.modelling;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.modelling.IModellingDAO;
import com.gjw.entity.modelling.Modelling;
import com.gjw.utils.StringUtil;

/**
 * 物料dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月16日
 * 
 */
@Component("modellingDAOHibernateImpl")
public class ModellingDAOHibernateImpl extends AbstractDAOHibernateImpl implements IModellingDAO {

    @Override
    protected Class<?> getEntityClass() {
        return Modelling.class;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<Modelling> pageByCondition(Modelling modelling) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from Modelling where invalid = 0");
        if(StringUtil.notEmpty(modelling.getName())){
            hql.append(" and name like ?");
            ls.add("%"+modelling.getName()+"%");
        }
        if(StringUtil.notEmpty(modelling.getCode())){
            hql.append(" and code = ?");
            ls.add(modelling.getCode());
        }
        if(StringUtil.notEmpty(modelling.getStyle()) && StringUtil.notEmpty(modelling.getStyle().getText())){
            hql.append(" and style.text like ?");
            ls.add("%"+modelling.getStyle().getText()+"%");
        }
        hql.append(" order by id desc");
        return (List<Modelling>) super.findByListCallBack(hql.toString(), "", ls, null);
    }

    @Override
    public Long countByCondition(Modelling modelling) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from Modelling where invalid = 0");
        if(StringUtil.notEmpty(modelling.getName())){
            hql.append(" and name like ?");
            ls.add("%"+modelling.getName()+"%");
        }
        if(StringUtil.notEmpty(modelling.getCode())){
            hql.append(" and code = ?");
            ls.add(modelling.getCode());
        }
        if(StringUtil.notEmpty(modelling.getStyle()) && StringUtil.notEmpty(modelling.getStyle().getText())){
            hql.append(" and style.text like ?");
            ls.add("%"+modelling.getStyle().getText()+"%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public Modelling queryByID(Long id) {
        // TODO Auto-generated method stub
        return (Modelling) super.get(id);
    }

    @Override
    public boolean updateModelling(Modelling modelling) {
        // TODO Auto-generated method stub
        Modelling old = (Modelling) super.get(modelling.getId());
        if(StringUtil.notEmpty(modelling.getPhoto()) && null == modelling.getPhoto().getId()){
            modelling.setPhoto(null);
        }
        StringUtil.copyProperties(modelling, old);
        return super.update(old)>0;
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }

}
