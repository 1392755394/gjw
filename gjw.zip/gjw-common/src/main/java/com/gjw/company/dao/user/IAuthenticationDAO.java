package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.Authentication;
import com.gjw.entity.user.User;

/**
 * 
* @Description: 
* @author  qingye
* @date Dec 23, 2015 3:27:20 PM
*
 */
public interface IAuthenticationDAO extends IDAO {

    Authentication getByLogin(String login, String className);

    List<Authentication> findByUser(User user);

    void updateByUser(Authentication auth);

    Authentication getByLoginTypeAndUser(User user, String className);

    List<Authentication> listAllForPassword();
}
