package com.gjw.company.dao.impl.cooperator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cooperator.IWebCooperatorDAO;
import com.gjw.entity.cooperator.WebCooperator;
import com.gjw.utils.StringUtil;

@Component("webCooperatorDAOHibernateImpl")
public class WebCooperatorDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebCooperatorDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebCooperator.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebCooperator> pageByCondition(WebCooperator cooperator) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebCooperator as wc where wc.id != 0");
        if (StringUtil.notEmpty(cooperator.getCompany())) {
            hql.append(" and wc.company like ?");
            ls.add("%" + cooperator.getCompany() + "%");
        }
        if (StringUtil.notEmpty(cooperator.getCity())) {
            hql.append(" and wc.city like ?");
            ls.add("%" + cooperator.getCity() + "%");
        }
        if (null != cooperator.getPropertyType() && 0l != cooperator.getPropertyType().getId()) {
            hql.append(" and wc.propertyType.id = ?");
            ls.add(cooperator.getPropertyType().getId());
        }
        hql.append("order by wc.id desc");
        return (List<WebCooperator>) super.findByPageCallBack(hql.toString(), "", ls, cooperator, null);
    }

    @Override
    public Long countByCondition(WebCooperator cooperator) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebCooperator as wc where wc.id != 0");
        if (StringUtil.notEmpty(cooperator.getCompany())) {
            hql.append(" and wc.company like ?");
            ls.add("%" + cooperator.getCompany() + "%");
        }
        if (StringUtil.notEmpty(cooperator.getCity())) {
            hql.append(" and wc.city like ?");
            ls.add("%" + cooperator.getCity() + "%");
        }
        if (null != cooperator.getPropertyType() && 0l != cooperator.getPropertyType().getId()) {
            hql.append(" and wc.propertyType.id = ?");
            ls.add(cooperator.getPropertyType().getId());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

}
