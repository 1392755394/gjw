package com.gjw.company.service.impl.building;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.company.service.building.IGesBuildingService;
import com.gjw.entity.building.GesBuilding;
import com.gjw.entity.building.GesBuildingCityOperatorItem;
import com.gjw.entity.building.GesBuildingColorConfig;
import com.gjw.entity.building.GesBuildingPhotoItem;
import com.gjw.entity.building.House;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsVO;
@Service("gesBuildingServiceImpl")
public class GesBuildingServiceImpl extends AbstractServiceImpl implements IGesBuildingService{
    /**
     * 根据楼盘ID查询楼盘信息
     */
    @Transactional(readOnly=true)
    @Override
    public GesBuilding listByID(Long id) {
        // TODO Auto-generated method stub
        GesBuilding building=super.getGesBuildingDAO().listByID(id);
        Hibernate.initialize(building.getPhoto());
        Hibernate.initialize(building.getDictionary());
        Hibernate.initialize(building.getConstructionCategory());
        Hibernate.initialize(building.getProvince());
        Hibernate.initialize(building.getCity());
        Hibernate.initialize(building.getCounty());
        Hibernate.initialize(building.getLogo());
        return building;
    }
    /**
     * 批量删除楼盘
     */
    @Transactional
    @Override
    public boolean updateGesBuilding(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            GesBuilding building=super.getGesBuildingDAO().listByID(Long.valueOf(id));
            building.setInvalid(true);
            super.getGesBuildingDAO().updateGesBuilding(building);
        }
        return true;
    }
    /**
     * 创建楼盘
     */
    @Transactional
    @Override
    public boolean createGesBuilding(GesBuilding model) {
        // TODO Auto-generated method stub
        if(null==model.getLogo().getId()){
            model.setLogo(null);
        }
        return super.getGesBuildingDAO().createGesBuilding(model);
    }
    /**
     * 楼盘分页
     */
    @Transactional(readOnly=true)
    @Override
    public List<GesBuilding> listByGesBuilding(GesBuilding building) {
        // TODO Auto-generated method stub
        List<GesBuilding> list=super.getGesBuildingDAO().listByGesBuilding(building);
        for (GesBuilding gesBuilding : list) {
            Hibernate.initialize(gesBuilding.getPhoto());
            Hibernate.initialize(gesBuilding.getProvince());
            Hibernate.initialize(gesBuilding.getCity());;
            Hibernate.initialize(gesBuilding.getCounty());
            GesBuildingCityOperatorItem item=super.getGesBuildingCityOperatorItemDAO().listByBuildingId(gesBuilding.getId());
            if(null!=item){
                item.setBuilding(null);
                Hibernate.initialize(item.getOperator());
                gesBuilding.setGesbuildingCityOperatorItem(item);
            }
        }
        return list;
    }
    /**
     * 统计楼盘总数
     */
    @Transactional(readOnly=true)
    @Override
    public long count(GesBuilding building) {
        // TODO Auto-generated method stub
        return super.getGesBuildingDAO().count(building);
    }
    /**
     * 解除楼盘和城运商关联
     */
    @Override
    @Transactional()
    public boolean updateBuildingAndBulingCityOperatorItem(GesBuilding model, Long buildingItemId) {
        // TODO Auto-generated method stub
        GesBuilding building=super.getGesBuildingDAO().listByID(model.getId());
        Hibernate.initialize(building.getPhoto());
        Hibernate.initialize(building.getLogo());
        StringUtil.copyProperties(model,building);
        if(null==building.getLogo() || null==building.getLogo().getId()){
            building.setLogo(null);
        }
        super.getGesBuildingDAO().updateGesBuilding(building);
        if(null!=buildingItemId && 0!=buildingItemId){
            GesBuildingCityOperatorItem buildingCityItem=super.getGesBuildingCityOperatorItemDAO().listByID(buildingItemId);
            buildingCityItem.setInvalid(true);
            super.getGesBuildingCityOperatorItemDAO().updateGesBuildingCityOperatorItem(buildingCityItem);
        }
        return true;
    }
    /**
     * 创建楼盘与城运商的关系
     */
    @Override
    @Transactional()
    public boolean createBulingCityOperatorItem(GesBuildingCityOperatorItem model){
        GesBuilding building=super.getGesBuildingDAO().listByID(model.getBuilding().getId());
        GesCityOperator cityOperator=super.getGesCityOperatorDAO().listByID(model.getOperator().getId());
        building.setStatus(3);
        model.setBuilding(building);
        model.setOperator(cityOperator);
        model.setInvalid(false);
        super.getGesBuildingCityOperatorItemDAO().saveOrUpdate(model);
        return true;
    }
    /**
     * 获取未与楼盘合作城运商列表
     */
    @Override
    @Transactional(readOnly=true)
    public List<GesBuildingCityOperatorItem> listByGesBuildingCityOperatorItem(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        List<GesBuildingCityOperatorItem> list=super.getGesBuildingCityOperatorItemDAO().listByGesBuildingCityOperatorItem(model);
        for (GesBuildingCityOperatorItem gesBuildingCityOperatorItem : list) {
            Hibernate.initialize(gesBuildingCityOperatorItem.getBuilding());
            if(null!=gesBuildingCityOperatorItem.getBuilding() && null!=gesBuildingCityOperatorItem.getBuilding().getPhoto()){
                Hibernate.initialize(gesBuildingCityOperatorItem.getBuilding().getPhoto());
            }
            if(null!=gesBuildingCityOperatorItem.getBuilding() && null!=gesBuildingCityOperatorItem.getBuilding().getCity()){
                Hibernate.initialize(gesBuildingCityOperatorItem.getBuilding().getCity());
            }
            Hibernate.initialize(gesBuildingCityOperatorItem.getOperator());
        }
        return list;
    }
    /**
     * 获取未与楼盘合作城运商总数
     */
    @Override
    @Transactional(readOnly=true)
    public Long listByGesBuildingCityOperatorItemCount(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        return super.getGesBuildingCityOperatorItemDAO().count(model);
    }
    /**
     * 获取楼盘相册
     */
    @Override
    @Transactional(readOnly=true)
    public GesBuildingPhotoItem listByGesBuildingPhotoItemID(Long id) {
        // TODO Auto-generated method stub
        return super.getGesBuildingPhotoItemDAO().listByID(id);
    }
    /**
     * 更新楼盘相册图片状态
     */
    @Override
    @Transactional()
    public boolean updateGesBuildingPhotoItem(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        GesBuildingPhotoItem item=super.getGesBuildingPhotoItemDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        if(null!=model.getInvalid()){
            item.setInvalid(model.getInvalid());
        }
        return super.getGesBuildingPhotoItemDAO().updateGesBuildingPhotoItem(item);
    }
    /**
     * 创建楼盘相册图片信息记录
     */
    @Override
    @Transactional()
    public boolean createGesBuildingPhotoItem(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        model.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
        return super.getGesBuildingPhotoItemDAO().createGesBuildingPhotoItem(model);
    }
    /**
     * 楼盘相册图片总数
     */
    @Override
    @Transactional(readOnly=true)
    public long gesBuildingPhotoItemcount(GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        return super.getGesBuildingPhotoItemDAO().count(model);
    }
    /**
     * 楼盘相册图片列表
     */
    @Override
    @Transactional(readOnly=true)
    public List<GesBuildingPhotoItem> listByGesBuildingPhotoItem(
            GesBuildingPhotoItem model) {
        // TODO Auto-generated method stub
        List<GesBuildingPhotoItem> list=super.getGesBuildingPhotoItemDAO().listByGesBuildingPhotoItem(model);
        for (GesBuildingPhotoItem gesBuildingPhotoItem : list) {
            Hibernate.initialize(gesBuildingPhotoItem.getPhoto());
            if(null!=gesBuildingPhotoItem.getDictionary()){
                Hibernate.initialize(gesBuildingPhotoItem.getDictionary());
            }
        }
        return list;
    }
    /**
     * 根据ID查询house
     */
    @Override
    @Transactional(readOnly=true)
    public House listByHouseID(Long id) {
        // TODO Auto-generated method stub
        House house=super.getHouseDAO().listByID(id);
        Hibernate.initialize(house.getType());
        Hibernate.initialize(house.getPhoto());
        Hibernate.initialize(house.getFloorPlan());
        Hibernate.initialize(house.getBuilding());
        return super.getHouseDAO().listByID(id);
    }
    /**
     * 更新house
     */
    @Override
    @Transactional()
    public boolean updateHouse(House model) {
        // TODO Auto-generated method stub
        if(null!=model.getId()){
            House house=super.getHouseDAO().listByID(model.getId());
            StringUtil.copyProperties(model, house);
            return super.getHouseDAO().updateHouse(house);
        }else{
            model.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            return super.getHouseDAO().createHouse(model);
        }
    }
    /**
     * 创建house
     */
    @Override
    @Transactional()
    public boolean createHouse(House model) {
        // TODO Auto-generated method stub
        return super.getHouseDAO().createHouse(model);
    }
    /**
     * 统计house总数
     */
    @Override
    @Transactional(readOnly=true)
    public long houseCount(House model) {
        // TODO Auto-generated method stub
        return super.getHouseDAO().count(model);
    }
    /**
     * house列表
     */
    @Override
    @Transactional(readOnly=true)
    public List<House> listByHouse(House model) {
        // TODO Auto-generated method stub
        List<House> list=super.getHouseDAO().listByHouse(model);
        for (House house : list) {
            Hibernate.initialize(house.getType());
        }
        return list;
    }
    /**
     * 批量删除house
     */
    @Override
    @Transactional()
    public boolean deleteHouse(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        for (String id : idArray) {
            House house=super.getHouseDAO().listByID(Long.valueOf(id));
            house.setInvalid(true);
            super.getHouseDAO().updateHouse(house);
        }
        return true;
    }
    /**
     * 删除城运商与楼盘关联
     */
    @Override
    @Transactional()
    public boolean deleteGesBuildingCityOperatorItem(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        GesBuildingCityOperatorItem item=super.getGesBuildingCityOperatorItemDAO().listByID(model.getId());
        item.setInvalid(true);
        if(null!=model.getBuilding() && null!=model.getBuilding().getId()){
            GesBuilding building=super.getGesBuildingDAO().listByID(model.getBuilding().getId());
            building.setStatus(2);
            super.getGesBuildingDAO().updateGesBuilding(building);
        }
        return super.getGesBuildingCityOperatorItemDAO().updateGesBuildingCityOperatorItem(item);
    }
    @Transactional(readOnly=true)
    @Override
    public GesBuildingColorConfig listGesBuildingColorConfigByID(Long id) {
        // TODO Auto-generated method stub
        GesBuildingColorConfig model=super.getGesBuildingColorConfigDAOHibernateImpl().listByID(id);
        return model;
    }
    @Transactional()
    @Override
    public boolean updateGesBuildingColorConfig(GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        GesBuildingColorConfig modelFlag=super.getGesBuildingColorConfigDAOHibernateImpl().listByID(model.getId());
        StringUtil.copyProperties(model, modelFlag);
        return super.getGesBuildingColorConfigDAOHibernateImpl().updateGesBuildingColorConfig(modelFlag);
    }
    @Transactional()
    @Override
    public boolean createGesBuildingColorConfig(
            GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        return super.getGesBuildingColorConfigDAOHibernateImpl().createGesBuildingColorConfig(model);
    }
    @Transactional(readOnly=true)
    @Override
    public long countGesBuildingColorConfig(GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        return super.getGesBuildingColorConfigDAOHibernateImpl().count(model);
    }
    @Transactional(readOnly=true)
    @Override
    public List<GesBuildingColorConfig> listByGesBuildingColorConfig(
            GesBuildingColorConfig model) {
        // TODO Auto-generated method stub
        List<GesBuildingColorConfig> list=super.getGesBuildingColorConfigDAOHibernateImpl().listByGesBuildingColorConfig(model);
        for (GesBuildingColorConfig gesBuildingColorConfig : list) {
            Hibernate.initialize(gesBuildingColorConfig.getBuilding());
        }
        return list;
    }
    /**
     * 楼盘分页
     */
    @Transactional(readOnly=true)
    @Override
    public List<GesBuilding> listByGesBuildingForApp(GesBuilding building) {
        List<GesBuilding> list=super.getGesBuildingDAO().listByGesBuilding(building);
        List<GesBuilding> items=new ArrayList<GesBuilding>();
        for (GesBuilding gesBuilding : list) {
            if(null!=gesBuilding.getName() && gesBuilding.getName().equals("G系列")){
                continue;
            }
            
            GoodsVO goods = new GoodsVO();
            Dictionary goodsType = new Dictionary(GoodsDiyConstant.GOODS_TYPE_Z);
            goods.setGoodsType(goodsType);
            House house = new House();
            house.setBuilding(gesBuilding);
            goods.setHouse(house);

            List<Goods> bgoods = super.getGoodsDAO().pageForWebApp(goods, "Y");
            if(null!=bgoods && bgoods.size()>0){
                Hibernate.initialize(gesBuilding.getPhoto());
                Hibernate.initialize(gesBuilding.getProvince());
                Hibernate.initialize(gesBuilding.getCity());;
                Hibernate.initialize(gesBuilding.getCounty());
                GesBuildingCityOperatorItem item=super.getGesBuildingCityOperatorItemDAO().listByBuildingId(gesBuilding.getId());
                if(null!=item){
                    item.setBuilding(null);
                    Hibernate.initialize(item.getOperator());
                    gesBuilding.setGesbuildingCityOperatorItem(item);
                }
                items.add(gesBuilding);
            }
        }
        return items;
    }

}
