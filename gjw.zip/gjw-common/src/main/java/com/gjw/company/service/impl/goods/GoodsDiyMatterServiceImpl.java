package com.gjw.company.service.impl.goods;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.goods.IGoodsDiyMatterService;
import com.gjw.entity.goods.GoodsDiyMatter;

/**
 * DIY清单service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月28日
 * 
 */
@Component("goodsDiyMatterServiceImpl")
public class GoodsDiyMatterServiceImpl extends AbstractServiceImpl implements IGoodsDiyMatterService {

    @Override
    @Transactional(readOnly = true)
    public List<GoodsDiyMatter> listRoomDiyMatter(Long roomId) {
        List<GoodsDiyMatter> list = super.getGoodsDiyMatterDAO().listRoomDiyMatter(roomId);
        for (GoodsDiyMatter gm: list) {
            Hibernate.initialize(gm.getMark());
            Hibernate.initialize(gm.getMatter().getBrand());
            Hibernate.initialize(gm.getMatter().getImage());
            Hibernate.initialize(gm.getMatter().getEffectImage());
            Hibernate.initialize(gm.getOriginal());
            if (gm.getOriginal() != null) {
                Hibernate.initialize(gm.getOriginal().getBrand());
                Hibernate.initialize(gm.getOriginal().getImage());
            }
        }
        return list;
    }

}
