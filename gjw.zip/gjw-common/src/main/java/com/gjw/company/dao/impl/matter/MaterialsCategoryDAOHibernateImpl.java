package com.gjw.company.dao.impl.matter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.matter.IMaterialsCategoryDAO;
import com.gjw.entity.matter.MaterialsCategory;
import com.gjw.utils.StringUtil;
import com.gjw.vo.MaterialsCategoryVO;

/**
 * 建材类目dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月14日
 * 
 */
@Component("materialsCategoryDAOHibernateImpl")
public class MaterialsCategoryDAOHibernateImpl extends AbstractDAOHibernateImpl implements IMaterialsCategoryDAO {

    @Override
    protected Class<?> getEntityClass() {
        return MaterialsCategory.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<MaterialsCategory> listCategoryByParentId(long parentId) {

        String hql = "from MaterialsCategory m where m.parent.id = ? and m.invalid = false order by m.code asc";

        return (List<MaterialsCategory>) super.getHibernateTemplate().find(hql, parentId);
    }

    @Override
    public Long countCategoryByParentId(long parentId) {

        List<Object> ls = new ArrayList<Object>();
        String hql = "from MaterialsCategory m where m.parent.id = ? and m.invalid = false ";
        ls.add(parentId);

        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public MaterialsCategory queryByID(Long id) {
        return (MaterialsCategory) super.get(id);
    }

    /**
     * 建材库分类同步查询
     * <p>
     * 此处做特殊处理-------因为在与ERP做对接时的规则是必须先有上级编码,而物料分类中的编码上下级不存在关系
     * <p>
     * 如 上级物料编码是A，下级物料编码是H而不是AH，为了符合ERP规范此处写sql直接拼接
     * 
     * 
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Map<String, Object>> listMaterialsCategoryForSynch(MaterialsCategory materialsCategory) {
        String sql = "SELECT   id, name,code, synch_type as type " + " FROM base_materials_category  "
                + " WHERE invalid = '0'  AND PARENT_ID = 1  AND synch_type NOT IN (1130102, 1130105)   "
                + " UNION ALL   " + " SELECT  a.id, a.NAME, CONCAT(b.code, a.CODE), a.synch_type   "
                + " FROM base_materials_category a,  " + "   (SELECT  id,  CODE FROM base_materials_category   "
                + "   WHERE invalid = '0'  AND PARENT_ID = 1) b   "
                + " WHERE a.PARENT_ID = b.id AND a.invalid = '0'   AND a.synch_type not in(1130102,1130105)   "
                + " UNION  ALL  SELECT  gmc.id,gmc.NAME,  CONCAT(gmd.code, gmc.CODE) CODE,gmc.synch_type   "
                + " FROM  base_materials_category gmc,  "
                + "   (SELECT   a.id,  a.NAME, CONCAT(b.code, a.CODE) AS CODE, a.synch_type   "
                + "   FROM base_materials_category a,  " + "   (SELECT  id,  CODE FROM  base_materials_category   "
                + "     WHERE invalid = '0'  AND PARENT_ID = 1) b   "
                + "   WHERE a.PARENT_ID = b.id   AND a.invalid = '0' "
                // +
                // " AND ( a.synch_type not in(1130102,1130105) or a.synch_type is null)"
                + ") gmd   "
                + " WHERE gmc.PARENT_ID = gmd.id  AND gmc.invalid = '0'   AND gmc.synch_type not in(1130102,1130105) ";
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createSQLQuery(sql);
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        return query.list();
    }

    @Override
    public void updateMaterialsCategory(MaterialsCategoryVO obj) {
        String hql = " update MaterialsCategory set synchType.id=? where id=?";
        List<Object> list = new ArrayList<Object>();
        list.add(obj.getType());
        list.add(Long.parseLong(obj.getId()));
        super.updateByParam(hql, list);
    }

    @Override
    public boolean updateCategory(MaterialsCategory materialsCategory) {
        // TODO Auto-generated method stub
        MaterialsCategory old = (MaterialsCategory) super.get(materialsCategory.getId());
        StringUtil.copyProperties(materialsCategory, old);
        super.update(old);
        return true;
    }

}