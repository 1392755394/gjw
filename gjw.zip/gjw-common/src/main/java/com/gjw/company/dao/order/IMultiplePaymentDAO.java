package com.gjw.company.dao.order;

import java.util.List;
import java.util.Map;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.MultiplePayment;
import com.gjw.vo.order.MultiplePaymentVO;

public interface IMultiplePaymentDAO extends IDAO {

	public Map<String, Object> queryPaymentRecord(MultiplePayment multiplePayment);
	
	public List<MultiplePayment> queryRecordNoPay(MultiplePaymentVO multiplePayment);
	
	public long queryPayedMoney(MultiplePayment multiplePayment);
	
	public void addMultiplePayment(MultiplePayment multiplePayment);
	
	public long queryCompletePay(MultiplePayment multiplePayment);
	
	/**
     * 官网个人中心 查询支付记录
     * @param orderId
     * @return
     */
    public List<MultiplePaymentVO> queryPersonalPaymentRecord(long orderId);
    
    /**
     * 更新多次支付记录的支付状态
     * @param multiplePayment
     * @return
     */
    public boolean updateMultiplePayStatus(MultiplePayment multiplePayment);
    
    /**
     * 查询某一个阶段的最新的未支付的记录
     * @param multiplePayment
     * @return
     */
    public MultiplePayment queryLatestRecordNoPay(MultiplePayment multiplePayment);
    
    /**
     * 更新多次支付记录的支付流水号
     * @param multiplePayment
     * @return
     */
    public int updateSerialPayNo(MultiplePayment multiplePayment);
    
    /**
     * 查询90%保证金支付记录
     * @return
     */
    public List<MultiplePayment> queryDepositMultiplePayRecord(MultiplePayment multiplePayment);
    
    /**
     * 更新多次支付记录的支付信息
     * @param multiplePayment
     * @return
     */
    public int updateMultiplePay(MultiplePayment multiplePayment);
    
    public boolean updateRecordById(MultiplePayment multiplePayment);
    
    /**
     * 根据支付的流水号或者id查询支付记录
     * @param multiplePayment
     * @return
     */
    public List<MultiplePayment> queryMultiplePaymentByCodeOrId(MultiplePayment multiplePayment);
	
}
