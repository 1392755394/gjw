package com.gjw.company.dao.impl.customer;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.customer.IGesAppointmentDAO;
import com.gjw.entity.customer.GesAppointment;
import com.gjw.entity.salestool.Captcha;
import com.gjw.utils.StringUtil;


@Component("gesAppointmentDAOHibernateImpl")
public class GesAppointmentDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesAppointmentDAO {
    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesAppointment.class;
    }

    @Override
    public int updateAppointment(GesAppointment record) {
        // TODO Auto-generated method stub
        GesAppointment old = (GesAppointment) super.get(record.getId());
        StringUtil.copyProperties(record, old);
        return super.update(old);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesAppointment> listByBuildingId(Long buildingId) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesAppointment where invalid = 0 and building.id ="+buildingId);
        hql.append(" order by updatedDatetime desc");
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery(hql.toString());
        return query.list();
        
    }

    @Override
    public GesAppointment getById(Long id) {
        // TODO Auto-generated method stub
        return (GesAppointment) super.get(id);
    }

}
