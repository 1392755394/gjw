package com.gjw.company.service.impl.salestool;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.salestool.IIpadAdvertService;
import com.gjw.entity.salestool.IpadAdvert;
import com.gjw.utils.StringUtil;

@Service("ipadAdvertServiceImpl")
public class IpadAdvertServiceImpl extends AbstractServiceImpl implements IIpadAdvertService{
    
    @Override
    @Transactional(readOnly=true)
    public IpadAdvert listByID(Long id) {
        // TODO Auto-generated method stub
        IpadAdvert model=super.getIpadAdvertDAOHibernateImpl().listByID(id);
        return model;
    }

    @Override
    @Transactional()
    public boolean updateIpadAdvert(IpadAdvert model) {
        // TODO Auto-generated method stub
        IpadAdvert modelFlag=super.getIpadAdvertDAOHibernateImpl().listByID(model.getId());
        StringUtil.copyProperties(model, modelFlag);
        return super.getIpadAdvertDAOHibernateImpl().updateIpadAdvert(modelFlag);
    }

    @Override
    @Transactional()
    public boolean createIpadAdvert(IpadAdvert model) {
        // TODO Auto-generated method stub
        return super.getIpadAdvertDAOHibernateImpl().createIpadAdvert(model);
    }

    @Override
    @Transactional(readOnly=true)
    public long count(IpadAdvert model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    @Transactional(readOnly=true)
    public List<IpadAdvert> listByIPadAdvert() {
        // TODO Auto-generated method stub
        List<IpadAdvert> list = super.getIpadAdvertDAOHibernateImpl().listByIPadAdvert();
        if(null != list && list.size()>0){
            for (IpadAdvert ipadAdvert : list) {
                Hibernate.initialize(ipadAdvert.getImageUrl());
            }
        }
        return list;
    }

}
