package com.gjw.company.service.article;

import java.util.List;

import com.gjw.entity.article.WebArticle;
import com.gjw.entity.collection.WebCollectionItem;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;
import com.gjw.entity.label.WebLabel;
import com.gjw.entity.topic.WebTopic;

/**
 * created by 重剑 on 2015/9/17 0017
 */
public interface IWebArticleService {

    WebArticle get(Long id);

    List<WebArticle> pageByName(WebArticle article);

    long countByName(WebArticle article);

    void batchDelete(List<Long> idList);

    void batchReuse(List<Long> idList);

    /**
     * @Description
     * @param article
     * @param labelList
     * @param topicList
     * @author qingye
     * @date Dec 30, 2015 1:18:35 PM
     */

    void add(WebArticle article, List<WebLabel> labelList, List<WebTopic> topicList);

    /**
     * @Description
     * @param article
     * @param labelList
     * @param topicList
     * @author qingye
     * @date Dec 30, 2015 1:53:58 PM
     */

    void update(WebArticle article, List<WebLabel> labelList, List<WebTopic> topicList);

    List<WebArticle> listByArticle(WebArticle model);

    long count(WebArticle model);

    List<WebArticle> listByWebEncyclopediaLabelItem(List<WebEncyclopediaLabelItem> items, Long userId);

    /**
     * 根据用户收藏文章id查询文章列表
     * 
     * @Description
     * @param list
     * @return
     * @author gwb
     * @date 2016年3月29日 上午11:35:46
     */
    List<WebArticle> listArticleBy(List<WebCollectionItem> list);

}
