package com.gjw.company.service.encyclopedia;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;

/**
 * 百科标签关系service接口
* @Description: 
* @author  zhaoyonglian
* @date 2015年12月23日 上午11:07:51
*
 */
public interface IWebEncyclopediaLabelItemService extends IService {
    /**
     * 
     * @Description 由类型及id获取相关标签列表
     * @param item
     * @return
     * @author zhaoyonglian
     * @date 2015年12月23日 上午10:28:07
     */
    public List<WebEncyclopediaLabelItem> listByInfoAndDictionary(WebEncyclopediaLabelItem item);
    
    /**
     * 
    * @Description  获得关联标签名字符串
    * @param item
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月23日 下午4:12:30
     */
    public String getLabelNameByInfoAndDictionary(WebEncyclopediaLabelItem item);
    
    /**
     * 
     * @Description 由类型及id删除相关标签
     * @param item
     * @return
     * @author zhaoyonglian
     * @date 2015年12月23日 上午10:34:36
     */
    public boolean invalidByInfoAndDictionary(WebEncyclopediaLabelItem item);
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean addRelation(WebEncyclopediaLabelItem item);
    
    /**
     * 
    * @Description  获取特定字典的标签名称字符串
    * @param item
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月26日 上午9:57:00
     */
    public String getLabelNameByCondition(WebEncyclopediaLabelItem item,Long dictionary);
    
    /**
     * 
    * @Description  获取关联标签id字符串
    * @param item
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月26日 下午3:03:25
     */
    public String getLabelIdByCondition(WebEncyclopediaLabelItem item,Long dictionary);
    
    public Long countByInfoAndDictionary(WebEncyclopediaLabelItem item);
}
