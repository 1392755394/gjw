package com.gjw.company.dao.impl.user;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.user.IRoleDAO;
import com.gjw.entity.user.Role;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Epee on 2016-03-03 14:14.
 */
@Component("com.gjw.company.dao.impl.user.RoleDAOHibernateImpl")
public class RoleDAOHibernateImpl extends AbstractDAOHibernateImpl implements IRoleDAO{

    private static final String loadAllRoleNamesHQL =
            "select R.name from UserRoleItem URI join fetch URI.Role R where URI.user.id = :userId";

    @Override
    protected Class getEntityClass() {
        return Role.class;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<String> loadAllRoleNames(Long userId) {
        return (List<String>) getHibernateTemplate().findByNamedParam("loadAllRoleNames", "userId", userId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Role> listChildRoles(long parentID) {
       return  (List<Role>)this.getHibernateTemplate().find("from Role where parentId=? and invalid = false", parentID);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Role> listRoles() {
        return (List<Role>)this.getHibernateTemplate().find("from Role where invalid = false");
    }

    @Override
    public Role getRoleById(long id) {
        return (Role)get(id);
    }

    @Override
    public boolean update(Role role) {
        return super.update(role) == 1?true:false;
    }

    @Override
    public boolean delete(Role role) {
        return false;
    }

    @Override
    public long create(Role role) {
        super.saveResultBoolean(role);
        return role.getId();
    }


}
