package com.gjw.company.dao.user;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.user.User;

/**
 * 
* @Description: 
* @author  qingye
* @date Dec 23, 2015 3:27:13 PM
*
 */
public interface IUserDAO extends IDAO {

    User getByUsername(String username);
    User getByMobile(String mobile);
    User getByEmail(String email);
    User get(Long id);
    User getByUserNameAndPassWord(User user);
    /** 
    * @Description  
    * @return
    * @author qingye   
    * @date Jan 9, 2016 1:39:49 PM
    */
    
    List<User> test();
    User getByAccount(String account);


}
