package com.gjw.company.dao.cityoperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperatorCompare;

public interface IGesCityOperatorCompareDAO extends IDAO{
    public GesCityOperatorCompare listByID(Long id);

    public boolean updateGesCityOperatorCompare(GesCityOperatorCompare model);

    public boolean createGesCityOperatorCompare(GesCityOperatorCompare model);
    
    public long count(GesCityOperatorCompare model);
    
    public List<GesCityOperatorCompare> listByGesCityOperatorCompare(GesCityOperatorCompare model);
}
