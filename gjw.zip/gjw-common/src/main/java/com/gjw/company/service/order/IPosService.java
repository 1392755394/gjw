package com.gjw.company.service.order;

import java.util.Map;

import com.gjw.entity.order.GesPaymentRecord;

public interface IPosService {
	
	/**
	 * 刷卡准备
	 * @param orderId
	 * @param username
	 * @param action
	 * @return
	 */
	public Map<String, Object> ready(Long orderId, Long userId,Integer action);
	
	/**
	 * 刷卡成功返回值处理
	 * @param paymentRecord
	 * @param userId
	 * @return
	 */
	public Map<String, Object> complete(GesPaymentRecord paymentRecord, Long userId);

}
