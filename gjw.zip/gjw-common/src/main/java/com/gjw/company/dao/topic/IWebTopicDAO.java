package com.gjw.company.dao.topic;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.topic.WebTopic;

/**
 * 
* @Description: 话题dao接口类
* @author  zhaoyonglian
* @date 2015年12月24日 上午10:41:35
*
 */
public interface IWebTopicDAO extends IDAO {

	/**
	 * 
	* @Description  话题详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月24日 上午10:41:46
	 */
	public WebTopic getById(Long id);
	
	/**
	 * 
	* @Description  分页列表，搜索条件：话题标题
	* @param topic
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月24日 上午10:58:11
	 */
	public List<WebTopic> pageByNameAndInvalid(WebTopic topic);
	
	/**
	 * 
	* @Description  总数
	* @param topic
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月24日 上午10:56:56
	 */
	public Long countByNameAndInvalid(WebTopic topic);
	
	/**
	 * 
	* @Description  修改记录
	* @param topic
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月24日 上午10:56:47
	 */
	public boolean updateTopic(WebTopic topic);

    
}
