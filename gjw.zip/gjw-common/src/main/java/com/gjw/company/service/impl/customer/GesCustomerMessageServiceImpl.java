package com.gjw.company.service.impl.customer;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.customer.IGesCustomerMessageService;
import com.gjw.entity.customer.GesCustomerMessage;
import com.gjw.utils.StringUtil;
@Component("gesCustomerMessageServiceImpl")
public class GesCustomerMessageServiceImpl extends AbstractServiceImpl implements IGesCustomerMessageService{
    /**
     * 根据ID查询客户消息
     */
    @Override
    @Transactional(readOnly=true)
    public GesCustomerMessage listByID(Long id) {
        // TODO Auto-generated method stub
        GesCustomerMessage model=super.getGesCustomerMessageDAO().listByID(id);
        return model;
    }
    /**
     * 更新客户消息
     */
    @Override
    @Transactional()
    public boolean updateGesCustomerMessage(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        GesCustomerMessage item=super.getGesCustomerMessageDAO().listByID(model.getId());
        StringUtil.copyProperties(model, item);
        return super.getGesCustomerMessageDAO().updateGesCustomerMessage(item);
    }
    /**
     * 创建客户消息
     */
    @Override
    @Transactional()
    public boolean createGesCustomerMessage(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        return super.getGesCustomerMessageDAO().createGesCustomerMessage(model);
    }
    /**
     * 客户消息列表
     */
    @Override
    @Transactional(readOnly=true)
    public List<GesCustomerMessage> listByGesCustomerMessage(
            GesCustomerMessage model) {
        // TODO Auto-generated method stub
        List<GesCustomerMessage> list=super.getGesCustomerMessageDAO().listByGesCustomerMessage(model);
        return list;
    }
    /**
     * 客户消息总数
     */
    @Override
    @Transactional(readOnly=true)
    public long count(GesCustomerMessage model) {
        // TODO Auto-generated method stub
        return super.getGesCustomerMessageDAO().count(model);
    }

}
