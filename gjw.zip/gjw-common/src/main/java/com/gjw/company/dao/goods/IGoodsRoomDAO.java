package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.vo.GoodsVO;

/**
 * 产品包房间dao接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
public interface IGoodsRoomDAO extends IDAO {

    /**
     * 查询产品包房间列表
     * 
     * @Description
     * @param goodsId
     *            查询条件：产品包ID
     * @return 产品包房间列表
     * @author guojianbin
     * @date 2015年12月21日
     */
    public List<GoodsRoom> listGoodsRoomByGoodsId(Long goodsId);

    /**
     * 根据ID查询产品包房间信息
     * 
     * @Description
     * @param id
     *            查询条件：房间ID
     * @return 产品包房间
     * @author guojianbin
     * @date 2015年12月24日
     */
    public GoodsRoom queryById(Long id);

    /**
     * 批量删除产品包
     * 
     * @Description
     * @param ids
     *            房间ID
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月24日
     */
    public boolean delBatchByID(String ids);

    /**
     * 保存产品包房间信息
     * 
     * @Description
     * @param goodsRoom
     *            产品包房间
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月24日
     */
    public boolean update(GoodsRoom goodsRoom);

    /**
     * 新增产品包房间信息
     * 
     * @Description
     * @param goodsRoom
     *            产品包房间
     * @return 产品包房间ID
     * @author guojianbin
     * @date 2015年12月24日
     */
    public long create(GoodsRoom goodsRoom);

    /**
     * 效果图分页查询
     * 
     * @Description
     * @param goodsVO
     * @author gwb
     * @date 2016年3月5日 上午9:32:14
     */
    public List<GoodsRoom> pageList(GoodsVO goodsVO);

    /**
     * 效果图分页总数
     * 
     * @Description
     * @param goodsVO
     * @return
     * @author gwb
     * @date 2016年3月5日 上午9:34:38
     */
    public long pageListCount(GoodsVO goodsVO);

    /**
     * <p>
     * 效果图
     * <p>
     * 点击图片进入里面
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2016年3月5日 上午11:39:16
     */
    public List<Long> getAllId();

}
