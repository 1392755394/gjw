package com.gjw.company.service.impl.area;

import java.sql.Timestamp;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.area.IGesCityService;
import com.gjw.entity.area.GesArea;
import com.gjw.entity.area.GesCity;
import com.gjw.entity.area.GesCityDredge;
import com.gjw.vo.GesAreaVO;

@Component("gesCityServiceImpl")
public class GesCityServiceImpl extends AbstractServiceImpl implements IGesCityService {

    @Override
    @Transactional(readOnly=true)
    public GesCity getCityByCityId(long cityId) {

        GesCity city = getGesCityDAO().getCityByCityId(cityId); 
        if(null!=city)Hibernate.initialize(city.getCity());
        return city;
    }
    
    @Override
    @Transactional
    public long addCityDetail(GesCity gesCity) {

        return getGesCityDAO().addCityDetail(gesCity);
    }
    
    @Override
    @Transactional
    public long addDredgeCity(GesAreaVO areaVO) {

        GesCityDredge cityDredge = new GesCityDredge();
        cityDredge.setUser(areaVO.getUser());
        cityDredge.setCreatedDatetime(new Timestamp(System.currentTimeMillis()) );
        
        GesArea cityArea = new GesArea();
        GesArea provinceArea = new GesArea();
        provinceArea.setId(areaVO.getProvinceId());
        
        GesArea area = null;
        if(areaVO.getCuntroyId()==-1){ //加入城市时为-1， 同时需要更新，所以需要cityid ，更新iscity为'y'
            cityArea.setId(areaVO.getCityId()); //城市更新设置完成，开通表只插入传递过来的省，市，用户Id
            //查询area
            area = super.getGesAreaDAO().getById(areaVO.getCityId());
        }else{
            area = super.getGesAreaDAO().getById(areaVO.getCuntroyId());//若不是更新，则id为县id
            cityArea.setId(areaVO.getCuntroyId());//同时设置dredgecityid为县id
        }
        area.setIsAdd("y");
        cityDredge.setCity(cityArea);
        cityDredge.setProvince(provinceArea);
        //分开操作area 与dredge
        long flag = getGesCityDAO().addDredgeCity(cityDredge);
        if(flag>0){
            flag = getGesCityDAO().updateGesAreaById(area)<=0?0:flag;
        }
        return flag;
    }
    
    @Override
    @Transactional
    public long deleteDredgeCity(GesAreaVO areaVO) {

        GesArea area=null;
        if(areaVO.getCuntroyId()==-1){
            area = super.getGesAreaDAO().getById(areaVO.getCityId());
        }else{
            area = super.getGesAreaDAO().getById(areaVO.getCuntroyId());
        }
        area.setIsAdd("n");
        GesCityDredge cityDredge = new GesCityDredge();
        cityDredge.setId(areaVO.getDredgeId());
        return getGesCityDAO().deleteDredgeCity(cityDredge, area);
    }
    
    @Override
    public GesArea getGesAreaById(long id) {

        return getGesCityDAO().getGesAreaById(id);
    }
    
    @Override
    @Transactional
    public long updateCityDetail(GesCity gesCity) {

        return getGesCityDAO().updateCityDetail(gesCity);
    }
    
    @Override
    public GesCity getGesCityById(long id) {

        return getGesCityDAO().getGesCityById(id);
    }
}
