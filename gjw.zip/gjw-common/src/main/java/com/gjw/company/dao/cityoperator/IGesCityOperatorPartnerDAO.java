package com.gjw.company.dao.cityoperator;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperatorPartner;

public interface IGesCityOperatorPartnerDAO extends IDAO{
    public GesCityOperatorPartner listByID(Long id);

    public boolean updateGesCityOperatorPartner(GesCityOperatorPartner model);

    public boolean createGesCityOperatorPartner(GesCityOperatorPartner model);
    
    public long count(GesCityOperatorPartner model);
    
    public List<GesCityOperatorPartner> listByGesCityOperatorPartner(GesCityOperatorPartner model);
}
