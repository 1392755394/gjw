package com.gjw.company.service.customer;

import java.util.List;
import java.util.Map;

import com.gjw.base.service.IService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.customer.GesCustomerQuestion;
import com.gjw.entity.customer.GesCustomerReserve;
import com.gjw.entity.order.GesOrder;
import com.gjw.vo.customer.GesCustomerReserveVO;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.customer.UserVO;

public interface IGesCustomerService extends IService {

    public Map<Object, Object> pageGesCustomer(GesCustomerVO gesCustomerVO);
    
    public List<GesCustomerVO> listByGesCustomer4Export(GesCustomerVO gesCustomerVO);
    
    public List<GesCustomer> getGesCustomerByGesCustomer(GesCustomer gesCustomer);
    
    public long updateGesCustomerByGesCustomer(GesCustomer gesCustomer);
    
    public GesCustomer getGesCustomerById(long id);
    
    public long saveGesCustomer(GesCustomer gesCustomer);
    
    public GesCustomer customerValidate(GesCustomer model);
    
    public void addGesCustomer(GesCustomer gesCustomer,GesCustomerReserve gesCustomerReserve,Long shopId);
    
    /*----------------- question------------------------------*/
    public long updateGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
    public long saveGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
    public Map<Object, Object> pageGesCustomerQuestion(GesCustomerQuestion gesCustomerQuestion);
    
    public GesCustomerQuestion getGesCustomerQuestionById(long id);
    /*----------------- question end-------------------------*/
    
    /*----------------- reserve--------------------------------*/
    public Map<String, Object> pageGesCustomerReserve(GesCustomerReserveVO gesCustomerReserveVO);
    
    public GesCustomerReserve getGesCustomerReserveById(long id);
    
    public List<GesCustomerReserve> pageByGesCustomerReserve(GesCustomerReserve model);
    /*----------------- reserve end-------------------- ------*/
    
    /*----------------- user------------------------------------*/
    public Map<Object, Object> pageUserByUser(UserVO user);
    /*----------------- user end------------------------------*/
   
    /*----------------- other----------------------------------*/
    public List<GesOrder> pageOrderByGesOrder(GesOrder order);
    public List<GesCityOperator> listGesCityOperator(String orgType, long shopId, long operatorId);
    public long saveCustomerReserve(GesCustomerReserve gesCustomerReserve);
    public long updateCustomerReserve(GesCustomerReserve gesCustomerReserve);
    public boolean delBatchByID(String ids, Class<?> clazz);
    /*-------------------other end---------------------------*/
}
