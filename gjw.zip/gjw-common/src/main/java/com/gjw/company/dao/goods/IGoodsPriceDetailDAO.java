package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.GoodsPriceDetail;

/**
 * 产品包价格dao接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月25日 
 *
 */
public interface IGoodsPriceDetailDAO extends IDAO {

    /**
     * 查询产品包价格列表
     * @Description  
     * @param goodsId 查询条件：产品包ID
     * @return 产品包价格列表
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public List<GoodsPriceDetail> listGoodsPriceByGoodsId(Long goodsId);
    
    /**
     * 保存产品包价格信息
     * 
     * @Description
     * @param goodsPriceDetail
     *            产品包价格
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月25日
     */
    public boolean update(GoodsPriceDetail goodsPriceDetail);
    
    /**
     * 新增产品包价格信息
     * 
     * @Description
     * @param goodsPriceDetail
     *            产品包价格
     * @return 产品包价格ID
     * @author guojianbin
     * @date 2015年12月25日
     */
    public long create(GoodsPriceDetail goodsPriceDetail);
}
