package com.gjw.company.dao.impl.order;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IGesPaymentRecordDAO;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.gjb.enumeration.EPaymentRecordStatus;

@Component("gesPaymentRecordDAOHibernateImpl")
public class GesPaymentRecordDAOHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesPaymentRecordDAO {

	private final static Logger log=LoggerFactory.getLogger(GesPaymentRecordDAOHibernateImpl.class);
	
	@Override
	protected Class getEntityClass() {
		return GesPaymentRecord.class;
	}

	/**
	 * 删除冗余的数据
	 */
	@Override
	public boolean deleteRedundantData(GesPaymentRecord paymentRecord) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesPaymentRecord p set p.invalid=? where p.code!=? and p.orderStatus=? "
				+ "and p.gesOrder.id=? ");
		param.add(true);
		param.add(paymentRecord.getCode());
		param.add(paymentRecord.getOrderStatus());
		param.add(paymentRecord.getGesOrder().getId());
		log.info("删除冗余数据：invalid：true ，code："+paymentRecord.getCode()+",orderStatus:"+paymentRecord.getOrderStatus()+",orderId:"+paymentRecord.getGesOrder().getId());
		return super.updateByParam(hql.toString(), param);
	}

	/**
	 * 根据支付的流水号，更新记录状态为已到账
	 */
	@Override
	public boolean updateRecordStatus(GesPaymentRecord paymentRecord) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update GesPaymentRecord p set p.payStatus=?,updatedDatetime=? where p.code=? ");
		param.add(EPaymentRecordStatus.GET_RES.getValue());
		param.add(new Timestamp(System.currentTimeMillis()));
		param.add(paymentRecord.getCode());
		log.info("更新支付记录信息：paystatus:"+EPaymentRecordStatus.GET_RES.getValue()+",code:"+paymentRecord.getCode());
		return super.updateByParam(hql.toString(), param);
	}

	@Override
	public void createPaymentRecord(GesPaymentRecord paymentRecord) {
		super.add(paymentRecord);
	}

	/**
	 * 获取最新的一条支付记录
	 */
	@Override
	public GesPaymentRecord judgeTimeInterval(long orderId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("from GesPaymentRecord p where p.invalid=? and p.gesOrder.id=? ");
		hql.append("order by p.createdDatetime desc ");
		param.add(false);
		param.add(orderId);
		
		return (GesPaymentRecord) queryByParam(hql.toString(), param);
	}
	
	@Override
	public Object queryByParam(String hql, List<Object> list) {
		List<Object> result = (List<Object>) super.findByListCallBack(hql,null, list, null);
		if (result != null && result.size() > 0) {
			return result.get(0);
		} else {
			return null;
		}
    }

	@Override
	public GesPaymentRecord queryPaymentRecordById(long id) {
		
		return (GesPaymentRecord) super.get(id);
	}

}
