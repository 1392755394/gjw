package com.gjw.company.service.impl.oa;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.common.constants.TaskConstant;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesCommunicationDAO;
import com.gjw.company.dao.oa.IGesProjectTaskDAO;
import com.gjw.company.dao.oa.IGesTaskParticipantDAO;
import com.gjw.company.service.oa.IGesTaskParticipantService;
import com.gjw.entity.oa.GesCommunication;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.entity.oa.GesTaskParticipant;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.event.base.BaseEventPublisher;
import com.gjw.event.oa.GesTaskParticipantEvent;
import com.gjw.event.oa.SendMailEvent;
import com.gjw.vo.oa.GesProjectTaskVO;
import com.gjw.vo.oa.GesTaskParticipantVO;

@Component("gesTaskParticipantServiceImpl")
public class GesTaskParticipantSercviceImpl implements
		IGesTaskParticipantService {
    
    @Resource(name="gesProjectTaskHibernateImpl")
    private IGesProjectTaskDAO gesProjectTaskDAO;

	@Resource(name="gesTaskParticipantHibernateImpl")
	private IGesTaskParticipantDAO gesTaskParticipantDAO;

    @Resource(name="baseEventPublisher")
    private BaseEventPublisher baseEventPublisher;
    
    @Resource(name="gesCommunicationHibernateImpl")
    private IGesCommunicationDAO gesCommunicationDAO;
    
    public IGesProjectTaskDAO getGesProjectTaskDAO() {
        return gesProjectTaskDAO;
    }

    public void setGesProjectTaskDAO(IGesProjectTaskDAO gesProjectTaskDAO) {
        this.gesProjectTaskDAO = gesProjectTaskDAO;
    }
	
	public IGesTaskParticipantDAO getGesTaskParticipantDAO() {
		return gesTaskParticipantDAO;
	}

	public void setGesTaskParticipantDAO(
			IGesTaskParticipantDAO gesTaskParticipantDAO) {
		this.gesTaskParticipantDAO = gesTaskParticipantDAO;
	}

	@Override
	@Transactional(readOnly=true)
	public List<GesTaskParticipantVO> queryMemberInfoByTaskId(Long taskId) {
		
		return getGesTaskParticipantDAO().queryMemberInfoByTaskId(taskId);
	}

    @Override
    @Transactional
    public boolean delMember(GesTaskParticipant taskParticipant) {
    	//任务成员的删除需要做以下判断
		// 1.用户自己不能删除自己 2.只有发布人才能删除负责人 3.项目/任务中必须有一个负责人
    	GesTaskParticipant taskParticipantVO = getGesTaskParticipantDAO().getTaskParticipant(taskParticipant.getId());
		long currentUserId = taskParticipant.getUser().getId();
		if (currentUserId == taskParticipantVO.getParticipant().getId()) {
			return false;
		}
		Long taskId=taskParticipantVO.getTask().getId();
		List<GesTaskParticipantVO> taskParticipants = this.queryMemberInfoByTaskId(taskId);
		GesTaskParticipantVO currentUser = null;
		int countOfPersonInCharge = 0;
		for (GesTaskParticipantVO item : taskParticipants) {
			if (item.getUserId() == currentUserId) {
				currentUser = item;
			}
			if (item.getType() == 1
					&& item.getId() != taskParticipantVO.getId()) {
				countOfPersonInCharge++;
			}
		}
		if (!currentUser.getIsCreator() && taskParticipantVO.getParticipantType() == 1) {
			return false;
		}
		if (countOfPersonInCharge < 1) {
			return false;
		}

		boolean boolResult = getGesTaskParticipantDAO().delMember(taskParticipant);
		
		GesProjectTask projectTaskVO = getGesProjectTaskDAO().queryGesProject(taskId);
		UserInfoGES userInfoGes=(UserInfoGES) taskParticipantVO.getParticipant().getUserInfo(PlatformEnum.Ges);
		String content = "<html><head><meta http-equiv=" + "Content-Type"
				+ " content=" + "text/html; charset=gb2312" + "></head><body>"
				+ userInfoGes.getRealName() + "您好：" + "<br/>&nbsp&nbsp&nbsp&nbsp"
				 + "你不再参与任务【"
				+ projectTaskVO.getContent() + "】"
				+ "<br/><br/>（这是一封系统自动发出的邮件，请勿回复）</body></html>";
		// 异步发送邮件
		SendMailEvent event = new SendMailEvent(taskParticipantVO);
        event.setContent(content);
        event.setEmail(userInfoGes.getContactEmail());
        event.setSubject("成员调整");
        baseEventPublisher.publishEvent(event);
    	
        return boolResult;
    }

    @Override
    @Transactional
    public int addBatchMember(long taskId, String userIds, int type, String loginUserName) {
        
        List<GesTaskParticipant> list = new ArrayList<GesTaskParticipant>();

        // 根据taskid查询taskinfo
        GesProjectTaskVO projectTaskVO = getGesProjectTaskDAO().queryTaskById(taskId);

        // 字符串分隔
        String[] ids = userIds.split(",");
        // 循环填充list
        for (String id : ids) {
            GesTaskParticipant taskParticipant = new GesTaskParticipant();
            GesProjectTask task = new GesProjectTask();
            task.setId(taskId);
            taskParticipant.setTask(task);
            User user=new User();
            user.setId(Long.parseLong(id));
            taskParticipant.setParticipant(user);
            taskParticipant.setParticipantType(type);
            taskParticipant.setDifference(projectTaskVO.getDifference());
            taskParticipant.setIsHandle(0);
            taskParticipant.setIsCreator(false);
            taskParticipant.setCommunication(null);
            taskParticipant.setInvalid(TaskConstant.DEL_FLAG_NO);
            list.add(taskParticipant);
        }

        // 批量添加成员
        int num = getGesTaskParticipantDAO().batchSaveTaskParticipant(list);
        
        // 发布添加成员事件
        for (GesTaskParticipant p : list) {
            GesTaskParticipantEvent event = new GesTaskParticipantEvent(p);
            event.setOprateName(loginUserName);
            baseEventPublisher.publishEvent(event);
        }
        
        return num;
    }

    /**
     * 查询登录用户是否是某一个任务的创建人或者负责人(项目和任务)
     * @param taskId
     * @param userId
     * @return
     */
	@Override
	@Transactional(readOnly=true)
	public List<GesTaskParticipantVO> getMemberInfo(long taskId, long userId) {
		return getGesTaskParticipantDAO().getMemberInfo(taskId, userId);
	}

	/**
     * 通过任务id和用户id查询成员信息
     * @param taskId
     * @param userId
     * @return
     */
	@Override
	@Transactional(readOnly=true)
	public List<GesTaskParticipantVO> getMemberByIdAndUserid(long taskId,long userId) {
        return getGesTaskParticipantDAO().getMemberByIdAndUserid(taskId, userId);
	}

	/**
	 * 提升负责人
	 */
	@Override
	@Transactional
	public boolean alterMemeberType(GesTaskParticipant taskParticipant) {
		//更改参与者或者负责人的类型，
		// 只有发起人才有权限把参与人变为负责人或者把负责人变为参与人；如果是把参与人变为负责人，不需要做任何校验；如果是把负责人变为参与人，则需要校验是否还有其他负责人
		GesCommunication communication = new GesCommunication();
		long currentUserId = taskParticipant.getUser().getId();
		communication.setUser(taskParticipant.getUser());

		GesTaskParticipant taskParticipantVO = getGesTaskParticipantDAO().getTaskParticipant(taskParticipant.getId());
		String realName=taskParticipantVO.getParticipant().getUserInfo(PlatformEnum.Ges).getRealName();
		List<GesTaskParticipantVO> taskParticipants = this.queryMemberInfoByTaskId(taskParticipantVO.getTask().getId());
		GesTaskParticipantVO currentUser = null;
		int countOfPersonInCharge = 0;
		for (GesTaskParticipantVO item : taskParticipants) {
			if (item.getUserId() == currentUserId) {
				currentUser = item;
			}
			if (taskParticipant.getParticipantType() == 1
					&& taskParticipantVO.getParticipantType() == 0) {
				if (item.getType() == 1
						&& item.getId() != taskParticipant.getId()) {
					countOfPersonInCharge++;
				}
			}
		}
		if (!currentUser.getIsCreator()) {
			return false;
		}
		if (taskParticipant.getParticipantType() == 1 && taskParticipantVO.getParticipantType() == 0
				&& countOfPersonInCharge < 1) {
			return false;
		}

		communication.setTask(taskParticipantVO.getTask());
		
		if (taskParticipant.getParticipantType() == 1 && taskParticipantVO.getParticipantType() == 0) {
			communication.setContent(realName + "提升为负责人");
		} else if (taskParticipant.getParticipantType() == 0
				&& taskParticipantVO.getParticipantType() == 1) {
			communication.setContent(realName + "变更为参与人");
		}
		gesCommunicationDAO.createCommunication(communication);

		taskParticipantVO.setParticipantType(taskParticipant.getParticipantType());
		return getGesTaskParticipantDAO().update(taskParticipantVO)>0;
	}

    @Override
    @Transactional
    public boolean updateTaskDeal(Long taskId, Integer isDeal, Long userId) {
        return getGesTaskParticipantDAO().updateTaskDeal(taskId, isDeal, userId);
    }

}
