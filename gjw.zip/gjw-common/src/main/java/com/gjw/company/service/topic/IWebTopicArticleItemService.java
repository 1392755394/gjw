package com.gjw.company.service.topic;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.topic.WebTopicArticleItem;

/**
 * 
* @Description: 话题service接口
* @author  zhaoyonglian
* @date 2015年12月24日 上午11:15:04
*
 */
public interface IWebTopicArticleItemService extends IService {
    
    /**
     * 
    * @Description  话题相关文章列表
    * @param topicId
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 下午4:05:23
     */
    public List<WebTopicArticleItem> listByTopic(Long topicId);
    
    
    /**
     * 
    * @Description  批量删除话题文章
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月24日 上午11:15:50
     */
    public String invalidByIds(String ids,Long topicId);
    
    
    
    /**
     * 
    * @Description  删除数据（软删除）
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:33:05
     */
    public int invalid(Long id);
    
    
    /**
     * 
    * @Description  增加数据
    * @param entity
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月14日 下午3:32:34
     */
    public boolean insert(WebTopicArticleItem entity);
    
    /**
     * 
    * @Description  批量增加话题文章关系
    * @param topicId
    * @param articleIds
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月4日 上午11:42:29
     */
    public String insertByArticleIds(Long topicId,String articleIds);
    
    
    public List<WebTopicArticleItem> listByArticle(Long articleId);


    /** 
    * @Description  
    * @return
    * @author qingye   
    * @date Dec 30, 2015 5:14:30 PM
    */
    
    public List<WebTopicArticleItem> countGroupByTopic();
}
