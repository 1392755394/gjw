package com.gjw.company.dao.erp;

import java.util.List;
import java.util.Map;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesRdRecord;
import com.gjw.vo.RdRecordVO;

/**
 * 销售出库单管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月15日 下午3:29:13
 * 
 */
public interface IGesRdRecordDAO extends IDAO {

    /**
     * 销售出库单分页查询
     * 
     * @Description
     * @return
     * @author gwb
     * @date 2015年12月15日 下午4:03:28
     */
    public List<GesRdRecord> pageByRdRecord(RdRecordVO rdRecord);

    /**
     * 销售出库单分页查询总数
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月15日 下午4:03:40
     */
    public Long count(RdRecordVO rdRecord);

    /**
     * 根据 单据编号 修改销售出库单状态
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月16日 上午10:17:20
     */
    public boolean updateByRecordCode(GesRdRecord rdRecord);

    /**
     * 根据 rdRecord查询对象
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2015年12月18日 上午11:23:07
     */
    public GesRdRecord getByGesRdRecord(GesRdRecord rdRecord);

    /**
     * 新增出库单
     * 
     * @Description
     * @param rdRecord
     * @author gwb
     * @date 2015年12月18日 上午11:28:57
     */
    public void create(GesRdRecord rdRecord);

    /**
     * 采购入库单分页查询
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年1月4日 上午9:59:30
     */
    public List<Map> pageStockByRdRecord(RdRecordVO rdRecord);

    /**
     * 采购入库单分页查询总数
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年1月4日 上午9:59:30
     */
    public Long countStock(RdRecordVO rdRecord);

    /**
     * 构家网销售出库单
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年1月4日 上午11:42:59
     */
    public List<GesRdRecord> ListByRdRecord(RdRecordVO rdRecord);

    public List<GesRdRecord> pageStockOutByRdRecord(RdRecordVO rdRecord);

    public Long countStockOut(RdRecordVO rdRecord);

    public void deleteGesRdRecord(String ids);

    public void updateAmount(Long id, Integer amount);

    /**
     * 运营管理---销售出库单page
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年3月8日 下午1:46:36
     */
    public List<GesRdRecord> pageByRdRecordOpMat(RdRecordVO rdRecord);

    /**
     * 运营管理---销售出库单count
     * 
     * @Description
     * @param rdRecord
     * @return
     * @author gwb
     * @date 2016年3月8日 下午1:46:52
     */
    public Long countOpMat(RdRecordVO rdRecord);

}
