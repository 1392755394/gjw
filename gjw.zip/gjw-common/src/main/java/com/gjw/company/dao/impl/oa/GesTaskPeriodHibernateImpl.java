package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.oa.IGesTaskPeriodDAO;
import com.gjw.entity.oa.GesTaskPeriod;
import com.gjw.utils.StringUtil;
import com.gjw.vo.oa.GesTaskPeriodVO;

@Component("gesTaskPeriodHibernateImpl")
public class GesTaskPeriodHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesTaskPeriodDAO {

	@Override
	protected Class<?> getEntityClass() {
		return GesTaskPeriod.class;
	}

	/**
	 * 根据任务的id查询任务的阶段
	 * @param taskId
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Override
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskId(Long taskId) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select a.id as id,a.periodName as periodName,a.orderTag as orderIndex ");
		hql.append(",(select concat(count(p.id),'') from GesProjectTask p where p.period.id=a.id) as taskNum ");
		hql.append(" from GesTaskPeriod a where a.invalid=? and a.task.id=? ");
		hql.append(" order by a.orderTag asc ");
		param.add(false);
		param.add(taskId);
		return (List<GesTaskPeriodVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskPeriodVO.class));
	}

    @SuppressWarnings("unchecked")
    @Override
    public List<GesTaskPeriodVO> queryTaskPeriodByTaskId(Long taskId) {
        StringBuffer hql=new StringBuffer();
        List<Object> param=new ArrayList<Object>();
        hql.append("select a.id as id,a.periodName as periodName,a.orderTag as orderIndex ");
        hql.append(" from GesTaskPeriod a where a.invalid=? and a.task.id=? ");
        hql.append(" order by a.orderTag asc ");
        param.add(false);
        param.add(taskId);
        return (List<GesTaskPeriodVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskPeriodVO.class));
    }

    @Override
    public long addTaskPeriod(GesTaskPeriod taskPeriod) {
        super.add(taskPeriod);
        return taskPeriod.getId();
    }

    @Override
    public boolean updateTaskPeriod(GesTaskPeriod taskPeriod) {
        GesTaskPeriod old = (GesTaskPeriod) super.get(taskPeriod.getId());
        StringUtil.copyProperties(taskPeriod, old);
        return super.update(old) == 1;
    }

    @Override
    public int queryMaxOrder(Long taskId) {
        String hql = "select max(a.orderTag) from GesTaskPeriod a where a.task.id=? ";
        List<Object> param=new ArrayList<Object>();
        param.add(taskId);
        Object max = super.queryByParam(hql, param);
        return max == null ? 0 : (int)max;
    }

    @Override
    public boolean delTaskPeriod(GesTaskPeriod taskPeriod) {
        return super.remove(taskPeriod.getId()) > 0;
    }

    @SuppressWarnings("unchecked")
    @Override
    public GesTaskPeriod queryNextPeriod(GesTaskPeriod taskPeriod) {
        String hql = "from GesTaskPeriod a where a.orderTag > ? and a.task.id=? order by a.orderTag asc ";
        List<GesTaskPeriod> list = (List<GesTaskPeriod>) super.getHibernateTemplate().find(hql, taskPeriod.getOrderTag(),
                taskPeriod.getTask().getId());
        return list.get(0);
    }

    @SuppressWarnings("unchecked")
    @Override
    public GesTaskPeriod queryPrevPeriod(GesTaskPeriod taskPeriod) {
        String hql = "from GesTaskPeriod a where a.orderTag < ? and a.task.id=? order by a.orderTag desc ";
        List<GesTaskPeriod> list = (List<GesTaskPeriod>) super.getHibernateTemplate().find(hql, taskPeriod.getOrderTag(),
                taskPeriod.getTask().getId());
        return list.get(0);
    }

    /**
     * 施工管理项目
     */
	@Override
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskIdForPM(
			Long taskId) {
		StringBuffer hql=new StringBuffer();
        List<Object> param=new ArrayList<Object>();
        hql.append("select a.accentedphase as periodName,concat(count(a.keypoint),'') as taskNum ");
		hql.append(" from GesPmModel a where a.invalid=? and a.type=? ");
		hql.append(" group by a.accentedphase order by a.id asc ");
		param.add(false);
		param.add(3);
		return (List<GesTaskPeriodVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesTaskPeriodVO.class));
	}
	
	

}
