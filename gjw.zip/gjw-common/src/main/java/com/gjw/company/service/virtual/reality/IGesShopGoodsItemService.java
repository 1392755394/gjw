package com.gjw.company.service.virtual.reality;

import java.util.List;

import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.vo.GoodsVO;

/**
 * 虚拟现实
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月26日 下午2:43:11
 * 
 */
public interface IGesShopGoodsItemService {
    /**
     * 4S店产品包
    * @Description  
    * @param goods
    * @return
    * @author zyq   
    * @date 2016年3月14日 上午10:16:50
     */
    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model);
    /**
     * <p>
     * 虚拟现实---分页查询
     * 
     * @Description
     * @param goods
     * @return
     * @author gwb
     * @date 2016年2月26日 上午10:15:43
     */
    public List<Goods> getPageGoodsList(GoodsVO goods);

    /**
     * 虚拟现实总数查询
     * 
     * @Description
     * @param gesShopGoodsItem
     * @return
     * @author gwb
     * @date 2016年2月26日 上午10:18:15
     */
    public long getPageGoodsListCount(GoodsVO gesShopGoodsItem);
}
