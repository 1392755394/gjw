package com.gjw.company.service.goods;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsDiyMatter;

/**
 * DIY清单service接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月28日 
 *
 */
public interface IGoodsDiyMatterService extends IService {

    /**
     * 查询单个空间的DIY清单的物料信息
     * @Description  
     * @param roomId 查询条件：空间ID
     * @return DIY清单列表
     * @author guojianbin   
     * @date 2015年12月28日
     */
    public List<GoodsDiyMatter> listRoomDiyMatter(Long roomId);
}
