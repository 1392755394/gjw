package com.gjw.company.dao.impl.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.support.IWebSupportItemDAO;
import com.gjw.entity.support.WebSupportItem;

/**
 * 点赞相关操作
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月25日 上午10:07:33
 * 
 */
@Component("webSupportItemDAOHibernateImpl")
public class WebSupportItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebSupportItemDAO {

    @Override
    protected Class<WebSupportItem> getEntityClass() {
        return WebSupportItem.class;
    }

    @Override
    public boolean insert(WebSupportItem webSupportItem) {
        return super.saveResultBoolean(webSupportItem);
    }

    @Override
    public boolean deleteWebSupportItem(Long id) {
        return super.delete(id) == 1;
    }

    @Override
    public boolean deleteByContent(WebSupportItem webSupportItem) {
        String hql = " update WebSupportItem set invalid=1 where 1=1";
        List<Object> list = new ArrayList<Object>();
        if(null!=webSupportItem.getId()){
            hql=hql+" and id=?";
            list.add(webSupportItem.getId());
        }
        if(null!=webSupportItem.getUser() && null!=webSupportItem.getUser().getId()){
            hql=hql+" and user.id=?";
            list.add(webSupportItem.getUser().getId());
        }
        if(null!=webSupportItem.getPropertyType() && null!=webSupportItem.getPropertyType().getId()){
            hql=hql+" and propertyType.id=?";
            list.add(webSupportItem.getPropertyType().getId());
        }
        if(null!=webSupportItem.getInfo()){
            hql=hql+" and info=?";
            list.add(webSupportItem.getInfo());
        }
        return super.updateByParam(hql, list);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebSupportItem> userSupportList(WebSupportItem webSupportItem) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebSupportItem where invalid =?");
        List<Object> list = new ArrayList<Object>();
        list.add(false);
        if (webSupportItem.getInfo() != null) {
            hql.append(" and info=?");
            list.add(webSupportItem.getInfo());
        }
        return (List<WebSupportItem>) super.findByPageCallBack(hql.toString(), "", list, webSupportItem, null);
    }

    @Override
    public long countByContent(WebSupportItem webSupportItem) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebSupportItem where invalid =0");
        List<Object> list = new ArrayList<Object>();
        if (webSupportItem.getInfo() != null) {
            hql.append(" and info=?");
            list.add(webSupportItem.getInfo());
        }
        if (webSupportItem.getUser() != null && webSupportItem.getUser().getId() != null) {
            hql.append(" and user.id=?");
            list.add(webSupportItem.getUser().getId());
        }
        if (webSupportItem.getPropertyType() != null && webSupportItem.getPropertyType().getId() != null) {
            hql.append(" and propertyType.id=?");
            list.add(webSupportItem.getPropertyType().getId());
        }
        return super.findByPageCallBackCount(hql.toString(), list);
    }

}
