package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.WebOrderLog;
import com.gjw.vo.WebOrderLogVO;

/**
 * 
* @Description: 日志dao接口类
* @author  zhaoyonglian
* @date 2015年12月19日 上午10:40:49
*
 */
public interface IWebOrderLogDAO extends IDAO {

	/**
	 * 
	* @Description  日志详情
	* @param id
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月19日 上午10:40:37
	 */
	public WebOrderLog getById(Long id);
	
	/**
	 * 
	* @Description  分页列表，搜索条件：内容
	* @param content
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月10日 下午2:34:10
	 */
	public List<WebOrderLog> pageByContent(WebOrderLogVO log);
	
	/**
	 * 
	* @Description  总数
	* @param log
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月14日 下午1:51:20
	 */
	public Long countByContent(WebOrderLogVO log);
	
	/**
	 * 
	* @Description  修改日志信息
	* @param log
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月19日 上午10:40:00
	 */
	public boolean updateLog(WebOrderLog log);
	
	/**
     * 
    * @Description  标签下所有案例
    * @param labelId
    * @param log
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月2日 下午2:25:24
     */
    public List<WebOrderLog> findOrderByLabel(Long labelId, WebOrderLog log);
    
    /**
     * 
    * @Description  订单最新的日志
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月2日 下午3:27:55
     */
    public WebOrderLog findLastByOrder(Long orderId);
    
    /**
     * 
    * @Description  获取订单所有日志
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月3日 下午4:39:12
     */
    public List<WebOrderLog> findAllByOrder(Long orderId);
    
    /**
     * 
    * @Description  获取订单，标签下日志
    * @param labelId
    * @param orderId
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月23日 上午10:42:13
     */
    public List<WebOrderLog> findLogByLabelAndOrder(Long labelId,Long orderId);
    
    /**
     * 
    * @Description  获取所有有日志的订单id
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月23日 下午3:19:20
     */
    public List<Long> getAllOrder();
}
