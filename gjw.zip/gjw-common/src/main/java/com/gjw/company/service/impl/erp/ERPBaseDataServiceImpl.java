/**
 * Project Name:ges-service-goujia
 * File Name:ERPBaseDataServiceImpl.java
 * Package Name:com.goujia.ges.service.impl
 * Date:2015年8月7日下午2:36:12
 * Copyright (c) 2015, chenzhou1025@126.com All Rights Reserved.
 *
 */

package com.gjw.company.service.impl.erp;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.support.WebApplicationObjectSupport;

import com.alibaba.fastjson.JSONObject;
import com.gjw.company.dao.cityoperator.IGesCityOperatorDAO;
import com.gjw.company.dao.erp.IGesErpCodeDAO;
import com.gjw.company.dao.erp.IGesErpSynchLogDAO;
import com.gjw.company.dao.erp.IGesStoreDAO;
import com.gjw.company.dao.erp.IMatterUnitDAO;
import com.gjw.company.dao.matter.IMaterialsCategoryDAO;
import com.gjw.company.dao.matter.IMatterDAO;
import com.gjw.company.dao.order.IGesOrderDAO;
import com.gjw.company.dao.user.IDeptDAO;
import com.gjw.company.service.erp.IERPBaseDataService;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.erp.GesErpCode;
import com.gjw.entity.erp.GesErpSynchLog;
import com.gjw.entity.erp.ws.ComputationUnitWs;
import com.gjw.entity.erp.ws.CurrentStockWs;
import com.gjw.entity.erp.ws.CustomerWs;
import com.gjw.entity.erp.ws.DepartmentWs;
import com.gjw.entity.erp.ws.GL_accvouchWs;
import com.gjw.entity.erp.ws.InventoryClassWs;
import com.gjw.entity.erp.ws.InventoryWs;
import com.gjw.entity.erp.ws.PersonWs;
import com.gjw.entity.erp.ws.SO_SOMainWs;
import com.gjw.entity.erp.ws.WarehouseWs;
import com.gjw.entity.erp.ws.fitemss97Ws;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.matter.MatterUnit;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.store.GesStore;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.User;
import com.gjw.utils.StringUtil;
import com.gjw.vo.MaterialsCategoryVO;

/**
 * ERP接口service
 * 
 * @author 1
 * @version
 * @since JDK 1.6
 * @see
 */
@Service("erpBaseDataServiceImpl")
public class ERPBaseDataServiceImpl extends WebApplicationObjectSupport implements IERPBaseDataService {
    private Logger LOG = LoggerFactory.getLogger(ERPBaseDataServiceImpl.class);

    // @Autowired
    // private DeptDao deptDao;
    //
    // @Autowired
    // private DataBaseLogDao dataBaseLogDao;
    // @Autowired
    // private MatterDao matterDao;
    //
    // @Autowired
    // private ShopDao shopDao;
    // @Autowired
    // private OrderDao orderDao;
    // @Autowired
    // private CityOperatorDao cityOperatorDao;
    //
    // @Autowired
    // private StoreDao storeDao;
    // @Autowired
    // private UserDao userDao;
    //
    // @Autowired
    // private MaterialsCategoryDao materialsCategoryDao;
    // @Autowired
    // private DataBaseDictionaryDao dataBaseDictionaryDao;

    @Autowired
    private IGesErpCodeDAO gesErpCodeDAO;
    @Autowired
    private IGesCityOperatorDAO gesCityOperatorDAO;

    @Autowired
    private IGesStoreDAO gesStoreDAO;

    @Autowired
    private IMaterialsCategoryDAO materialsCategoryDAO;

    @Autowired
    private IMatterUnitDAO matterUnitDAO;

    @Autowired
    private IMatterDAO matterDAO;

    @Autowired
    private IGesErpSynchLogDAO gesErpSynchLogDAO;

    @Autowired
    private IGesOrderDAO gesOrderDAO;

    @Autowired
    private IDeptDAO deptDAO;

    /**
     * 销售订单自动流转接 Insert
     * 
     * @author gwb
     * @param xml
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:22:26
     */
    @Override
    @Transactional
    public String SO_SOMainWsInsert(HttpServletRequest request, String xml, String cSerialnumber) {
        SO_SOMainWs client = (SO_SOMainWs) this.getApplicationContext().getBean("clientSO_SOMainWs");
        return client.Insert(xml, cSerialnumber);
    }

    @Override
    @Transactional
    public String SO_SOMainWsUpdate(HttpServletRequest request, String xml, String cSerialnumber) {
        SO_SOMainWs client = (SO_SOMainWs) this.getApplicationContext().getBean("clientSO_SOMainWs");
        return client.Update(xml, cSerialnumber);
    }

    /**
     * 现存量情况表（城运商查询）接口 CurrentStockWsGetAll
     * 
     * @author gwb
     * @param cInvCode
     * @param cWhCode
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:23:43
     */
    @Override
    @Transactional
    public String CurrentStockWsGetAll(HttpServletRequest request, String cInvCode, String cWhCode, String cSerialnumber) {
        CurrentStockWs client = (CurrentStockWs) this.getApplicationContext().getBean("clientCurrentStockWs");
        return client.GetAll(cInvCode, cWhCode, cSerialnumber);

    }

    @Override
    @Transactional
    public String CurrentStockWsGetAll2(HttpServletRequest request, String cInvCode, String cCusCode, String cDefine3,
            String dDateB, String dDateE, String cRollback, String cSerialnumber) {
        CurrentStockWs client = (CurrentStockWs) this.getApplicationContext().getBean("clientCurrentStockWs");
        return client.GetAll2(cInvCode, cCusCode, cDefine3, dDateB, dDateE, cRollback, cSerialnumber);
    }

    @Override
    @Transactional
    public String CurrentStockWsUpdate(HttpServletRequest request, String cCode, int rows, String cSerialnumber) {
        CurrentStockWs client = (CurrentStockWs) this.getApplicationContext().getBean("clientCurrentStockWs");
        return client.Update(cCode, rows, cSerialnumber);
    }

    /**
     * 3 销售收款情况表(客户对帐单)接口 GL_accvouchWsGetAll
     * 
     * @author gwb
     * @param citem_id
     * @param ccus_id
     * @param cdefine3
     * @param dDateB
     * @param dDateE
     * @param cSerialnumber
     * @return 2015年8月7日 下午2:27:26
     */
    @Override
    @Transactional
    public String GL_accvouchWsGetAll(HttpServletRequest request, String citem_id, String ccus_id, String cdefine3,
            String dDateB, String dDateE, String cSerialnumber) {

        GL_accvouchWs client = (GL_accvouchWs) this.getApplicationContext().getBean("clientGL_accvouchWs");
        return client.GetAll(citem_id, ccus_id, cdefine3, dDateB, dDateE, cSerialnumber);
    }

    /**
     * 客户档案需要同步接口 CustomerWsInsert
     * 
     * @author gwb
     * @param cCusCode
     * @param cCusName
     * @param cCusAbbName
     * @param cCCCode
     * @param cSerialnumbe
     * @return 2015年8月7日 下午2:27:15
     */
    @Override
    @Transactional
    public String CustomerWsInsert(HttpServletRequest request, String cCusCode, String cCusName, String cCusAbbName,
            String cCCCode, String cSerialnumbe, List<GesShop> listShop) {
        CustomerWs client = (CustomerWs) this.getApplicationContext().getBean("clientCustomerWs");

        // DataBaseDictionary dataBaseDictionary = new DataBaseDictionary();
        // dataBaseDictionary.setListtime(new Date());
        // dataBaseDictionary.setLastoperater(UserHelper.loginName());
        // dataBaseDictionary.setProcjectcode("0103");
        //
        // try {
        // dataBaseDictionaryDao.updateByPrimaryKeySelective(dataBaseDictionary);
        // } catch (Exception e) {
        // LOG.error("----------------------客户档案需要同步接口修改基础数据字典表失败-----------------------");
        // e.printStackTrace();
        //
        // }
        //
        // for (GesShop obj : listShop) {
        // String re = "";
        // DataBaseLog dataBaseLog = new DataBaseLog();
        // if (obj.getType() == 2 || obj.getType() == 1) {
        // re = client.Insert(obj.getCode(), obj.getName(), obj.getName(), "15",
        // "123");
        // } else {
        // re = CustomerWsUpdate(request, null, null, null, null, null, obj);
        // }
        // JSONObject json = (JSONObject) JSONObject.parse(re);
        // dataBaseLog.setModulename("客户档案");
        // dataBaseLog.setProjectname("4S店");
        // dataBaseLog.setModulecode("01");
        // dataBaseLog.setProjectcode("0103");
        // dataBaseLog.setData(obj.getName());
        // dataBaseLog.setDatabasecode(obj.getCode());
        // dataBaseLog.setOperaterid(UserHelper.cuid());
        // dataBaseLog.setOperatername(UserHelper.loginName());
        // dataBaseLog.setCreatetime(new Date());
        // dataBaseLog.setType(json.get("success") + "");
        // dataBaseLog.setMsg(json.get("message") + "");
        //
        // int id = 0;
        // try {
        // id = dataBaseLogDao.insert(dataBaseLog);
        // } catch (Exception e) {
        // LOG.error("----------------------客户档案需要同步接口，插入基础数据日志表失败4s店id为：" +
        // obj.getId()
        // + "-----------------------");
        // e.printStackTrace();
        //
        // }
        //
        // if (id > 0) {
        // if (json.get("success").equals("0")) {
        // obj.setType(0);
        // } else {
        // obj.setType(1);
        // }
        //
        // try {
        // shopDao.update(obj);
        // } catch (Exception e) {
        // LOG.error("----------------------客户档案需要同步接口，修改4s店同步结果失败，4s店id为：" +
        // obj.getId()
        // + "-----------------------");
        // e.printStackTrace();
        //
        // }
        //
        // }
        // }

        return null;
    }

    @Override
    @Transactional
    public String CustomerWsUpdate(HttpServletRequest request, String cCusCode, String cCusName, String cCusAbbName,
            String cCCCode, String cSerialnumbe, GesShop shop) {
        CustomerWs client = (CustomerWs) this.getApplicationContext().getBean("clientCustomerWs");
        return client.Update(shop.getCode(), shop.getName(), shop.getName(), "15", "123");

    }

    /**
     * 存货分类档案需要同步接口
     */
    @Override
    @Transactional
    public String InventoryClassWsInsert(HttpServletRequest request, String cInvCCode, String cInvCName,
            String cSerialnumbe, List<Map<String, Object>> listMaterialsCategory, Long cuid) {
        InventoryClassWs client = (InventoryClassWs) this.getApplicationContext().getBean("clientInventoryClassWs");
        // gesErpCodeDAO
        GesErpCode dataBaseDictionary = new GesErpCode();
        dataBaseDictionary.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        User user = new User();
        user.setId(cuid);
        dataBaseDictionary.setLastOperater(user);
        dataBaseDictionary.setProcjectCode("0302");
        try {
            gesErpCodeDAO.updateByProcjectCode(dataBaseDictionary);
        } catch (Exception e) {
            LOG.error("----------------------存货分类档案需要同步接口，修改基础数据字段表失败-----------------------");
            e.printStackTrace();

        }

        for (Map<String, Object> obj : listMaterialsCategory) {
            String re = "";
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();
            if (obj.get("type") == null || obj.get("type").toString().equals("1130101")
                    || obj.get("type").toString().equals("1130103")) {
                re = client.Insert(obj.get("code").toString(), obj.get("name").toString(), "123");
            } else if (obj.get("type").toString().equals("1130104")) {
                re = InventoryClassWsUpdate(request, null, null, null, obj);
            }

            if (StringUtil.isEmpty(re))
                continue;

            if (LOG.isInfoEnabled()) {

                LOG.info("接口返回结果：{}", re);
            }

            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("基础数据");
            dataBaseLog.setProjectName("建材库类目");
            dataBaseLog.setModuleCode("03");
            dataBaseLog.setProjectCode("0302");
            dataBaseLog.setDataName(obj.get("name").toString());
            dataBaseLog.setDataBaseCode(obj.get("code").toString());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType((Integer.parseInt(json.get("success").toString())));
            dataBaseLog.setMsg(obj.get("code").toString() + " " +   obj.get("name").toString() + " " + json.get("message") + "");
            try {
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {
                LOG.error("----------------------存货分类档案需要同步接口，向基础数日志表插入数据失败，id为：" + obj.get("id").toString()
                        + "-----------------------");
                e.printStackTrace();

            }
            if (dataBaseLog.getId() > 0) {
                MaterialsCategoryVO materialsCategoryVO = new MaterialsCategoryVO();
                materialsCategoryVO.setId(obj.get("id").toString());
                if (json.get("success").equals("0")) {
                    materialsCategoryVO.setType(Long.parseLong("1130102"));
                } else if (json.get("message").toString().contains("已存在")) {
                    materialsCategoryVO.setType(Long.parseLong("1130105"));
                } else {
                    materialsCategoryVO.setType(Long.parseLong("1130103"));
                }

                try {
                    materialsCategoryDAO.updateMaterialsCategory(materialsCategoryVO);
                } catch (Exception e) {
                    LOG.error("----------------------存货分类档案需要同步接口，修改基础数据同步状态失败，id为：" + obj.get("id").toString()
                            + "-----------------------");
                    e.printStackTrace();

                }

            }
        }

        return null;
    }

    @Override
    @Transactional
    public String InventoryClassWsUpdate(HttpServletRequest request, String cInvCCode, String cInvCName,
            String cSerialnumbe, Map<String, Object> obj) {
        InventoryClassWs client = (InventoryClassWs) this.getApplicationContext().getBean("clientInventoryClassWs");
        return client.Update(obj.get("code").toString(), obj.get("name").toString(), "123");
    }

    /**
     * 存货档案需要同步接口--物料
     * <p>
     * 物料
     */
    @Override
    @Transactional
    public String InventoryWsInsert(HttpServletRequest request, String cInvCode, String cInvName, String cInvCCode,
            String cComUnitCode, String cSerialnumbe, List<Matter> listMatter, Long cuid) {
        InventoryWs client = (InventoryWs) this.getApplicationContext().getBean("clientInventoryWs");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        /************** 最后修改人 *****************/
        User user = new User();
        user.setId(cuid);
        gesErpCode.setLastOperater(user);
        gesErpCode.setProcjectCode("0303");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {
            LOG.error("----------------------存货档案需要同步接口，修改基础数据字典表失败-----------------------");
            e.printStackTrace();

        }

        for (Matter obj : listMatter) {
            String re = "";
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();

            if (obj.getSynchType() == null || obj.getSynchType().getId() == 1130101
                    || obj.getSynchType().getId() == 1130103) {
                re = client.Insert(obj.getCode(), obj.getName(), obj.getCode().substring(1, 5), obj.getMatterUnit()
                        .getCode(), "123");

            } else if (obj.getSynchType().getId() == 1130104) {
                re = InventoryWsUpdate(request, null, null, null, null, null, obj);
            }

            if (StringUtil.isEmpty(re))
                continue;

            if (LOG.isInfoEnabled()) {
                LOG.info("接口返回结果:{}", re);
            }

            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("基础数据");
            dataBaseLog.setProjectName("物料档案");
            dataBaseLog.setModuleCode("03");
            dataBaseLog.setProjectCode("0303");
            dataBaseLog.setDataName(obj.getName());
            dataBaseLog.setDataBaseCode(obj.getCode());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType((Integer.parseInt(json.get("success").toString())));
            dataBaseLog.setMsg(obj.getCode() + " " + obj.getName() + " " + json.get("message") + "");

            try {
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {
                LOG.error("----------------------存货档案需要同步接口，向基础数据日志表插入数据失败id:" + obj.getId()
                        + "-----------------------");
                e.printStackTrace();

            }
            if (dataBaseLog.getId() > 0) {
                Dictionary dictionary = new Dictionary();

                if (json.get("success").equals("0")) {
                    dictionary.setId(1130102l);
                    obj.setSynchType(dictionary);
                } else if (json.get("message").toString().contains("已存在")) {
                    dictionary.setId(1130105l);
                    obj.setSynchType(dictionary);
                } else {
                    dictionary.setId(1130103l);
                    obj.setSynchType(dictionary);
                }

                try {
                    matterDAO.updateMatter4Syn(obj);
                } catch (Exception e) {

                    LOG.error("----------------------存货档案需要同步接口，修改基础数据同步结果状态失败id为:" + obj.getId()
                            + "-----------------------");
                    e.printStackTrace();

                }

            }
        }

        return null;
    }

    @Override
    @Transactional
    public String InventoryWsUpdate(HttpServletRequest request, String cInvCode, String cInvName, String cInvCCode,
            String cComUnitCode, String cSerialnumbe, Matter atter) {
        InventoryWs client = (InventoryWs) this.getApplicationContext().getBean("clientInventoryWs");
        return client.Update(atter.getCode(), atter.getName(), atter.getCode().substring(1, 5), atter.getMatterUnit()
                .getCode(), "123");
    }

    /**
     * 部门档案需要同步接口
     */
    @Override
    @Transactional
    public String DepartmentWsInsert(HttpServletRequest request, String cDepCode, String cDepName, String cSerialnumbe,
            List<Dept> listDept, Long cuid) {
        DepartmentWs client = (DepartmentWs) this.getApplicationContext().getBean("clientDepartmentWs");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        /************** 最后修改人 *****************/
        User user = new User();
        user.setId(cuid);
        gesErpCode.setLastOperater(user);
        gesErpCode.setProcjectCode("0201");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {
            LOG.error("----------------------部门档案需要同步接口，修改基础数据字典表失败-----------------------");
            e.printStackTrace();

        }

        for (Dept dept : listDept) {
            String re = "";
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();
            if (dept.getPropertyType() == null || dept.getPropertyType().getId() == 1130101
                    || dept.getPropertyType().getId() == 1130103) {
                re = client.Insert(dept.getCode(), dept.getName(), "123");
            } else if (dept.getPropertyType().getId() == 1130104) {
                re = DepartmentWsUpdate(request, null, null, null, dept);
            }
            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("组织架构");
            dataBaseLog.setProjectName("部门档案");
            dataBaseLog.setModuleCode("02");
            dataBaseLog.setProjectCode("0201");
            dataBaseLog.setDataName(dept.getName());
            dataBaseLog.setDataBaseCode(dept.getCode());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(dept.getCode() + " " +  dept.getName() + " " + json.get("message") + "");

            try {
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {

                LOG.error("----------------------部门档案需要同步接口，向基础数据日志表插入数据失败id为：" + dept.getId()
                        + "-----------------------");
                e.printStackTrace();

            }
            if (dataBaseLog.getId() > 0) {
                Dictionary propertyType = new Dictionary();
                if (json.get("success").equals("0")) {
                    propertyType.setId(1130102l);
                    dept.setPropertyType(propertyType);
                } else if (json.get("message").toString().contains("已存在")) {
                    propertyType.setId(1130105l);
                    dept.setPropertyType(propertyType);
                } else {
                    propertyType.setId(1130103l);
                    dept.setPropertyType(propertyType);
                }
                try {
                    deptDAO.updateDeptForSynch(dept);
                } catch (Exception e) {

                    LOG.error("----------------------部门档案需要同步接口，修改基础数据同步结果失败id为：" + dept.getId()
                            + "-----------------------");
                    e.printStackTrace();

                }

            }
        }
        return null;
    }

    @Override
    @Transactional
    public String DepartmentWsUpdate(HttpServletRequest request, String cDepCode, String cDepName, String cSerialnumbe,
            Dept dept) {
        DepartmentWs client = (DepartmentWs) this.getApplicationContext().getBean("clientDepartmentWs");
        return client.Update(dept.getCode(), dept.getName(), "123");

    }

    /**
     * 人员档案需要同步接口
     */
    @Override
    @Transactional
    public String PersonWsInsert(HttpServletRequest request, String cPersonCode, String cPersonName, String cDepCode,
            String rSex, String cSerialnumbe, List<DeptUser> listUserVO, Long cuid) {
        PersonWs client = (PersonWs) this.getApplicationContext().getBean("clientPersonWs");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        User user = new User();
        user.setId(cuid);
        gesErpCode.setLastOperater(user);
        gesErpCode.setProcjectCode("0202");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {
            LOG.error("----------------------人员档案需要同步接口，修改基础数据字典表失败-----------------------");
            e.printStackTrace();

        }

        for (DeptUser dept : listUserVO) {
            String re = "";
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();
            if (dept.getSynchType() == null || dept.getSynchType().getId() == 1130101
                    || dept.getSynchType().getId() == 1130103) {
                re = client.Insert(dept.getId() + "", dept.getUser().getPlatformUserInfo().getRealName(), dept
                        .getDept().getCode(), "", "123");
            } else {
                re = PersonWsUpdate(request, null, null, null, null, null, dept);
            }
            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("组织架构");
            dataBaseLog.setProjectName("人员档案");
            dataBaseLog.setModuleCode("02");
            dataBaseLog.setProjectCode("0202");
            dataBaseLog.setDataName(dept.getUser().getPlatformUserInfo().getRealName());
            dataBaseLog.setDataBaseCode(dept.getDept().getCode());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(dept.getUser().getPlatformUserInfo().getRealName() + " " + json.get("message") + "");
            try {
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {
                LOG.error("----------------------人员档案需要同步接口，向基础数据日志表插入数据失败，id为：" + dept.getId()
                        + "-----------------------");
                e.printStackTrace();

            }
            if (dataBaseLog.getId() > 0) {

                Dictionary propertyType = new Dictionary();
                if (json.get("success").equals("0")) {
                    propertyType.setId(1130102l);
                    dept.setSynchType(propertyType);
                } else if (json.get("message").toString().contains("已存在")) {
                    propertyType.setId(1130105l);
                    dept.setSynchType(propertyType);
                } else {
                    propertyType.setId(1130103l);
                    dept.setSynchType(propertyType);
                }

                try {
                    deptDAO.updateDeptUserForSynch(dept);
                } catch (Exception e) {

                    LOG.error("----------------------人员档案需要同步接口，修改基础数据同步结果失败，id为：" + dept.getId()
                            + "-----------------------");
                    e.printStackTrace();

                }
            }
        }
        return null;
    }

    @Override
    @Transactional
    public String PersonWsUpdate(HttpServletRequest request, String cPersonCode, String cPersonName, String cDepCode,
            String rSex, String cSerialnumbe, DeptUser userVO) {
        PersonWs client = (PersonWs) this.getApplicationContext().getBean("clientPersonWs");
        return client.Update(userVO.getId() + "", userVO.getUser().getPlatformUserInfo().getRealName(), userVO
                .getDept().getCode(), "", "123");

    }

    /**
     * 仓库档案需要同步接口
     */
    // TODO
    @Override
    @Transactional
    public String WarehouseWsInsert(HttpServletRequest request, String cWhCode, String cWhName, String cSerialnumber,
            List<GesStore> listStore, Long cuid) {
        WarehouseWs client = (WarehouseWs) this.getApplicationContext().getBean("clientWarehouseWs");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        User lastOperater = new User();
        lastOperater.setId(cuid);
        gesErpCode.setLastOperater(lastOperater);
        gesErpCode.setProcjectCode("0301");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {
            LOG.error("----------------------仓库档案需要同步接口，修改基础数据字典表失败-----------------------");
            e.printStackTrace();

        }

        for (GesStore dept : listStore) {
            String re = "";
            /*----------------------------*/
            // 数据同步类型：0：同步成功，1：同步失败,2：未同步，3：同步后已修改
            // 679未同步（默认状态）---680同步成功 ----681同步失败 ----682同步后修改---- 683同步失败数据已存在
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();

            if (dept.getSynchType() == null || dept.getSynchType().getId() == 1130101
                    || dept.getSynchType().getId() == 1130103) {
                re = client.Insert(dept.getCode(), dept.getName(), "123");
            } else {
                re = WarehouseWsUpdate(request, null, null, null, dept);
            }
            JSONObject json = (JSONObject) JSONObject.parse(re);
            /*----------------------------*/
            dataBaseLog.setModuleName("基础数据");
            dataBaseLog.setProjectName("仓库档案");
            dataBaseLog.setModuleCode("03");
            dataBaseLog.setProjectCode("0301");
            dataBaseLog.setDataName(dept.getName());
            dataBaseLog.setDataBaseCode(dept.getCode());
            // dataBaseLog.setOperaterid(UserHelper.cuid());
            // dataBaseLog.setOperatername(UserHelper.loginName());
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(dept.getCode() + " " +  dept.getName() + " " + json.get("message") + "");

            try {
                /*----------------------------*/
                // id = dataBaseLogDao.insert(dataBaseLog);ss
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {
                LOG.error("----------------------仓库档案需要同步接口，箱基础书字典表插入数据失败id为：" + dept.getId()
                        + "-----------------------");
                e.printStackTrace();

            }

            GesStore store = new GesStore();
            store.setId(dept.getId());
            if (dataBaseLog.getId() > 0) {
                Dictionary dictionary = new Dictionary();
                if (json.get("success").equals("0")) {
                    dictionary.setId(1130102l);
                    store.setSynchType(dictionary);
                } else if (json.get("message").toString().contains("已存在")) {
                    dictionary.setId(1130105l);
                    store.setSynchType(dictionary);
                } else {
                    dictionary.setId(1130103l);
                    store.setSynchType(dictionary);
                }
                try {
                    gesStoreDAO.updateById(store);
                } catch (Exception e) {

                    LOG.error("----------------------仓库档案需要同步接口，修改基础数据同步结果id为：" + dept.getId()
                            + "-----------------------");
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    @Override
    @Transactional
    public String WarehouseWsUpdate(HttpServletRequest request, String cWhCode, String cWhName, String cSerialnumber,
            GesStore storeVO) {
        WarehouseWs client = (WarehouseWs) this.getApplicationContext().getBean("clientWarehouseWs");
        return client.Update(storeVO.getCode(), storeVO.getName(), "123");
    }

    /**
     * 项目档案需要同步 施工项目
     */
    @Override
    @Transactional
    public String Fitemss97WsInsert(HttpServletRequest request, String citemcode, String citemname,
            String cSerialnumber, List<GesOrder> listOrder, Long cuid) {
        fitemss97Ws client = (fitemss97Ws) this.getApplicationContext().getBean("clientfitemss97Ws");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        User lastOperater = new User();
        lastOperater.setId(cuid);
        gesErpCode.setLastOperater(lastOperater);

        gesErpCode.setProcjectCode("0305");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e2) {

            LOG.error("----------------------项目档案需要同步 施工项目，修改项目施工字典表状态失败-----------------------");
            e2.printStackTrace();

        }

        for (GesOrder dept : listOrder) {
            String re = "";
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();

            if (dept.getProjectType() == null || dept.getProjectType() == 1130101 || dept.getProjectType() == 1130103) {
                re = client.Insert(dept.getCode(), dept.getCode() + dept.getGoods().getName(), "123");
            } else {
                re = Fitemss97WsUpdate(request, null, null, null, dept);
            }
            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("基础数据");
            dataBaseLog.setProjectName("项目档案");
            dataBaseLog.setModuleCode("03");
            dataBaseLog.setProjectCode("0305");
            dataBaseLog.setDataName(dept.getShop().getName());
            dataBaseLog.setDataBaseCode(dept.getCode());
            dataBaseLog.setOperaterId(lastOperater);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(dept.getCode() + " " +  dept.getGoods().getName() + " " + json.get("message") + "");
            try {
                // id = dataBaseLogDao.insert(dataBaseLog);
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e1) {
                LOG.error("-----------------订单id为：" + dept.getId() + "项目施工档案数据同步插入日志表失败！id为：" + dept.getId()
                        + "---------------");
                e1.printStackTrace();
            }

            GesOrder order = new GesOrder();
            order.setId(dept.getId());
            if (dataBaseLog.getId() > 0) {

                // Dictionary dictionary = new Dictionary();
                if (json.get("success").equals("0")) {
                    // dictionary.setId(1130102l);
                    order.setProjectType(1130102);
                } else if (json.get("message").toString().contains("已存在")) {
                    // dictionary.setId(1130105l);
                    order.setProjectType(1130105);
                } else {
                    // dictionary.setId(1130103l);
                    order.setProjectType(1130103);
                }
                try {
                    gesOrderDAO.updateProjectSynch(order);
                } catch (Exception e) {
                    LOG.error("---------------------订单号为：" + order.getId() + "修改项目施工管理同步结果失败------------------------");
                    e.printStackTrace();

                }

            }
        }

        return null;
    }

    @Override
    @Transactional
    public String Fitemss97WsUpdate(HttpServletRequest request, String citemcode, String citemname,
            String cSerialnumber, GesOrder order) {
        fitemss97Ws client = (fitemss97Ws) this.getApplicationContext().getBean("clientfitemss97Ws");
        // return client.Update(order.getCode(), order.getCode() +
        // order.getGoodsName(), "123");
        return "";
    }

    /**
     * 计量单位档案需要同步 单位
     */
    @Override
    @Transactional
    public String ComputationUnitWsInsert(HttpServletRequest request, String cComunitCode, String cComUnitName,
            String cSerialnumber, List<MatterUnit> listMatter, Long cuid) {
        ComputationUnitWs client = (ComputationUnitWs) this.getApplicationContext().getBean("clientComputationUnitWs");
        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        /************** 最后修改人 *****************/
        User user = new User();
        user.setId(cuid);
        gesErpCode.setLastOperater(user);
        gesErpCode.setProcjectCode("0304");
        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {

            LOG.error("---------------------计量单位档案需要同步 单位,修改基础数据字典表状态失败--------------------------");
            e.printStackTrace();

        }

        for (MatterUnit obj : listMatter) {
            String re = "";
            // DataBaseLog dataBaseLog = new DataBaseLog();
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();
            if (obj.getSynchType() == null || obj.getSynchType().getId() == 1130101
                    || obj.getSynchType().getId() == 1130103) {
                re = client.Insert(obj.getCode(), obj.getUnitName(), "123");
            } else if (obj.getSynchType().getId() == 1130104) {
                re = ComputationUnitWsUpdate(request, null, null, null, obj);
            }

            if (LOG.isInfoEnabled()) {
                LOG.info(re);
            }

            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("基础数据");
            dataBaseLog.setProjectName("计量单位");
            dataBaseLog.setModuleCode("03");
            dataBaseLog.setProjectCode("0304");
            dataBaseLog.setDataName(obj.getUnitName());
            dataBaseLog.setDataBaseCode(obj.getCode());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(obj.getCode() + " " +  obj.getUnitName()+ " " +json.get("message") + "");

            try {
                // id = dataBaseLogDao.insert(dataBaseLog);
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {

                LOG.error("---------------------计量单位档案需要同步 单位,向基础数据字典表插入数据失败，id为：" + obj.getId()
                        + "-------------------------");
                e.printStackTrace();

            }

            if (dataBaseLog.getId() > 0) {
                Dictionary dictionary = new Dictionary();
                if (json.get("success").equals("0")) {
                    dictionary.setId(1130102l);
                    obj.setSynchType(dictionary);
                } else if (json.get("message").toString().contains("已存在")) {
                    dictionary.setId(1130105l);
                    obj.setSynchType(dictionary);
                } else {
                    dictionary.setId(1130103l);
                    obj.setSynchType(dictionary);
                }

                try {
                    matterUnitDAO.updateMatterUnitSynch(obj);
                } catch (Exception e) {

                    LOG.error("---------------------计量单位档案需要同步 单位,修改基础数据同步结果失败id为：" + obj.getId()
                            + "-------------------------");
                    e.printStackTrace();

                }

            }
        }
        return null;
    }

    @Override
    @Transactional
    public String ComputationUnitWsUpdate(HttpServletRequest request, String cComunitCode, String cComUnitName,
            String cSerialnumber, MatterUnit matter) {
        ComputationUnitWs client = (ComputationUnitWs) this.getApplicationContext().getBean("clienComputationUnitWs");
        return client.Update(matter.getCode(), matter.getUnitName(), "123");
    }

    /**
     * 往来单位分类档案需要同步
     */
    @Override
    @Transactional
    public String CustomerClassWsInsert(HttpServletRequest request, String cCCCode, String cCCName, String cSerialnumber) {
        // CustomerClassWs client = (CustomerClassWs)
        // this.getApplicationContext().getBean("clientCustomerClassWs");
        // String re = client.Insert("15", "4s店客户", "123");
        // LOG.info("------------往来单位分类档案需要同步开始-----------------------");
        // DataBaseDictionary dataBaseDictionary = new DataBaseDictionary();
        // dataBaseDictionary.setListtime(new Date());
        // dataBaseDictionary.setLastoperater(UserHelper.loginName());
        // dataBaseDictionary.setProcjectcode("0101");
        //
        // try {
        // dataBaseDictionaryDao.updateByPrimaryKeySelective(dataBaseDictionary);
        // } catch (Exception e) {
        //
        // LOG.error("------------往来单位分类档案需要同步,修改基础数据字典表失败-----------------------");
        // e.printStackTrace();
        //
        // }
        //
        // DataBaseLog dataBaseLog = new DataBaseLog();
        // JSONObject json = (JSONObject) JSONObject.parse(re);
        // dataBaseLog.setModulename("客户档案");
        // dataBaseLog.setProjectname("4s点客户");
        // dataBaseLog.setModulecode("01");
        // dataBaseLog.setProjectcode("0101");
        // dataBaseLog.setData("4s点客户");
        // dataBaseLog.setDatabasecode("14");
        // dataBaseLog.setOperaterid(UserHelper.cuid());
        // dataBaseLog.setOperatername(UserHelper.loginName());
        // dataBaseLog.setCreatetime(new Date());
        // dataBaseLog.setType(json.get("success") + "");
        //
        // try {
        // int id = dataBaseLogDao.insert(dataBaseLog);
        // } catch (Exception e) {
        //
        // LOG.error("------------往来单位分类档案需要同步,4s店客户向基础数据日志表插入数据失败-----------------------");
        // e.printStackTrace();
        //
        // }
        //
        // String re1 = client.Insert("14", "承运商客户", "123");
        // DataBaseLog dataBaseLog1 = new DataBaseLog();
        // JSONObject json1 = (JSONObject) JSONObject.parse(re1);
        // dataBaseLog1.setModulename("基础数据");
        // dataBaseLog1.setProjectname("承运商客户");
        // dataBaseLog1.setModulecode("01");
        // dataBaseLog1.setProjectcode("0101");
        // dataBaseLog1.setData("4s点客户");
        // dataBaseLog1.setDatabasecode("15");
        // dataBaseLog1.setOperaterid(UserHelper.cuid());
        // dataBaseLog1.setOperatername(UserHelper.loginName());
        // dataBaseLog1.setCreatetime(new Date());
        // dataBaseLog1.setType(json1.get("success") + "");
        // try {
        // int id1 = dataBaseLogDao.insert(dataBaseLog);
        // } catch (Exception e) {
        //
        // LOG.error("------------往来单位分类档案需要同步,承运商客户向基础数据日志表插入数据失败-----------------------");
        // e.printStackTrace();
        //
        // }
        return null;
    }

    //
    @Override
    @Transactional
    public String CustomerClassWsUpdate(HttpServletRequest request, String cCCCode, String cCCName, String cSerialnumber) {
        // CustomerClassWs client = (CustomerClassWs)
        // this.getApplicationContext().getBean("clienCustomerClassWs");
        // client.Update("15", "4s点客户", "123");
        // client.Update("14", "承运商客户", "123");
        return null;
    }

    /**
     * 
     * 城运商客户数据同步
     */
    @Override
    @Transactional
    public String CustomerWsInsertCity(HttpServletRequest request, String cCusCode, String cCusName,
            String cCusAbbName, String cCCCode, String cSerialnumbe, List<GesCityOperator> listCityOperator, Long cuid) {
        CustomerWs client = (CustomerWs) this.getApplicationContext().getBean("clientCustomerWs");

        GesErpCode gesErpCode = new GesErpCode();
        gesErpCode.setUpdatedDatetime(new Timestamp(System.currentTimeMillis()));
        /************** 最后修改人 *****************/
        User user = new User();
        user.setId(cuid);
        gesErpCode.setLastOperater(user);
        gesErpCode.setProcjectCode("0102");

        try {
            gesErpCodeDAO.updateByProcjectCode(gesErpCode);
        } catch (Exception e) {
            LOG.error("------------城运商客户数据同步,城运商客户数据同步，修改基础数据字典表失败-----------------------");
            e.printStackTrace();

        }

        for (GesCityOperator obj : listCityOperator) {
            if (obj.getUfCode() == null)
                continue;
            String re = "";
            // DataBaseLog dataBaseLog = new DataBaseLog();
            GesErpSynchLog dataBaseLog = new GesErpSynchLog();
            if (obj.getSynchType() == null || obj.getSynchType().getId() == 1130101
                    || obj.getSynchType().getId() == 1130103) {
                /*
                 * 1．cCusCode 客户编码 2．cCusName客户名称 3．cCusAbbName客户简称
                 * 4．cCCCode客户分类编码 5．cSerialnumber 接口序列号
                 */
                re = client.Insert(obj.getUfCode(), obj.getCompanyName(), obj.getCompanyName(), "03", "123");
            } else {
                re = CustomerWsUpdateCity(request, null, null, null, null, null, obj);
            }
            JSONObject json = (JSONObject) JSONObject.parse(re);
            dataBaseLog.setModuleName("客户档案");
            dataBaseLog.setProjectName("城运商");
            dataBaseLog.setModuleCode("01");
            dataBaseLog.setProjectCode("0102");
            dataBaseLog.setDataName(obj.getCompanyName());
            dataBaseLog.setDataBaseCode(obj.getUfCode());
            dataBaseLog.setOperaterId(user);
            dataBaseLog.setCreatedDatetime(new Timestamp(System.currentTimeMillis()));
            dataBaseLog.setSynchType(Integer.parseInt(json.get("success").toString()));
            dataBaseLog.setMsg(obj.getUfCode() + " " +  obj.getCompanyName() + " " + json.get("message") + "");
            try {
                gesErpSynchLogDAO.addGesErpSynchLog(dataBaseLog);
            } catch (Exception e) {
                LOG.error("------------城运商客户数据同步,城运商客户数据同步，向基础数据日志表中插入数据失败-----------------------");
                e.printStackTrace();

            }
            if (dataBaseLog.getId() > 0) {
                Dictionary dictionary = new Dictionary();
                if (json.get("success").equals("0")) {
                    dictionary.setId(1130102l);
                    obj.setSynchType(dictionary);
                } else if (json.get("message").toString().contains("已存在")) {
                    dictionary.setId(1130105l);
                    obj.setSynchType(dictionary);
                } else {
                    dictionary.setId(1130103l);
                    obj.setSynchType(dictionary);
                }
                try {
                    gesCityOperatorDAO.update(obj);
                } catch (Exception e) {

                    LOG.error("------------城运商客户数据同步,城运商客户数据同步，修改基础数据同步结果失败-----------------------");
                    e.printStackTrace();

                }

            }
        }
        return null;
    }

    @Override
    @Transactional
    public String CustomerWsUpdateCity(HttpServletRequest request, String cCusCode, String cCusName,
            String cCusAbbName, String cCCCode, String cSerialnumbe, GesCityOperator cityOperator) {
        CustomerWs client = (CustomerWs) this.getApplicationContext().getBean("clientCustomerWs");
        return client.Update(cityOperator.getCode(), cityOperator.getCompanyName(), cityOperator.getCompanyName(),
                "15", "123");
    }

}
