package com.gjw.company.service.app;

import java.util.List;

import com.gjw.entity.app.WebContrast;

public interface IWebContrastService {
    public WebContrast get(Long id);

    public List<WebContrast> getList(WebContrast webContrast);
    
    public boolean addWebContrast(WebContrast webContrast);
    
    public void updateWebContrast(WebContrast webContrast);
}
