package com.gjw.company.dao.order;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.order.WebOrderVideo;

/**
 * 
* @Description: 视频dao接口类
* @author  zhaoyonglian
* @date 2015年12月19日 上午10:40:49
*
 */
public interface IWebOrderVideoDAO extends IDAO {

	/**
	 * 
	* @Description  获得订单视频列表
	* @param orderId
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月19日 下午3:21:34
	 */
	public List<WebOrderVideo> listByOrder(Long orderId);
	
	
	/**
	 * 
	* @Description  修改视频信息
	* @param log
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月19日 上午10:40:00
	 */
	public boolean updateVideo(WebOrderVideo video);
}
