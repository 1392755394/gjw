package com.gjw.company.service.app;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.app.WebContrastDetail;

public interface IWebContrastDetailService extends IService{
    public WebContrastDetail get(Long id);

    public List<WebContrastDetail> getList(WebContrastDetail model);
    
    public boolean addWebContrastDetail(WebContrastDetail model);
    
    public void updateWebContrastDetail(WebContrastDetail model);
}
