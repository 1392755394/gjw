package com.gjw.company.dao.topic;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.topic.WebTopicArticleItem;

/**
 * 
* @Description: 话题文章dao接口类
* @author  zhaoyonglian
* @date 2015年12月24日 上午10:41:35
*
 */
public interface IWebTopicArticleItemDAO extends IDAO {

	
	/**
	 * 
	* @Description  话题相关文章列表
	* @param topicId
	* @return
	* @author zhaoyonglian   
	* @date 2015年12月24日 下午4:05:23
	 */
	public List<WebTopicArticleItem> listByTopic(Long topicId);
	
	/**
	 * 
	* @Description  文章相关话题列表
	* @param articleId
	* @return
	* @author qingye   
	* @date Dec 30, 2015 2:30:59 PM
	 */
	public List<WebTopicArticleItem> listByArticle(Long articleId);

    /** 
    * @Description  
    * @param article
    * @author qingye   
    * @date Dec 30, 2015 3:09:34 PM
    */
    
    public void deleteByArticle(WebArticle article);

    /** 
    * @Description  
    * @return
    * @author qingye   
    * @date Dec 30, 2015 5:15:04 PM
    */
    
    public List<WebTopicArticleItem> countGroupByTopic();
    
}
