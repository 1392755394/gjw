package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.Dept;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesCityOperatorVO;
import com.gjw.vo.oa.TaskPersonVO;
import com.gjw.vo.oa.UserVO;

public interface IGesTaskPersonDAO extends IDAO {
	
	/**
	 * 获取任务中的常用客户
	 * @param taskPerson
	 * @return
	 */
	public List<TaskPersonVO> listCustomerInProjectTask(TaskPersonVO taskPerson);
	
	/**
	 * 获取交流中的常用客户
	 * @param taskPerson
	 * @return
	 */
	public List<TaskPersonVO> listCustomerInCommunication(TaskPersonVO taskPerson);
	
	public List<GesCityOperator> queryCityOperator(GesCityOperatorVO gesCityOperatorVO);
	
	public List<GesShop> queryShop(GesShop gesShop);
	
	public List<GesCustomer> queryCustomer(GesCustomerVO gesCustomerVO);
	
	public List<UserVO> queryUserByDept(UserVO userVO);
	
	public List<Dept> queryDeptByParentId(Dept dept);
	
	public List<UserVO> queryUser(UserVO userVO);
	

}
