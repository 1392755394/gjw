package com.gjw.company.service.impl.goods;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.service.goods.IGoodsAppMarkService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsAppMark;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.entity.matter.Matter;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsAppMarkVO;
import com.gjw.vo.GoodsMarkVO;

/**
 * 产品包APP锚点service实现
 * 
 * @Description:
 * @author guojianbin   
 * @date 2016年04月20日 
 * 
 */
@Component("goodsAppMarkServiceImpl")
public class GoodsAppMarkServiceImpl extends AbstractServiceImpl implements IGoodsAppMarkService {

    @Override
    @Transactional
    public boolean deleteById(Long markId) {
        // 软删除App锚点
        super.getGoodsAppMarkDao().remove(markId);
        GoodsMatter goodsMatter = new GoodsMatter();
        GoodsAppMark mark = new GoodsAppMark();
        mark.setId(markId);
        goodsMatter.setAppMark(mark);
        // 相关goods_matter物料APP锚点置空
        return super.getGoodsMatterDao().updateMatterByAppMark(goodsMatter);
    }

    @Override
    @Transactional
    public boolean update(GoodsAppMark mark) {
        return super.getGoodsAppMarkDao().update(mark);
    }

    @Override
    @Transactional
    public long create(GoodsAppMark mark) {
        return super.getGoodsAppMarkDao().create(mark);
    }

    @Override
    @Transactional
    public boolean createAppMarkAndMatter(GoodsAppMarkVO markVO) {
        try {
            GoodsAppMark goodsMark = new GoodsAppMark();
            // 赋值给父类
            PropertyUtils.copyProperties(goodsMark, markVO);
            // 新增锚点类型为物料锚点
            Dictionary type = new Dictionary();
            type.setId(DictionaryConstants.DICTIONARY_GOODS_MARK_ONE);
            goodsMark.setType(type);
            // 新增锚点
            this.create(goodsMark);

            // 修改标配物料（标配，及锚点id） 根据goodsId，matterId,roomId,修改
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包信息
            Goods goods = new Goods();
            goods.setId(markVO.getGoodsId());
            goodsMatter.setGoods(goods);
            // 物料信息
            goodsMatter.setMatter(markVO.getMatter());
            // 房间信息
            goodsMatter.setRoom(markVO.getGoodsRoom());
            // 锚点信息
            goodsMatter.setAppMark(goodsMark);
            // 设置为标配
            //Dictionary dic = new Dictionary();
            //dic.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
            //goodsMatter.setType(dic);
            super.getGoodsMatterDao().updateMatter(goodsMatter);

        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    @Transactional
    public boolean updateAppMarkAndMatter(GoodsAppMarkVO markVO) {
        try {
            GoodsAppMark goodsMark = new GoodsAppMark();
            // 赋值给父类
            PropertyUtils.copyProperties(goodsMark, markVO);
            // 修改锚点信息
            this.update(goodsMark);
            // 修改标配物料id 根据goodsId，markId,roomId,修改
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包信息
            Goods goods = new Goods();
            goods.setId(markVO.getGoodsId());
            goodsMatter.setGoods(goods);
            // 房间信息
            goodsMatter.setRoom(markVO.getGoodsRoom());
            // 锚点信息
            goodsMatter.setAppMark(goodsMark);
            // 修改锚点标配 前把原来锚点对应的标配物料锚点置空
            // 设置为标配
            //Dictionary dic = new Dictionary();
            //dic.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
            //goodsMatter.setType(dic);
            super.getGoodsMatterDao().updateMatterByAppMark(goodsMatter);
            // 物料信息
            goodsMatter.setMatter(markVO.getMatter());
            // 标配信息插入mark值
            super.getGoodsMatterDao().updateMatter(goodsMatter);

        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
