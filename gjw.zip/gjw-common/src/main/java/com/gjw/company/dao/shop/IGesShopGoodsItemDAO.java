package com.gjw.company.dao.shop;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.vo.GoodsVO;

public interface IGesShopGoodsItemDAO extends IDAO {
    public GesShopGoodsItem listByID(Long id);

    public boolean updateGesShopGoodsItem(GesShopGoodsItem model);

    public boolean createGesShopGoodsItem(GesShopGoodsItem model);

    public long count(GesShopGoodsItem model);

    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model);

    public GesShopGoodsItem listByShopAndGood(GesShopGoodsItem model);

    /**
     * 查看产品4s店列表
     * 
     * @Description
     * @param goods
     *            产品
     * @return 4s店列表
     * @author guojianbin
     * @date 2016年1月30日
     */
    public List<GesShop> listShopByGoods(Goods goods);

    /**
     * <p>
     * 虚拟现实---分页查询
     * 
     * @Description
     * @param goods
     * @return
     * @author gwb
     * @date 2016年2月26日 上午10:15:43
     */
    public List<Goods> getPageGoodsList(GoodsVO goods);

    /**
     * 虚拟现实总数查询
     * 
     * @Description
     * @param gesShopGoodsItem
     * @return
     * @author gwb
     * @date 2016年2月26日 上午10:18:15
     */
    public long getPageGoodsListCount(GoodsVO gesShopGoodsItem);

}
