package com.gjw.company.dao.impl.salestool;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.ICaptchaRecordDAO;
import com.gjw.entity.salestool.CaptchaRecord;

@Component("captchaRecordDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class CaptchaRecordDAOHibernateImpl extends AbstractDAOHibernateImpl implements ICaptchaRecordDAO{

    @Override
    public CaptchaRecord listByID(Long id) {
        // TODO Auto-generated method stub
        return (CaptchaRecord) super.get(id);
    }

    @Override
    public boolean updateCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public List<CaptchaRecord> listByCaptchaRecord(CaptchaRecord model) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return CaptchaRecord.class;
    }

}
