package com.gjw.company.dao.impl.recommend;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.recommend.IWebRecommendInfoDAO;
import com.gjw.entity.recommend.WebRecommendInfo;
import com.gjw.utils.StringUtil;

/**
 * dao的Hibernate实现
 */
@Component("webRecommendInfoDAOHibernateImpl")
public class WebRecommendInfoDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebRecommendInfoDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebRecommendInfo.class;
    }

    @Override
    public WebRecommendInfo getById(Long id) {
        // TODO Auto-generated method stub
        return (WebRecommendInfo) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebRecommendInfo> pageByNameAndCode(WebRecommendInfo info) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebRecommendInfo wri where wri.id !=0 ");
        if (StringUtil.notEmpty(info.getInfoTitle())) {
            hql.append(" and wri.infoTitle like ?");
            ls.add("%" + info.getInfoTitle() + "%");
        }
        if (null != info.getPosition() && StringUtil.notEmpty(info.getPosition().getPosCode())) {
            hql.append(" and wri.position.posCode = ?");
            ls.add(info.getPosition().getPosCode());
        }
        hql.append(" order by wri.id desc");
        return (List<WebRecommendInfo>) super.findByPageCallBack(hql.toString(), "", ls, info, null);
    }

    @Override
    public Long countByNameAndCode(WebRecommendInfo info) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebRecommendInfo wri where wri.id !=0 ");
        if (StringUtil.notEmpty(info.getInfoTitle())) {
            hql.append(" and wri.infoTitle like ?");
            ls.add("%" + info.getInfoTitle() + "%");
        }
        if (null != info.getPosition() && 0l != info.getPosition().getId()) {
            hql.append(" and wri.postion.posCode = ?");
            ls.add(info.getPosition().getPosCode());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updateInfo(WebRecommendInfo info) {
        // TODO Auto-generated method stub
        WebRecommendInfo in = (WebRecommendInfo) super.get(info.getId());
        StringUtil.copyProperties(info, in);
        super.update(in);
        return true;
    }

}
