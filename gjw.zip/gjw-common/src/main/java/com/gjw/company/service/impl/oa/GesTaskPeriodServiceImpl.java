package com.gjw.company.service.impl.oa;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.dao.oa.IGesTaskPeriodDAO;
import com.gjw.company.service.oa.IGesTaskPeriodService;
import com.gjw.entity.oa.GesTaskPeriod;
import com.gjw.vo.oa.GesTaskPeriodVO;

@Component("gesTaskPeriodServiceImpl")
public class GesTaskPeriodServiceImpl extends AbstractServiceImpl implements
		IGesTaskPeriodService {

	@Resource(name="gesTaskPeriodHibernateImpl")
	private IGesTaskPeriodDAO gesTaskPeriodDAO;
	
	public IGesTaskPeriodDAO getGesTaskPeriodDAO() {
		return gesTaskPeriodDAO;
	}

	public void setGesTaskPeriodDAO(IGesTaskPeriodDAO gesTaskPeriodDAO) {
		this.gesTaskPeriodDAO = gesTaskPeriodDAO;
	}

	/**
	 * 通过任务的id查询任务阶段以及阶段下的任务数目
	 * @param taskId
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskId(Long taskId) {
		//获取任务下的阶段数目及每个阶段的任务总数
		List<GesTaskPeriodVO> list=getGesTaskPeriodDAO().queryTaskPeriodAndTaskNumByTaskId(taskId);
		return list;
	}

    @Override
    @Transactional(readOnly=true)
    public List<GesTaskPeriodVO> queryTaskPeriodByTaskId(Long taskId) {
        return getGesTaskPeriodDAO().queryTaskPeriodByTaskId(taskId);
    }

    @Override
    @Transactional
    public long addTaskPeriod(GesTaskPeriod taskPeriod) {
        int maxOrder = getGesTaskPeriodDAO().queryMaxOrder(taskPeriod.getTask().getId());
        taskPeriod.setOrderTag(maxOrder + 1);
        return getGesTaskPeriodDAO().addTaskPeriod(taskPeriod);
    }

    @Override
    @Transactional
    public boolean updateTaskPeriod(GesTaskPeriod taskPeriod) {
        return getGesTaskPeriodDAO().updateTaskPeriod(taskPeriod);
    }

    @Override
    @Transactional
    public boolean delTaskPeriod(GesTaskPeriod taskPeriod) {
        return getGesTaskPeriodDAO().delTaskPeriod(taskPeriod);
    }

    @Override
    @Transactional
    public boolean updateTaskPeriodForMove(GesTaskPeriodVO taskPeriodVO) {
        
        GesTaskPeriod taskPeriod = taskPeriodVO.generateEntity();
        
        //判断任务阶段的移动方向
        //0 向上移动
        if(taskPeriodVO.getMoveDirection()==0){
            //向上移动 更新 上一个阶段
            GesTaskPeriod prevPeriod = getGesTaskPeriodDAO().queryPrevPeriod(taskPeriod);
            prevPeriod.setOrderTag(taskPeriod.getOrderTag());
            boolean result=getGesTaskPeriodDAO().updateTaskPeriod(prevPeriod);
            //向上移动 更新上一个阶段成功，更新 本阶段
            if(result){
                //本阶段的orderIndex减1
                taskPeriod.setOrderTag(taskPeriod.getOrderTag()-1);
                //更新orderIndex
                return getGesTaskPeriodDAO().updateTaskPeriod(taskPeriod);
            }           
        }else if(taskPeriodVO.getMoveDirection()==1){//向下移动
            //向下移动 更新下一个阶段
            GesTaskPeriod nextPeriod = getGesTaskPeriodDAO().queryNextPeriod(taskPeriod);
            nextPeriod.setOrderTag(taskPeriod.getOrderTag());
            boolean result=getGesTaskPeriodDAO().updateTaskPeriod(nextPeriod);
            //向下移动 更新下一个阶段成功，更新本阶段
            if(result){
                //本阶段的orderIndex加1
                taskPeriod.setOrderTag(taskPeriod.getOrderTag()+1);
                //更新orderIndex
                return getGesTaskPeriodDAO().updateTaskPeriod(taskPeriod);
            }
        }
        return false;
    }

    /**
	 * 通过施工管理项目的id查询任务阶段以及阶段下的任务数目
	 * @param taskId
	 * @return
	 */
	@Override
	@Transactional(readOnly=true)
	public List<GesTaskPeriodVO> queryTaskPeriodAndTaskNumByTaskIdForPM(Long taskId) {
		//获取任务下的阶段数目及每个阶段的任务总数
		List<GesTaskPeriodVO> list=getGesTaskPeriodDAO().queryTaskPeriodAndTaskNumByTaskIdForPM(taskId);
		return list;
	}
    
}
