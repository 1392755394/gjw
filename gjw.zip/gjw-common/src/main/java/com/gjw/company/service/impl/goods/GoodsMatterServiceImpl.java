package com.gjw.company.service.impl.goods;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.DictionaryConstants;
import com.gjw.company.service.goods.IGoodsMatterService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.goods.GoodsMatter;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsMatterVO;

/**
 * 产品包房间service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("goodsMatterServiceImpl")
public class GoodsMatterServiceImpl extends AbstractServiceImpl implements IGoodsMatterService {

    @Override
    @Transactional(readOnly = true)
    public List<GoodsMatter> pageStandardMatter(GoodsMatterVO goodsMatter) {
        // TODO Auto-generated method stub
        List<GoodsMatter> list = super.getGoodsMatterDao().pageStandardMatter(goodsMatter);
        if (null != list && list.size() > 0) {
            for (GoodsMatter gm : list) {
                Hibernate.initialize(gm.getMatter());
                if (null != gm.getMatter() && null != gm.getMatter().getBrand()
                        && null != gm.getMatter().getBrand().getId()) {
                    Hibernate.initialize(gm.getMatter().getBrand());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countStandardMatter(GoodsMatterVO goodsMatter) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().countStandardMatter(goodsMatter);
    }

    @Override
    @Transactional(readOnly = true)
    public GoodsMatter queryById(Long id) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().queryById(id);
    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().delBatchByID(ids);
    }

    @Override
    @Transactional
    public boolean update(Long id, Integer amount, Boolean isStandard) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().update(id, amount, isStandard);
    }

    @Override
    @Transactional
    public boolean createBatchGoodsMatter(String matterIds, String amounts, Long goodsId, Long roomId) {
        // TODO Auto-generated method stub
        String[] matterIdArray = matterIds.split(",");
        String[] amount = amounts.split(",");
        int index = 0;
        for (String matterId : matterIdArray) {
            // 产品物料关系对象
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包id
            Goods goods = new Goods();
            goods.setId(goodsId);
            goodsMatter.setGoods(goods);
            // 物料id
            Matter matter = new Matter();
            matter.setId(Long.valueOf(matterId));
            goodsMatter.setMatter(matter);
            // 数量
            goodsMatter.setAmount(Integer.valueOf(amount[index]));
            // 默认类型为标配
            Dictionary type = new Dictionary();
            type.setId(DictionaryConstants.DICTIONARY_GOODS_MATTER_Y);
            goodsMatter.setType(type);
            // 房间id
            GoodsRoom room = new GoodsRoom();
            room.setId(roomId);
            goodsMatter.setRoom(room);
            super.getGoodsMatterDao().create(goodsMatter);
            index++;
        }
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsMatter> listMatterWithType(Long markId, Long type) {
        // TODO Auto-generated method stub
        List<GoodsMatter> list = super.getGoodsMatterDao().listMatterWithType(markId, type);
        if(null != list  && list.size()>0){
            for (GoodsMatter goodsMatter : list) {
                Hibernate.initialize(goodsMatter.getMatter());
                if(null != goodsMatter.getMatter()){
                    Hibernate.initialize(goodsMatter.getMatter().getEffectImage());
                    Hibernate.initialize(goodsMatter.getMatter().getImage());
                    Hibernate.initialize(goodsMatter.getMatter().getBrand());
                }
                Hibernate.initialize(goodsMatter.getRoom());
                if(null != goodsMatter.getRoom()){
                    Hibernate.initialize(goodsMatter.getRoom().getRootRoom());
                }
                Hibernate.initialize(goodsMatter.getMark());
                Hibernate.initialize(goodsMatter.getType());
            }
        }
        return list;
    }

    @Override
    @Transactional
    public boolean batchDelOptMatter(Long goodsId, Long roomId, String matterIds) {
        // TODO Auto-generated method stub
        String[] matterIdArray = matterIds.split(",");
        boolean result = false;
        for (String matterId : matterIdArray) {
            // 产品物料关系对象
            GoodsMatter goodsMatter = new GoodsMatter();
            // 产品包id
            Goods goods = new Goods();
            goods.setId(goodsId);
            goodsMatter.setGoods(goods);
            // 物料id
            Matter matter = new Matter();
            matter.setId(Long.valueOf(matterId));
            goodsMatter.setMatter(matter);
            // 房间id
            GoodsRoom room = new GoodsRoom();
            room.setId(roomId);
            goodsMatter.setRoom(room);
            result = super.getGoodsMatterDao().updateMatterByMark(goodsMatter);
        }
        return result;
    }
    
    //DIY接口start

    @Override
    @Transactional(readOnly=true)
    public List<GoodsMatter> listMatter(GoodsMatter goodsMatter) {
        List<GoodsMatter> list = super.getGoodsMatterDao().listMatter(goodsMatter);
        if (null != list && list.size() > 0) {
            for (GoodsMatter gm : list) {
                Hibernate.initialize(gm.getMark());
                Hibernate.initialize(gm.getMatter());
                if(null != gm.getMatter()){
                    Hibernate.initialize(gm.getMatter().getEffectImage());
                    Hibernate.initialize(gm.getMatter().getImage());
                    Hibernate.initialize(gm.getMatter().getBrand());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional
    public boolean batchCreate(List<GoodsMatter> list) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().batchCreate(list);
    }

    @Override
    @Transactional
    public boolean update(GoodsMatter goodsMatter) {
        // TODO Auto-generated method stub
        return super.getGoodsMatterDao().update(goodsMatter);
    }

    @Override
    @Transactional(readOnly=true)
    public List<GoodsMatter> pageMatterByGoodsAndCategory(GoodsMatter goodsMatter) {
        List<GoodsMatter> list = super.getGoodsMatterDao().pageMatterByGoodsAndCategory(goodsMatter);
        for (GoodsMatter gm : list) {
            Hibernate.initialize(gm.getMatter());
            if(null != gm.getMatter()){
                Hibernate.initialize(gm.getMatter().getImage());
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly=true)
    public Long countMatterByGoodsAndCategory(GoodsMatter goodsMatter) {
        return super.getGoodsMatterDao().countMatterByGoodsAndCategory(goodsMatter);
    }

    @Override
    @Transactional(readOnly=true)
    public List<GoodsMatter> listMarkForGes(Long roomId, Long type) {
        // TODO Auto-generated method stub
        List<GoodsMatter> ls = super.getGoodsMatterDao().listMarkForGes(roomId, type);
        if(null != ls && ls.size()>0){
            for (GoodsMatter goodsMatter : ls) {
                Hibernate.initialize(goodsMatter.getMark());
                Hibernate.initialize(goodsMatter.getMatter());
                if(StringUtil.notEmpty(goodsMatter.getMark())){
                    Hibernate.initialize(goodsMatter.getMark().getType());
                }
            }
        }
        return ls;
    }

    @Override
    @Transactional(readOnly=true)
    public List<GoodsMatter> listAppMarkForGes(Long roomId, Long type) {
        List<GoodsMatter> ls = super.getGoodsMatterDao().listAppMarkForGes(roomId, type);
        if(null != ls && ls.size()>0){
            for (GoodsMatter goodsMatter : ls) {
                Hibernate.initialize(goodsMatter.getAppMark());
                Hibernate.initialize(goodsMatter.getMatter());
                if(StringUtil.notEmpty(goodsMatter.getAppMark())){
                    Hibernate.initialize(goodsMatter.getAppMark().getType());
                }
            }
        }
        return ls;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsMatter> pageAppStandardMatter(GoodsMatterVO goodsMatter) {
        List<GoodsMatter> list = super.getGoodsMatterDao().pageAppStandardMatter(goodsMatter);
        if (null != list && list.size() > 0) {
            for (GoodsMatter gm : list) {
                Hibernate.initialize(gm.getMatter());
                if (null != gm.getMatter() && null != gm.getMatter().getBrand()
                        && null != gm.getMatter().getBrand().getId()) {
                    Hibernate.initialize(gm.getMatter().getBrand());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countAppStandardMatter(GoodsMatterVO goodsMatter) {
        return super.getGoodsMatterDao().countAppStandardMatter(goodsMatter);
    }

    @Override
    @Transactional(readOnly = true)
    public List<GoodsMatter> listMatterWithAppMark(Long markId, Long type) {
        List<GoodsMatter> list = super.getGoodsMatterDao().listMatterWithAppMark(markId, type);
        if(null != list  && list.size()>0){
            for (GoodsMatter goodsMatter : list) {
                Hibernate.initialize(goodsMatter.getMatter());
                if(null != goodsMatter.getMatter()){
                    Hibernate.initialize(goodsMatter.getMatter().getEffectImage());
                    Hibernate.initialize(goodsMatter.getMatter().getImage());
                    Hibernate.initialize(goodsMatter.getMatter().getBrand());
                }
                Hibernate.initialize(goodsMatter.getRoom());
                if(null != goodsMatter.getRoom()){
                    Hibernate.initialize(goodsMatter.getRoom().getRootRoom());
                }
                Hibernate.initialize(goodsMatter.getAppMark());
                Hibernate.initialize(goodsMatter.getType());
            }
        }
        return list;
    }
}
