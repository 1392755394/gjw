package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.GesCommonConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.company.dao.oa.IGesTaskPersonDAO;
import com.gjw.entity.cityoperator.GesCityOperator;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.user.Dept;
import com.gjw.utils.StringUtil;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesCityOperatorVO;
import com.gjw.vo.oa.TaskPersonVO;
import com.gjw.vo.oa.UserVO;

@Component("gesTaskPersonHibernateImpl")
public class GesTaskPersonHibernateImpl extends AbstractDAOHibernateImpl
		implements IGesTaskPersonDAO {

	@Override
	protected Class<?> getEntityClass() {
		return null;
	}

	/**
	 * 获取任务中的常用客户
	 * @param taskPerson
	 * @return
	 */
	@Override
	public List<TaskPersonVO> listCustomerInProjectTask(TaskPersonVO taskPerson) {
		StringBuffer hql=new StringBuffer();
		hql.append("from GesProjectTask a,");
		assembleCustomerQuery(taskPerson, hql);
		hql.append(" where b.invalid=? and a.founder.id=? and a.customerType=? and b.id=a.customerId group by a.customerId order by a.createdDatetime desc ");
		List<TaskPersonVO> list = queryLatestCustomer(taskPerson, hql);
		return list;
	}

	/**
	 * 获取交流中的常用客户
	 * @param taskPerson
	 * @return
	 */
	@Override
	public List<TaskPersonVO> listCustomerInCommunication(
			TaskPersonVO taskPerson) {
		StringBuffer hql=new StringBuffer();
		hql.append("from GesCommunication a,");
		assembleCustomerQuery(taskPerson, hql);
		hql.append(" where b.invalid=? and a.user.id=? and a.customerType=? and b.id=a.customerId group by a.customerId order by a.createdDatetime desc ");
		List<TaskPersonVO> list = queryLatestCustomer(taskPerson, hql);
		return list;
	}

	protected void assembleCustomerQuery(TaskPersonVO taskPerson,
			StringBuffer hql) {
		String prefixQuery="";
		if(taskPerson.getType()==0){
			prefixQuery="select a.customerId as id,b.companyName as name,cast(-1 as long) as parentId,a.customerType as type,max(a.createdDatetime) as createdDatetime ";
			hql.append("GesCityOperator b ");
		}else if(taskPerson.getType()==1){
			prefixQuery="select a.customerId as id,b.name as name,cast(-2 as long) as parentId,a.customerType as type,max(a.createdDatetime) as createdDatetime ";
			hql.append("GesShop b ");
		}else if(taskPerson.getType()==2){
			prefixQuery="select a.customerId as id,b.name as name,cast(-3 as long) as parentId,a.customerType as type,max(a.createdDatetime) as createdDatetime ";
			hql.append("GesCustomer b ");
		}
		hql.insert(0, prefixQuery);
	}

	@SuppressWarnings("unchecked")
    protected List<TaskPersonVO> queryLatestCustomer(TaskPersonVO taskPerson,
			StringBuffer hql) {
		//参数列表
		List<Object> param=new ArrayList<Object>();
		param.add(false);
		param.add(taskPerson.getLoginId());
		param.add(taskPerson.getType());
		List<TaskPersonVO> list=(List<TaskPersonVO>) super.findByPageCallBack(hql.toString(), null, param, taskPerson, Transformers.aliasToBean(TaskPersonVO.class));
		return list;
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<GesCityOperator> queryCityOperator(GesCityOperatorVO gesCityOperatorVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select c.companyName as companyName,c.id as id from GesCityOperator c ");
		if(gesCityOperatorVO.getShopId()!=null&&gesCityOperatorVO.getShopId()>0){
			hql.append(",GesShop s ");
		}
		hql.append(" where 1=1 and c.invalid=? ");
		param.add(false);
		if(StringUtil.notEmpty(gesCityOperatorVO.getContactName())){
			hql.append(" and c.companyName like ? ");
			param.add("%"+gesCityOperatorVO.getContactName()+"%");
		}
		if(gesCityOperatorVO.getId()!=null&&gesCityOperatorVO.getId()>0){
			hql.append(" and c.id=? ");
			param.add(gesCityOperatorVO.getId());
		}
		if(gesCityOperatorVO.getShopId()!=null&&gesCityOperatorVO.getShopId()>0){
			hql.append(" and s.operator.id=c.id and s.id=? ");
			param.add(gesCityOperatorVO.getShopId());
		}
		hql.append(" order by c.id desc");
		return (List<GesCityOperator>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesCityOperator.class));
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<GesShop> queryShop(GesShop gesShop) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select s.name as name,s.id as id from GesShop s ");
		hql.append(" where 1=1 and s.invalid=? ");
		param.add(false);
		if(StringUtil.notEmpty(gesShop.getName())){
			hql.append(" and s.name like ? ");
			param.add("%"+gesShop.getName()+"%");
		}
		if(gesShop.getOperator()!=null&&gesShop.getOperator().getId()!=null&&gesShop.getOperator().getId()>0){
			hql.append(" and s.operator.id=? ");
			param.add(gesShop.getOperator().getId());
		}
		if(gesShop.getId()!=null&&gesShop.getId()>0){
			hql.append(" and s.id=? ");
			param.add(gesShop.getId());
		}
		hql.append(" order by s.id desc");
		return (List<GesShop>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesShop.class));
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<GesCustomer> queryCustomer(GesCustomerVO gesCustomerVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select c.name as name,c.id as id from GesCustomer c ");
		if(StringUtil.notEmpty(gesCustomerVO.getOrgType())){
			if(gesCustomerVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)||
					gesCustomerVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" ,UserInfoGES g ");
			}
		}
		hql.append(" where 1=1 and c.invalid=? ");
		param.add(false);
		if(StringUtil.notEmpty(gesCustomerVO.getName())){
			hql.append(" and c.name like ?");
			param.add("%"+gesCustomerVO.getName()+"%");
		}
		if(StringUtil.notEmpty(gesCustomerVO.getOrgType())){
			if(gesCustomerVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and c.shop.id=g.shop.id and g.id=? ");
				param.add(gesCustomerVO.getId());
			}else if(gesCustomerVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and c.operator.id=g.operator.id and g.id=? ");
				param.add(gesCustomerVO.getId());
			}
		}
		hql.append(" order by c.updatedDatetime desc ");
		
		return (List<GesCustomer>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(GesCustomer.class));
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<UserVO> queryUserByDept(UserVO userVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select u.user.id as id,u.realName as realName,u.user.username as userName from UserInfo u ,DeptUser d ");
		hql.append(" where 1=1 and u.invalid=? and u.type=? and u.user.id=d.user.id ");
		param.add(false);
		param.add(PlatformEnum.Ges.getObj().getId().intValue());
		if(userVO.getDeptId()!=null){
			hql.append(" and d.dept.id=? ");
			param.add(userVO.getDeptId());
		}
		if(userVO.getTaskId()!=null){
			hql.append(" and u.user.id not in ( select p.participant.id from GesTaskParticipant p where p.invalid=false and p.task.id=?) ");
			param.add(userVO.getTaskId());
		}
		hql.append(" order by u.updatedDatetime desc ");
		
		return (List<UserVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(UserVO.class));
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<Dept> queryDeptByParentId(Dept dept) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select d.id as id,d.name as name from Dept d ");
		hql.append(" where 1=1 and d.invalid=? ");
		param.add(false);
		if(dept.getParent()!=null&&dept.getParent().getId()!=null){
			hql.append(" and d.parent.id=?");
			param.add(dept.getParent().getId());
		}
		
		return (List<Dept>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(Dept.class));
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<UserVO> queryUser(UserVO userVO) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("select g.user.id as id,g.realName as realName,g.user.username as userName from UserInfoGES g ");
		hql.append(" where 1=1 and g.invalid=? ");
		param.add(false);
		if(StringUtil.notEmpty(userVO.getUserName())){
			hql.append(" and (g.realName like ? or g.user.username like ? ) ");
			param.add("%"+userVO.getUserName()+"%");
			param.add("%"+userVO.getUserName()+"%");
		}
		if(userVO.getSearchType()!=null&&userVO.getSearchType().intValue()==0){
			hql.append(" and g.orgType=? ");
			param.add(GesCommonConstants.ORG_TYPE_CITY_OPERATOR);
			if(userVO.getOrgType()!=null&& userVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and g.operator.id=? ");
				param.add(userVO.getOrgId());
			}else if(userVO.getOrgType()!=null&& userVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and g.operator.id in ( select s.operator.id from GesShop s where s.id=? ) ");
				param.add(userVO.getOrgId());
			}
		}else if(userVO.getSearchType()!=null&&userVO.getSearchType().intValue()==1){
			hql.append(" and g.orgType=? ");
			param.add(GesCommonConstants.ORG_TYPE_SHOP);
			if(userVO.getOrgType()!=null&& userVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_CITY_OPERATOR)){
				hql.append(" and g.shop.id in ( select s.id from GesShop s where s.operator.id=? ) ");
				param.add(userVO.getOrgId());
			}else if(userVO.getOrgType()!=null&& userVO.getOrgType().equals(GesCommonConstants.ORG_TYPE_SHOP)){
				hql.append(" and g.shop.id=? ");
				param.add(userVO.getOrgId());
			}
		}else{
			hql.append(" and g.orgType=? ");
			param.add(GesCommonConstants.ORG_TYPE_GJW);
		}
		if(userVO.getTaskId()!=null&&userVO.getTaskId()>0){
			hql.append(" and g.user.id not in ( select p.participant.id from GesTaskParticipant p where p.invalid=false and p.task.id=? ) ");
			param.add(userVO.getTaskId());
		}
		
		return (List<UserVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(UserVO.class));
	}
	
	
	
}
