package com.gjw.company.dao.impl.app;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.app.IWebContrastDetailDAO;
import com.gjw.entity.app.WebContrastDetail;

@Component("webContrastDetailHibernateImpl")
@SuppressWarnings("unchecked")
public class WebContrastDetailHibernateImpl extends AbstractDAOHibernateImpl implements IWebContrastDetailDAO{
    public WebContrastDetail get(Long id) {
        return (WebContrastDetail) super.get(id);
    }
    @Override
    public List<WebContrastDetail> getList(WebContrastDetail model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from WebContrastDetail item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if(null!=model.getContrast() && null!=model.getContrast().getId()){
            hql=hql+" and item.contrast.id=?";
            params.add(model.getContrast().getId());
        }
        hql = hql + " order by item.createdDatetime desc";
        return (List<WebContrastDetail>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public boolean addWebContrastDetail(WebContrastDetail model) {
        // TODO Auto-generated method stub
        super.add(model);
        return true;
    }

    @Override
    public void updateWebContrastDetail(WebContrastDetail model) {
        // TODO Auto-generated method stub
        super.update(model);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebContrastDetail.class;
    }

}
