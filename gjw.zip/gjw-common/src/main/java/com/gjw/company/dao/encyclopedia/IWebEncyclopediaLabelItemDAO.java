package com.gjw.company.dao.encyclopedia;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.encyclopedia.WebEncyclopediaLabelItem;

/**
 * 
 * @Description: 标签关系表dao接口
 * @author zhaoyonglian
 * @date 2015年12月23日 上午10:24:21
 * 
 */
public interface IWebEncyclopediaLabelItemDAO extends IDAO {

    /**
     * 
     * @Description 由类型及id获取相关标签列表
     * @param item
     * @return
     * @author zhaoyonglian
     * @date 2015年12月23日 上午10:28:07
     */
    public List<WebEncyclopediaLabelItem> listByInfoAndDictionary(WebEncyclopediaLabelItem item);

    /**
     * 
     * @Description 由类型及id删除相关标签
     * @param item
     * @return
     * @author zhaoyonglian
     * @date 2015年12月23日 上午10:34:36
     */
    public boolean invalidByInfoAndDictionary(WebEncyclopediaLabelItem item);

    /** 
    * @Description  
    * @param dictionary
    * @param id
    * @author qingye   
    * @date Dec 30, 2015 3:04:51 PM
    */
    
    public void deleteByPropertyAndInfo(Dictionary property, Long id);
    
    /**
     * 总数
    * @Description  
    * @param item
    * @return
    * @author zyq   
    * @date 2016年3月1日 上午10:44:14
     */
    public Long countByInfoAndDictionary(WebEncyclopediaLabelItem item);
}
