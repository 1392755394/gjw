package com.gjw.company.dao.article;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.article.WebArticleGoods;


public interface IWebArticleGoodsDAO extends IDAO{

    /** 
    * @Description
    * @param article
    * @return
    * @author qingye
    * @date Dec 31, 2015 4:17:33 PM
    */
    
    List<WebArticleGoods> listByArticle(Long article);

    /** 
    * @Description  
    * @param item
    * @author qingye   
    * @date Dec 31, 2015 5:30:10 PM
    */
    
    void deleteByArticleAndGoods(WebArticleGoods item);
    
    
    
}
