package com.gjw.company.service.impl.xggoujia;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.xggoujia.XgGoujiaService;
import com.gjw.entity.xggoujia.XgGoujia;
@Component("xgGoujiaServiceImpl")
public class XgGoujiaServiceImpl extends AbstractServiceImpl implements XgGoujiaService {

	@Override
	@Transactional(readOnly = true)
	public List<XgGoujia> getListXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().getListXgGoujia(xgGoujia);
	}

	
	@Override
	@Transactional
	public Long saveXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().saveXgGoujia(xgGoujia);
	}

	@Override
	@Transactional
	public Long updateXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().updateXgGoujia(xgGoujia);
	}

	@Override
	@Transactional
	public Long deleteXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().deleteXgGoujia(xgGoujia);
	}

	@Override
	@Transactional(readOnly=true)
	public XgGoujia getByIdXgGoujia(Long id) {
		// TODO Auto-generated method stub
		XgGoujia xgGoujia=super.getXgGoujiaDao().getByIdXgGoujia(id);
		return xgGoujia;
	}

	@Override
	@Transactional(readOnly=true)
	public Long count(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().count(xgGoujia);
	}

	@Override
	@Transactional(readOnly=true)
	public List<XgGoujia> pageListXgGoujia(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		List<XgGoujia> list=super.getXgGoujiaDao().pageListXgGoujia(xgGoujia);
		return list;
	}


	@Override
	@Transactional(readOnly=true)
	public List<XgGoujia> pageListByName(XgGoujia xgGoujia) {
		// TODO Auto-generated method stub
		return super.getXgGoujiaDao().pageListByName(xgGoujia);
	}
	
	 

}
