package com.gjw.company.dao.oa;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.customer.GesCustomer;
import com.gjw.entity.oa.GesProjectTask;
import com.gjw.vo.customer.GesCustomerVO;
import com.gjw.vo.oa.GesProjectTaskQueryVO;
import com.gjw.vo.oa.GesProjectTaskVO;
import com.gjw.vo.oa.UserVO;

/**
 * 
 * @author jjw
 *
 */
public interface IGesProjectTaskDAO extends IDAO {
	
	public void addGesProjectTask(GesProjectTask gesProjectTask);
	
	/**
	 * 查询用户的所有任务项目以及最新的交流信息
	 * @param 
	 * @return
	 */
	public List<GesProjectTaskQueryVO> queryAllProjectTaskCommunicationByUserId(GesProjectTaskQueryVO gesProjectTaskVO);
	
	/**
	 * 统计用户的所有任务项目以及最新的交流信息
	 * @param 
	 * @return
	 */
	public Long countAllProjectTaskCommunicationByUserId(GesProjectTaskQueryVO gesProjectTaskVO);
	
	/**
	 * 更新任务项目的最新交流id
	 * @param gesProjectTask
	 * @return
	 */
	public int updateGesProjectTaskCommunicationId(GesProjectTask gesProjectTask);
	
	/**
	 * 根据条件查询任务项目统计信息
	 * @param gesProjectTaskVO
	 * @param choose 标记执行哪一条sql语句
	 * @return
	 */
	public List<GesProjectTaskQueryVO> queryTaskByFeature(GesProjectTaskQueryVO gesProjectTaskVO,int choose);
	
	/**
	 * 根据条件统计任务项目个数
	 * @param gesProjectTaskVO
	 * @param choose标记执行哪一条sql语句
	 * @return
	 */
	public Long countTaskByFeature(GesProjectTaskQueryVO gesProjectTaskVO,int choose);
	
	public GesProjectTaskVO queryTaskById(Long taskId);
	
    /**
     * 批量保存数据
     * @param list 任务列表
     * @return 插入数据的条数
     */
    public int batchAddProjectTask(List<GesProjectTask> list);
    
    /**
     * 根据任务的id查询任务的阶段和子任务
     * @param taskId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskPeriodAndSubTaskByTaskId(long taskId);
    
    /**
     * 根据订单ID获取项目
     * @Description  
     * @param orderId 订单ID
     * @author guojianbin   
     * @date 2016年1月6日 
     */
    public List<GesProjectTask> queryByOrderId(Long orderId);
    
    /**
     * 根据任务的id获取任务的信息
     * @param taskId
     * @return
     */
    public GesProjectTask queryAllTaskInfoByTaskId(Long taskId);
    
    /**
     * 根据任务的id更新任务的状态
     * @param projectTask
     * @return
     */
    public int updateTaskStatusByTaskId(GesProjectTask projectTask);
    
    /**
     * 根据阶段的id查询阶段下的任务信息
     * @param periodId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskByTaskPeriod(Long periodId);
    
    /**
     * 根据任务id查询任务的基本信息以及交流信息（目前没有使用）
     * @param taskId
     * @return
     */
    public GesProjectTaskVO queryNewTaskByTaskId(Long taskId);
    
    /**
     * 根据用户的id查询用户的信息
     * @param userId
     * @return
     */
    public UserVO queryUserInfoByUserId(Long userId);
    
    /**
     * 根据施工管理项目的阶段的名称查询阶段下的任务信息
     * @param periodId
     * @return
     */
    public List<GesProjectTaskVO> queryTaskByTaskPeriodForPM(Long taskId,String periodName);
    
    public int updateTaskCheckInfo(GesProjectTask projectTask);
    
    public GesProjectTask queryGesProject(Long id);
    /**
    * @Description  根据订单ID查询对应客户的最新项目记录  
    * @param customer
    * @return
    * @author xiaoyang   
    * @date 2016年3月9日 下午2:45:08
     */
    public GesProjectTask projectTaskByCustomer(GesCustomerVO customer);
    
    public long countGesProjectTaskByParentId(long parentId); 
    
}
