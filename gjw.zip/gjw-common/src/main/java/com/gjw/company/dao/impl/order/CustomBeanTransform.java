package com.gjw.company.dao.impl.order;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.property.ChainedPropertyAccessor;
import org.hibernate.property.PropertyAccessor;
import org.hibernate.property.PropertyAccessorFactory;
import org.hibernate.property.Setter;
import org.hibernate.transform.ResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gjw.common.enumeration.OrderStatus;

/**
 * 自定义的实体转换器
 * 目前仅实现类订单状态的转换，有其他需要再扩展
 * 目前是在hibernate自身的转化器的基础上实现的状态转换，后期根据需要通过反射自己实现转换器
 * @author jjw
 *
 */
@SuppressWarnings("serial")
public class CustomBeanTransform implements ResultTransformer {
	
	private static final Logger log=LoggerFactory.getLogger(CustomBeanTransform.class);

	@SuppressWarnings("rawtypes")
	private final Class resultClass;
	private boolean isInitialized;
	private String[] aliases;
	private Setter[] setters;
	private boolean isTransformStatus;
	private int num=0;
	
	@SuppressWarnings("rawtypes")
	public CustomBeanTransform(Class resultClass,boolean status){
		if ( resultClass == null ) {
			throw new IllegalArgumentException( "resultClass cannot be null" );
		}
		isInitialized = false;
		this.resultClass = resultClass;
		this.isTransformStatus=status;
	}
	
	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		Object result;

		try {
			if ( ! isInitialized ) {
				initialize( aliases );
			}//此处去掉了缓存检查
			
			result = resultClass.newInstance();

			for ( int i = 0; i < aliases.length; i++ ) {
				if ( setters[i] != null ) {
					setters[i].set( result, tuple[i], null );//可以在此处获取属性的名称，判断是orderStatus，则保存tuple的值
				}
			}
			if(isTransformStatus){
				if(tuple[num]!=null){
					try{
						setters[aliases.length].set(result, OrderStatus.valueOf(tuple[num].toString()).getText(), null);
					}catch(Exception e){
						log.error("转换状态异常："+e);
						setters[aliases.length].set(result, "订单状态异常", null);
					}
				}else{
					setters[aliases.length].set(result, "订单状态异常", null);
				}
			}
		}
		catch ( InstantiationException e ) {
			throw new HibernateException( "Could not instantiate resultclass: " + resultClass.getName() );
		}
		catch ( IllegalAccessException e ) {
			throw new HibernateException( "Could not instantiate resultclass: " + resultClass.getName() );
		}

		return result;
	}

	private void initialize(String[] aliases) {
		PropertyAccessor propertyAccessor = new ChainedPropertyAccessor(
				new PropertyAccessor[] {
						PropertyAccessorFactory.getPropertyAccessor( resultClass, null ),
						PropertyAccessorFactory.getPropertyAccessor( "field" )
				}
		);
		if(isTransformStatus){
			this.aliases = new String[ aliases.length+1 ];
			setters = new Setter[ aliases.length+1 ];
		}else{
			this.aliases = new String[ aliases.length ];
			setters = new Setter[ aliases.length ];
		}
		for ( int i = 0; i < aliases.length; i++ ) {
			String alias = aliases[ i ];
			if ( alias != null ) {
				this.aliases[ i ] = alias;
				setters[ i ] = propertyAccessor.getSetter( resultClass, alias );
				if(alias.equals("orderStatus")){
					this.num=i;//这一步可以去掉，采用获取setters的属性名称获取状态值
				}
			}
		}
		if(isTransformStatus){
			this.aliases[aliases.length]="orderStatusName";//目前固定，后续有业务需要再修改
			setters[aliases.length]=propertyAccessor.getSetter( resultClass, "orderStatusName" );
		}
		isInitialized = true;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List transformList(List collection) {
		return collection;
	}
	
}
