package com.gjw.company.dao.validation;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.validation.SmsValidation;

public interface ISmsValidationDAO extends IDAO{
    SmsValidation getLastByMobile(String mobile);
    
    public List<SmsValidation> querySmsValidationByMobileAndCode(SmsValidation smsValidation);
    
    public boolean updateSmsValidationInvalidForOrder(SmsValidation smsValidation);
}
