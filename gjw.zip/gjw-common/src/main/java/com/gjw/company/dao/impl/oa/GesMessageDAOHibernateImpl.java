package com.gjw.company.dao.impl.oa;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.TaskConstant;
import com.gjw.company.dao.oa.IGesMessageDAO;
import com.gjw.entity.oa.GesMessage;
import com.gjw.entity.user.User;

/**
 * OA消息dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2016年1月16日 
 *
 */
@Component("gesMessageDAOHibernateImpl")
public class GesMessageDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesMessageDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GesMessage.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public GesMessage queryNewMessage(Long userId) {

        String hql = "from GesMessage g where g.user.id = ? ";
        
        List<GesMessage> list = (List<GesMessage>) super.getHibernateTemplate().find(hql, userId);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            GesMessage message = new GesMessage();
            message.setNewTaskNum(0);
            message.setNewProjectNum(0);
            message.setNewMessageNum(0);
            return message;
        }
    }

    @Override
    public boolean resetNewMessage(int type, Long userId) {
        GesMessage message = queryNewMessage(userId);
        switch (type) {
            case TaskConstant.MESSAGE_TYPE_TASK:
                message.setNewTaskNum(0);
                break;
            case TaskConstant.MESSAGE_TYPE_PROJECT:
                message.setNewProjectNum(0);
                break;
            case TaskConstant.MESSAGE_TYPE_MESSAGE:
                message.setNewMessageNum(0);
                break;
        }
        return super.update(message) == 1;
    }

    @Override
    public boolean addNewMessage(int type, Long userId, int num) {
        GesMessage message = queryNewMessage(userId);
        User user = new User();
        user.setId(userId);
        message.setUser(user);
        switch (type) {
            case TaskConstant.MESSAGE_TYPE_TASK:
                message.setNewTaskNum(message.getNewTaskNum() + num);
                break;
            case TaskConstant.MESSAGE_TYPE_PROJECT:
                message.setNewProjectNum(message.getNewProjectNum() + num);
                break;
            case TaskConstant.MESSAGE_TYPE_MESSAGE:
                message.setNewMessageNum(message.getNewMessageNum() + num);
                break;
        }
        super.saveOrUpdate(message);
        return true;
    }

}
