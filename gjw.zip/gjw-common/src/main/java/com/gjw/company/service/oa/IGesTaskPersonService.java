package com.gjw.company.service.oa;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.gjw.entity.user.UserInfoGES;
import com.gjw.vo.oa.TaskPersonVO;
import com.gjw.vo.oa.UserVO;

public interface IGesTaskPersonService {
	
	/**
	 * 获取可选客户分类:
	 * 构家网显示: 城运商+4S店+业主;
	 * 城运商显示: 4S店+业主;
	 * 4S店显示: 业主;
	 * @return 客户分类
	 */
	public List<TaskPersonVO> selectCustomer(String orgType);
	
	/**
	 * 获取常用客户列表
	 * @param taskPerson 客户(类型)
	 * @return 客户列表
	 */
	List<TaskPersonVO> listCustomer(TaskPersonVO taskPerson);
	
	/**
	 * 根据类型及名称查询客户列表
	 * @param type
	 * @param name
	 * @param user
	 * @return
	 */
	List<TaskPersonVO> queryCustomer(int type, String name,UserVO user);
	
	/**
	 * 获取下属部门及员工列表
	 * @param parentId 部门Id
	 * @return 下属部门及员工列表，员工在先，下属部门在后
	 */
	List<TaskPersonVO> listUser(long parentId, Long taskId,UserVO user);
	
	List<TaskPersonVO> queryUserByName(UserVO userVO);

}
