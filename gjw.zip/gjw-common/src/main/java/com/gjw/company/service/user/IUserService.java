package com.gjw.company.service.user;

import java.util.List;

import com.gjw.entity.user.User;
import com.gjw.entity.user.UserRoleItem;
import com.gjw.vo.user.UserVO;

/**
 * created by 重剑 on 2015/9/17 0017
 */
public interface IUserService {
    void modifyEmail(User user);

    void modifyMobile(User user);

    User get(Long id);

    User getWithAllInfo(Long id);

    List<String> loadAllRoleNames(Long userId);

    List<String> loadAllPermissionNames(Long userId);

    List<UserRoleItem> listRolesOfUser(Long userId);

    List<User> test();

    /**
     * @Description
     * @param username
     * @return
     * @author qingye
     * @date Jan 21, 2016 4:48:48 PM
     */

    User getByUsername(String username);

    User getByMobile(String phone);

    User getByEmail(String email);

    boolean updateUser(User user);

    boolean saveResultBoolean(User user);

    User getByUserNameAndPassWord(User user);

    /**
     * 根据用户名和密码获取房产销售工具用户
     * 
     * @Description
     * @param account
     *            用户名
     * @param passwordKey
     *            密码
     * @return 房产销售工具用户
     * @author guojianbin
     * @date 2016年3月9日
     */
    UserVO getSalesToolUser(String account, String passwordKey);

    User getWapUser(String account, String passwordKey);

    User getByAccount(String account);
    
    boolean remove(long id);
    
    User getAppUser(String account, String passwordKey);
}
