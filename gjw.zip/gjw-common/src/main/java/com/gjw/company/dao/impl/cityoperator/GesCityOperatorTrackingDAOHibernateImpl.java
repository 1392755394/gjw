package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesCityOperatorTrackingDAO;
import com.gjw.entity.cityoperator.GesCityOperatorTracking;
import com.gjw.utils.StringUtil;

@Component("gesCityOperatorTrackingDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesCityOperatorTrackingDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesCityOperatorTrackingDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesCityOperatorTracking.class;
    }

    @Override
    public GesCityOperatorTracking listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesCityOperatorTracking) super.get(id);
    }

    @Override
    public boolean updateGesCityOperatorTracking(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesCityOperatorTracking(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorTracking item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getTitle())){
            hql=hql+" and item.title like ?";
            params.add(super.getFuzzyCondition(model.getTitle()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        if(StringUtil.notEmpty(model.getGmtStartFrom())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtStartFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtStartTo())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtStartTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesCityOperatorTracking> listByGesCityOperatorTracking(
            GesCityOperatorTracking model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesCityOperatorTracking item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getCityOperator() && null!=model.getCityOperator().getId()){
            hql=hql+" and item.cityOperator.id=?";
            params.add(model.getCityOperator().getId());
        }
        if(StringUtil.notEmpty(model.getTitle())){
            hql=hql+" and item.title like ?";
            params.add(super.getFuzzyCondition(model.getTitle()));
        }
        if(StringUtil.notEmpty(model.getRemark())){
            hql=hql+" and item.remark like ?";
            params.add(super.getFuzzyCondition(model.getRemark()));
        }
        if(null!=model.getOwner() && null!=model.getOwner().getId()){
            hql=hql+" and item.owner.id=?";
            params.add(model.getOwner().getId());
        }
        if(StringUtil.notEmpty(model.getGmtStartFrom())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')>=?";
            params.add(model.getGmtStartFrom().toString());
        }
        if(StringUtil.notEmpty(model.getGmtStartTo())){
            hql=hql+" and DATE_FORMAT(item.createdDatetime,'%Y-%m-%d')<=?";
            params.add(model.getGmtStartTo().toString());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesCityOperatorTracking>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
