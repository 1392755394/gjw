package com.gjw.company.service.impl.virtual.reality;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.virtual.reality.IGesShopGoodsItemService;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.vo.GoodsVO;

/**
 * 虚拟现实
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月26日 下午2:44:21
 * 
 */
@Service("gesShopGoodsItemServiceImpl")
public class GesShopGoodsItemServiceImpl extends AbstractServiceImpl implements IGesShopGoodsItemService {
    @Override
    @Transactional(readOnly = true)
    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model){
        List<GesShopGoodsItem> list=super.getGesShopGoodsItemDAO().listByGesShopGoodsItem(model);
        for (GesShopGoodsItem gesShopGoodsItem : list) {
            Hibernate.initialize(gesShopGoodsItem.getShop());
        }
        return list;
    }
    
    
    @Override
    @Transactional(readOnly = true)
    public List<Goods> getPageGoodsList(GoodsVO goods) {

        List<Goods> list = super.getGesShopGoodsItemDAO().getPageGoodsList(goods);
        for (Goods shopGoods : list) {
            shopGoods.getPhoto().getPath();

        }
        return list;

    }

    @Override
    @Transactional(readOnly = true)
    public long getPageGoodsListCount(GoodsVO goods) {
        return super.getGesShopGoodsItemDAO().getPageGoodsListCount(goods);
    }
}
