package com.gjw.company.dao.app;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.app.WebDesigner;

public interface IWebDesignerDAO extends IDAO{
    public WebDesigner get(Long id);

    public List<WebDesigner> getList(WebDesigner model);
    
    public boolean addWebDesigner(WebDesigner model);
    
    public void updateWebDesigner(WebDesigner model);
    
    public WebDesigner getTopic(Long topicId);
}
