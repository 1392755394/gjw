package com.gjw.company.service.impl.order;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.order.IPaymentRecordResponseDAO;
import com.gjw.company.service.order.IPaymentRecordResponseService;
import com.gjw.entity.order.GesPaymentRecordResponse;

@Component("paymentRecordResponseServiceImpl")
public class PaymentRecordResponseServiceImpl implements
		IPaymentRecordResponseService {
	
	private final static Logger log=LoggerFactory.getLogger(PaymentRecordResponseServiceImpl.class);
	
	@Resource(name="paymentRecordResponseDAOHibernateImpl")
	private IPaymentRecordResponseDAO paymentRecordResponseDAO;
	
	public IPaymentRecordResponseDAO getPaymentRecordResponseDAO() {
		return paymentRecordResponseDAO;
	}

	public void setPaymentRecordResponseDAO(
			IPaymentRecordResponseDAO paymentRecordResponseDAO) {
		this.paymentRecordResponseDAO = paymentRecordResponseDAO;
	}

	/**
	 * 批量添加银行返回的支付记录信息
	 */
	@Override
	@Transactional
	public void addPaymentRecordResponse(List<GesPaymentRecordResponse> list) {
		Integer addNum=getPaymentRecordResponseDAO().batchAddPaymentRecordResponse(list);
		log.info("批量添加的支付信息个数为："+addNum);
	}

	
	
}
