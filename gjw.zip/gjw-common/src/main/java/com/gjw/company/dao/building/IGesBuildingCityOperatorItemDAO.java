package com.gjw.company.dao.building;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.building.GesBuildingCityOperatorItem;

public interface IGesBuildingCityOperatorItemDAO extends IDAO{
    
    public GesBuildingCityOperatorItem listByID(Long id);

    public boolean updateGesBuildingCityOperatorItem(GesBuildingCityOperatorItem model);

    public boolean createGesBuildingCityOperatorItem(GesBuildingCityOperatorItem model);
    
    public long count(GesBuildingCityOperatorItem model);
    
    public List<GesBuildingCityOperatorItem> listByGesBuildingCityOperatorItem(GesBuildingCityOperatorItem model);
    
    public GesBuildingCityOperatorItem listByBuildingId(Long buildingId);
}
