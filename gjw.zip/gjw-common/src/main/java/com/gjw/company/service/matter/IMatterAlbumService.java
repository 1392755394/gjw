package com.gjw.company.service.matter;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.matter.MatterAlbum;

/**
 * 物料相册service接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
public interface IMatterAlbumService extends IService {
    
    /**
     * 新增物料相册
     * @Description  
     * @param matterAlbum 物料相册
     * @return 物料相册ID
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public Long create(MatterAlbum matterAlbum);
    
    /**
     * 删除物料相册
     * @Description  
     * @param id 物料相册ID
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public boolean deleteById(long id);
    
    /**
     * 查询物料相册列表
     * 
     * @Description
     * @param matterId 物料ID
     * @return 物料相册列表
     * @author guojianbin
     * @date 2015年12月21日
     */
    public List<MatterAlbum> listAlbumByMatterID(long matterId);
}
