package com.gjw.company.dao.salestool;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.salestool.CaptchaRecord;

public interface ICaptchaRecordDAO extends IDAO{
    public CaptchaRecord listByID(Long id);

    public boolean updateCaptchaRecord(CaptchaRecord model);

    public boolean createCaptchaRecord(CaptchaRecord model);
    
    public long count(CaptchaRecord model);
    
    public List<CaptchaRecord> listByCaptchaRecord(CaptchaRecord model);
}
