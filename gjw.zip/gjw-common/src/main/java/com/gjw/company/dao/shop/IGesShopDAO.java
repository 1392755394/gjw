package com.gjw.company.dao.shop;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.shop.GesShop;
import com.gjw.vo.GesShopVO;

public interface IGesShopDAO extends IDAO {
    public GesShop listByID(Long id);

    public boolean updateGesShop(GesShop model);

    public boolean createGesShop(GesShop model);

    public long count(GesShop model);

    public List<GesShop> listByGesShop(GesShop model);
    
    public List<GesShopVO> listByGesShop4Export(GesShop model);
    
    /**
     * 根据用户id查询shop信息
     * 
     * @Description
     * @param id
     * @return
     * @author gwb
     * @date 2016年4月7日 下午12:31:59
     */
    public GesShop getShopCityIdByUserId(Long id);

}
