package com.gjw.company.dao.impl.oa;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.oa.IGesMemberDAO;
import com.gjw.entity.user.User;
import com.gjw.vo.oa.UserVO;

@Component("gesMemberHibernateImpl")
public class GesMemberHibernateImpl extends AbstractDAOHibernateImpl implements
		IGesMemberDAO {

	@Override
	protected Class getEntityClass() {
		return null;
	}

	/**
	 * 后期移动
	 */
	@Override
	public UserVO queryUserInfo(long id) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" select g.user.id as id,g.realName as realName,t.path as headPortrait ");
		hql.append(" from UserInfoGES g left join g.avatar t where g.user.id=? ");
		param.add(id);
		List<UserVO> list=(List<UserVO>) super.findByListCallBack(hql.toString(), null, param, Transformers.aliasToBean(UserVO.class));
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}
	/**
	 * 会员详细(官网用户)
	 * @param id
	 * @return
	 */
	@Override
	public User queryMember(long id) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" from User u where u.id=?");
		param.add(id);
		return (User) super.queryByParam(hql.toString(), param);
	}
	
	
}
