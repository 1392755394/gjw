package com.gjw.company.dao.erp;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.erp.GesPaymentOrder;
import com.gjw.vo.GesPaymentOrderVO;

/**
 * 付款单dao接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月31日 
 *
 */
public interface IGesPaymentOrderDAO extends IDAO {

    /**
     * 查询付款单列表
     * @Description  
     * @param paymentOrder 查询条件：日期范围、单据编号、单据状态、收款单位
     * @return 付款单列表
     * @author guojianbin   
     * @date 2015年12月31日
     */
    public List<GesPaymentOrder> pagePaymentOrder(GesPaymentOrderVO paymentOrder);

    /**
     * 查询付款单总数
     * @Description  
     * @param paymentOrder 查询条件：日期范围、单据编号、单据状态、收款单位
     * @return 付款单总数
     * @author guojianbin   
     * @date 2015年12月31日
     */
    public Long countPaymentOrder(GesPaymentOrderVO paymentOrder);
    
    /**
     * 根据ID获取付款单信息
     * @Description  
     * @param id 付款单id
     * @return 付款单
     * @author guojianbin   
     * @date 2015年12月31日
     */
    public GesPaymentOrder queryByID(Long id);

    /**
     * 新增付款单
     * 
     * @Description
     * @param paymentOrder 付款单
     * @return 付款单ID
     * @author guojianbin
     * @date 2015年12月31日
     */
    public long create(GesPaymentOrder paymentOrder);

    /**
     * 修改付款单
     * 
     * @Description
     * @param paymentOrder 付款单
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月31日
     */
    public boolean update(GesPaymentOrder paymentOrder);
}
