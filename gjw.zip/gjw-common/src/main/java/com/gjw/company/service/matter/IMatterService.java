package com.gjw.company.service.matter;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;
import com.gjw.vo.GesSoMatterVO;

/**
 * 物料service接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月16日
 * 
 */
public interface IMatterService extends IService {

    /**
     * 查询物料列表
     * 
     * @Description
     * @param matterCriteria
     *            查询条件
     * @return 物料列表
     * @author guojianbin
     * @date 2015年12月16日
     */
    public List<Matter> pageMatter(Matter matterCriteria);

    /**
     * 查询物料总数
     * 
     * @Description
     * @param matterCriteria
     *            查询条件
     * @return 物料总数
     * @author guojianbin
     * @date 2015年12月16日
     */
    public Long countMatter(Matter matterCriteria);

    /**
     * 根据ID获取物料信息，包含品牌及分类信息
     * 
     * @Description
     * @param id
     *            物料id
     * @return 物料
     * @author guojianbin
     * @date 2015年12月16日
     */
    public Matter queryByIDWithBrandAndCategory(Long id);

    /**
     * 根据getcInvCode查询物料编号
     * 
     * @Description
     * @param getcInvCode
     * @return
     * @author gwb
     * @date 2015年12月18日 上午11:31:27
     */
    public Matter getIdByCode(String getcInvCode);

    /**
     * 新增物料
     * 
     * @Description
     * @param matter
     *            物料
     * @return 物料ID
     * @author guojianbin
     * @date 2015年12月17日
     */
    public long create(Matter matter);

    /**
     * 修改物料
     * 
     * @Description
     * @param matter
     *            物料
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月17日
     */
    public boolean update(Matter matter);

    /**
     * 批量删除物料
     * 
     * @Description
     * @param ids
     *            物料ID
     * @return 成功与否
     * @author guojianbin
     * @date 2015年12月17日
     */
    public boolean delBatchByID(String ids);

    /**
     * 查询物料规格列表
     * 
     * @Description
     * @param matterSpecCriteria
     *            查询条件
     * @return 物料规格列表
     * @author guojianbin
     * @date 2015年12月19日
     */
    // public List<Matter> pageMatterSpec(MatterSpec matterSpecCriteria);

    /**
     * 查询物料规格总数
     * 
     * @Description
     * @param matterSpecCriteria
     *            查询条件
     * @return 物料规格总数
     * @author guojianbin
     * @date 2015年12月19日
     */
    // public Long countMatterSpec(MatterSpec matterSpecCriteria);

    /**
     * 物料同步列表查询
     * 
     * @Description
     * @param mater
     * @return
     * @author gwb
     * @date 2015年12月19日 下午4:46:11
     */
    public List<Matter> listMatter(Matter mater);

    /**
     * 物料同步列表查询
     * 
     * @Description
     * @param mater
     * @return
     * @author gwb
     * @date 2015年12月19日 下午4:46:11
     */
    public Long count(Matter mater);

    /**
     * 新增子物料
     * 
     * @Description
     * @param matter
     *            子物料
     * @return 子物料ID
     * @author guojianbin
     * @date 2015年12月22日
     */
    public long createChildMatter(Matter matter);

    /**
     * 根据产品包房间分页查询没有分配额物料列表
     * 
     * @Description
     * @param matterCriteria
     *            物料查询条件
     * @param goodsRoomCriteria
     *            产品包房间查询条件
     * @return 物料列表
     * @author guojianbin
     * @date 2016年1月16日
     */
    public List<Matter> pageForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria);

    /**
     * 根据产品包房间分页查询没有分配额物料列表
     * 
     * @Description
     * @param matterCriteria
     *            物料查询条件
     * @param goodsRoomCriteria
     *            产品包房间查询条件
     * @return 物料总数
     * @author guojianbin
     * @date 2016年1月16日
     */
    public Long countForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria);

    /**
     * 根据ID获取物料详情
     * 
     * @Description
     * @param id
     *            物料id
     * @return 物料
     * @author guojianbin
     * @date 2016年1月21日
     */
    public Matter queryByID(Long id);

    /**
     * 手动采购物流总数---关联关系
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2016年1月26日 上午10:33:53
     */
    public Long countNotInPoDetail(GesSoMatterVO soMatter);

    /**
     * 手动采购物流list---关联关系
     * 
     * @Description
     * @param soMatter
     * @return
     * @author gwb
     * @date 2016年1月26日 上午10:34:24
     */
    public List<Matter> pageNotInPoDetail(GesSoMatterVO soMatter);

}
