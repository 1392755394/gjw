package com.gjw.company.service.impl.support;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.support.IWebSupportItemService;
import com.gjw.entity.support.WebSupportItem;

/**
 * web 点赞相关操作
 * 
 * @Description:
 * @author gwb
 * @date 2016年2月25日 上午10:05:15
 * 
 */
@Service("webSupportItemServiceImpl")
public class WebSupportItemServiceImpl extends AbstractServiceImpl implements IWebSupportItemService {

    @Override
    @Transactional
    public boolean insert(WebSupportItem webSupportItem) {
        return super.getWebSupportItemDAO().insert(webSupportItem);
    }

    @Override
    @Transactional
    public boolean deleteWebSupportItem(Long id) {
        return super.getWebSupportItemDAO().deleteWebSupportItem(id);
    }

    @Override
    @Transactional
    public boolean deleteByContent(WebSupportItem webSupportItem) {
        return super.getWebSupportItemDAO().deleteByContent(webSupportItem);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebSupportItem> userSupportList(WebSupportItem webSupportItem) {
        return super.getWebSupportItemDAO().userSupportList(webSupportItem);
    }

    @Override
    @Transactional(readOnly = true)
    public long countByContent(WebSupportItem webSupportItem) {
        return super.getWebSupportItemDAO().countByContent(webSupportItem);
    }

}
