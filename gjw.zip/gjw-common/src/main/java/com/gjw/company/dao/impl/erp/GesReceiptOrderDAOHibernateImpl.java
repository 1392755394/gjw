package com.gjw.company.dao.impl.erp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesReceiptOrderDAO;
import com.gjw.entity.erp.GesReceiptOrder;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesReceiptOrderVO;

/**
 * 收款单dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月30日 
 *
 */
@Component("gesReceiptOrderDAOHibernateImpl")
public class GesReceiptOrderDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesReceiptOrderDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GesReceiptOrder.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesReceiptOrder> pageReceiptOrder(GesReceiptOrderVO receiptOrder) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesReceiptOrder where invalid = false ");
        if (StringUtil.notEmpty(receiptOrder.getCode())) {
            hql.append("  and code = ?");
            ls.add(receiptOrder.getCode());
        }
        if (StringUtil.notEmpty(receiptOrder.getPayer())) {
            hql.append("  and payer like ?");
            ls.add(getFuzzyCondition(receiptOrder.getPayer()));
        }
        if (StringUtil.notEmpty(receiptOrder.getStatus())) {
            hql.append("  and status = ?");
            ls.add(receiptOrder.getStatus());
        }
        if (StringUtil.notEmpty(receiptOrder.getGmtVoucherFrom())) {
            hql.append("  and gmtVoucher >= ?");
            ls.add(receiptOrder.getGmtVoucherFrom());
        }
        if (StringUtil.notEmpty(receiptOrder.getGmtVoucherTo())) {
            hql.append("  and gmtVoucher <= ?");
            ls.add(receiptOrder.getGmtVoucherTo());
        }
        if (receiptOrder.getOperator() != null && receiptOrder.getOperator().getId() != null) {
            ls.add(receiptOrder.getOperator().getId());
            hql.append("  and operator.id=?");
        } else {
            hql.append("  and operator=null");
        }
        if (receiptOrder.getShop() != null && receiptOrder.getShop().getId() != null) {
            ls.add(receiptOrder.getShop().getId());
            hql.append("  and shop.id=?");
        } else {
            hql.append("  and shop=null");
        }
        return (List<GesReceiptOrder>) super.findByPageCallBack(hql.toString(), "", ls, receiptOrder, null);
    }

    @Override
    public Long countReceiptOrder(GesReceiptOrderVO receiptOrder) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesReceiptOrder where invalid = false ");
        if (StringUtil.notEmpty(receiptOrder.getCode())) {
            hql.append("  and code = ?");
            ls.add(receiptOrder.getCode());
        }
        if (StringUtil.notEmpty(receiptOrder.getPayer())) {
            hql.append("  and payer like ?");
            ls.add(getFuzzyCondition(receiptOrder.getPayer()));
        }
        if (StringUtil.notEmpty(receiptOrder.getStatus())) {
            hql.append("  and status = ?");
            ls.add(receiptOrder.getStatus());
        }
        if (StringUtil.notEmpty(receiptOrder.getGmtVoucherFrom())) {
            hql.append("  and gmtVoucher >= ?");
            ls.add(receiptOrder.getGmtVoucherFrom());
        }
        if (StringUtil.notEmpty(receiptOrder.getGmtVoucherTo())) {
            hql.append("  and gmtVoucher <= ?");
            ls.add(receiptOrder.getGmtVoucherTo());
        }
        if (receiptOrder.getOperator() != null && receiptOrder.getOperator().getId() != null) {
            ls.add(receiptOrder.getOperator().getId());
            hql.append("  and operator.id=?");
        } else {
            hql.append("  and operator=null");
        }
        if (receiptOrder.getShop() != null && receiptOrder.getShop().getId() != null) {
            ls.add(receiptOrder.getShop().getId());
            hql.append("  and shop.id=?");
        } else {
            hql.append("  and shop=null");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public GesReceiptOrder queryByID(Long id) {
        return (GesReceiptOrder) super.get(id);
    }

    @Override
    public long create(GesReceiptOrder receiptOrder) {
        if (receiptOrder.getOperator() != null && receiptOrder.getOperator().getId() == null) {
            receiptOrder.setOperator(null);
        }
        if (receiptOrder.getShop() != null && receiptOrder.getShop().getId() == null) {
            receiptOrder.setShop(null);
        }
        receiptOrder.setGmtBusiness(new Timestamp(System.currentTimeMillis()));
        super.add(receiptOrder);
        return receiptOrder.getId();
    }

    @Override
    public boolean update(GesReceiptOrder receiptOrder) {
        GesReceiptOrder old = (GesReceiptOrder) super.get(receiptOrder.getId());
        if (receiptOrder.getOperator() != null && receiptOrder.getOperator().getId() == null) {
            receiptOrder.setOperator(null);
        }
        if (receiptOrder.getShop() != null && receiptOrder.getShop().getId() == null) {
            receiptOrder.setShop(null);
        }
        receiptOrder.setGmtBusiness(new Timestamp(System.currentTimeMillis()));
        if (null != receiptOrder.getStatus()) {
            receiptOrder.setGmtAudit(new Timestamp(System.currentTimeMillis()));
        }
        StringUtil.copyPropertiesAllowEmpty(receiptOrder, old);
        return super.update(old) == 1;
    }

    @Override
    public Integer batchCreate(List<GesReceiptOrder> receiptOrderList) {
        return super.batchAdd(receiptOrderList);
    }

    @SuppressWarnings("unchecked")
    @Override
    public GesReceiptOrder queryByUniqueID(Long uniqueId) {

        String hql = "from GesReceiptOrder where uniqueId = ? ";
        
        List<GesReceiptOrder> list = (List<GesReceiptOrder>) super.getHibernateTemplate().find(hql, uniqueId);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

}
