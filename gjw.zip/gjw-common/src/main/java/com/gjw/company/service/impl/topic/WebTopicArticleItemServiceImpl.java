package com.gjw.company.service.impl.topic;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.topic.IWebTopicArticleItemDAO;
import com.gjw.company.dao.topic.IWebTopicDAO;
import com.gjw.company.service.topic.IWebTopicArticleItemService;
import com.gjw.entity.article.WebArticle;
import com.gjw.entity.topic.WebTopic;
import com.gjw.entity.topic.WebTopicArticleItem;

@Component("webTopicArticleItemServiceImpl")
public class WebTopicArticleItemServiceImpl implements IWebTopicArticleItemService {

    @Autowired
    private IWebTopicArticleItemDAO dao;
    @Autowired
    private IWebTopicDAO topicDao;

    @Override
    @Transactional(readOnly = true)
    public List<WebTopicArticleItem> listByTopic(Long topicId) {
        // TODO Auto-generated method stub
        List<WebTopicArticleItem> list = dao.listByTopic(topicId);
        if (null != list && list.size() > 0) {
            for (WebTopicArticleItem webTopicArticleItem : list) {
                if (null != webTopicArticleItem.getArticle().getId()) {
                    Hibernate.initialize(webTopicArticleItem.getArticle());
                    if(null!=webTopicArticleItem.getArticle().getImage()){
                        Hibernate.initialize(webTopicArticleItem.getArticle().getImage());
                    }
                }
                if (null != webTopicArticleItem.getArticle().getUser().getId()) {
                    Hibernate.initialize(webTopicArticleItem.getArticle().getUser());
                }
            }
        }
        return list;
    }

    @Override
    @Transactional
    public boolean insert(WebTopicArticleItem entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public String insertByArticleIds(Long topicId, String articleIds) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        boolean row = false; // 操作结果
        if (articleIds != null && articleIds.length() > 0) {
            if (articleIds.contains(",")) {
                String[] str = articleIds.split(",");
                for (String id : str) {
                    WebTopic topic = new WebTopic();
                    topic.setId(topicId);
                    WebArticle article = new WebArticle();
                    article.setId(Long.valueOf(id));
                    WebTopicArticleItem item = new WebTopicArticleItem(topic, article);
                    row = this.insert(item);
                    if (row) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                WebTopic topic = new WebTopic();
                topic.setId(topicId);
                WebArticle article = new WebArticle();
                article.setId(Long.valueOf(articleIds));
                WebTopicArticleItem item = new WebTopicArticleItem(topic, article);
                row = this.insert(item);
                if (row) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        //修改话题相关文章数量
        WebTopic topic = topicDao.getById(topicId);
        Integer number = topic.getAssociatedArticleNumber();
        number = number + success;
        topic.setAssociatedArticleNumber(number);
        topicDao.updateTopic(topic);
        if (0 == success && 0 != error) {
            return "失败添加" + error + "条话题文章关系！";
        } else if (0 == error && 0 != success) {
            return "成功添加" + success + "条话题文章关系！";
        } else if (0 == success && 0 == error) {
            return "请选择添加的话题文章关系！";
        } else {
            return "成功添加" + success + "条话题文章关系,失败添加" + error + "条话题文章关系！";
        }

    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids,Long topicId) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = this.invalid(Long.valueOf(id));
                    if (row > 0) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                row = this.invalid(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        //修改话题相关文章数量
        WebTopic topic = topicDao.getById(topicId);
        Integer number = topic.getAssociatedArticleNumber();
        number = number - success;
        topic.setAssociatedArticleNumber(number);
        topicDao.updateTopic(topic);
        if (0 == success && 0 != error) {
            return "失败移除" + error + "条话题文章关系！";
        } else if (0 == error && 0 != success) {
            return "成功移除" + success + "条话题文章关系！";
        } else if (0 == success && 0 == error) {
            return "请选择移除的话题文章关系！";
        } else {
            return "成功移除" + success + "条话题文章关系,失败移除" + error + "条话题文章关系！";
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebTopicArticleItem> listByArticle(Long articleId) {
        List<WebTopicArticleItem> items = dao.listByArticle(articleId);
        for (WebTopicArticleItem item : items) {
            Hibernate.initialize(item.getTopic());
        }
        return items;
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebTopicArticleItem> countGroupByTopic() {
        return dao.countGroupByTopic();
    }
}
