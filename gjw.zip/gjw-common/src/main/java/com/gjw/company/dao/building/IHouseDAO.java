package com.gjw.company.dao.building;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.building.House;

public interface IHouseDAO extends IDAO{
    public House listByID(Long id);

    public boolean updateHouse(House model);

    public boolean createHouse(House model);
    
    public long count(House model);
    
    public List<House> listByHouse(House model);
}
