package com.gjw.company.dao.impl.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.validation.ISmsValidationDAO;
import com.gjw.entity.validation.SmsValidation;

/**
 * created by 重剑 on 2015/9/17 0017
 */
@Component("smsValidationDAOHibernateImpl")
public class SmsValidationDAOHibernateImpl extends AbstractDAOHibernateImpl implements ISmsValidationDAO {

    @Override
    public SmsValidation getLastByMobile(String mobile) {
        String hql="from SmsValidation where invalid=0 and mobile=? order by createdDatetime desc";
        List<SmsValidation> list=(List<SmsValidation>)this.getHibernateTemplate().find(hql, mobile);
        if(!list.isEmpty())
            return list.get(0);
        return null;
    }

    @Override
    protected Class<?> getEntityClass() {
        return SmsValidation.class;
    }

	@Override
	public List<SmsValidation> querySmsValidationByMobileAndCode(SmsValidation smsValidation) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append(" from SmsValidation where invalid=? and validateCode=? and event=? and mobile=? order by createdDatetime desc");
		param.add(false);
		param.add(smsValidation.getValidateCode());
		param.add(smsValidation.getEvent());
		param.add(smsValidation.getMobile());
		return (List<SmsValidation>) super.findByListCallBack(hql.toString(), null, param, null);
	}

	@Override
	public boolean updateSmsValidationInvalidForOrder(SmsValidation smsValidation) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("update SmsValidation set invalid=? where event=? and mobile=? ");
		param.add(true);
		param.add(smsValidation.getEvent());
		param.add(smsValidation.getMobile());
		return super.updateByParam(hql.toString(), param);
	}

}
