package com.gjw.company.dao.impl.goods;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.goods.IGoodsAppMarkDAO;
import com.gjw.entity.goods.GoodsAppMark;
import com.gjw.entity.goods.GoodsMark;
import com.gjw.utils.StringUtil;

/**
 * 
 * @Description: 产品包APP锚点dao实现类
 * @author guojianbin   
 * @date 2016年04月20日 
 *
 */
@Component("goodsAppMarkDAOHibernateImpl")
public class GoodsAppMarkDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsAppMarkDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsAppMark.class;
    }

    @Override
    public boolean update(GoodsAppMark mark) {
        GoodsAppMark old = (GoodsAppMark) super.get(mark.getId());
        StringUtil.copyProperties(mark, old);
        super.update(old);
        return true;
    }

    @Override
    public long create(GoodsAppMark mark) {
        super.add(mark);
        return mark.getId();
    }


}
