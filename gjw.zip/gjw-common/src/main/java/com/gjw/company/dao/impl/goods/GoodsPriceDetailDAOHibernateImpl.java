package com.gjw.company.dao.impl.goods;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.goods.IGoodsPriceDetailDAO;
import com.gjw.entity.goods.GoodsPriceDetail;
import com.gjw.utils.StringUtil;

/**
 * 产品包价格dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月25日 
 *
 */
@Component("goodsPriceDetailDAOHibernateImpl")
public class GoodsPriceDetailDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsPriceDetailDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsPriceDetail.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsPriceDetail> listGoodsPriceByGoodsId(Long goodsId) {

        String hql = "from GoodsPriceDetail gp where gp.goods.id = ? order by gp.orderTag asc";
        
        return (List<GoodsPriceDetail>) super.getHibernateTemplate().find(hql, goodsId);
    }

    @Override
    public boolean update(GoodsPriceDetail goodsPriceDetail) {
        GoodsPriceDetail old = (GoodsPriceDetail) super.get(goodsPriceDetail.getId());
        StringUtil.copyPropertiesAllowEmpty(goodsPriceDetail, old);
        return super.update(old) == 1;
    }

    @Override
    public long create(GoodsPriceDetail goodsPriceDetail) {
        super.add(goodsPriceDetail);
        return goodsPriceDetail.getId();
    }

}
