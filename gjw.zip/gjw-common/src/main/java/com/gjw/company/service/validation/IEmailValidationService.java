package com.gjw.company.service.validation;

import com.gjw.entity.validation.EmailValidation;


/**
 * created by guojianbin on 2016/3/2
 */
public interface IEmailValidationService {
    void create(EmailValidation smsValidation);
    EmailValidation findLastByEmail(String email);
}
