package com.gjw.company.dao.impl.building;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.building.IGesBuildingCityOperatorItemDAO;
import com.gjw.entity.building.GesBuildingCityOperatorItem;
import com.gjw.utils.StringUtil;
@Component("gesBuildingCityOperatorItemDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesBuildingCityOperatorItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesBuildingCityOperatorItemDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesBuildingCityOperatorItem.class;
    }

    @Override
    public GesBuildingCityOperatorItem listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesBuildingCityOperatorItem) super.get(id);
    }

    @Override
    public boolean updateGesBuildingCityOperatorItem(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesBuildingCityOperatorItem(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesBuildingCityOperatorItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding()){
            if(null!=model.getBuilding().getId()){
                hql=hql+" and item.building.id=?";
                params.add(model.getBuilding().getId());
            }
            if(StringUtil.notEmpty(model.getBuilding().getName())){
                hql=hql+" and item.building.name like ?";
                params.add(super.getFuzzyCondition(model.getBuilding().getName()));
            }
        }
        if(null!=model.getOperator()){
            if(null!=model.getOperator().getId()){
                hql=hql+" and item.operator.id=?";
                params.add(model.getOperator().getId());
            }
            if(StringUtil.notEmpty(model.getOperator().getContactName())){
                hql=hql+" and item.operator.contactName like ?";
                params.add(super.getFuzzyCondition(model.getOperator().getContactName()));
            }
            if(StringUtil.notEmpty(model.getOperator().getCompanyName())){
                hql=hql+" and item.operator.companyName like ?";
                params.add(super.getFuzzyCondition(model.getOperator().getCompanyName()));
            }
        }
        hql=hql+" order by item.invalid";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesBuildingCityOperatorItem> listByGesBuildingCityOperatorItem(
            GesBuildingCityOperatorItem model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        if(null==model.getStatus()){
            model.setStatus(1);
        }
        String hql=" from GesBuildingCityOperatorItem item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getBuilding()){
            if(null!=model.getBuilding().getId()){
                hql=hql+" and item.building.id=?";
                params.add(model.getBuilding().getId());
            }
            if(StringUtil.notEmpty(model.getBuilding().getName())){
                hql=hql+" and item.building.name like ?";
                params.add(super.getFuzzyCondition(model.getBuilding().getName()));
            }
        }
        if(null!=model.getOperator()){
            if(null!=model.getOperator().getId()){
                hql=hql+" and item.operator.id=?";
                params.add(model.getOperator().getId());
            }
            if(StringUtil.notEmpty(model.getOperator().getContactName())){
                hql=hql+" and item.operator.contactName like ?";
                params.add(super.getFuzzyCondition(model.getOperator().getContactName()));
            }
            if(StringUtil.notEmpty(model.getOperator().getCompanyName())){
                hql=hql+" and item.operator.companyName like ?";
                params.add(super.getFuzzyCondition(model.getOperator().getCompanyName()));
            }
        }
        hql=hql+" order by item.invalid";
        return (List<GesBuildingCityOperatorItem>) super.findByPageCallBack(hql,"",params,model,null);
    }
    
    @Override
    public GesBuildingCityOperatorItem listByBuildingId(Long buildingId) {
        // TODO Auto-generated method stub
        Session session = getHibernateTemplate().getSessionFactory().getCurrentSession();
        String hql=" from GesBuildingCityOperatorItem item where item.invalid=0 and item.building.id=:buildingId";
        Query query=session.createQuery(hql);
        query.setLong("buildingId", buildingId);
        List<GesBuildingCityOperatorItem> list=query.list();
        if(null!=list && list.size()>0){
            return list.get(0);
        }
        return null;
    }
}
