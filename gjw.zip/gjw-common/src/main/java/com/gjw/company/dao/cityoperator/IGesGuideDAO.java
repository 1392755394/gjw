package com.gjw.company.dao.cityoperator;

import java.util.List;
import com.gjw.base.dao.IDAO;
import com.gjw.entity.cityoperator.GesGuide;

public interface IGesGuideDAO extends IDAO{
    public GesGuide listByID(Long id);

    public boolean updateGesGuide(GesGuide model);

    public boolean createGesGuide(GesGuide model);
    
    public long count(GesGuide model);
    
    public List<GesGuide> listByGesGuide(GesGuide model);
}
