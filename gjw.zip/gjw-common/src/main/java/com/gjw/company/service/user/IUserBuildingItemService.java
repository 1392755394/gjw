package com.gjw.company.service.user;

import com.gjw.base.service.IService;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserBuildingItem;

public interface IUserBuildingItemService extends IService {
    UserBuildingItem queryByUser(User user);
}
