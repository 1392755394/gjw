package com.gjw.company.service.order;

import java.util.Map;

import com.gjw.vo.order.PaymentRecordResponseVO;

public interface IAccountCheckService {
	
	/**
	 * 分页获取对账信息
	 * @param record
	 * @return
	 */
	public Map<String,Object> pageFinance(PaymentRecordResponseVO record);
	
	/**
	 * 对账簿核算
	 * @param record
	 * @return
	 */
	public boolean updateOrderStatus(PaymentRecordResponseVO record);
	
	/**
     * 清理数据
     */
	public boolean updateClear(PaymentRecordResponseVO record);
	
	/**
     * 修改订单状态(该功能删除)
     */
	public boolean updateModify(PaymentRecordResponseVO record);
	
	/**
     * 退款核算处理，目前只是更新对账簿记录为已核算
     */
	public boolean updateRefund(PaymentRecordResponseVO record);

}
