package com.gjw.company.dao.impl.app;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.app.IWebContrastDAO;
import com.gjw.entity.app.WebContrast;
import com.gjw.entity.app.WebContrastDetail;

@Component("webContrastDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class WebContrastDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebContrastDAO{
    
    public WebContrast get(Long id) {
        return (WebContrast) super.get(id);
    }
    
    @Override
    public List<WebContrast> getList(WebContrast model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        if (null == model.getStatus()) {
            model.setStatus(1);
        }
        String hql = " from WebContrast item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if(null!=model.getType()){
            hql=hql+" and item.type=?";
            params.add(model.getType());
        }
        hql = hql + " order by item.createdDatetime desc";
        return (List<WebContrast>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public boolean addWebContrast(WebContrast webContrast){
        // TODO Auto-generated method stub
        super.add(webContrast);
        return true;
    }

    @Override
    public void updateWebContrast(WebContrast webContrast){
        // TODO Auto-generated method stub
        super.update(webContrast);
    }

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebContrast.class;
    }

}
