package com.gjw.company.dao.impl.building;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.building.IGesBuildingDAO;
import com.gjw.entity.building.GesBuilding;
import com.gjw.utils.StringUtil;

@Component("gesBuildingDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesBuildingDAOHibernaterImpl extends AbstractDAOHibernateImpl implements IGesBuildingDAO{

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesBuilding.class;
    }

    @Override
    public List<GesBuilding> listByGesBuilding(GesBuilding building) {
        // TODO Auto-generated method stub
        if(null==building.getInvalid()){
            building.setInvalid(false);
        }
        String hql=" from GesBuilding building where 1=1 ";
        List<Object> params = new ArrayList<Object>();
        if(null!=building.getInvalid()){
            hql=hql+" and building.invalid=?";
            params.add(building.getInvalid());
        }
        if(StringUtil.notEmpty(building.getName())){
            hql=hql+" and building.name like ?";
            params.add(super.getFuzzyCondition(building.getName()));
        }
        if(StringUtil.notEmpty(building.getDeveloper())){
            hql=hql+" and building.developer like ?";
            params.add(super.getFuzzyCondition(building.getDeveloper()));
        }
        if(null!=building.getProvince() && null!=building.getProvince().getId()){
            hql=hql+" and building.province.id=?";
            params.add(building.getProvince().getId());
        }
        if(null!=building.getCity() && null!=building.getCity().getId()){
            hql=hql+" and building.city.id=?";
            params.add(building.getCity().getId());
        }
        if(null!=building.getCounty() && null!=building.getCounty().getId()){
            hql=hql+" and building.county.id=?";
            params.add(building.getCounty().getId());
        }
//        if(null!=building.getLongitude() && 0<building.getLongitude()){
//            hql=hql+" and ABS(building.longitude-?)<=0.05";
//            params.add(building.getLongitude());
//        }
//        if(null!=building.getLatitude() && 0<building.getLatitude()){
//            hql=hql+" and ABS(building.latitude-?)<=0.05";
//            params.add(building.getDeveloper());
//        }
        //查询未合作的楼盘
        if(null!=building.getStatus() && -1==building.getStatus()){
            hql=hql+" and ( building.status=1 or building.status=2 )";
        }
        hql=hql+" order by status desc,created_datetime desc";
        return (List<GesBuilding>) super.findByPageCallBack(hql, "", params, building, null);
    }

    @Override
    public GesBuilding listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesBuilding) super.get(id);
    }

    @Override
    public boolean updateGesBuilding(GesBuilding model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesBuilding(GesBuilding model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesBuilding building) {
        // TODO Auto-generated method stub
        if(null==building.getInvalid()){
            building.setInvalid(false);
        }
        String hql=" from GesBuilding building where 1=1 ";
        List<Object> params = new ArrayList<Object>();
        if(null!=building.getInvalid()){
            hql=hql+" and building.invalid=?";
            params.add(building.getInvalid());
        }
        if(StringUtil.notEmpty(building.getName())){
            hql=hql+" and building.name like ?";
            params.add(super.getFuzzyCondition(building.getName()));
        }
        if(StringUtil.notEmpty(building.getDeveloper())){
            hql=hql+" and building.developer like ?";
            params.add(super.getFuzzyCondition(building.getDeveloper()));
        }
        if(null!=building.getProvince() && null!=building.getProvince().getId()){
            hql=hql+" and building.province.id=?";
            params.add(building.getProvince().getId());
        }
        if(null!=building.getCity() && null!=building.getCity().getId()){
            hql=hql+" and building.city.id=?";
            params.add(building.getCity().getId());
        }
        if(null!=building.getCounty() && null!=building.getCounty().getId()){
            hql=hql+" and building.county.id=?";
            params.add(building.getCounty().getId());
        }
//        if(null!=building.getLongitude() && 0<building.getLongitude()){
//            hql=hql+" and ABS(building.longitude-?)<=0.05";
//            params.add(building.getLongitude());
//        }
//        if(null!=building.getLatitude() && 0<building.getLatitude()){
//            hql=hql+" and ABS(building.latitude-?)<=0.05";
//            params.add(building.getDeveloper());
//        }
        //查询未合作的楼盘
        if(null!=building.getStatus() && -1==building.getStatus()){
            hql=hql+" and ( building.status=1 or building.status=2 )";
        }
        hql=hql+" order by status desc,created_datetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

}
