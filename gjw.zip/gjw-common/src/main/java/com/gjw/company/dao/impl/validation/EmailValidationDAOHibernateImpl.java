package com.gjw.company.dao.impl.validation;

import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.validation.IEmailValidationDAO;
import com.gjw.entity.validation.EmailValidation;

@Component("emailValidationDAOHibernateImpl")
public class EmailValidationDAOHibernateImpl extends AbstractDAOHibernateImpl implements IEmailValidationDAO {

    @Override
    public void create(EmailValidation smsValidation) {
        super.add(smsValidation);
    }

    @SuppressWarnings("unchecked")
    @Override
    public EmailValidation findLastByEmail(String email) {
        String hql="from EmailValidation where invalid=0 and email=? order by createdDatetime desc";
        List<EmailValidation> list=(List<EmailValidation>)super.getHibernateTemplate().find(hql, email);
        if(!list.isEmpty())
            return list.get(0);
        return null;
    }

    @Override
    protected Class<?> getEntityClass() {
        return EmailValidation.class;
    }

}
