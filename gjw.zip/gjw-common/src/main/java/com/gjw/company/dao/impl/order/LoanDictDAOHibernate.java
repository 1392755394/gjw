package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.ILoanDictDAO;
import com.gjw.entity.order.LoanDict;
import com.gjw.utils.StringUtil;

@Component("loanDictDAOHibernate")
public class LoanDictDAOHibernate extends AbstractDAOHibernateImpl implements
		ILoanDictDAO {

	@Override
	protected Class getEntityClass() {
		return LoanDict.class;
	}

	@Override
	public List<LoanDict> queryByCIP(LoanDict dict) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("from LoanDict d where d.invalid=? ");
		param.add(false);
		if(StringUtil.notEmpty(dict.getCode())){
			hql.append(" and d.code=? ");
			param.add(dict.getCode());
		}
		if(dict.getId()!=null&&dict.getId()>0){
			hql.append(" and d.id=? ");
			param.add(dict.getId());
		}
		if(dict.getDict()!=null && dict.getDict().getId()!=null){
			hql.append(" and d.dict.id=? ");
			param.add(dict.getDict().getId());
		}
		hql.append(" order by d.orderTag asc ");
		return (List<LoanDict>) super.findByListCallBack(hql.toString(), null, param, null);
	}

	@Override
	public LoanDict queryRate(LoanDict dict) {
		StringBuffer hql=new StringBuffer();
		List<Object> param=new ArrayList<Object>();
		hql.append("from LoanDict d where d.invalid=? ");
		param.add(false);
		hql.append(" and name=? and code=? ");
		param.add(dict.getName());
		param.add(dict.getCode());
		return (LoanDict) queryByParam(hql.toString(), param);
	}
	
	public Object queryByParam(String hql, List<Object> list) {
        List<Object> result=(List<Object>) super.findByListCallBack(hql, null, list, null);
        if(result!=null && result.size()>0){
        	return result.get(0);
        }else{
        	return null;
        }
    }

}
