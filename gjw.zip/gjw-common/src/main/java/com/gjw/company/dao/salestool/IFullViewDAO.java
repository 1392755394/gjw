package com.gjw.company.dao.salestool;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.salestool.FullView;

public interface IFullViewDAO extends IDAO{
    public FullView listByID(Long id);

    public boolean updateFullView(FullView model);

    public boolean createFullView(FullView model);
    
    public long count(FullView model);
    
    public List<FullView> listByFullView(FullView model);
    
    /**
     * 
    * @Description  通过验证码查看全景列表
    * @param captcha
    * @return
    * @author zhaoyonglian   
    * @date 2016年3月11日 上午11:31:03
     */
    public List<FullView> listByCaptcha(String captcha);
}
