package com.gjw.company.dao.impl.shop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.company.dao.shop.IGesShopGoodsItemDAO;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.shop.GesShop;
import com.gjw.entity.shop.GesShopGoodsItem;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsVO;

@Component("gesShopGoodsItemDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesShopGoodsItemDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesShopGoodsItemDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesShopGoodsItem.class;
    }

    @Override
    public GesShopGoodsItem listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesShopGoodsItem) super.get(id);
    }

    @Override
    public boolean updateGesShopGoodsItem(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        return super.update(model) == 1;
    }

    @Override
    public boolean createGesShopGoodsItem(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        String hql = " from GesShopGoodsItem item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and item.status=?";
            params.add(model.getStatus());
        }
        if (null != model.getShop() && null != model.getShop().getId()) {
            hql = hql + " and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        if (null != model.getShop() && null != model.getShop().getOperator()
                && null != model.getShop().getOperator().getId()) {
            hql = hql + " and item.shop.operator.id=?";
            params.add(model.getShop().getOperator().getId());
        }
        if (null != model.getShop() && StringUtil.notEmpty(model.getShop().getName())) {
            hql = hql + " and item.shop.name like ?";
            params.add(super.getFuzzyCondition(model.getShop().getName()));
        }
        if (null != model.getShop() && null != model.getShop().getProvince()
                && null != model.getShop().getProvince().getId()) {
            hql = hql + " and item.shop.province.id=?";
            params.add(model.getShop().getProvince().getId());
        }
        if (null != model.getShop() && null != model.getShop().getCity() && null != model.getShop().getCity().getId()) {
            hql = hql + " and item.shop.city.id=?";
            params.add(model.getShop().getCity().getId());
        }
        if (null != model.getShop() && null != model.getShop().getCounty()
                && null != model.getShop().getCounty().getId()) {
            hql = hql + " and item.shop.county.id=?";
            params.add(model.getShop().getCounty().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getId()) {
            hql = hql + " and item.goods.id=?";
            params.add(model.getGoods().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getStatus()) {
            hql = hql + " and item.goods.status=?";
            params.add(model.getGoods().getStatus());
        }
        if (null != model.getGoods() && StringUtil.notEmpty(model.getGoods().getName())) {
            hql = hql + " and item.goods.name like ?";
            params.add(super.getFuzzyCondition(model.getGoods().getName()));
        }
        if (null != model.getGoods() && null != model.getGoods().getStyle()
                && null != model.getGoods().getStyle().getId()) {
            hql = hql + " and item.goods.style.id=?";
            params.add(model.getGoods().getStyle().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouse()
                && null != model.getGoods().getHouse().getId()) {
            hql = hql + " and item.goods.house.id=?";
            params.add(model.getGoods().getHouse().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouse() && null != model.getGoods().getHouse()
                && null != model.getGoods().getHouse().getBuilding()
                && null != model.getGoods().getHouse().getBuilding().getId()) {
            hql = hql + " and item.goods.house.building.id=?";
            params.add(model.getGoods().getHouse().getBuilding().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouseType()
                && null != model.getGoods().getHouseType().getId()) {
            hql = hql + " and item.goods.houseType.id=?";
            params.add(model.getGoods().getHouseType().getId());
        }
        hql = hql + " order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesShopGoodsItem> listByGesShopGoodsItem(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        if (null == model.getInvalid()) {
            model.setInvalid(false);
        }
        String hql = " from GesShopGoodsItem item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and item.status=?";
            params.add(model.getStatus());
        }
        if (null != model.getShop() && null != model.getShop().getId()) {
            hql = hql + " and item.shop.id=?";
            params.add(model.getShop().getId());
        }
        if (null != model.getShop() && null != model.getShop().getOperator()
                && null != model.getShop().getOperator().getId()) {
            hql = hql + " and item.shop.operator.id=?";
            params.add(model.getShop().getOperator().getId());
        }
        if (null != model.getShop() && StringUtil.notEmpty(model.getShop().getName())) {
            hql = hql + " and item.shop.name like ?";
            params.add(super.getFuzzyCondition(model.getShop().getName()));
        }
        if (null != model.getShop() && null != model.getShop().getProvince()
                && null != model.getShop().getProvince().getId()) {
            hql = hql + " and item.shop.province.id=?";
            params.add(model.getShop().getProvince().getId());
        }
        if (null != model.getShop() && null != model.getShop().getCity() && null != model.getShop().getCity().getId()) {
            hql = hql + " and item.shop.city.id=?";
            params.add(model.getShop().getCity().getId());
        }
        if (null != model.getShop() && null != model.getShop().getCounty()
                && null != model.getShop().getCounty().getId()) {
            hql = hql + " and item.shop.county.id=?";
            params.add(model.getShop().getCounty().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getId()) {
            hql = hql + " and item.goods.id=?";
            params.add(model.getGoods().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getStatus()) {
            hql = hql + " and item.goods.status=?";
            params.add(model.getGoods().getStatus());
        }
        if (null != model.getGoods() && StringUtil.notEmpty(model.getGoods().getName())) {
            hql = hql + " and item.goods.name like ?";
            params.add(super.getFuzzyCondition(model.getGoods().getName()));
        }
        if (null != model.getGoods() && null != model.getGoods().getStyle()
                && null != model.getGoods().getStyle().getId()) {
            hql = hql + " and item.goods.style.id=?";
            params.add(model.getGoods().getStyle().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouse()
                && null != model.getGoods().getHouse().getId()) {
            hql = hql + " and item.goods.house.id=?";
            params.add(model.getGoods().getHouse().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouse() && null != model.getGoods().getHouse()
                && null != model.getGoods().getHouse().getBuilding()
                && null != model.getGoods().getHouse().getBuilding().getId()) {
            hql = hql + " and item.goods.house.building.id=?";
            params.add(model.getGoods().getHouse().getBuilding().getId());
        }
        if (null != model.getGoods() && null != model.getGoods().getHouseType()
                && null != model.getGoods().getHouseType().getId()) {
            hql = hql + " and item.goods.houseType.id=?";
            params.add(model.getGoods().getHouseType().getId());
        }
        hql = hql + " order by item.createdDatetime desc";
        return (List<GesShopGoodsItem>) super.findByPageCallBack(hql, "", params, model, null);
    }

    @Override
    public GesShopGoodsItem listByShopAndGood(GesShopGoodsItem model) {
        // TODO Auto-generated method stub
        if (null != model.getInvalid()) {
            model.setInvalid(false);
        }
        String hql = " from GesShopGoodsItem item where 1=1";
        List<Object> params = new ArrayList<Object>();
        if (null != model.getInvalid()) {
            hql = hql + " and item.invalid=?";
            params.add(model.getInvalid());
        }
        if (null != model.getStatus()) {
            hql = hql + " and item.status=?";
            params.add(model.getStatus());
        }
        if (null != model.getShop() && null != model.getShop().getId()) {
            hql = hql + " and item.shop.id=?";
            params.add(model.getShop().getId());
            if (null != model.getShop().getOperator() && null != model.getShop().getOperator().getId()) {
                hql = hql + " and item.shop.operator.id=?";
                params.add(model.getShop().getOperator().getId());
            }
        }
        if (null != model.getGoods() && null != model.getGoods().getId()) {
            hql = hql + " and item.goods.id=?";
            params.add(model.getGoods().getId());
        }
        hql = hql + " order by item.createdDatetime desc";
        List<GesShopGoodsItem> list = (List<GesShopGoodsItem>) super.findByPageCallBack(hql, "", params, model, null);
        if (null != list && list.size() > 0) {
            return list.get(0);
        }
        return null;
    }

    @Override
    public List<GesShop> listShopByGoods(Goods goods) {

        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("select item.shop from GesShopGoodsItem item ");
        hql.append("where item.goods.id = ? ");
        ls.add(goods.getId());
        if (goods.getHouse() != null && goods.getHouse().getBuilding() != null) {
            if (goods.getHouse().getBuilding().getCity() != null
                    && goods.getHouse().getBuilding().getCity().getId() != null) {
                hql.append("  and item.shop.city.id=?");
                ls.add(goods.getHouse().getBuilding().getCity().getId());
            }
            if (goods.getHouse().getBuilding().getCounty() != null
                    && goods.getHouse().getBuilding().getCounty().getId() != null) {
                hql.append("  and item.shop.county.id=?");
                ls.add(goods.getHouse().getBuilding().getCounty().getId());
            }
        }
        hql.append(" and item.invalid = false and item.status = ? ");
        ls.add(GoodsDiyConstant.SHOP_GOODS_STATUS_ENABLE);

        Query query = session.createQuery(hql.toString());
        for (int i = 0; i < ls.size(); i++) {
            query.setParameter(i, ls.get(i));
        }
        return query.list();
    }

    // ***********************************虚拟现实----开始****************************************
    @Override
    public List<Goods> getPageGoodsList(GoodsVO vo) {
        // 0已上架1已下架2已删除
        // hql.append(" from GesShopGoodsItem where invalid=0 and status=0 and goods.status=0 and goods.effectPath !='' ");
        Map<String, Object> map = this.getMap(vo);
        String hql = map.get("hql").toString();
        hql += "order by item.goods.id desc";

        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery("select  distinct item.goods  " + hql.toString());
        List<Object> ls = (List<Object>) map.get("list");
        for (int i = 0; i < ls.size(); i++) {
            query.setParameter(i, ls.get(i));
        }
        query.setFirstResult(vo.getStart());
        query.setMaxResults(vo.getPageSize());
        return query.list();
        // return null;
        // return (List<GesShopGoodsItem>) super.findByPageCallBack(hql, "",
        // (List<Object>) map.get("list"), vo, null);
    }

    @Override
    public long getPageGoodsListCount(GoodsVO vo) {
        Map<String, Object> map = this.getMap(vo);
        String hql = map.get("hql").toString();
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createQuery("select count(distinct item.goods) " + hql.toString());
        List<Object> ls = (List<Object>) map.get("list");
        for (int i = 0; i < ls.size(); i++) {
            query.setParameter(i, ls.get(i));
        }
        return (long) query.uniqueResult();

        // return super.findByPageCallBackCount(map.get("hql").toString(),
        // (List<Object>) map.get("list"));
    }

    private Map<String, Object> getMap(GoodsVO vo) {
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        // 0已上架1已下架2已删除
        hql.append("  from GesShopGoodsItem as   item  where item.invalid=0 and item.status=0 and item.goods.status=2  ");
        if (vo.getShopId() != null) {
            hql.append(" and item.shop.id=? ");
            list.add(vo.getShopId());
        }
        if (vo.getHouse() != null && vo.getHouse().getBuilding() != null) {
            if (vo.getHouse().getBuilding().getId() != null) {
                hql.append(" and item.goods.house.buiding.id=? ");
                list.add(vo.getHouse().getBuilding().getId());
            }
            if (vo.getHouse().getBuilding().getProvince() != null
                    && vo.getHouse().getBuilding().getProvince().getId() != null) {
                hql.append(" and item.goods.house.buiding.province.id=? ");
                list.add(vo.getHouse().getBuilding().getProvince().getId());
            }
            if (vo.getHouse().getBuilding().getCounty() != null
                    && vo.getHouse().getBuilding().getCounty().getId() != null) {
                hql.append(" and item.goods.house.buiding.county.id=? ");
                list.add(vo.getHouse().getBuilding().getCounty().getId());
            }

            // if
            // (gesShopGoodsItem.getGoods().getHouse().getBuilding().getCity()
            // != null
            // &&
            // gesShopGoodsItem.getGoods().getHouse().getBuilding().getCity().getId()
            // != null) {
            // hql.append(" and goods.house.buiding.city.id=? ");
            // list.add(gesShopGoodsItem.getGoods().getHouse().getBuilding().getCity().getId());
            // }

        }
        if (vo.getType() != null && vo.getHouse() != null && vo.getHouse().getBuilding() != null) {
            if (vo.getType().equals("0")) {
                hql.append(" and item.goods.house.buiding.city.id=? ");
                list.add(vo.getHouse().getBuilding().getCity().getId());
            }
            if (vo.getType().equals("1")) {
                hql.append(" and item.goods.house.buiding.county.id=? ");
                list.add(vo.getHouse().getBuilding().getCounty().getId());
            }
        }

        if (vo.getStyleId() != null) {
            hql.append(" and item.goods.style.id=?");
            list.add(vo.getStyleId());
        }
        if (vo.getIsPromotion() != null) {
            hql.append(" and item.goods.isPromotion=?");
            list.add(vo.getIsPromotion());
        }
        if (vo.getDiyType() != null && vo.getDiyType().getId() != null) {
            hql.append(" and item.goods.diyType.id=?");
            list.add(vo.getDiyType().getId());
        }

        if (vo.getHouseTypeId() != null) {
            hql.append(" and item.goods.houseType.id=?");
            list.add(vo.getHouseTypeId());
        }
        if (vo.getMaxPrice() != null) {
            hql.append(" and item.goods.discountPrice<=?");
            list.add(vo.getMaxPrice());
        }
        if (vo.getMinPrice() != null) {
            hql.append(" and item.goods.discountPrice>=?");
            list.add(vo.getMinPrice());
        }
        if (vo.getGoodsType() != null && vo.getGoodsType().getId() != null) {
            hql.append(" and item.goods.goodsType.id=?");
            list.add(vo.getGoodsType().getId());
        }
        if (vo.getEffectPath() != null) {
            hql.append(" and item.goods.effectPath !='' ");
        }
        if (vo.getIsRecommend() != null) {
            hql.append(" and item.goods.isRecommend=?");
            list.add(vo.getIsRecommend());
        }
        if (vo.getMinArea() != null && vo.getMinArea() > 0) {
            hql.append(" and item.goods.house.floorArea>=?");
            list.add(vo.getMinArea());
        }
        if (vo.getMaxArea() != null && vo.getMaxArea() > 0) {
            hql.append(" and item.goods.house.floorArea=?");
            list.add(vo.getMaxArea());
        }
        if (StringUtil.notEmpty(vo.getQ())) {
            hql.append(" and ( item.goods.name like '%" + vo.getQ() + "%' or item.goods.houseType.text like '%"
                    + vo.getQ() + "%' or item.goods.style.text like '%" + vo.getQ()
                    + "%'  or item.goods.house.building.name like '%" + vo.getQ()
                    + "%' or item.goods.house.building.county.name like '%" + vo.getQ() + "%' )");
        }

        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }
    // ***********************************虚拟现实----结束****************************************
}
