package com.gjw.company.dao.impl.topic;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.topic.IWebTopicDAO;
import com.gjw.entity.topic.WebTopic;
import com.gjw.utils.StringUtil;

/**
 * dao的Hibernate实现
 */
@Component("webTopicDAOHibernateImpl")
public class WebTopicDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebTopicDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebTopic.class;
    }

    @Override
    public WebTopic getById(Long id) {
        // TODO Auto-generated method stub
        return (WebTopic) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebTopic> pageByNameAndInvalid(WebTopic topic) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if (topic.getInvalid()) {
            hql.append(" from WebTopic where invalid = 1");
        } else {
            hql.append(" from WebTopic where invalid = 0");
        }
        if (StringUtil.notEmpty(topic.getName())) {
            hql.append(" and name like ?");
            ls.add("%" + topic.getName() + "%");
        }
        hql.append("order by id desc");
        return (List<WebTopic>) super.findByPageCallBack(hql.toString(), "", ls, topic, null);
    }

    @Override
    public Long countByNameAndInvalid(WebTopic topic) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        if (topic.getInvalid()) {
            hql.append(" from WebTopic where invalid = 1");
        } else {
            hql.append(" from WebTopic where invalid = 0");
        }
        if (StringUtil.notEmpty(topic.getName())) {
            hql.append(" and name like ?");
            ls.add("%" + topic.getName() + "%");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updateTopic(WebTopic topic) {
        // TODO Auto-generated method stub
        WebTopic top = (WebTopic) super.get(topic.getId());
        StringUtil.copyProperties(topic, top);
        super.update(top);
        return true;
    }

}
