package com.gjw.company.dao.impl.cityoperator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.cityoperator.IGesGuideDAO;
import com.gjw.entity.cityoperator.GesGuide;
import com.gjw.utils.StringUtil;

@Component("gesGuideDAOHibernateImpl")
@SuppressWarnings("unchecked")
public class GesGuideDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesGuideDAO{
    
    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return GesGuide.class;
    }
    
    @Override
    public GesGuide listByID(Long id) {
        // TODO Auto-generated method stub
        return (GesGuide) super.get(id);
    }

    @Override
    public boolean updateGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        return super.update(model)==1;
    }

    @Override
    public boolean createGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        return super.saveResultBoolean(model);
    }

    @Override
    public long count(GesGuide model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        String hql=" from GesGuide item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getOperator() && StringUtil.notEmpty(model.getOperator().getContactName())){
            hql=hql+" and item.order.operator.contactName like ?";
            params.add(super.getFuzzyCondition(model.getOperator().getContactName()));
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return super.findByPageCallBackCount(hql, params);
    }

    @Override
    public List<GesGuide> listByGesGuide(GesGuide model) {
        // TODO Auto-generated method stub
        if(null==model.getInvalid()){
            model.setInvalid(false);
        }
        String hql=" from GesGuide item where 1=1";
        List<Object> params=new ArrayList<Object>();
        if(null!=model.getInvalid()){
            hql=hql+" and item.invalid=?";
            params.add(model.getInvalid());
        }
        if(null!=model.getStatus()){
            hql=hql+" and item.status=?";
            params.add(model.getStatus());
        }
        if(null!=model.getOperator() && StringUtil.notEmpty(model.getOperator().getContactName())){
            hql=hql+" and item.order.operator.contactName like ?";
            params.add(super.getFuzzyCondition(model.getOperator().getContactName()));
        }
        if(null!=model.getDictionary() && null!=model.getDictionary().getId()){
            hql=hql+" and item.dictionary.id=?";
            params.add(model.getDictionary().getId());
        }
        hql=hql+" order by item.createdDatetime desc";
        return (List<GesGuide>) super.findByPageCallBack(hql, "", params, model, null);
    }

}
