package com.gjw.company.dao.impl.order;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.order.IWebOrderLogDAO;
import com.gjw.entity.order.WebOrderLog;
import com.gjw.utils.StringUtil;
import com.gjw.vo.WebOrderLogVO;

/**
 * 
 * @Description: 日志实现类
 * @author zhaoyonglian
 * @date 2015年12月19日 上午10:41:15
 * 
 */
@Component("webOrderLogDAOHibernateImpl")
public class WebOrderLogDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebOrderLogDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return WebOrderLog.class;
    }

    @Override
    public WebOrderLog getById(Long id) {
        // TODO Auto-generated method stub
        return (WebOrderLog) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebOrderLog> pageByContent(WebOrderLogVO log) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLog as log where log.invalid = 0");
        if (null != log.getOrderId() && 0l != log.getOrderId()) {
            hql.append(" and log.gesOrder.id = ?");
            ls.add(log.getOrderId());
        }
        if (StringUtil.notEmpty(log.getContent())) {
            hql.append(" and log.content like ?");
            ls.add("%" + log.getContent() + "%");
        }
        if (null != log.getLabelId()) {
            hql.append(" and log.label.parent.id=?");
            ls.add(log.getLabelId());
        }
        hql.append(" order by id desc");
        return (List<WebOrderLog>) super.findByPageCallBack(hql.toString(), "", ls, log, null);
    }

    @Override
    public Long countByContent(WebOrderLogVO log) {
        // TODO Auto-generated method stub
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLog as log where log.invalid = 0");
        if (null != log.getOrderId() && 0l != log.getOrderId()) {
            hql.append(" and log.gesOrder.id = ?");
            ls.add(log.getOrderId());
        }
        if (StringUtil.notEmpty(log.getContent())) {
            hql.append(" and log.content like ?");
            ls.add("%" + log.getContent() + "%");
        }
        if (null != log.getLabel() && null != log.getLabel().getId()) {
            hql.append(" and log.label.id=?");
            ls.add(log.getLabel().getId());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public boolean updateLog(WebOrderLog log) {
        // TODO Auto-generated method stub
        WebOrderLog lo = (WebOrderLog) super.get(log.getId());
        StringUtil.copyProperties(log, lo);
        super.update(lo);
        return true;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<WebOrderLog> findOrderByLabel(Long labelId, WebOrderLog log) {
        // TODO Auto-generated method stub
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();
        // hql.append("select a.orderId from (");
        hql.append(" from WebOrderLog where invalid = 0");
        if (StringUtil.notEmpty(labelId) && 0 != labelId) {
            hql.append(" and label.id = ?");
            ls.add(labelId);
        }
        hql.append(" group by gesOrder.id");
        hql.append(" order by max(createdDatetime) desc ");
        List<WebOrderLog> list = (List<WebOrderLog>) super.findByPageCallBack(hql.toString(), "", ls, log, null);
        return list;
    }

    @Override
    @SuppressWarnings("unchecked")
    public WebOrderLog findLastByOrder(Long orderId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLog where invalid = 0 and gesOrder.id =:orderId order by createdDatetime desc");
        Query query = session.createQuery(hql.toString());
        query.setLong("orderId", orderId);
        List<WebOrderLog> list = query.list();
        if (null != list && list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebOrderLog> findAllByOrder(Long orderId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLog where invalid=0 and gesOrder.id =:orderId order by label.parent.orderTag, label.orderTag, createdDatetime");
        Query query = session.createQuery(hql.toString());
        query.setLong("orderId", orderId);
        return query.list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebOrderLog> findLogByLabelAndOrder(Long labelId, Long orderId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" from WebOrderLog where gesOrder.id =:orderId and label.id =:labelId order by label.orderTag");
        Query query = session.createQuery(hql.toString());
        query.setLong("orderId", orderId);
        query.setLong("labelId", labelId);
        return query.list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> getAllOrder() {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append("select DISTINCT gesOrder.id from WebOrderLog order by id desc");
        Query query = session.createQuery(hql.toString());
        return query.list();
    }
}
