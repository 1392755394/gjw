package com.gjw.company.dao.impl.erp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesPaymentOrderDAO;
import com.gjw.entity.erp.GesPaymentOrder;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesPaymentOrderVO;

/**
 * 付款单dao实现
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月31日 
 *
 */
@Component("gesPaymentOrderDAOHibernateImpl")
public class GesPaymentOrderDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesPaymentOrderDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GesPaymentOrder.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GesPaymentOrder> pagePaymentOrder(GesPaymentOrderVO paymentOrder) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesPaymentOrder where invalid = false ");
        if (StringUtil.notEmpty(paymentOrder.getCode())) {
            hql.append("  and code = ?");
            ls.add(paymentOrder.getCode());
        }
        if (StringUtil.notEmpty(paymentOrder.getPayee())) {
            hql.append("  and payee like ?");
            ls.add(getFuzzyCondition(paymentOrder.getPayee()));
        }
        if (StringUtil.notEmpty(paymentOrder.getStatus())) {
            hql.append("  and status = ?");
            ls.add(paymentOrder.getStatus());
        }
        if (StringUtil.notEmpty(paymentOrder.getGmtVoucherFrom())) {
            hql.append("  and gmtVoucher >= ?");
            ls.add(paymentOrder.getGmtVoucherFrom());
        }
        if (StringUtil.notEmpty(paymentOrder.getGmtVoucherTo())) {
            hql.append("  and gmtVoucher <= ?");
            ls.add(paymentOrder.getGmtVoucherTo());
        }
        if (paymentOrder.getCityOperator() != null && paymentOrder.getCityOperator().getId() != null) {
            ls.add(paymentOrder.getCityOperator().getId());
            hql.append("  and cityOperator.id=?");
        } else {
            hql.append("  and cityOperator=null");
        }
        if (paymentOrder.getShop() != null && paymentOrder.getShop().getId() != null) {
            ls.add(paymentOrder.getShop().getId());
            hql.append("  and shop.id=?");
        } else {
            hql.append("  and shop=null");
        }
        return (List<GesPaymentOrder>) super.findByPageCallBack(hql.toString(), "", ls, paymentOrder, null);
    }

    @Override
    public Long countPaymentOrder(GesPaymentOrderVO paymentOrder) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from GesPaymentOrder where invalid = false ");
        if (StringUtil.notEmpty(paymentOrder.getCode())) {
            hql.append("  and code = ?");
            ls.add(paymentOrder.getCode());
        }
        if (StringUtil.notEmpty(paymentOrder.getPayee())) {
            hql.append("  and payee like ?");
            ls.add(getFuzzyCondition(paymentOrder.getPayee()));
        }
        if (StringUtil.notEmpty(paymentOrder.getStatus())) {
            hql.append("  and status = ?");
            ls.add(paymentOrder.getStatus());
        }
        if (StringUtil.notEmpty(paymentOrder.getGmtVoucherFrom())) {
            hql.append("  and gmtVoucher >= ?");
            ls.add(paymentOrder.getGmtVoucherFrom());
        }
        if (StringUtil.notEmpty(paymentOrder.getGmtVoucherTo())) {
            hql.append("  and gmtVoucher <= ?");
            ls.add(paymentOrder.getGmtVoucherTo());
        }
        if (paymentOrder.getCityOperator() != null && paymentOrder.getCityOperator().getId() != null) {
            ls.add(paymentOrder.getCityOperator().getId());
            hql.append("  and cityOperator.id=?");
        } else {
            hql.append("  and cityOperator=null");
        }
        if (paymentOrder.getShop() != null && paymentOrder.getShop().getId() != null) {
            ls.add(paymentOrder.getShop().getId());
            hql.append("  and shop.id=?");
        } else {
            hql.append("  and shop=null");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public GesPaymentOrder queryByID(Long id) {
        return (GesPaymentOrder) super.get(id);
    }

    @Override
    public long create(GesPaymentOrder paymentOrder) {
        if (paymentOrder.getCityOperator() != null && paymentOrder.getCityOperator().getId() == null) {
            paymentOrder.setCityOperator(null);
        }
        if (paymentOrder.getShop() != null && paymentOrder.getShop().getId() == null) {
            paymentOrder.setShop(null);
        }
        paymentOrder.setGmtBusiness(new Timestamp(System.currentTimeMillis()));
        super.add(paymentOrder);
        return paymentOrder.getId();
    }

    @Override
    public boolean update(GesPaymentOrder paymentOrder) {
        GesPaymentOrder old = (GesPaymentOrder) super.get(paymentOrder.getId());
        if (paymentOrder.getCityOperator() != null && paymentOrder.getCityOperator().getId() == null) {
            paymentOrder.setCityOperator(null);
        }
        if (paymentOrder.getShop() != null && paymentOrder.getShop().getId() == null) {
            paymentOrder.setShop(null);
        }
        paymentOrder.setGmtBusiness(new Timestamp(System.currentTimeMillis()));
        if (null != paymentOrder.getStatus()) {
            paymentOrder.setGmtAudit(new Timestamp(System.currentTimeMillis()));
        }
        StringUtil.copyPropertiesAllowEmpty(paymentOrder, old);
        return super.update(old) == 1;
    }

}
