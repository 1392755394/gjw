package com.gjw.company.dao.matter;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.matter.MatterSpec;

/**
 * 物料规格dao接口
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
public interface IMatterSpecDAO extends IDAO {

    /**
     * 查询物料规格列表
     * 
     * @Description
     * @param matterSpecCriteria
     *            查询条件
     * @return 物料规格列表
     * @author guojianbin
     * @date 2015年12月21日
     */
    public List<MatterSpec> pageMatterSpec(MatterSpec matterSpecCriteria);

    /**
     * 查询物料规格总数
     * 
     * @Description
     * @param matterSpecCriteria 
     *            查询条件
     * @return 物料规格总数
     * @author guojianbin
     * @date 2015年12月21日
     */
    public Long countMatterSpec(MatterSpec matterSpecCriteria);
    
    /**
     * 新增物料规格
     * @Description  
     * @param matterSpec 物料规格
     * @return 物料规格ID
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public long create(MatterSpec matterSpec);
    
    /**
     * 修改物料规格
     * @Description  
     * @param matterSpec 物料规格
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public boolean update(MatterSpec matterSpec);
    
    /**
     * 删除物料规格
     * @Description  
     * @param id 物料规格ID
     * @return 成功与否
     * @author guojianbin   
     * @date 2015年12月21日
     */
    public boolean deletedByID(long id);
}
