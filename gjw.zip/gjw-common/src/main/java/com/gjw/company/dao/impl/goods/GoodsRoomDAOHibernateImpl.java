package com.gjw.company.dao.impl.goods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.goods.IGoodsRoomDAO;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GoodsVO;

/**
 * 产品包房间dao实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月21日
 * 
 */
@Component("goodsRoomDAOHibernateImpl")
public class GoodsRoomDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGoodsRoomDAO {

    @Override
    protected Class<?> getEntityClass() {
        return GoodsRoom.class;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsRoom> listGoodsRoomByGoodsId(Long goodsId) {

        String hql = "from GoodsRoom gr where gr.invalid = false and gr.goods.id = ? order by gr.orderTag asc";

        return (List<GoodsRoom>) super.getHibernateTemplate().find(hql, goodsId);
    }

    @Override
    public GoodsRoom queryById(Long id) {
        return (GoodsRoom) super.get(id);
    }

    @Override
    public boolean delBatchByID(String ids) {

        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }

        return super.delBatchByID(idList) > 0;
    }

    @Override
    public boolean update(GoodsRoom goodsRoom) {
        GoodsRoom old = (GoodsRoom) super.get(goodsRoom.getId());
        if (goodsRoom.getEffectImage() != null && goodsRoom.getEffectImage().getId() == null) {
            goodsRoom.setEffectImage(null);
        }
        if (goodsRoom.getRoomAttribute() != null && goodsRoom.getRoomAttribute().getId() == null) {
            goodsRoom.setRoomAttribute(null);
        }
        if (goodsRoom.getPhotoApp() != null && goodsRoom.getPhotoApp().getId() == null) {
            goodsRoom.setPhotoApp(null);
        }
        StringUtil.copyPropertiesAllowEmpty(goodsRoom, old);
        return super.update(old) == 1;
    }

    @Override
    public long create(GoodsRoom goodsRoom) {
        if (goodsRoom.getEffectImage() != null && goodsRoom.getEffectImage().getId() == null) {
            goodsRoom.setEffectImage(null);
        }
        if (goodsRoom.getRoomAttribute() != null && goodsRoom.getRoomAttribute().getId() == null) {
            goodsRoom.setRoomAttribute(null);
        }
        if (goodsRoom.getPhotoApp() != null && goodsRoom.getPhotoApp().getId() == null) {
            goodsRoom.setPhotoApp(null);
        }
        super.add(goodsRoom);
        return goodsRoom.getId();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodsRoom> pageList(GoodsVO goodsVO) {
        Map<String, Object> map = getPageListMap(goodsVO);
        return (List<GoodsRoom>) super.findByPageCallBack(
                map.get("hql").toString() + " order by  createdDatetime desc", null, (List<Object>) map.get("list"),
                goodsVO, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public long pageListCount(GoodsVO goodsVO) {
        Map<String, Object> map = getPageListMap(goodsVO);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    /**
     * 效果图查询语句
     * 
     * @Description
     * @param goodsVO
     * @return
     * @author gwb
     * @date 2016年3月5日 上午9:42:36
     */
    private Map<String, Object> getPageListMap(GoodsVO goodsVO) {
        Map<String, Object> map = new HashMap<String, Object>();
        StringBuffer hql = new StringBuffer();
        List<Object> list = new ArrayList<Object>();
        hql.append(" from GoodsRoom where invalid=0 and length(photo2D.path)>15 and goods.status=2 and id!=0 ");
        if (goodsVO.getStyleId() != null) {
            hql.append(" and goods.style.id=?");
            list.add(goodsVO.getStyleId());
        }
        if (goodsVO.getHouseTypeId() != null) {
            hql.append(" and goods.houseType.id=?");
            list.add(goodsVO.getHouseTypeId());
        }
        if (goodsVO.getMinArea() != null && goodsVO.getMinArea() > 0) {
            hql.append(" and goods.house.floorArea>=?");
            list.add(goodsVO.getMinArea());
        }
        if (goodsVO.getMaxArea() != null && goodsVO.getMaxArea() > 0) {
            hql.append(" and goods.house.floorArea<=?");
            list.add(goodsVO.getMaxArea());
        }
        if (goodsVO.getRoomId() != null && goodsVO.getRoomId() > 0) {
            hql.append(" and roomAttribute.id=?");
            list.add(goodsVO.getRoomId());
        }
        if (StringUtil.notEmpty(goodsVO.getQ())) {
            hql.append(" and ( goods.name like '%" + goodsVO.getQ() + "%' or goods.housType.text like '%"
                    + goodsVO.getQ() + "%' or goods.style.text like '%" + goodsVO.getQ() + "%' or name like '%"
                    + goodsVO.getQ() + "%' or summary like '%" + goodsVO.getQ() + "%') ");

        }
        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Long> getAllId() {
        StringBuffer hql = new StringBuffer();
        // List<Object> list = new ArrayList<Object>();
        hql.append("select gr.id from p_goods_room gr ,p_goods  pg where gr.invalid=0 and pg.status=2 and gr.goods_id=pg.id");
        // super.findByListCallBack(hql.toString(), null, list, null);
        // return (List<Long>) super.findByListCallBack(hql.toString(), null,
        // list, null);
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        Query query = session.createSQLQuery(hql.toString());
        return query.list();
    }
}
