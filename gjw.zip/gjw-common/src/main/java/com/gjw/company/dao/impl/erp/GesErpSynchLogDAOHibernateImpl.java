package com.gjw.company.dao.impl.erp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesErpSynchLogDAO;
import com.gjw.entity.erp.GesErpSynchLog;
import com.gjw.utils.StringUtil;

/**
 * 基础数据同步日志
 * 
 * @Description:
 * @author gwb
 * @date 2016年1月7日 上午10:14:49
 * 
 */
@Component("gesErpSynchLogDAOHibernateImpl")
public class GesErpSynchLogDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesErpSynchLogDAO {

    @SuppressWarnings("unchecked")
    @Override
    public List<GesErpSynchLog> pageByGesErpSynchLog(GesErpSynchLog gesErpSynchLog) {
        Map<String, Object> map = this.getHql(gesErpSynchLog);
        return (List<GesErpSynchLog>) super.findByPageCallBack(map.get("hql").toString(), null,
                (List<Object>) map.get("list"), gesErpSynchLog, null);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long count(GesErpSynchLog gesErpSynchLog) {
        Map<String, Object> map = this.getHql(gesErpSynchLog);
        return super.findByPageCallBackCount(map.get("hql").toString(), (List<Object>) map.get("list"));
    }

    @Override
    public Boolean addGesErpSynchLog(GesErpSynchLog gesErpSynchLog) {

        return super.saveResultBoolean(gesErpSynchLog);
    }

    @Override
    protected Class<GesErpSynchLog> getEntityClass() {
        return GesErpSynchLog.class;
    }

    private Map<String, Object> getHql(GesErpSynchLog gesErpSynchLog) {
        StringBuffer hql = new StringBuffer();
        Map<String, Object> map = new HashMap<String, Object>();
        List<Object> list = new ArrayList<Object>();
        hql.append("  from GesErpSynchLog where invalid=0 ");
        if (StringUtil.notEmpty(gesErpSynchLog.getModuleCode())) {
            hql.append(" and moduleCode=? ");
            list.add(gesErpSynchLog.getModuleCode());
        }
        if (StringUtil.notEmpty(gesErpSynchLog.getProjectCode())) {
            hql.append(" and projectCode=? ");
            list.add(gesErpSynchLog.getProjectCode());
        }
        if (StringUtil.notEmpty(gesErpSynchLog.getSynchType())) {
            hql.append(" and synchType=? ");
            list.add(gesErpSynchLog.getSynchType());
        }
        if (StringUtil.notEmpty(gesErpSynchLog.getCreateTime())) {
            hql.append("  and DATE_FORMAT(createdDatetime,'%Y-%m-%d')>=?");
            list.add(gesErpSynchLog.getCreateTime());
        }
        if (StringUtil.notEmpty(gesErpSynchLog.getOperaterName())) {
            hql.append(" and operaterName=? ");
            list.add(gesErpSynchLog.getOperaterName());
        }
        hql.append(" order by createdDatetime desc");
        map.put("hql", hql.toString());
        map.put("list", list);
        return map;
    }
}
