package com.gjw.company.service.impl.matter;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.company.service.matter.IMatterService;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Brand;
import com.gjw.entity.matter.MaterialsCategory;
import com.gjw.entity.matter.Matter;
import com.gjw.entity.matter.MatterSequence;
import com.gjw.entity.matter.MatterUnit;
import com.gjw.entity.store.GesStore;
import com.gjw.vo.GesSoMatterVO;
import com.gjw.vo.RdRecordsVO;

/**
 * 物料service实现
 * 
 * @Description:
 * @author guojianbin
 * @date 2015年12月16日
 * 
 */
@Component("matterServiceImpl")
public class MatterServiceImpl extends AbstractServiceImpl implements IMatterService {

    @Override
    @Transactional(readOnly = true)
    public List<Matter> pageMatter(Matter matterCriteria) {
        return super.getMatterDAO().pageMatter(matterCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countMatter(Matter matterCriteria) {
        return super.getMatterDAO().countMatter(matterCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Matter queryByIDWithBrandAndCategory(Long id) {
        return super.getMatterDAO().queryByIDWithBrandAndCategory(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Matter getIdByCode(String getcInvCode) {

        return super.getMatterDAO().getIdByCode(getcInvCode);
    }

    @Override
    @Transactional
    public long create(Matter matter) {

        // 设置物料编码
        matter.setCode(generateCode(matter));
        matter.setParent(null);
        // 设置软硬装区分
        setClassification(matter);
        // 设置位置分类
        setPosition(matter);
        return super.getMatterDAO().create(matter);
    }

    @Override
    @Transactional
    public boolean update(Matter matter) {
        return super.getMatterDAO().update(matter);
    }

    /**
     * 生成物料编码：根据四级类目的编码+品牌编码+"-"+随机数生成物料编码
     * 
     * @Description
     * @param matter
     *            物料
     * @return 物料编码
     * @author guojianbin
     * @date 2015年12月17日
     */
    private String generateCode(Matter matter) {

        // 物料库为W
        StringBuffer codeFirst = new StringBuffer("W");
        // 类型编码
        StringBuffer codeSecond = new StringBuffer();
        codeFirst.append(concatCode(codeSecond.toString(), matter.getCategory().getId()));
        codeFirst.append("-");
        // 根据品牌ID查询品牌的编码
        Brand brand = new Brand();
        brand = super.getBrandDAO().queryByID(matter.getBrand().getId());
        codeFirst.append(brand.getCode());
        codeFirst.append("-");
        // 根据品牌id查询该品牌下的序列号,如果序列存在，就加1
        MatterSequence sequence = super.getMatterSequenceDAO().queryByBrandID(matter.getBrand().getId());
        if (sequence != null && sequence.getSequence() > 0) {
            NumberFormat nf = new DecimalFormat("0000");
            codeFirst.append(nf.format(sequence.getSequence()));
            sequence.setSequence(sequence.getSequence() + 1);
            super.getMatterSequenceDAO().update(sequence);
        } else {
            MatterSequence ms = new MatterSequence();
            ms.setSequence(2);
            ms.setBrand(brand);
            super.getMatterSequenceDAO().create(ms);
            codeFirst.append("0001");
        }
        // codeFirst.append(RandomUtils.nextInt(8999)+1000);

        // 根据四级类目的编码+品牌编码+"-"+随机数生成物料编码
        return codeFirst.toString();
    }

    private String concatCode(String code, Long id) {

        MaterialsCategory materialsCategory = super.getMaterialsCategoryDAO().queryByID(id);
        if (materialsCategory == null) {
            return code;
        }
        code = materialsCategory.getCode() + code;
        if (materialsCategory.getParent().getId() != 1) {
            code = concatCode(code, materialsCategory.getParent().getId());
        }

        return code;
    }

    /**
     * 设置软硬装区分
     * 
     * @Description
     * @param matter
     *            物料
     * @author guojianbin
     * @date 2015年12月17日
     */
    private void setClassification(Matter matter) {

        long categoryFirstId = matter.getCategoryFirst().getId();
        long classificationId = GoodsDiyConstant.MATTER_CLASSIFICATION_OTHER;

        // 软装:移动家具系统F、艺术陈设系统A、电气设备安装系统G
        if (categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_YIDONGJIAJU
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_YISHUCHENSHE
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_DIANQISHEBEI) {
            classificationId = GoodsDiyConstant.MATTER_CLASSIFICATION_SOFT;
        }
        // 硬装:厨卫阳台系统K、柜体收纳系统T、三墙面造型系统M、灯光照明系统L、五金链接系统H
        if (categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_CHUWEIYANGTAI
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_GUITISHOUNA
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_SANQIANGMIAN
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_DENGGUANG
                || categoryFirstId == GoodsDiyConstant.CATEGORY_FIRST_WUJINLIANJIE) {
            classificationId = GoodsDiyConstant.MATTER_CLASSIFICATION_HARD;
        }

        Dictionary dictionary = new Dictionary();
        dictionary.setId(classificationId);
        matter.setClassification(dictionary);

    }

    /**
     * 设置位置分类
     * 
     * @Description
     * @param matter
     *            物料
     * @author guojianbin
     * @date 2015年12月17日
     */
    private void setPosition(Matter matter) {

        long categoryId = matter.getCategory().getId();
        long positionId = GoodsDiyConstant.MATTER_POSITION_OTHER;

        // 顶部:MZ16 集成吊顶 id：185
        if (categoryId == GoodsDiyConstant.CATEGORY_THIRD_JICHENGDIAODING) {
            positionId = GoodsDiyConstant.MATTER_POSITION_TOP;
        }
        // 底部:MZ02 瓷砖 id：171 MZ05 木地板 id：174
        if (categoryId == GoodsDiyConstant.CATEGORY_THIRD_CIZHUAN
                || categoryId == GoodsDiyConstant.CATEGORY_THIRD_MUDIBAN) {
            positionId = GoodsDiyConstant.MATTER_POSITION_BOTTOM;
        }
        // 左部:MZ15壁纸 id：184
        if (categoryId == GoodsDiyConstant.CATEGORY_THIRD_BIZHI) {
            positionId = GoodsDiyConstant.MATTER_POSITION_LEFT;
        }

        Dictionary dictionary = new Dictionary();
        dictionary.setId(positionId);
        matter.setPosition(dictionary);

    }

    @Override
    @Transactional
    public boolean delBatchByID(String ids) {
        return super.getMatterDAO().delBatchByID(ids);
    }

    /**
     * 物料同步列表查询
     */
    @Override
    @Transactional(readOnly = true)
    public List<Matter> listMatter(Matter mater) {
        List<Matter> list = super.getMatterDAO().listMatter(mater);
        List<MatterUnit> matterUnitList = super.getMatterUnitDAO().listAllValidMatter();
        Map<String, MatterUnit> matterUnitMap = new HashMap<String, MatterUnit>();
        for (MatterUnit matterUnit : matterUnitList) {
            matterUnitMap.put(matterUnit.getUnitName(), matterUnit);
        }
        for (Matter obj : list) {
            Hibernate.initialize(obj.getSynchType());
            if (matterUnitMap.containsKey(obj.getUnit())){
                obj.setMatterUnit(matterUnitMap.get(obj.getUnit()));
            }

        }
        return list;
    }

    @Override
    @Transactional
    public long createChildMatter(Matter matter) {

        StringBuffer code = new StringBuffer();
        Long parentId = matter.getParent().getId();

        Matter m = queryByIDWithBrandAndCategory(parentId);
        code.append(m.getCode() + "-");
        code.append(countChildWithDelete(parentId) + 1);

        // 根据四级类目的编码+品牌编码+"-"+随机数生成物料编码
        matter.setCode(code.toString());
        matter.setParent(m);
        // 设置软硬装区分
        setClassification(matter);
        // 设置位置分类
        setPosition(matter);
        return super.getMatterDAO().create(matter);
    }

    public Long countChildWithDelete(Long parentId) {

        return super.getMatterDAO().countChildWithDelete(parentId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Matter> pageForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria) {
        return super.getMatterDAO().pageForNoBelongGoods(matterCriteria, goodsRoomCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countForNoBelongGoods(Matter matterCriteria, GoodsRoom goodsRoomCriteria) {
        return super.getMatterDAO().countForNoBelongGoods(matterCriteria, goodsRoomCriteria);
    }

    @Override
    @Transactional(readOnly = true)
    public Matter queryByID(Long id) {
        Matter matter = super.getMatterDAO().queryByIDWithBrandAndCategory(id);
        Hibernate.initialize(matter.getCategorySecond());
        Hibernate.initialize(matter.getCategoryFirst());
        Hibernate.initialize(matter.getUseNature());
        Hibernate.initialize(matter.getProcessProp());
        Hibernate.initialize(matter.getDistributionPhase());
        Hibernate.initialize(matter.getShippingMethods());
        Hibernate.initialize(matter.getProcessingMethods());
        Hibernate.initialize(matter.getTakeAddressType());
        Hibernate.initialize(matter.getInstaller());
        return matter;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countNotInPoDetail(GesSoMatterVO soMatter) {
        return super.getMatterDAO().countNotInPoDetail(soMatter);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Matter> pageNotInPoDetail(GesSoMatterVO soMatter) {
        List<Matter> list = super.getMatterDAO().pageNotInPoDetail(soMatter);
        List<GesStore> listStore = new ArrayList<GesStore>();
        for (Matter matter : list) {
            RdRecordsVO rdRecords = new RdRecordsVO();
            rdRecords.setMatterId(matter.getId());
            matter.getBrand().getName();
            Long inventory = super.getGesStoreInventoryDAO().sumInventory(rdRecords, listStore);
            matter.setStockNum(inventory);
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(Matter mater) {
        return super.getMatterDAO().count(mater);
    }
}