package com.gjw.company.service.impl.topic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.company.dao.topic.IWebTopicDAO;
import com.gjw.company.service.topic.IWebTopicService;
import com.gjw.entity.topic.WebTopic;

@Component("webTopicServiceImpl")
public class WebTopicServiceImpl implements IWebTopicService {

    @Autowired
    private IWebTopicDAO dao;

    @Override
    @Transactional(readOnly = true)
    public WebTopic getById(Long id) {
        // TODO Auto-generated method stub
        WebTopic topic = dao.getById(id);
        if(null != topic && null  != topic.getImage()){
            topic.getImage().getPath();
        }
        return dao.getById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WebTopic> pageByNameAndInvalid(WebTopic topic) {
        // TODO Auto-generated method stub
        List<WebTopic> list = dao.pageByNameAndInvalid(topic);
        if(null != list && list.size()>0){
            for (WebTopic webTopic : list) {
                webTopic.getImage().getPath();
            }
        }
        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Long countByNameAndInvalid(WebTopic topic) {
        // TODO Auto-generated method stub
        return dao.countByNameAndInvalid(topic);
    }

    @Override
    @Transactional
    public boolean insert(WebTopic entity) {
        // TODO Auto-generated method stub
        return dao.saveResultBoolean(entity);
    }

    @Override
    @Transactional
    public boolean update(WebTopic entity) {
        // TODO Auto-generated method stub
        return dao.updateTopic(entity);
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public String invalidByIds(String ids) {
        // TODO Auto-generated method stub
        int success = 0; // 成功条数
        int error = 0; // 失败条数
        int row = 0; // 操作结果
        if (ids != null && ids.length() > 0) {
            if (ids.contains(",")) {
                String[] str = ids.split(",");
                for (String id : str) {
                    row = this.invalid(Long.valueOf(id));
                    if (row > 0) {
                        ++success;
                    } else {
                        ++error;
                    }
                }
            } else {
                row = this.invalid(Long.valueOf(ids));
                if (row > 0) {
                    ++success;
                } else {
                    ++error;
                }
            }
        }
        if (0 == success && 0 != error) {
            return "失败废弃" + error + "条话题！";
        } else if (0 == error && 0 != success) {
            return "成功废弃" + success + "条话题！";
        } else if (0 == success && 0 == error) {
            return "请选择废弃的话题！";
        } else {
            return "成功废弃" + success + "条话题,失败废弃" + error + "条话题！";
        }

    }

}
