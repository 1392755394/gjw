package com.gjw.company.dao.impl.erp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.erp.IGesPoMainDAO;
import com.gjw.entity.erp.GesPoMain;
import com.gjw.utils.StringUtil;
import com.gjw.vo.GesPoMainVO;

/**
 * 销售----采购
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月10日 下午2:40:40
 * 
 */
@Component("gesPoMainDAOHibernateImpl")
public class GesPoMainDAOHibernateImpl extends AbstractDAOHibernateImpl implements IGesPoMainDAO {

    @Override
    protected Class getEntityClass() {
        return GesPoMain.class;
    }

    /**
     * 分页查询hql
     * 
     * @Description
     * @param model
     * @return
     * @author gwb
     * @date 2015年12月12日 下午4:01:30
     */
    public Map<String, Object> getHql(GesPoMainVO model) {
        Map<String, Object> map = new HashMap<String, Object>();
        StringBuffer hql = new StringBuffer();
        List<Object> ls = new ArrayList<Object>();

        hql.append("  from GesPoMain  pm  where invalid=0");
        // + "left join fetch  pm.location as location,GesOrder o "
        // +
        // ",GesShop shop, GesCityOperator operator ,User buyer ,UserInfo userInfo ,GesStore warehouse"
        // + " where pm.gesOrder.id=o.id  and pm.shop.id=shop.id "
        // + "and pm.cityOperator.id=operator.id "
        // +
        // " and o.buyer.id=buyer.id and buyer.id=userInfo.id  and pm.location.id=location.id and pm.warehouse.id=warehouse.id and pm.invalid=0");
        if (StringUtil.notEmpty(model.getShopName())) {
            hql.append("  and pm.shop.name=?");
            ls.add(model.getShopName());
        }
        if (model.getShop() != null && model.getShop().getId() != null) {
            hql.append("  and pm.shop.id=?");
            ls.add(model.getShop().getId());
        }

        if (StringUtil.notEmpty(model.getOperatorName())) {
            hql.append("  and pm.cityOperator.companyName=?");
            ls.add(model.getOperatorName());
        }
        if (model.getCityOperator() != null && model.getCityOperator().getId() != null) {
            hql.append("  and pm.cityOperator.id=?");
            ls.add(model.getCityOperator().getId());
        }
        // 4S店采购订单编号
        if (StringUtil.notEmpty(model.getPoCode())) {
            ls.add(model.getPoCode());
            hql.append("  and pm.poCode=?");
        }// 构家网销售订单
        if (StringUtil.notEmpty(model.getSoCode())) {
            ls.add(model.getSoCode());
            hql.append("  and pm.soCode=?");
        }// 购买者
        if (StringUtil.notEmpty(model.getBuyer())) {
            ls.add(model.getBuyer());
            hql.append("  and userInfo.realName=?");
        }
        if (StringUtil.notEmpty(model.getGmtCreateFrom())) {
            ls.add(model.getGmtCreateFrom().toString());
            hql.append("  and DATE_FORMAT(o.createdDatetime,'%Y-%m-%d')>=?");
        }
        if (StringUtil.notEmpty(model.getGmtCreateTo())) {
            ls.add(model.getGmtCreateTo());
            hql.append("  and DATE_FORMAT(o.createdDatetime,'%Y-%m-%d')<=?");
        }
        if (model.getStatus() != -1) {
            ls.add(model.getStatus());
            hql.append("  and pm.status=?");
        }

        if (model.getIsPush() != null) {
            if (model.getIsPush() == false) {
                ls.add(false);
                hql.append("  and pm.isPush=?");
            } else {
                ls.add(true);
                hql.append("  and (pm.isPush =? or pm.isPush is null))");
            }

        }

        hql.append(" order by pm.createdDatetime desc");
        map.put("hql", hql.toString());
        map.put("listParamater", ls);
        return map;
    }

    /**
     * 分页总数
     */
    @Override
    public Long count(GesPoMainVO model) {
        Map<String, Object> map = this.getHql(model);
        return super.countHql(map.get("hql").toString(), (List<Object>) map.get("listParamater"));
    }

    /**
     * 销售订单分页查询
     */
    @Override
    public List<?> pageByPoMain(GesPoMainVO model) {

        Map<String, Object> map = this.getHql(model);

        // String hqlResultParameter =
        // " select pm.id as id,pm.gesOrder.id as orderId, "
        // + "pm.soCode as soCode,pm.poCode as poCode,pm.issuer as issuer,"
        // +
        // "pm.receiver as receiver,pm.receiveAddress as receiveAddress,pm.status as status,pm.isPush as isPush,pm.remark as remark ,"
        // + "o.totalAmount as totalAmount,userInfo.realName as buyer,"
        // +
        // "pm.createdDatetime as gmtCreate,operator.companyName as  operatorName, "
        // +
        // "shop.name as shopName,location.name as locationName,warehouse.name as warehouseName ";
        return super
                .findByPageHql(map.get("hql").toString(), "", (List<Object>) map.get("listParamater"), model, false);

    }

    /**
     * 销售订单 确认订单状态
     */
    @Override
    public boolean updateByPoCode(GesPoMain poMain) {
        // Session session =
        // getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        hql.append(" update GesPoMain set status=? ,updatedDatetime=? ");
        List<Object> list = new ArrayList<Object>();
        list.add(poMain.getStatus());
        list.add(new Timestamp(System.currentTimeMillis()));
        if (poMain.getPushUser() != null && poMain.getPushUser().getId() != null) {
            hql.append(" ,pushUser.id=?");
            list.add(poMain.getPushUser().getId());
        }
        if (poMain.getIsPush() != null) {
            hql.append(" ,isPush=?");
            list.add(poMain.getIsPush());
        }
        hql.append(" where poCode=? ");
        list.add(poMain.getPoCode());
        return super.updateByParam(hql.toString(), list);

    }

    /**
     * 根据poCode查询 GesPoMain
     */
    @Override
    public GesPoMain getByGesPoMain(GesPoMain poMain) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesPoMain where invalid=0 ");
        List<Object> list = new ArrayList<Object>();
        if (StringUtil.notEmpty(poMain.getSoCode())) {
            hql.append(" and soCode=? ");
            list.add(poMain.getSoCode());
        }
        if (StringUtil.notEmpty(poMain.getPoCode())) {
            hql.append(" and poCode=? ");
            list.add(poMain.getPoCode());
        }
        return (GesPoMain) super.queryByParam(hql.toString(), list);

    }

    @Override
    public GesPoMain getByGesPoMainBySynch(GesPoMain po) {
        StringBuffer hql = new StringBuffer();
        hql.append(" from GesPoMain where invalid=0 ");
        List<Object> list = new ArrayList<Object>();
        hql.append(" and soCode=? ");
        list.add(po.getSoCode());
        return (GesPoMain) super.queryByParam(hql.toString(), list);
    }
}
