package com.gjw.company.service.impl.erp;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.service.impl.AbstractServiceImpl;
import com.gjw.company.service.erp.IGesPoDetailService;
import com.gjw.entity.erp.GesPoDetail;
import com.gjw.entity.erp.GesSoMatterItem;
import com.gjw.entity.goods.GoodsRoom;
import com.gjw.entity.matter.Matter;

/**
 * 采购管理
 * 
 * @Description:
 * @author gwb
 * @date 2015年12月17日 下午1:32:38
 * 
 */
@Service("gesPoDetailServiceImpl")
public class GesPoDetailServiceImpl extends AbstractServiceImpl implements IGesPoDetailService {

    @Override
    @Transactional(readOnly = true)
    public List<GesPoDetail> pagePoDetailByPoCode(GesPoDetail poCode) {
        List<GesPoDetail> detailList = super.getGesPoDetailDAO().pagePoDetailByPoCode(poCode);
        for (GesPoDetail detail : detailList) {
            detail.getMatter().getName();
            detail.getMatter().getBrand().getName();
            // detail.getSoMatter().getMarketPrice();
            if (detail.getRoom() != null) {
                detail.getRoom().getName();
            }
        }
        return detailList;
    }

    @Override
    @Transactional(readOnly = true)
    public GesPoDetail getRoomIdById(Long iorderseq) {
        GesPoDetail pDetail = super.getGesPoDetailDAO().getRoomIdById(iorderseq);
        if (pDetail != null && pDetail.getRoom() != null) {
            pDetail.getRoom().getName();
        }
        return pDetail;
    }

    @Override
    @Transactional(readOnly = true)
    public Long count(GesPoDetail poDetail) {
        return super.getGesPoDetailDAO().count(poDetail);
    }

    @Override
    @Transactional
    public boolean batchCreate(String matterCodes, String prices, String poCode, String smIds, Long goodsId,
            String roomIds, String amounts, String matterIds, String matterType) {
        String[] matterIdArray = matterIds.split(",");
        String[] amount = amounts.split(",");
        String[] smIdArray = smIds.split(",");
        String[] price = prices.split(",");
        // String[] matterCode = matterCodes.split(",");
        String[] roomIdArray = roomIds.split(",");
        int index = 0;
        for (String matterId : matterIdArray) {
            GesPoDetail poDetail = new GesPoDetail();
            poDetail.setPoCode(poCode);
            GesSoMatterItem soMatterItem = new GesSoMatterItem();
            soMatterItem.setId(Long.valueOf(smIdArray[index]));
            poDetail.setSoMatter(soMatterItem);
            Matter matter = new Matter();
            matter.setId(Long.valueOf(matterId));
            poDetail.setMatter(matter);
            if (roomIds.length() > 0) {
                GoodsRoom room = new GoodsRoom();
                room.setId(Long.valueOf(roomIdArray[index]));
                poDetail.setRoom(room);
            }
            // 金额
            Double am = Double.valueOf(amount[index]) * Double.valueOf(price[index]);
            poDetail.setAmount(am);
            poDetail.setQuantity(Double.valueOf(amount[index]));
            poDetail.setPurPrice(Long.valueOf(price[index]));
            poDetail.setdPreDate(new Timestamp(System.currentTimeMillis()));
            super.getGesPoDetailDAO().create(poDetail);
            index++;
        }
        return true;
    }

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 批量删除
     */
    @Override
    @Transactional
    public boolean batchDel(String ids) {
        return super.getGesPoDetailDAO().batchDel(ids);
    }

    /**
     * <p>
     * 发起采购关联产品
     * <p>
     * 修改采购数量
     */
    @Override
    @Transactional
    public boolean updateAmount(Long id, Double amount) {
        return super.getGesPoDetailDAO().updateAmount(id, amount);
    }

}
