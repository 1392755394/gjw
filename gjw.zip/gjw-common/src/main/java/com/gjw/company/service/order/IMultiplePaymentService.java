package com.gjw.company.service.order;

import java.math.BigDecimal;
import java.util.Map;

import com.gjw.common.web.JsonResult;
import com.gjw.entity.order.GesOrder;
import com.gjw.entity.order.GesPaymentRecord;
import com.gjw.vo.order.GesOrderVO;
import com.gjw.vo.order.MultiplePaymentVO;

public interface IMultiplePaymentService {
	
	public Map<String, Object> queryMultiplePaymentRecord(Long orderId);
	
	public JsonResult<Boolean> addMultiplePayment(MultiplePaymentVO multiplePayment,int type);
	
	/**
	 * 订单支付记录查询及余额查询
	 * @param orderId
	 * @param userId
	 * @return
	 */
	public Map<String, Object> queryOrderPaymentRecord(Long orderId,Long userId);
	
	/**
     * 查询需要确认支付的金额，仅限30%确认支付调用，后期和10%、90%支付合并到一个方法中
     * @param order
     */
	public Long queryConfirmPayMoneyForThirty(GesOrderVO order);
	
	/**
	 * 查询需要支付的金额 web 可以和ges的合并
	 */
	public Long queryNeedPayMoney(GesOrderVO order,Long userId);
	
	/**
	 * 更新多次支付记录的支付状态和支付方式以及支付的金额字段
	 * @param order
	 * @param paymentRecord
	 */
	public void updateMultiplePaymentStatus(GesOrderVO order,GesPaymentRecord paymentRecord);
	
	/**
	 * 判断已支付的金额是否等于需要支付的金额，如果是，则更新订单的状态和支付记录状态 否则只更新支付记录为已收到银行反馈信息
	 * @param order
	 * @param paymentRecord
	 * @param status
	 */
	public boolean updateOrderStatusWeb(GesOrderVO order,GesPaymentRecord paymentRecord,String status);
	
	/**
     * 更新多次支付记录表中的状态，以后和updateMultiplePaymentStatus合并
     * @return
     */
	public int updateRecordStatusAndOrderStatus(GesOrderVO order,GesPaymentRecord paymentRecord);
	
	/**
	 * ges中获取需要支付的金额，可以和官网的合并，统一返回值，本次只是copy
	 * @param orderId
	 * @return
	 */
	public JsonResult<BigDecimal> queryNeedPayMoneyForGes(Long orderId,Long userId);
	
	/**
     * 编辑记录 id/orderId/payMoney需要传
     */
    public JsonResult<Boolean> updateMultiplePaymentRecord(MultiplePaymentVO multiplePayment);
    
    /**
     * 核对合同时，根据订单支付的金额，修改订单状态(后期和线下支付的判断合并)
     * @param orderId
     */
    public void checkContractUpdateStatus(Long userId,Long orderId,String phone);
	
}
