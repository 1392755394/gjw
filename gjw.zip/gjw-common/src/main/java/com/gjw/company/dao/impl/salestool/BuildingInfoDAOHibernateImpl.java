package com.gjw.company.dao.impl.salestool;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.salestool.IBuildingInfoDAO;
import com.gjw.entity.goods.Goods;
import com.gjw.entity.salestool.BuildingInfo;
import com.gjw.utils.StringUtil;
/**
 * @author dabai email:qp(a)goujiawang.com
 */

@Component("buildingInfoDAOHibernateImpl")
public class BuildingInfoDAOHibernateImpl extends AbstractDAOHibernateImpl implements IBuildingInfoDAO {

    @Override
    protected Class<?> getEntityClass() {
        return BuildingInfo.class;
    }
	
	@SuppressWarnings("unchecked")
    @Override
    public List<BuildingInfo> pageBuildingInfo(BuildingInfo buildingInfo) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingInfo m ");     
        hql.append("where m.invalid = false ");
        if (buildingInfo.getStatus() != null){
            ls.add(buildingInfo.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingInfo.getBuildingSaleConfig() != null && buildingInfo.getBuildingSaleConfig().getId() != null){
            ls.add(buildingInfo.getBuildingSaleConfig().getId());
            hql.append("  and m.buildingSaleConfig.id = ?");
        }
        if (StringUtil.notEmpty(buildingInfo.getSortField())) {
            hql.append("  order by m.").append(buildingInfo.getSortField()).append(" ");
            hql.append(buildingInfo.getSortOrder()).append(" ,m.updatedDatetime desc");
        } else {
            hql.append("  order by m.updatedDatetime desc");
        }
        return (List<BuildingInfo>) super.findByPageCallBack(hql.toString(), "", ls, buildingInfo, null);
    }
	
	 @Override
    public Long count(BuildingInfo buildingInfo) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from BuildingInfo m ");
        hql.append("where m.invalid = false ");
        if (buildingInfo.getStatus() != null){
            ls.add(buildingInfo.getStatus());
            hql.append("  and m.status=?");
        }
        if (buildingInfo.getBuildingSaleConfig() != null && buildingInfo.getBuildingSaleConfig().getId() != null){
            ls.add(buildingInfo.getBuildingSaleConfig().getId());
            hql.append("  and m.buildingSaleConfig.id = ?");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
	
	 @Override
    public BuildingInfo queryByID(long id) {
       return (BuildingInfo)super.get(id);
    }

    @Override
    public long create(BuildingInfo buildingInfo) {
        buildingInfo.setContainsGoods(false);
        super.add(buildingInfo);
        return buildingInfo.getId();
    }
	
	   @Override
    public boolean update(BuildingInfo buildingInfo) {
        return super.update( buildingInfo) == 1;
    }
    
    @Override
    public boolean deletes(String ids) {
        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }

    @Override
    public List<Goods> pageGoods4BuildingInfo(BuildingInfo buildingInfo) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods m ");     
        hql.append("where m.invalid = false ");
        if (buildingInfo.getId() != null){
            ls.add(buildingInfo.getId());
            ls.add(buildingInfo.getId());
            hql.append(" and m.house.building.id = (select building.id from BuildingSaleConfig where id = (select buildingSaleConfig.id from BuildingInfo where id = ?) )");
            hql.append(" and m.id not in (select goods.id from BuildingInfoGoods where buildingInfo.id = ? and invalid=false)");
        }
        if (StringUtil.notEmpty(buildingInfo.getGoodsName())){
            ls.add(getFuzzyCondition(buildingInfo.getGoodsName()));
            hql.append(" and m.name like ? ");
        }
        if (StringUtil.notEmpty(buildingInfo.getSortField())) {
            hql.append("  order by m.").append(buildingInfo.getSortField()).append(" ");
            hql.append(buildingInfo.getSortOrder()).append(" ,m.updatedDatetime desc");
        } else {
            hql.append("  order by m.updatedDatetime desc");
        }
        return (List<Goods>) super.findByPageCallBack(hql.toString(), "", ls, buildingInfo, null);
    }

    @Override
    public Long countGoods4BuildingInfo(BuildingInfo buildingInfo) {
        List<Object> ls = new ArrayList<Object>();
        StringBuffer hql = new StringBuffer();
        hql.append("from Goods m ");     
        hql.append("where m.invalid = false ");
        if (buildingInfo.getId() != null){
            ls.add(buildingInfo.getId());
            ls.add(buildingInfo.getId());
            hql.append(" and m.house.building.id = (select building.id from BuildingSaleConfig where id = (select buildingSaleConfig.id from BuildingInfo where id = ?) )");
            hql.append(" and m.id not in (select goods.id from BuildingInfoGoods where buildingInfo.id = ? and invalid=false)");
        }
        if (StringUtil.notEmpty(buildingInfo.getGoodsName())){
            ls.add(getFuzzyCondition(buildingInfo.getGoodsName()));
            hql.append(" and m.name like ? ");
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }
 
    
}
