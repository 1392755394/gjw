package com.gjw.company.service.user;

import java.util.List;

import com.gjw.entity.user.DeptUser;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserInfo;
import com.gjw.entity.user.UserInfoGES;
import com.gjw.vo.user.UserVO;

public interface IUserInfoService {
    
    public void registerApp(UserInfo userInfo);
    
    public void register(UserInfo userInfo);

    public void registerWithRoldId(UserInfo userInfo, String roleId);

    public void update(UserInfo userInfo);

    public void add(UserInfo userInfo);

    public List<User> pageUserByOwnerForGes(UserInfo user);

    /**
     * @Description
     * @param owner
     * @return
     * @author qingye
     * @date Jan 7, 2016 10:00:07 AM
     */

    long countUserByOwnerForGes(UserInfo owner);

    public List<User> getByOrgIdAndTypeForGes(Long orgId, String orgType);

    /**
     * @Description
     * @param userInfo
     * @return
     * @author qingye
     * @date Jan 9, 2016 11:09:22 AM
     */

    public Long countForGes(UserInfoGES userInfo);

    public List<User> pageForGes(UserInfoGES userInfo);

    /**
     * @Description
     * @param id
     * @return
     * @author qingye
     * @date Jan 11, 2016 3:41:10 PM
     */

    public boolean remove(long id);

    /**
     * @Description
     * @param userinfo
     * @author qingye
     * @date Jan 11, 2016 4:35:41 PM
     */

    public void updateForGes(UserInfoGES userinfo);

    public void updateForGesWithRoleId(UserInfoGES userinfo, String roleId);

    /**
     * @Description
     * @param deptUser
     * @return
     * @author qingye
     * @date Jan 15, 2016 11:42:10 AM
     */

    public Long countByDept(DeptUser deptUser);

    /**
     * @Description
     * @param deptUser
     * @return
     * @author qingye
     * @date Jan 15, 2016 11:42:16 AM
     */

    public List<DeptUser> pageByDept(DeptUser deptUser);

    /**
     * @Description
     * @param deptUser
     * @return
     * @author qingye
     * @date Jan 15, 2016 2:44:27 PM
     */

    public Long countUncheckByDept(DeptUser deptUser);

    /**
     * @Description
     * @param deptUser
     * @return
     * @author qingye
     * @date Jan 15, 2016 2:44:32 PM
     */

    public List<User> pageUncheckByDept(DeptUser deptUser);

    public UserInfoGES userInfoForGes(UserInfoGES userInfo);

    public List<UserVO> pageForSalesTool(UserInfoGES userInfo);

    public void updateForSalesTool(UserVO user, UserInfoGES userinfo);

    public void registerForSalesTool(UserVO user, UserInfo userInfo);

    public UserInfo userInfo(Long id);

}
