package com.gjw.company.dao.impl.label;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.gjw.base.dao.impl.AbstractDAOHibernateImpl;
import com.gjw.company.dao.label.IWebLabelDAO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.entity.label.WebLabel;

@Component("webLabelDAOHibernateImpl")
public class WebLabelDAOHibernateImpl extends AbstractDAOHibernateImpl implements IWebLabelDAO {

    @Override
    protected Class<?> getEntityClass() {
        return WebLabel.class;
    }

    @Override
    public WebLabel get(Long id) {
        return (WebLabel) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebLabel> listParentByPeroperty(Dictionary peroperty) {
        return (List<WebLabel>) this.getHibernateTemplate().find(
                "from WebLabel where propertyType.id=? and invalid=0 and parent.id=0  order by orderTag",
                peroperty.getId());
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebLabel> listChildByParent(Long parentId) {
        if (parentId == 1050105) {
            return (List<WebLabel>) this.getHibernateTemplate().find(
                    "from WebLabel where parent.id=0 and propertyType.id =?  and invalid=0  order by orderTag",
                    parentId);
        } else {
            return (List<WebLabel>) this.getHibernateTemplate().find(
                    "from WebLabel where parent.id=? and  invalid=0  order by orderTag", parentId);
        }

    }

    @Override
    public void updatePeropertyByParent(Dictionary peroperty, Long parentId) {
        this.getHibernateTemplate().bulkUpdate("update WebLabel set propertyType.id=? where parent.id=?",
                peroperty.getId(), parentId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<WebLabel> page(WebLabel label) {
        StringBuffer hql = new StringBuffer(
                "from WebLabel label left join fetch label.propertyType where label.invalid=?");
        List<Object> ls = new ArrayList<Object>();
        ls.add(label.getInvalid() == null ? false : label.getInvalid());
        if (label.getName() != null && !label.getName().equals("")) {
            hql.append("and label.name like ?");
            ls.add("%" + label.getName() + "%");
        }
        if (label.getPropertyType() != null && label.getPropertyType().getId() != null
                && !label.getPropertyType().getId().equals(0)) {
            hql.append("and label.propertyType.id=?");
            ls.add(label.getPropertyType().getId());
        }
        return (List<WebLabel>) super.findByPageCallBack(hql.toString(), "", ls, label, null);

    }

    @Override
    public long count(WebLabel label) {
        StringBuffer hql = new StringBuffer("from WebLabel where invalid=?");
        List<Object> ls = new ArrayList<Object>();
        ls.add(label.getInvalid() == null ? false : label.getInvalid());
        if (label.getName() != null && !label.getName().equals("")) {
            hql.append("and name like ?");
            ls.add("%" + label.getName() + "%");
        }
        if (label.getPropertyType() != null && label.getPropertyType().getId() != null
                && !label.getPropertyType().getId().equals(0)) {
            hql.append("and propertyType.id=?");
            ls.add(label.getPropertyType().getId());
        }
        return super.findByPageCallBackCount(hql.toString(), ls);
    }

    @Override
    public void reuse(Long id) {
        String hql = "update WebLabel set invalid=0,updatedDatetime=now() where id=?";
        this.getHibernateTemplate().bulkUpdate(hql, id);
    }

}
