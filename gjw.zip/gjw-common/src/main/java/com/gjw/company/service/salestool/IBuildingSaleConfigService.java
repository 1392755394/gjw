package com.gjw.company.service.salestool;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.salestool.BuildingSaleConfig;

public interface IBuildingSaleConfigService extends IService{
	
	public List<BuildingSaleConfig> pageBuildingSaleConfig(BuildingSaleConfig buildingsaleconfig);
	
	public Long count(BuildingSaleConfig buildingsaleconfig);

	public long create(BuildingSaleConfig buildingsaleconfig);
	
	public boolean update(BuildingSaleConfig buildingsaleconfig);
			
	public BuildingSaleConfig queryByID(long id);
	
	public boolean deletes(String ids);
}
