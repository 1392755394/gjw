package com.gjw.company.dao.goods;

import java.util.List;

import com.gjw.base.dao.IDAO;
import com.gjw.entity.goods.GoodsDiyMatter;

/**
 * DIY清单dao接口
 * @Description: 
 * @author  guojianbin
 * @date 2015年12月28日 
 *
 */
public interface IGoodsDiyMatterDAO extends IDAO {

    /**
     * 查询单个空间的DIY清单的物料信息
     * @param id
     * @return
     */
    public List<GoodsDiyMatter> listRoomDiyMatter(Long roomId);
    
    /**
     * 批量新增DIY清单信息
     * @param matterList
     * @return
     */
    public Integer batchCreate(List<GoodsDiyMatter> matterList);

    /**
     * 查询DIY的DIY清单的物料信息
     * @param id
     * @return
     */
    public List<GoodsDiyMatter> listByGoodsId(Long goodsId);
    
    /**
     * 保存DIY清单
     * 
     * @Description
     * @param goodsDiyMatter
     *            DIY清单
     * @return 成功与否
     * @author guojianbin
     * @date 2016年1月13日
     */
    public boolean update(GoodsDiyMatter goodsDiyMatter);

    /**
     * 批量删除DIY清单信息
     * @param goodsId
     * @return
     */
    public boolean deleteByGoodsId(Long goodsId);
}
