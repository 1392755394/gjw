package com.gjw.company.service.cooperator;

import java.util.List;

import com.gjw.base.service.IService;
import com.gjw.entity.cooperator.WebCooperator;

/**
 * 
* @Description: 入驻service接口
* @author  zhaoyonglian
* @date 2015年12月16日 下午4:28:29
*
 */
public interface IWebCooperatorService extends IService {
    /**
     * 
    * @Description  分页查询
    * @param cooperator
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月16日 下午4:15:47
     */
    public List<WebCooperator> pageByCondition(WebCooperator cooperator);
    
    /**
     * 
    * @Description  总算
    * @param cooperator
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月16日 下午4:16:20
     */
    public Long countByCondition(WebCooperator cooperator);
    
    /**
     * 
    * @Description  保存
    * @param cooperator
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月29日 下午3:47:46
     */
    public boolean save(WebCooperator cooperator);

}
