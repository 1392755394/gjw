package com.gjw.base.service.impl;

import javax.annotation.Resource;

import com.gjw.base.dao.IDictionaryDAO;
import com.gjw.base.service.IService;
import com.gjw.company.dao.app.IWebAdviceDAO;
import com.gjw.company.dao.app.IWebContrastDAO;
import com.gjw.company.dao.app.IWebContrastDetailDAO;
import com.gjw.company.dao.app.IWebDesignerDAO;
import com.gjw.company.dao.area.IGesAreaDAO;
import com.gjw.company.dao.area.IGesCityDAO;
import com.gjw.company.dao.article.IWebArticleDAO;
import com.gjw.company.dao.article.IWebArticleGoodsDAO;
import com.gjw.company.dao.building.IGesBuildingCityOperatorItemDAO;
import com.gjw.company.dao.building.IGesBuildingColorConfigDAO;
import com.gjw.company.dao.building.IGesBuildingDAO;
import com.gjw.company.dao.building.IGesBuildingPhotoItemDAO;
import com.gjw.company.dao.building.IHouseDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorCompareConclusionDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorCompareDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorContractDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorPartnerDAO;
import com.gjw.company.dao.cityoperator.IGesCityOperatorTrackingDAO;
import com.gjw.company.dao.cityoperator.IGesGuideDAO;
import com.gjw.company.dao.collection.IWebCollectionItemDAO;
import com.gjw.company.dao.comment.IWebCommentItemDAO;
import com.gjw.company.dao.customer.IGesAppointmentDAO;
import com.gjw.company.dao.customer.IGesCustomerDAO;
import com.gjw.company.dao.customer.IGesCustomerMessageDAO;
import com.gjw.company.dao.customer.IGesCustomerMessageLogDAO;
import com.gjw.company.dao.erp.IGesErpCodeDAO;
import com.gjw.company.dao.erp.IGesErpSynchLogDAO;
import com.gjw.company.dao.erp.IGesPaymentOrderDAO;
import com.gjw.company.dao.erp.IGesPoDetailDAO;
import com.gjw.company.dao.erp.IGesPoMainDAO;
import com.gjw.company.dao.erp.IGesRdRecordDAO;
import com.gjw.company.dao.erp.IGesRdRecordsDAO;
import com.gjw.company.dao.erp.IGesReceiptOrderDAO;
import com.gjw.company.dao.erp.IGesSoMatterItemDAO;
import com.gjw.company.dao.erp.IGesStoreDAO;
import com.gjw.company.dao.erp.IGesStoreInventoryDAO;
import com.gjw.company.dao.erp.IGesStoreLocationDAO;
import com.gjw.company.dao.erp.IMatterUnitDAO;
import com.gjw.company.dao.goods.IGoodsAppMarkDAO;
import com.gjw.company.dao.goods.IGoodsDAO;
import com.gjw.company.dao.goods.IGoodsDiyItemDAO;
import com.gjw.company.dao.goods.IGoodsDiyMatterDAO;
import com.gjw.company.dao.goods.IGoodsMarkDAO;
import com.gjw.company.dao.goods.IGoodsMatterDAO;
import com.gjw.company.dao.goods.IGoodsPriceDetailDAO;
import com.gjw.company.dao.goods.IGoodsRoomDAO;
import com.gjw.company.dao.label.IWebLabelDAO;
import com.gjw.company.dao.matter.IBrandDAO;
import com.gjw.company.dao.matter.IMaterialsCategoryDAO;
import com.gjw.company.dao.matter.IMatterAlbumDAO;
import com.gjw.company.dao.matter.IMatterDAO;
import com.gjw.company.dao.matter.IMatterSequenceDAO;
import com.gjw.company.dao.matter.IMatterSpecDAO;
import com.gjw.company.dao.menu.IGesMenuDAO;
import com.gjw.company.dao.menu.IGesMenuPermissionItemDAO;
import com.gjw.company.dao.menu.IGesMenuRoleItemDAO;
import com.gjw.company.dao.modelling.IModellingDAO;
import com.gjw.company.dao.modelling.IModellingMatterItemDAO;
import com.gjw.company.dao.oa.IGesMessageDAO;
import com.gjw.company.dao.oa.IGesPmModelDAO;
import com.gjw.company.dao.oa.IGesProjectTaskDAO;
import com.gjw.company.dao.order.IGesOrderDAO;
import com.gjw.company.dao.order.IGesOrderPayMoneyDAO;
import com.gjw.company.dao.order.IGesPaymentRecordDAO;
import com.gjw.company.dao.order.IMultiplePaymentDAO;
import com.gjw.company.dao.order.IPaymentRecordResponseDAO;
import com.gjw.company.dao.picture.IPictureDAO;
import com.gjw.company.dao.salestool.IBuildingInfoDAO;
import com.gjw.company.dao.salestool.IBuildingInfoGoodsDAO;
import com.gjw.company.dao.salestool.IBuildingSaleConfigDAO;
import com.gjw.company.dao.salestool.ICaptchaDAO;
import com.gjw.company.dao.salestool.ICaptchaRecordDAO;
import com.gjw.company.dao.salestool.IFullViewDAO;
import com.gjw.company.dao.salestool.IIpadAdvertDAO;
import com.gjw.company.dao.shop.IGesShopDAO;
import com.gjw.company.dao.shop.IGesShopGoodsItemDAO;
import com.gjw.company.dao.shop.IGesShopOrderFeedbackDAO;
import com.gjw.company.dao.shop.IGesShopPhotoItemDAO;
import com.gjw.company.dao.shop.IGesShopWorkerDAO;
import com.gjw.company.dao.support.IWebSupportItemDAO;
import com.gjw.company.dao.user.IAuthenticationDAO;
import com.gjw.company.dao.user.IDeptDAO;
import com.gjw.company.dao.user.IDeptUserDAO;
import com.gjw.company.dao.user.IPermissionDAO;
import com.gjw.company.dao.user.IRoleDAO;
import com.gjw.company.dao.user.IUserBuildingItemDAO;
import com.gjw.company.dao.user.IUserDAO;
import com.gjw.company.dao.user.IUserInfoDAO;
import com.gjw.company.dao.user.IUserPlatformDAO;
import com.gjw.company.dao.user.IUserRoleDAO;
import com.gjw.company.dao.validation.IEmailValidationDAO;
import com.gjw.company.dao.validation.ISmsValidationDAO;
import com.gjw.company.dao.xggoujia.XgGoujiaDAO;

abstract public class AbstractServiceImpl implements IService {
    // 房产销售
    @Resource(name = "captchaDAOHibernateImpl")
    private ICaptchaDAO captchaDAOHibernateImpl;
    @Resource(name = "captchaRecordDAOHibernateImpl")
    private ICaptchaRecordDAO captchaRecordDAOHibernateImpl;
    @Resource(name = "fullViewDAOHibernateImpl")
    private IFullViewDAO fullViewDAOHibernateImpl;
    @Resource(name = "ipadAdvertDAOHibernateImpl")
    private IIpadAdvertDAO ipadAdvertDAOHibernateImpl;
    @Resource(name = "buildingSaleConfigDAOHibernateImpl")
    private IBuildingSaleConfigDAO buildingSaleConfigDAO;
    @Resource(name = "buildingInfoDAOHibernateImpl")
    private IBuildingInfoDAO buildingInfoDAO;
    @Resource(name = "buildingInfoGoodsDAOHibernateImpl")
    private IBuildingInfoGoodsDAO buildingInfoGoodsDAO;

    public ICaptchaDAO getCaptchaDAOHibernateImpl() {
        return captchaDAOHibernateImpl;
    }

    public IGoodsAppMarkDAO getGoodsAppMarkDao() {
        return goodsAppMarkDao;
    }

    public void setGoodsAppMarkDao(IGoodsAppMarkDAO goodsAppMarkDao) {
        this.goodsAppMarkDao = goodsAppMarkDao;
    }

    public void setCaptchaDAOHibernateImpl(ICaptchaDAO captchaDAOHibernateImpl) {
        this.captchaDAOHibernateImpl = captchaDAOHibernateImpl;
    }

    public ICaptchaRecordDAO getCaptchaRecordDAOHibernateImpl() {
        return captchaRecordDAOHibernateImpl;
    }

    public void setCaptchaRecordDAOHibernateImpl(ICaptchaRecordDAO captchaRecordDAOHibernateImpl) {
        this.captchaRecordDAOHibernateImpl = captchaRecordDAOHibernateImpl;
    }

    public IFullViewDAO getFullViewDAOHibernateImpl() {
        return fullViewDAOHibernateImpl;
    }

    public void setFullViewDAOHibernateImpl(IFullViewDAO fullViewDAOHibernateImpl) {
        this.fullViewDAOHibernateImpl = fullViewDAOHibernateImpl;
    }

    public IIpadAdvertDAO getIpadAdvertDAOHibernateImpl() {
        return ipadAdvertDAOHibernateImpl;
    }

    public void setIpadAdvertDAOHibernateImpl(IIpadAdvertDAO ipadAdvertDAOHibernateImpl) {
        this.ipadAdvertDAOHibernateImpl = ipadAdvertDAOHibernateImpl;
    }

    @Resource(name = "gesBuildingColorConfigDAOHibernateImpl")
    private IGesBuildingColorConfigDAO gesBuildingColorConfigDAOHibernateImpl;

    public IGesBuildingColorConfigDAO getGesBuildingColorConfigDAOHibernateImpl() {
        return gesBuildingColorConfigDAOHibernateImpl;
    }

    public void setGesBuildingColorConfigDAOHibernateImpl(
            IGesBuildingColorConfigDAO gesBuildingColorConfigDAOHibernateImpl) {
        this.gesBuildingColorConfigDAOHibernateImpl = gesBuildingColorConfigDAOHibernateImpl;
    }

    @Resource(name = "webContrastDetailHibernateImpl")
    private IWebContrastDetailDAO webContrastDetailDAO;
    @Resource(name = "webDesignerHibernateImpl")
    private IWebDesignerDAO webDesignerDAO;
    // 客户消息录入start
    @Resource(name = "gesCustomerMessagesDAOHibernateImpl")
    private IGesCustomerMessageDAO gesCustomerMessageDAO;
    @Resource(name = "gesCustomerMessageLogDAOHibernateImpl")
    private IGesCustomerMessageLogDAO gesCustomerMessageLogDAO;
    @Resource(name = "gesAppointmentDAOHibernateImpl")
    private IGesAppointmentDAO gesAppointmentDAO;
    // end
    @Resource(name = "webAdviceDAOHibernateImpl")
    private IWebAdviceDAO webAdviceDAO;
    @Resource(name = "gesAreaDAOHibernateImpl")
    private IGesAreaDAO gesAreaDAO;
    @Resource(name = "pictureDAOHibernateImpl")
    private IPictureDAO pictureDAO;
    // 仓库
    @Resource(name = "gesStoreDAOHibernateImpl")
    private IGesStoreDAO gesStoreDAO;
    // 库存
    @Resource(name = "gesStoreInventoryDAOHibernateImpl")
    private IGesStoreInventoryDAO gesStoreInventoryDAO;
    // 库位
    @Resource(name = "gesStoreLocationDAOHibernateImpl")
    private IGesStoreLocationDAO gesStoreLocationDAO;
    @Resource(name = "webContrastDAOHibernateImpl")
    private IWebContrastDAO webContrastDAO;
    // 采购订单
    @Resource(name = "gesPoMainDAOHibernateImpl")
    private IGesPoMainDAO gesPoMainDAO;
    // 楼盘
    @Resource(name = "gesBuildingCityOperatorItemDAOHibernateImpl")
    private IGesBuildingCityOperatorItemDAO gesBuildingCityOperatorItemDAO;
    @Resource(name = "gesBuildingDAOHibernateImpl")
    private IGesBuildingDAO gesBuildingDAO;
    @Resource(name = "gesBuildingPhotoItemDAOHibernateImpl")
    private IGesBuildingPhotoItemDAO gesBuildingPhotoItemDAO;
    @Resource(name = "houseDAOHibernateImpl")
    private IHouseDAO houseDAO;
    // 城运商
    @Resource(name = "gesCityOperatorCompareConclusionDAOHibernateImpl")
    private IGesCityOperatorCompareConclusionDAO gesCityOperatorCompareConclusionDAO;
    @Resource(name = "gesCityOperatorCompareDAOHibernateImpl")
    private IGesCityOperatorCompareDAO gesCityOperatorCompareDAO;
    @Resource(name = "gesCityOperatorContractDAOHibernateImpl")
    private IGesCityOperatorContractDAO gesCityOperatorContractDAO;
    @Resource(name = "gesCityOperatorDAOHibernateImpl")
    private IGesCityOperatorDAO gesCityOperatorDAO;
    @Resource(name = "gesCityOperatorPartnerDAOHibernateImpl")
    private IGesCityOperatorPartnerDAO gesCityOperatorPartnerDAO;
    @Resource(name = "gesCityOperatorTrackingDAOHibernateImpl")
    private IGesCityOperatorTrackingDAO gesCityOperatorTrackingDAO;
    @Resource(name = "gesGuideDAOHibernateImpl")
    private IGesGuideDAO gesGuideDAO;
    // 4S店
    @Resource(name = "gesShopDAOHibernateImpl")
    private IGesShopDAO gesShopDAO;
    @Resource(name = "gesShopGoodsItemDAOHibernateImpl")
    private IGesShopGoodsItemDAO gesShopGoodsItemDAO;
    @Resource(name = "gesShopOrderFeedbackDAOHibernateImpl")
    private IGesShopOrderFeedbackDAO gesShopOrderFeedbackDAO;
    @Resource(name = "gesShopPhotoItemDAOHibernateImpl")
    private IGesShopPhotoItemDAO gesShopPhotoItemDAO;
    @Resource(name = "gesShopWorkerDAOHibernateImpl")
    private IGesShopWorkerDAO gesShopWorkerDAO;
    // 菜单
    @Resource(name = "gesMenuDAOHibernateImpl")
    private IGesMenuDAO gesMenuDAO;
    // 菜单权限
    @Resource(name = "gesMenuPermissionItemDAOHiberateImpl")
    private IGesMenuPermissionItemDAO gesMenuPermissionItemDAO;

    @Resource(name = "gesMenuRoleItemDAOHiberateImpl")
    private IGesMenuRoleItemDAO gesMenuRoleItemDAO;

    // 部门
    @Resource(name = "deptDAOHibernateImpl")
    private IDeptDAO deptDAO;

    public IDeptDAO getDeptDAO() {
        return deptDAO;
    }

    public void setDeptDAO(IDeptDAO deptDAO) {
        this.deptDAO = deptDAO;
    }

    @Resource(name = "deptUserDAOHibernateImpl")
    private IDeptUserDAO deptUserDAO;

    // 物料
    @Resource(name = "materialsCategoryDAOHibernateImpl")
    private IMaterialsCategoryDAO materialsCategoryDAO;
    @Resource(name = "brandDAOHibernateImpl")
    private IBrandDAO brandDAO;
    @Resource(name = "matterDAOHibernateImpl")
    private IMatterDAO matterDAO;
    @Resource(name = "matterSequenceDAOHibernateImpl")
    private IMatterSequenceDAO matterSequenceDAO;
    @Resource(name = "matterSpecDAOHibernateImpl")
    private IMatterSpecDAO matterSpecDAO;
    @Resource(name = "matterAlbumDAOHibernateImpl")
    private IMatterAlbumDAO matterAlbumDAO;

    // 造型库
    @Resource(name = "modellingDAOHibernateImpl")
    private IModellingDAO modellingDao;
    @Resource(name = "modellingMatterItemDAOHibernateImpl")
    private IModellingMatterItemDAO modellingMatterItemDao;

    @Resource(name = "gesRdRecordDAOHibernateImpl")
    private IGesRdRecordDAO gesRdRecordDAO;

    @Resource(name = "gesErpCodeDAOHibernateImpl")
    private IGesErpCodeDAO gesErpCodeDAO;

    @Resource(name = "dictionaryDAOHibernateImpl")
    private IDictionaryDAO dictionaryDao;
    /**
     * 采购
     */
    @Resource(name = "gesPoDetailDAOHibernateImpl")
    private IGesPoDetailDAO gesPoDetailDAO;

    @Resource(name = "webLabelDAOHibernateImpl")
    private IWebLabelDAO webLabelDAO;

    /**
     * 出入库单明细实体
     */
    @Resource(name = "gesRdRecordsDAOHibernateImpl")
    private IGesRdRecordsDAO gesRdRecordsDAO;

    // 产品包
    @Resource(name = "goodsRoomDAOHibernateImpl")
    private IGoodsRoomDAO goodsRoomDAO;
    @Resource(name = "goodsDAOHibernateImpl")
    private IGoodsDAO goodsDAO;
    @Resource(name = "goodsDiyItemDAOHibernateImpl")
    private IGoodsDiyItemDAO goodsDiyItemDAO;
    @Resource(name = "goodsPriceDetailDAOHibernateImpl")
    private IGoodsPriceDetailDAO goodsPriceDetailDAO;
    @Resource(name = "goodsDiyMatterDAOHibernateImpl")
    private IGoodsDiyMatterDAO goodsDiyMatterDAO;
    @Resource(name = "goodsMatterDAOHibernateImpl")
    private IGoodsMatterDAO goodsMatterDao;
    @Resource(name = "goodsMarkDAOHibernateImpl")
    private IGoodsMarkDAO goodsMarkDao;
    @Resource(name = "goodsAppMarkDAOHibernateImpl")
    private IGoodsAppMarkDAO goodsAppMarkDao;
    // ERP财务管理
    @Resource(name = "gesReceiptOrderDAOHibernateImpl")
    private IGesReceiptOrderDAO gesReceiptOrderDAO;
    @Resource(name = "gesPaymentOrderDAOHibernateImpl")
    private IGesPaymentOrderDAO gesPaymentOrderDAO;
    @Resource(name = "gesPmModelDAOHibernateImpl")
    private IGesPmModelDAO gesPmModelDAO;
    // OA消息
    @Resource(name = "gesMessageDAOHibernateImpl")
    private IGesMessageDAO gesMessageDAO;

    @Resource(name = "smsValidationDAOHibernateImpl")
    private ISmsValidationDAO smsValidationDAO;
    @Resource(name = "emailValidationDAOHibernateImpl")
    private IEmailValidationDAO emailValidationDAO;

    // web 点赞
    @Resource(name = "webSupportItemDAOHibernateImpl")
    private IWebSupportItemDAO webSupportItemDAO;
    // 收藏
    @Resource(name = "webCollectionItemDAOHiberanteImpl")
    private IWebCollectionItemDAO webCollectionItemDAO;
    // 评论
    @Resource(name = "webCommentItemDAOHibernateImpl")
    private IWebCommentItemDAO webCommentItemDAO;

    // 任务与项目
    @Resource(name = "gesProjectTaskHibernateImpl")
    private IGesProjectTaskDAO gesProjectTaskDAO;

    public IGesMessageDAO getGesMessageDAO() {
        return gesMessageDAO;
    }

    public void setGesMessageDAO(IGesMessageDAO gesMessageDAO) {
        this.gesMessageDAO = gesMessageDAO;
    }

    /**
     * 物料单位
     */
    @Resource(name = "matterUnitDAOHibernater")
    private IMatterUnitDAO matterUnitDAO;

    @Resource(name = "com.gjw.company.dao.impl.user.PermissionDAOHibernateImpl")
    private IPermissionDAO permissionDAO;

    @Resource(name = "com.gjw.company.dao.impl.user.RoleDAOHibernateImpl")
    private IRoleDAO roleDAO;

    @Resource(name = "userRoleDAOHibernateImpl")
    private IUserRoleDAO userRoleDAO;

    public IGesAppointmentDAO getGesAppointmentDAO() {
        return gesAppointmentDAO;
    }

    public void setGesAppointmentDAO(IGesAppointmentDAO gesAppointmentDAO) {
        this.gesAppointmentDAO = gesAppointmentDAO;
    }

    public IGesPmModelDAO getGesPmModelDAO() {
        return gesPmModelDAO;
    }

    public void setGesPmModelDAO(IGesPmModelDAO gesPmModelDAO) {
        this.gesPmModelDAO = gesPmModelDAO;
    }

    public IWebContrastDetailDAO getWebContrastDetailDAO() {
        return webContrastDetailDAO;
    }

    public void setWebContrastDetailDAO(IWebContrastDetailDAO webContrastDetailDAO) {
        this.webContrastDetailDAO = webContrastDetailDAO;
    }

    public IWebDesignerDAO getWebDesignerDAO() {
        return webDesignerDAO;
    }

    public void setWebDesignerDAO(IWebDesignerDAO webDesignerDAO) {
        this.webDesignerDAO = webDesignerDAO;
    }

    // 订单支付
    @Resource(name = "gesOrderPayMoneyDAOHibernateImpl")
    private IGesOrderPayMoneyDAO gesOrderPayMoney;

    @Resource(name = "gesCustomerDAOHibernateImpl")
    private IGesCustomerDAO gesCustomerDAO;

    /**
     * 构家网---- 产品包销售订单关联的物料(采购清单)实体
     * <P>
     * 城运商，4s店发起采购
     */
    @Resource(name = "gesSoMatterItemDAOHibernateImpl")
    private IGesSoMatterItemDAO gesSoMatterItemDAO;

    /**
     * 基础数据同步日志
     */
    @Resource(name = "gesErpSynchLogDAOHibernateImpl")
    private IGesErpSynchLogDAO GesErpSynchLogDAO;

    public IMatterAlbumDAO getMatterAlbumDAO() {
        return matterAlbumDAO;
    }

    @Resource(name = "webArticleDAOHibernateImpl")
    private IWebArticleDAO webArticleDAO;

    public IWebArticleDAO getWebArticleDAO() {
        return webArticleDAO;
    }

    public void setWebArticleDAO(IWebArticleDAO webArticleDAO) {
        this.webArticleDAO = webArticleDAO;
    }

    @Resource(name = "userPlatformDAOHibernateImpl")
    private IUserPlatformDAO userPlatformDAO;

    public IUserPlatformDAO getUserPlatformDAO() {
        return userPlatformDAO;
    }

    public void setUserPlatformDAO(IUserPlatformDAO userPlatformDAO) {
        this.userPlatformDAO = userPlatformDAO;
    }

    @Resource(name = "userBuildingItemDAOHibernateImpl")
    private IUserBuildingItemDAO userBuildingItemDAO;

    public IUserBuildingItemDAO getUserBuildingItemDAO() {
        return userBuildingItemDAO;
    }

    public void setUserBuildingItemDAO(IUserBuildingItemDAO userBuildingItemDAO) {
        this.userBuildingItemDAO = userBuildingItemDAO;
    }

    @Resource(name = "authenticationDAOHibernateImpl")
    private IAuthenticationDAO authenticationDAO;

    public IAuthenticationDAO getAuthenticationDAO() {
        return authenticationDAO;
    }

    public void setAuthenticationDAO(IAuthenticationDAO authenticationDAO) {
        this.authenticationDAO = authenticationDAO;
    }

    public IUserDAO getUserDAO() {
        return userDAO;
    }

    public void setUserDAO(IUserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public IUserInfoDAO getUserInfoDAO() {
        return userInfoDAO;
    }

    public void setUserInfoDAO(IUserInfoDAO userInfoDAO) {
        this.userInfoDAO = userInfoDAO;
    }

    @Resource(name = "userDAOHibernateImpl")
    private IUserDAO userDAO;

    @Resource(name = "userInfoDAOHibernateImpl")
    private IUserInfoDAO userInfoDAO;

    @Resource(name = "webArticleGoodsDAOHibernateImpl")
    private IWebArticleGoodsDAO webArticleGoodsDAO;

    public void setMatterAlbumDAO(IMatterAlbumDAO matterAlbumDAO) {
        this.matterAlbumDAO = matterAlbumDAO;
    }

    public IMatterSpecDAO getMatterSpecDAO() {
        return matterSpecDAO;
    }

    public void setMatterSpecDAO(IMatterSpecDAO matterSpecDAO) {
        this.matterSpecDAO = matterSpecDAO;
    }

    public IWebLabelDAO getWebLabelDAO() {
        return webLabelDAO;
    }

    public void setWebLabelDAO(IWebLabelDAO webLabelDAO) {
        this.webLabelDAO = webLabelDAO;
    }

    public IGoodsRoomDAO getGoodsRoomDAO() {
        return goodsRoomDAO;
    }

    public void setGoodsRoomDAO(IGoodsRoomDAO goodsRoomDAO) {
        this.goodsRoomDAO = goodsRoomDAO;
    }

    public IGoodsDAO getGoodsDAO() {
        return goodsDAO;
    }

    public void setGoodsDAO(IGoodsDAO goodsDAO) {
        this.goodsDAO = goodsDAO;
    }

    public IGoodsDiyItemDAO getGoodsDiyItemDAO() {
        return goodsDiyItemDAO;
    }

    public void setGoodsDiyItemDAO(IGoodsDiyItemDAO goodsDiyItemDAO) {
        this.goodsDiyItemDAO = goodsDiyItemDAO;
    }

    public IGoodsPriceDetailDAO getGoodsPriceDetailDAO() {
        return goodsPriceDetailDAO;
    }

    public void setGoodsPriceDetailDAO(IGoodsPriceDetailDAO goodsPriceDetailDAO) {
        this.goodsPriceDetailDAO = goodsPriceDetailDAO;
    }

    public IGoodsDiyMatterDAO getGoodsDiyMatterDAO() {
        return goodsDiyMatterDAO;
    }

    public void setGoodsDiyMatterDAO(IGoodsDiyMatterDAO goodsDiyMatterDAO) {
        this.goodsDiyMatterDAO = goodsDiyMatterDAO;
    }

    public IGoodsMatterDAO getGoodsMatterDao() {
        return goodsMatterDao;
    }

    public void setGoodsMatterDao(IGoodsMatterDAO goodsMatterDao) {
        this.goodsMatterDao = goodsMatterDao;
    }

    public IGoodsMarkDAO getGoodsMarkDao() {
        return goodsMarkDao;
    }

    public void setGoodsMarkDao(IGoodsMarkDAO goodsMarkDao) {
        this.goodsMarkDao = goodsMarkDao;
    }

    public IMatterSequenceDAO getMatterSequenceDAO() {
        return matterSequenceDAO;
    }

    public void setMatterSequenceDAO(IMatterSequenceDAO matterSequenceDAO) {
        this.matterSequenceDAO = matterSequenceDAO;
    }

    // 城市
    @Resource(name = "gesCityDAOHibernateImpl")
    private IGesCityDAO gesCityDAO;

    public IMatterDAO getMatterDAO() {
        return matterDAO;
    }

    public void setMatterDAO(IMatterDAO matterDAO) {
        this.matterDAO = matterDAO;
    }

    public IDictionaryDAO getDictionaryDao() {
        return dictionaryDao;
    }

    public void setDictionaryDao(IDictionaryDAO dictionaryDao) {
        this.dictionaryDao = dictionaryDao;
    }

    public IBrandDAO getBrandDAO() {
        return brandDAO;
    }

    public void setBrandDAO(IBrandDAO brandDAO) {
        this.brandDAO = brandDAO;
    }

    public IMaterialsCategoryDAO getMaterialsCategoryDAO() {
        return materialsCategoryDAO;
    }

    public void setMaterialsCategoryDAO(IMaterialsCategoryDAO materialsCategoryDAO) {
        this.materialsCategoryDAO = materialsCategoryDAO;
    }

    public IGesMenuDAO getGesMenuDAO() {
        return gesMenuDAO;
    }

    public void setGesMenuDAO(IGesMenuDAO gesMenuDAO) {
        this.gesMenuDAO = gesMenuDAO;
    }

    public IGesReceiptOrderDAO getGesReceiptOrderDAO() {
        return gesReceiptOrderDAO;
    }

    public void setGesReceiptOrderDAO(IGesReceiptOrderDAO gesReceiptOrderDAO) {
        this.gesReceiptOrderDAO = gesReceiptOrderDAO;
    }

    public IGesPaymentOrderDAO getGesPaymentOrderDAO() {
        return gesPaymentOrderDAO;
    }

    public void setGesPaymentOrderDAO(IGesPaymentOrderDAO gesPaymentOrderDAO) {
        this.gesPaymentOrderDAO = gesPaymentOrderDAO;
    }

    public IGesBuildingCityOperatorItemDAO getGesBuildingCityOperatorItemDAO() {
        return gesBuildingCityOperatorItemDAO;
    }

    public void setGesBuildingCityOperatorItemDAO(IGesBuildingCityOperatorItemDAO gesBuildingCityOperatorItemDAO) {
        this.gesBuildingCityOperatorItemDAO = gesBuildingCityOperatorItemDAO;
    }

    public IGesBuildingDAO getGesBuildingDAO() {
        return gesBuildingDAO;
    }

    public void setGesBuildingDAO(IGesBuildingDAO gesBuildingDAO) {
        this.gesBuildingDAO = gesBuildingDAO;
    }

    public IGesBuildingPhotoItemDAO getGesBuildingPhotoItemDAO() {
        return gesBuildingPhotoItemDAO;
    }

    public void setGesBuildingPhotoItemDAO(IGesBuildingPhotoItemDAO gesBuildingPhotoItemDAO) {
        this.gesBuildingPhotoItemDAO = gesBuildingPhotoItemDAO;
    }

    public IHouseDAO getHouseDAO() {
        return houseDAO;
    }

    public void setHouseDAO(IHouseDAO houseDAO) {
        this.houseDAO = houseDAO;
    }

    public IGesCityOperatorCompareConclusionDAO getGesCityOperatorCompareConclusionDAO() {
        return gesCityOperatorCompareConclusionDAO;
    }

    public void setGesCityOperatorCompareConclusionDAO(
            IGesCityOperatorCompareConclusionDAO gesCityOperatorCompareConclusionDAO) {
        this.gesCityOperatorCompareConclusionDAO = gesCityOperatorCompareConclusionDAO;
    }

    public IGesCityOperatorCompareDAO getGesCityOperatorCompareDAO() {
        return gesCityOperatorCompareDAO;
    }

    public void setGesCityOperatorCompareDAO(IGesCityOperatorCompareDAO gesCityOperatorCompareDAO) {
        this.gesCityOperatorCompareDAO = gesCityOperatorCompareDAO;
    }

    public IGesCityOperatorContractDAO getGesCityOperatorContractDAO() {
        return gesCityOperatorContractDAO;
    }

    public void setGesCityOperatorContractDAO(IGesCityOperatorContractDAO gesCityOperatorContractDAO) {
        this.gesCityOperatorContractDAO = gesCityOperatorContractDAO;
    }

    public IGesCityOperatorDAO getGesCityOperatorDAO() {
        return gesCityOperatorDAO;
    }

    public void setGesCityOperatorDAO(IGesCityOperatorDAO gesCityOperatorDAO) {
        this.gesCityOperatorDAO = gesCityOperatorDAO;
    }

    public IGesCityOperatorPartnerDAO getGesCityOperatorPartnerDAO() {
        return gesCityOperatorPartnerDAO;
    }

    public void setGesCityOperatorPartnerDAO(IGesCityOperatorPartnerDAO gesCityOperatorPartnerDAO) {
        this.gesCityOperatorPartnerDAO = gesCityOperatorPartnerDAO;
    }

    public IGesCityOperatorTrackingDAO getGesCityOperatorTrackingDAO() {
        return gesCityOperatorTrackingDAO;
    }

    public void setGesCityOperatorTrackingDAO(IGesCityOperatorTrackingDAO gesCityOperatorTrackingDAO) {
        this.gesCityOperatorTrackingDAO = gesCityOperatorTrackingDAO;
    }

    public IGesShopDAO getGesShopDAO() {
        return gesShopDAO;
    }

    public void setGesShopDAO(IGesShopDAO gesShopDAO) {
        this.gesShopDAO = gesShopDAO;
    }

    public IGesShopGoodsItemDAO getGesShopGoodsItemDAO() {
        return gesShopGoodsItemDAO;
    }

    public void setGesShopGoodsItemDAO(IGesShopGoodsItemDAO gesShopGoodsItemDAO) {
        this.gesShopGoodsItemDAO = gesShopGoodsItemDAO;
    }

    public IGesShopOrderFeedbackDAO getGesShopOrderFeedbackDAO() {
        return gesShopOrderFeedbackDAO;
    }

    public void setGesShopOrderFeedbackDAO(IGesShopOrderFeedbackDAO gesShopOrderFeedbackDAO) {
        this.gesShopOrderFeedbackDAO = gesShopOrderFeedbackDAO;
    }

    public IGesShopPhotoItemDAO getGesShopPhotoItemDAO() {
        return gesShopPhotoItemDAO;
    }

    public void setGesShopPhotoItemDAO(IGesShopPhotoItemDAO gesShopPhotoItemDAO) {
        this.gesShopPhotoItemDAO = gesShopPhotoItemDAO;
    }

    public IGesShopWorkerDAO getGesShopWorkerDAO() {
        return gesShopWorkerDAO;
    }

    public void setGesShopWorkerDAO(IGesShopWorkerDAO gesShopWorkerDAO) {
        this.gesShopWorkerDAO = gesShopWorkerDAO;
    }

    public IWebContrastDAO getWebContrastDAO() {
        return webContrastDAO;
    }

    public void setWebContrastDAO(IWebContrastDAO webContrastDAO) {
        this.webContrastDAO = webContrastDAO;
    }

    public IGesAreaDAO getGesAreaDAO() {
        return gesAreaDAO;
    }

    public void setGesAreaDAO(IGesAreaDAO gesAreaDAO) {
        this.gesAreaDAO = gesAreaDAO;
    }

    public IWebAdviceDAO getWebAdviceDAO() {
        return webAdviceDAO;
    }

    public void setWebAdviceDAO(IWebAdviceDAO webAdviceDAO) {
        this.webAdviceDAO = webAdviceDAO;
    }

    public IGesStoreDAO getGesStoreDAO() {
        return gesStoreDAO;
    }

    public void setGesStoreDAO(IGesStoreDAO gesStoreDAO) {
        this.gesStoreDAO = gesStoreDAO;
    }

    public IGesStoreInventoryDAO getGesStoreInventoryDAO() {
        return gesStoreInventoryDAO;
    }

    public void setGesStoreInventoryDAO(IGesStoreInventoryDAO gesStoreInventoryDAO) {
        this.gesStoreInventoryDAO = gesStoreInventoryDAO;
    }

    public IGesStoreLocationDAO getGesStoreLocationDAO() {
        return gesStoreLocationDAO;
    }

    public void setGesStoreLocationDAO(IGesStoreLocationDAO gesStoreLocationDAO) {
        this.gesStoreLocationDAO = gesStoreLocationDAO;
    }

    public IPictureDAO getPictureDAO() {
        return pictureDAO;
    }

    public void setPictureDAO(IPictureDAO pictureDAO) {
        this.pictureDAO = pictureDAO;
    }

    public IGesPoMainDAO getGesPoMainDAO() {
        return gesPoMainDAO;
    }

    public void setGesPoMainDAO(IGesPoMainDAO gesPoMainDAO) {
        this.gesPoMainDAO = gesPoMainDAO;
    }

    public IGesRdRecordDAO getGesRdRecordDAO() {
        return gesRdRecordDAO;
    }

    public void setGesRdRecordDAO(IGesRdRecordDAO gesRdRecordDAO) {
        this.gesRdRecordDAO = gesRdRecordDAO;
    }

    @Resource(name = "gesOrderDAOHibernateImpl")
    private IGesOrderDAO gesOrderDAO;

    public IGesOrderDAO getGesOrderDAO() {
        return gesOrderDAO;
    }

    public void setGesOrderDAO(IGesOrderDAO gesOrderDAO) {
        this.gesOrderDAO = gesOrderDAO;
    }

    public IGesErpCodeDAO getGesErpCodeDAO() {
        return gesErpCodeDAO;
    }

    public void setGesErpCodeDAO(IGesErpCodeDAO gesErpCodeDAO) {
        this.gesErpCodeDAO = gesErpCodeDAO;
    }

    public IGesPoDetailDAO getGesPoDetailDAO() {
        return gesPoDetailDAO;
    }

    public void setGesPoDetailDAO(IGesPoDetailDAO gesPoDetailDAO) {
        this.gesPoDetailDAO = gesPoDetailDAO;
    }

    public IGesRdRecordsDAO getGesRdRecordsDAO() {
        return gesRdRecordsDAO;
    }

    public void setGesRdRecordsDAO(IGesRdRecordsDAO gesRdRecordsDAO) {
        this.gesRdRecordsDAO = gesRdRecordsDAO;
    }

    public IMatterUnitDAO getMatterUnitDAO() {
        return matterUnitDAO;
    }

    public void setMatterUnitDAO(IMatterUnitDAO matterUnitDAO) {
        this.matterUnitDAO = matterUnitDAO;
    }

    public IGesCityDAO getGesCityDAO() {
        return gesCityDAO;
    }

    public void setGesCityDAO(IGesCityDAO gesCityDAO) {
        this.gesCityDAO = gesCityDAO;
    }

    public IGesGuideDAO getGesGuideDAO() {
        return gesGuideDAO;
    }

    public void setGesGuideDAO(IGesGuideDAO gesGuideDAO) {
        this.gesGuideDAO = gesGuideDAO;
    }

    public IGesCustomerDAO getGesCustomerDAO() {
        return gesCustomerDAO;
    }

    public void setGesCustomerDAO(IGesCustomerDAO gesCustomerDAO) {
        this.gesCustomerDAO = gesCustomerDAO;
    }

    public IGesOrderPayMoneyDAO getGesOrderPayMoney() {
        return gesOrderPayMoney;
    }

    public void setGesOrderPayMoney(IGesOrderPayMoneyDAO gesOrderPayMoney) {
        this.gesOrderPayMoney = gesOrderPayMoney;
    }

    public IWebArticleGoodsDAO getWebArticleGoodsDAO() {
        return webArticleGoodsDAO;
    }

    public void setWebArticleGoodsDAO(IWebArticleGoodsDAO webArticleGoodsDAO) {
        this.webArticleGoodsDAO = webArticleGoodsDAO;
    }

    public IGesSoMatterItemDAO getGesSoMatterItemDAO() {
        return gesSoMatterItemDAO;
    }

    public void setGesSoMatterItemDAO(IGesSoMatterItemDAO gesSoMatterItemDAO) {
        this.gesSoMatterItemDAO = gesSoMatterItemDAO;
    }

    public IGesErpSynchLogDAO getGesErpSynchLogDAO() {
        return GesErpSynchLogDAO;
    }

    public void setGesErpSynchLogDAO(IGesErpSynchLogDAO gesErpSynchLogDAO) {
        GesErpSynchLogDAO = gesErpSynchLogDAO;
    }

    public IGesCustomerMessageDAO getGesCustomerMessageDAO() {
        return gesCustomerMessageDAO;
    }

    public void setGesCustomerMessageDAO(IGesCustomerMessageDAO gesCustomerMessageDAO) {
        this.gesCustomerMessageDAO = gesCustomerMessageDAO;
    }

    public IGesCustomerMessageLogDAO getGesCustomerMessageLogDAO() {
        return gesCustomerMessageLogDAO;
    }

    public void setGesCustomerMessageLogDAO(IGesCustomerMessageLogDAO gesCustomerMessageLogDAO) {
        this.gesCustomerMessageLogDAO = gesCustomerMessageLogDAO;
    }

    public IModellingDAO getModellingDao() {
        return modellingDao;
    }

    public void setModellingDao(IModellingDAO modellingDao) {
        this.modellingDao = modellingDao;
    }

    public IModellingMatterItemDAO getModellingMatterItemDao() {
        return modellingMatterItemDao;
    }

    public void setModellingMatterItemDao(IModellingMatterItemDAO modellingMatterItemDao) {
        this.modellingMatterItemDao = modellingMatterItemDao;
    }

    public IDeptUserDAO getDeptUserDAO() {
        return deptUserDAO;
    }

    public void setDeptUserDAO(IDeptUserDAO deptUserDAO) {
        this.deptUserDAO = deptUserDAO;
    }

    public IWebSupportItemDAO getWebSupportItemDAO() {
        return webSupportItemDAO;
    }

    public void setWebSupportItemDAO(IWebSupportItemDAO webSupportItemDAO) {
        this.webSupportItemDAO = webSupportItemDAO;
    }

    public IWebCollectionItemDAO getWebCollectionItemDAO() {
        return webCollectionItemDAO;
    }

    public void setWebCollectionItemDAO(IWebCollectionItemDAO webCollectionItemDAO) {
        this.webCollectionItemDAO = webCollectionItemDAO;
    }

    public ISmsValidationDAO getSmsValidationDAO() {
        return smsValidationDAO;
    }

    public void setSmsValidationDAO(ISmsValidationDAO smsValidationDAO) {
        this.smsValidationDAO = smsValidationDAO;
    }

    public IWebCommentItemDAO getWebCommentItemDAO() {
        return webCommentItemDAO;
    }

    public void setWebCommentItemDAO(IWebCommentItemDAO webCommentItemDAO) {
        this.webCommentItemDAO = webCommentItemDAO;
    }

    public IPermissionDAO getPermissionDAO() {
        return permissionDAO;
    }

    public void setPermissionDAO(IPermissionDAO permissionDAO) {
        this.permissionDAO = permissionDAO;
    }

    public IRoleDAO getRoleDAO() {
        return roleDAO;
    }

    public void setRoleDAO(IRoleDAO roleDAO) {
        this.roleDAO = roleDAO;
    }

    public IEmailValidationDAO getEmailValidationDAO() {
        return emailValidationDAO;
    }

    public void setEmailValidationDAO(IEmailValidationDAO emailValidationDAO) {
        this.emailValidationDAO = emailValidationDAO;
    }

    @Resource(name = "gesPaymentRecordDAOHibernateImpl")
    private IGesPaymentRecordDAO gesPaymentRecordDAO;

    public IGesPaymentRecordDAO getGesPaymentRecordDAO() {
        return gesPaymentRecordDAO;
    }

    public void setGesPaymentRecordDAO(IGesPaymentRecordDAO gesPaymentRecordDAO) {
        this.gesPaymentRecordDAO = gesPaymentRecordDAO;
    }

    @Resource(name = "paymentRecordResponseDAOHibernateImpl")
    private IPaymentRecordResponseDAO paymentRecordResponseDAO;

    public IPaymentRecordResponseDAO getPaymentRecordResponseDAO() {
        return paymentRecordResponseDAO;
    }

    public void setPaymentRecordResponseDAO(IPaymentRecordResponseDAO paymentRecordResponseDAO) {
        this.paymentRecordResponseDAO = paymentRecordResponseDAO;
    }

    @Resource(name = "multiplePaymentDAOHibernateImpl")
    private IMultiplePaymentDAO multiplePaymentDAO;

    public IMultiplePaymentDAO getMultiplePaymentDAO() {
        return multiplePaymentDAO;
    }

    public void setMultiplePaymentDAO(IMultiplePaymentDAO multiplePaymentDAO) {
        this.multiplePaymentDAO = multiplePaymentDAO;
    }

    public IGesMenuRoleItemDAO getGesMenuRoleItemDAO() {
        return gesMenuRoleItemDAO;
    }

    public void setGesMenuRoleItemDAO(IGesMenuRoleItemDAO gesMenuRoleItemDAO) {
        this.gesMenuRoleItemDAO = gesMenuRoleItemDAO;
    }

    public IUserRoleDAO getUserRoleDAO() {
        return userRoleDAO;
    }

    public void setUserRoleDAO(IUserRoleDAO userRoleDAO) {
        this.userRoleDAO = userRoleDAO;
    }

    public IGesProjectTaskDAO getGesProjectTaskDAO() {
        return gesProjectTaskDAO;
    }

    public void setGesProjectTaskDAO(IGesProjectTaskDAO gesProjectTaskDAO) {
        this.gesProjectTaskDAO = gesProjectTaskDAO;
    }

    public IGesMenuPermissionItemDAO getGesMenuPermissionItemDAO() {
        return gesMenuPermissionItemDAO;
    }

    public void setGesMenuPermissionItemDAO(IGesMenuPermissionItemDAO gesMenuPermissionItemDAO) {
        this.gesMenuPermissionItemDAO = gesMenuPermissionItemDAO;
    }

    public IBuildingSaleConfigDAO getBuildingSaleConfigDAO() {
        return buildingSaleConfigDAO;
    }

    public void setBuildingSaleConfigDAO(
            IBuildingSaleConfigDAO buildingSaleConfigDAO) {
        this.buildingSaleConfigDAO = buildingSaleConfigDAO;
    }

    public IBuildingInfoDAO getBuildingInfoDAO() {
        return buildingInfoDAO;
    }

    public void setBuildingInfoDAO(IBuildingInfoDAO buildingInfoDAO) {
        this.buildingInfoDAO = buildingInfoDAO;
    }

    public IBuildingInfoGoodsDAO getBuildingInfoGoodsDAO() {
        return buildingInfoGoodsDAO;
    }

    public void setBuildingInfoGoodsDAO(IBuildingInfoGoodsDAO buildingInfoGoodsDAO) {
        this.buildingInfoGoodsDAO = buildingInfoGoodsDAO;
    }
    
    
    
    
  //练习
  	@Resource(name="xgGoujiaDaoImpl")
  	private XgGoujiaDAO xgGoujiaDao;

  	public XgGoujiaDAO getXgGoujiaDao() {
  		return xgGoujiaDao;
  	}

  	public void setXgGoujiaDao(XgGoujiaDAO xgGoujiaDao) {
  		this.xgGoujiaDao = xgGoujiaDao;
  	}
   

	

	
    
    

}
