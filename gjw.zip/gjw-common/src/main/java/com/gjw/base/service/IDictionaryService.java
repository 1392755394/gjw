package com.gjw.base.service;

import java.util.List;

import com.gjw.entity.dictionary.Dictionary;

/**
 * 
* @Description: 字典service接口类
* @author  zhaoyonglian
* @date 2015年12月12日 下午5:18:26
*
 */
public interface IDictionaryService extends IService {
    /**
     * 
    * @Description  获取问题详情
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月10日 下午2:31:48
     */
    
    public Dictionary getById(Long id);
    
    /**
     * 
    * @Description  查看下级所有类型
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月12日 下午4:26:39
     */
    public List<Dictionary> listChildrenById(Long id);	
    
    /**
     * 
    * @Description  废弃
    * @param id
    * @return
    * @author zhaoyonglian   
    * @date 2015年12月12日 下午5:27:28
     */
    public int invalid(Long id);
    
    /**
     * 
    * @Description  修改字典信息
    * @param dictionary
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午2:11:24
     */
    public boolean update(Dictionary dictionary);
    
    /**
     * 
    * @Description  新增字典信息
    * @param dictionary
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午2:11:41
     */
    public boolean create(Dictionary dictionary);
    
    /**
     * 
    * @Description  获取目前子级中最大id
    * @param parentId
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午2:38:54
     */
    public Long getIdByParent(Long parentId);
    
    /**
     * 
    * @Description  批量废弃字典
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午5:13:21
     */
    public boolean batchDel(String ids);
}
