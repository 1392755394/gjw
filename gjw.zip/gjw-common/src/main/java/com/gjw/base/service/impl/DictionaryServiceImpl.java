package com.gjw.base.service.impl;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.gjw.base.dao.IDictionaryDAO;
import com.gjw.base.service.IDictionaryService;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.utils.StringUtil;

/**
 * 
 * @Description: 字典service实现类
 * @author zhaoyonglian
 * @date 2015年12月12日 下午5:28:51
 * 
 */
@Component("dictionaryServiceImpl")
public class DictionaryServiceImpl implements IDictionaryService {
    @Autowired
    private IDictionaryDAO dao;

    @Override
    @Transactional(readOnly = true)
    public Dictionary getById(Long id) {
        // TODO Auto-generated method stub
        return dao.getById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Dictionary> listChildrenById(Long id) {
        // TODO Auto-generated method stub
        List<Dictionary> list=dao.listChildrenById(id);
        for (Dictionary dictionary : list) {
            if(0!=dictionary.getParent().getId()){
                Hibernate.initialize(dictionary.getParent());
            }
            long count=dao.getIdByParent(dictionary.getId());
            if(0<count){
                dictionary.setState("closed");
            }
        }
        return list;
    }

    @Override
    @Transactional
    public int invalid(Long id) {
        // TODO Auto-generated method stub
        return dao.remove(id);
    }

    @Override
    @Transactional
    public boolean update(Dictionary dictionary) {
        // TODO Auto-generated method stub
        return dao.updateDictionary(dictionary);
    }

    @Override
    @Transactional
    public boolean create(Dictionary dictionary) {
        // TODO Auto-generated method stub
        // 获取id及设置id
        Long id = null;
        if (StringUtil.notEmpty(dictionary.getParent()) && StringUtil.notEmpty(dictionary.getParent().getId())) {
            id = this.getIdByParent(dictionary.getParent().getId());
        } else {
            throw new ErrorCodeException(SECode.d_100001);
        }
        if (id == 0l) {
            dictionary.setId(dictionary.getParent().getId() * 100 + 1);
        } else {
            dictionary.setId(id + 1);
        }
        return dao.createDictionary(dictionary);
    }

    @Override
    public Long getIdByParent(Long parentId) {
        // TODO Auto-generated method stub
        return dao.getIdByParent(parentId);
    }

    @Override
    @Transactional
    public boolean batchDel(String ids) {
        // TODO Auto-generated method stub
        return dao.batchDel(ids);
    }

}
