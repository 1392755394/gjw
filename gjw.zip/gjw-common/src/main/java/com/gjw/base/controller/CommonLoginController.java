/**   
* @Title: LoginController.java
* @Package com.gjw.base.controller
* @Description: TODO(用一句话描述该文件做什么)
* @author qingye   
* @date Jan 4, 2016 5:04:46 PM
* @version V1.0   
*/

package com.gjw.base.controller;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jasig.cas.client.util.AbstractCasFilter;
import org.jasig.cas.client.validation.Assertion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gjw.common.constants.UserConstants;
import com.gjw.common.enumeration.PlatformEnum;
import com.gjw.common.handler.LoginHandler;
import com.gjw.common.helper.sso.SSOHelper;
import com.gjw.entity.user.User;
import com.gjw.entity.user.UserPlatformItem;

/**
 * @Description: 
 * @author  qingye
 * @date Jan 4, 2016 5:04:46 PM
 * 
 */

@Controller
public class CommonLoginController extends JsonController{
    @Autowired(required=false)
    private LoginHandler loginHandler;
    @Value("${platform.name}")
    private String platformName;
    @Autowired(required=false)
    private SSOHelper ssoHelper;
    
    @RequestMapping(value="login")
    @ResponseBody
    public String login(HttpServletRequest request,HttpServletResponse response){
        Assertion assertion = (Assertion) request.getSession().getAttribute(AbstractCasFilter.CONST_CAS_ASSERTION);
        String result="success";
//        if(assertion!=null){
        if(true){
//            User user=this.getAuthenticationService().getByLogin(assertion.getPrincipal().getName()).getUser();
            User user=this.getUserService().getWithAllInfo(109l);
            PlatformEnum platform=PlatformEnum.valueOfName(platformName);
//            if(loginHandler.hadPermission(request, response, user)){
            if(true){
                try{
                    user.setPlatformUserInfo(user.getUserInfo(platform));
                    loginHandler.setUserToSession(request.getSession(), user);
                    result=loginHandler.deal(request, response, user);
                }
                catch(Exception e){
                    loginFail(request,response,platform);
                    e.printStackTrace();
                    throw e;
                }
            }
            else{
                loginFail(request,response,platform);
                result="noPermission";
            }
        }
        return result;
    }
    
    private void loginFail(HttpServletRequest request,
            HttpServletResponse response,PlatformEnum platform){
        request.setAttribute(UserConstants.IGNORE_LOGIN_CHECK, true);
        int loginFlag=ssoHelper.getLoginFlagValue(request.getCookies());
        loginFlag=ssoHelper.cancleLoginFlag(platform,loginFlag);
        response.addCookie(ssoHelper.getCookie(loginFlag));
    }
    
    
}
