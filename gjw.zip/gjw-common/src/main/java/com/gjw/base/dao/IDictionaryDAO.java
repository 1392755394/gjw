package com.gjw.base.dao;

import java.util.List;

import com.gjw.entity.dictionary.Dictionary;

/**
 * 
 * @Description: 字典dao类
 * @author zhaoyonglian
 * @date 2015年12月12日 下午4:20:43
 * 
 */
public interface IDictionaryDAO extends IDAO {

    /**
     * 
     * @Description 获取字典详情
     * @param id
     * @return
     * @author zhaoyonglian
     * @date 2015年12月10日 下午2:31:48
     */
    public Dictionary getById(Long id);

    /**
     * 
     * @Description 查看下级所有类型
     * @param id
     * @return
     * @author zhaoyonglian
     * @date 2015年12月12日 下午4:26:39
     */
    public List<Dictionary> listChildrenById(Long id);
    
    /**
     * 
    * @Description  修改字典信息
    * @param dictioanry
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午2:21:51
     */
    public boolean updateDictionary(Dictionary dictioanry);
    
    /**
     * 
    * @Description  获取目前子级中最大id
    * @param parentId
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午2:38:54
     */
    public Long getIdByParent(Long parentId);
    
    /**
     * 
    * @Description  创建字典信息
    * @param dictionary
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午3:22:11
     */
    public boolean createDictionary(Dictionary dictionary);
    
    /**
     * 
    * @Description  批量废弃字典
    * @param ids
    * @return
    * @author zhaoyonglian   
    * @date 2016年1月7日 下午5:13:21
     */
    public boolean batchDel(String ids); 
    
}
