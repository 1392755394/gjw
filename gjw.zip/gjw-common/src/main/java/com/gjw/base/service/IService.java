package com.gjw.base.service;

public interface IService {
   
}
