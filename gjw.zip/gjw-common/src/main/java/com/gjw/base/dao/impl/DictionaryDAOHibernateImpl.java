package com.gjw.base.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import com.gjw.base.dao.IDictionaryDAO;
import com.gjw.entity.dictionary.Dictionary;
import com.gjw.utils.StringUtil;

/**
 * 产品包dao的Hibernate实现
 */
@Component("dictionaryDAOHibernateImpl")
public class DictionaryDAOHibernateImpl extends AbstractDAOHibernateImpl implements IDictionaryDAO {

    @Override
    protected Class<?> getEntityClass() {
        // TODO Auto-generated method stub
        return Dictionary.class;
    }

    @Override
    public Dictionary getById(Long id) {
        // TODO Auto-generated method stub
        return (Dictionary) super.get(id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Dictionary> listChildrenById(Long id) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        if (null == id) {
            return null;
        }
        hql.append(" from Dictionary where invalid = 0 and parent_id = :parent_id");
        hql.append(" order by orderTag asc");
        Query query = session.createQuery(hql.toString());
        query.setLong("parent_id", id);
        return query.list();
    }

    @Override
    public boolean updateDictionary(Dictionary dictioanry) {
        // TODO Auto-generated method stub
        Dictionary old = (Dictionary) super.get(dictioanry.getId());
        StringUtil.copyProperties(dictioanry, old);
//        old.setParent(null);
        super.update(old);
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Long getIdByParent(Long parentId) {
        // TODO Auto-generated method stub
        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
        StringBuffer hql = new StringBuffer();
        if (null == parentId) {
            return null;
        }
        hql.append(" from Dictionary where parent_id = :parent_id");
        hql.append(" order by id desc");
        Query query = session.createQuery(hql.toString());
        query.setLong("parent_id", parentId);
        List<Dictionary> list = query.list();
        if (null != list && list.size() > 0) {
            return list.get(0).getId();
        } else {
            return 0l;
        }
    }

    @Override
    public boolean createDictionary(Dictionary dictionary) {
        // TODO Auto-generated method stub
//        Session session = super.getHibernateTemplate().getSessionFactory().getCurrentSession();
//        StringBuffer sql = new StringBuffer();
//        sql.append("insert into base_dictionary(id,invalid,status,order_tag,created_datetime,updated_datetime,text,parent_id,remark) values");
//        sql.append("(" + dictionary.getId() + ",0,1," + dictionary.getOrderTag() + ",'");
//        sql.append(new Timestamp(System.currentTimeMillis()) + "','" + new Timestamp(System.currentTimeMillis())
//                + "','");
//        sql.append(dictionary.getText() + "'," + dictionary.getParent().getId() + ",'" + dictionary.getRemark() + "');");
//        PreparedStatement ps = session.createSQLQuery(sql.toString());con.prepareStatement(sql); 
//        ps.executeUpdate(); 
//        
//        Query query = session.createSQLQuery(sql.toString());
        return super.saveResultBoolean(dictionary);
    }

    @Override
    public boolean batchDel(String ids) {
        // TODO Auto-generated method stub
        String[] idArray = ids.split(",");
        List<Long> idList = new ArrayList<Long>();
        for (String id : idArray) {
            if (StringUtil.notEmpty(id))
                idList.add(Long.parseLong(id));
        }
        return super.delBatchByID(idList) > 0;
    }
}
