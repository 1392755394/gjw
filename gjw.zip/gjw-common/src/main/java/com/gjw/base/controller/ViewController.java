package com.gjw.base.controller;

import org.hibernate.ObjectNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

/**
 * 返回视图的Controller
 */
public class ViewController extends AbstractController {

	private static final Logger LOG = LoggerFactory.getLogger(ViewController.class);
	
	private String errPage = "error/500";
	
	/**
	 * 返回视图的异常处理
	 * @param ex 异常
	 * @return 视图
	 */
	@ExceptionHandler(Exception.class)
	public ModelAndView viewExceptionHandler(Exception ex) {
		
		LOG.error(ex.getMessage(), ex);
		
		ModelAndView modelAndView = new ModelAndView(); // 该方法返回的不是JSON
		
		if (ex instanceof ObjectNotFoundException) {
		    ObjectNotFoundException e = (ObjectNotFoundException)ex;
		    
            String errMsg = null;
            try {
                errMsg = String.format("ID为:%s的%s不存在，请联系系统管理员处理。", e.getIdentifier(), Class.forName(e.getEntityName()).getSimpleName());
            } catch (ClassNotFoundException e1) {
                e1.printStackTrace();
            }
            modelAndView.setViewName("error/error"); // 走视图解析器
	        modelAndView.addObject("error", errMsg); // 将异常信息内容传到页面
		    
		} else {
	        modelAndView.setViewName(errPage); // 走视图解析器
		}
		
		
		return modelAndView;
	}
}
