package com.gjw.base.controller;

import org.hibernate.ObjectNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gjw.common.error.ErrorResult;

/**
 * 返回json的Controller
 */
public class JsonController extends AbstractController {

	private static final Logger LOG = LoggerFactory.getLogger(JsonController.class);
	
	/**
	 * 返回json的异常处理
	 * @param ex 异常
	 * @return json结果
	 */
	@ExceptionHandler(Exception.class)
	public @ResponseBody ErrorResult jsonExceptionHandler(Exception ex) {
		
		LOG.error(ex.getMessage(), ex);
        
        if (ex instanceof ObjectNotFoundException) {
            ObjectNotFoundException e = (ObjectNotFoundException)ex;
            
            String errMsg = null;
            try {
                errMsg = String.format("ID为:%s的%s不存在，请联系系统管理员处理。", e.getIdentifier(), Class.forName(e.getEntityName()).getSimpleName());
            } catch (ClassNotFoundException e1) {
                e1.printStackTrace();
            }
            ErrorResult error = new ErrorResult();
            error.setMsg(errMsg);
            return error;
        } else {
            return getError(ex);
        }
		
	}
}
