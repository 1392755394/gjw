package com.gjw.base.controller;

import javax.annotation.Resource;

import com.gjw.base.service.IDictionaryService;
import com.gjw.common.error.ErrorResult;
import com.gjw.common.error.SECode;
import com.gjw.common.exception.ErrorCodeException;
import com.gjw.common.exception.GenericException;
import com.gjw.company.service.app.IWebAdbiceService;
import com.gjw.company.service.app.IWebContrastDetailService;
import com.gjw.company.service.app.IWebContrastService;
import com.gjw.company.service.app.IWebDesignerService;
import com.gjw.company.service.area.IGesAreaService;
import com.gjw.company.service.area.IGesCityService;
import com.gjw.company.service.article.IWebArticleGoodsService;
import com.gjw.company.service.article.IWebArticleService;
import com.gjw.company.service.building.IGesBuildingService;
import com.gjw.company.service.cityoperator.IGesCityOperatorService;
import com.gjw.company.service.collection.IWebCollectionItemService;
import com.gjw.company.service.comment.IWebCommentItemService;
import com.gjw.company.service.customer.IGesAppointmentService;
import com.gjw.company.service.customer.IGesCustomerMessageLogService;
import com.gjw.company.service.customer.IGesCustomerMessageService;
import com.gjw.company.service.customer.IGesCustomerService;
import com.gjw.company.service.encyclopedia.IWebEncyclopediaLabelItemService;
import com.gjw.company.service.erp.IERPBaseDataService;
import com.gjw.company.service.erp.IGesErpCodeService;
import com.gjw.company.service.erp.IGesErpSynchLogService;
import com.gjw.company.service.erp.IGesPaymentOrderService;
import com.gjw.company.service.erp.IGesPoDetailService;
import com.gjw.company.service.erp.IGesPoMainService;
import com.gjw.company.service.erp.IGesRdRecordService;
import com.gjw.company.service.erp.IGesRdRecordsService;
import com.gjw.company.service.erp.IGesReceiptOrderService;
import com.gjw.company.service.erp.IGesSoMatterItemService;
import com.gjw.company.service.erp.IGesStoreInventoryService;
import com.gjw.company.service.erp.IGesStoreLocationService;
import com.gjw.company.service.erp.IGesStoreService;
import com.gjw.company.service.erp.IMatterUnitService;
import com.gjw.company.service.goods.IGoodsAppMarkService;
import com.gjw.company.service.goods.IGoodsDiyItemService;
import com.gjw.company.service.goods.IGoodsDiyMatterService;
import com.gjw.company.service.goods.IGoodsMarkService;
import com.gjw.company.service.goods.IGoodsMatterService;
import com.gjw.company.service.goods.IGoodsPriceDetailService;
import com.gjw.company.service.goods.IGoodsRoomService;
import com.gjw.company.service.goods.IGoodsService;
import com.gjw.company.service.label.IWebLabelService;
import com.gjw.company.service.matter.IBrandService;
import com.gjw.company.service.matter.IMaterialsCategoryService;
import com.gjw.company.service.matter.IMatterAlbumService;
import com.gjw.company.service.matter.IMatterService;
import com.gjw.company.service.matter.IMatterSpecService;
import com.gjw.company.service.menu.IGesMenuRoleItemService;
import com.gjw.company.service.menu.IGesMenuService;
import com.gjw.company.service.modelling.IModellingMatterItemService;
import com.gjw.company.service.modelling.IModellingService;
import com.gjw.company.service.oa.IGesMessageService;
import com.gjw.company.service.order.IGesOrderPayMoneyService;
import com.gjw.company.service.order.IGesOrderService;
import com.gjw.company.service.order.ILoanDictService;
import com.gjw.company.service.order.IMultiplePaymentService;
import com.gjw.company.service.order.IOrderGjbPayService;
import com.gjw.company.service.order.IOwnerLoanService;
import com.gjw.company.service.order.IWebOrderLogService;
import com.gjw.company.service.picture.IPictureService;
import com.gjw.company.service.recommend.IWebRecommendInfoService;
import com.gjw.company.service.recommend.IWebRecommendPositionService;
import com.gjw.company.service.role.IRoleService;
import com.gjw.company.service.salestool.IBuildingInfoGoodsService;
import com.gjw.company.service.salestool.IBuildingInfoService;
import com.gjw.company.service.salestool.IBuildingSaleConfigService;
import com.gjw.company.service.salestool.ICaptchRecoredService;
import com.gjw.company.service.salestool.ICaptchaService;
import com.gjw.company.service.salestool.IFullViewService;
import com.gjw.company.service.salestool.IIpadAdvertService;
import com.gjw.company.service.shop.IGesShopService;
import com.gjw.company.service.support.IWebSupportItemService;
import com.gjw.company.service.topic.IWebTopicArticleItemService;
import com.gjw.company.service.user.IAuthenticationService;
import com.gjw.company.service.user.IDeptService;
import com.gjw.company.service.user.IUserBuildingItemService;
import com.gjw.company.service.user.IUserInfoService;
import com.gjw.company.service.user.IUserRoleService;
import com.gjw.company.service.user.IUserService;
import com.gjw.company.service.user.IValidateService;
import com.gjw.company.service.validation.IEmailValidationService;
import com.gjw.company.service.validation.ISmsValidationService;
import com.gjw.company.service.virtual.reality.IGesShopGoodsItemService;
import com.gjw.company.service.xggoujia.XgGoujiaService;

abstract public class AbstractController {
    //房产销售
    @Resource(name="captchaServiceImpl")
    private ICaptchaService captchaServiceImpl;
    @Resource(name="captchaRecordServiceImpl")
    private ICaptchRecoredService captchaRecordServiceImpl;
    @Resource(name="fullViewServiceImpl")
    private IFullViewService fullViewServiceImpl;
    @Resource(name="ipadAdvertServiceImpl")
    private IIpadAdvertService ipadAdvertServiceImpl;
    @Resource(name = "buildingSaleConfigServiceImpl")
    private IBuildingSaleConfigService buildingSaleConfigService;
    @Resource(name = "buildingInfoServiceImpl")
    private IBuildingInfoService buildingInfoService;
    @Resource(name = "buildingInfoGoodsServiceImpl")
    private IBuildingInfoGoodsService buildingInfoGoodsService;
    
    public ICaptchaService getCaptchaServiceImpl() {
        return captchaServiceImpl;
    }

    public void setCaptchaServiceImpl(ICaptchaService captchaServiceImpl) {
        this.captchaServiceImpl = captchaServiceImpl;
    }

    public ICaptchRecoredService getCaptchaRecordServiceImpl() {
        return captchaRecordServiceImpl;
    }

    public void setCaptchaRecordServiceImpl(
            ICaptchRecoredService captchaRecordServiceImpl) {
        this.captchaRecordServiceImpl = captchaRecordServiceImpl;
    }

    public IFullViewService getFullViewServiceImpl() {
        return fullViewServiceImpl;
    }

    public void setFullViewServiceImpl(IFullViewService fullViewServiceImpl) {
        this.fullViewServiceImpl = fullViewServiceImpl;
    }

    public IIpadAdvertService getIpadAdvertServiceImpl() {
        return ipadAdvertServiceImpl;
    }

    public void setIpadAdvertServiceImpl(IIpadAdvertService ipadAdvertServiceImpl) {
        this.ipadAdvertServiceImpl = ipadAdvertServiceImpl;
    }

    @Resource(name="webDesignerServiceImpl")
    private IWebDesignerService webDesignerServiceImpl;
    @Resource(name="webContrastDetailServiceImpl")
    private IWebContrastDetailService webContrastDetailServiceImpl;
    @Resource(name="webOrderLogServiceImpl")
    private IWebOrderLogService webOrderLogServiceImpl;
    public IWebOrderLogService getWebOrderLogServiceImpl() {
        return webOrderLogServiceImpl;
    }

    public void setWebOrderLogServiceImpl(IWebOrderLogService webOrderLogServiceImpl) {
        this.webOrderLogServiceImpl = webOrderLogServiceImpl;
    }

    // 客户消息start
    @Resource(name = "gesCustomerMessageServiceImpl")
    private IGesCustomerMessageService gesCustomerMessageService;
    @Resource(name = "gesCustomerMessageLogServiceImpl")
    private IGesCustomerMessageLogService gesCustomerMessageLogService;
    @Resource(name = "gesAppointmentServiceImpl")
    private IGesAppointmentService gesAppointmentService;
    // end
    @Resource(name = "webAdviceServiceImpl")
    private IWebAdbiceService webAdbiceService;
    @Resource(name = "gesAreaServiceImpl")
    private IGesAreaService gesAreaService;
    @Resource(name = "pictureServiceImpl")
    private IPictureService pictureService;
    @Resource(name = "gesStoreServiceImpl")
    private IGesStoreService gesStoreService;
    @Resource(name = "gesStoreLocationServiceImpl")
    private IGesStoreLocationService gesStoreLocationService;
    @Resource(name = "gesStoreInventoryServiceImpl")
    private IGesStoreInventoryService gesStoreInventoryService;
    @Resource(name = "webContrastServiceImpl")
    private IWebContrastService webContrastService;
    @Resource(name = "webEncyclopediaLabelItemServiceImpl")
    private IWebEncyclopediaLabelItemService webEncyclopediaLabelItemService;
    @Resource(name = "gesPoMainServiceImpl")
    private IGesPoMainService gesPoMainService;
    @Resource(name = "gesBuildingServiceImpl")
    private IGesBuildingService gesBuildingService;
    // 菜单
    @Resource(name = "gesMenuServiceImpl")
    private IGesMenuService gesMenuService;
    @Resource(name = "gesMenuRoleItemServiceImpl")
    private IGesMenuRoleItemService gesMenuRoleItemService; 
    // 部门
    @Resource(name = "deptServiceImpl")
    private IDeptService deptService;

    // 物料
    @Resource(name = "materialsCategoryServiceImpl")
    private IMaterialsCategoryService materialsCategoryService;
    @Resource(name = "brandServiceImpl")
    private IBrandService brandService;
    @Resource(name = "matterServiceImpl")
    private IMatterService matterService;
    @Resource(name = "matterSpecServiceImpl")
    private IMatterSpecService matterSpecService;
    @Resource(name = "matterAlbumServiceImpl")
    private IMatterAlbumService matterAlbumService;
    @Resource(name = "webArticleGoodsServiceImpl")
    private IWebArticleGoodsService webArticleGoodsService;
    // 造型库
    @Resource(name = "modellingServiceImpl")
    private IModellingService modellingService;
    @Resource(name = "modellingMatterItemServiceImpl")
    private IModellingMatterItemService modellingMatterItemService;

    // ÏúÊÛ³ö¿âµ¥¹ÜÀí
    @Resource(name = "gesRdRecordServiceImpl")
    private IGesRdRecordService gesRdRecordService;
    @Resource(name = "gesCityOperatorServiceImpl")
    private IGesCityOperatorService gesCityOperatorService;
    // 字典
    @Resource(name = "dictionaryServiceImpl")
    private IDictionaryService dictionaryService;
    // 4s店
    @Resource(name = "gesShopServiceImpl")
    private IGesShopService gesShopServiceImpl;

    @Resource(name = "gesRdRecordsServiceImpl")
    private IGesRdRecordsService gesRdRecordsService;
    // 产品包
    @Resource(name = "goodsRoomServiceImpl")
    private IGoodsRoomService goodsRoomService;
    @Resource(name = "goodsServiceImpl")
    private IGoodsService goodsService;
    @Resource(name = "goodsDiyItemServiceImpl")
    private IGoodsDiyItemService goodsDiyItemService;
    @Resource(name = "goodsPriceDetailServiceImpl")
    private IGoodsPriceDetailService goodsPriceDetailService;
    @Resource(name = "goodsDiyMatterServiceImpl")
    private IGoodsDiyMatterService goodsDiyMatterService;
    @Resource(name = "goodsMatterServiceImpl")
    private IGoodsMatterService goodsMatterService;
    @Resource(name = "gesOrderServiceImpl")
    private IGesOrderService gesOrderService;
    @Resource(name = "webTopicArticleItemServiceImpl")
    private IWebTopicArticleItemService webTopicArticleItemService;

    @Resource(name = "goodsMarkServiceImpl")
    private IGoodsMarkService goodsMarkService;
    @Resource(name = "goodsAppMarkServiceImpl")
    private IGoodsAppMarkService goodsAppMarkService;
    // ERP财务管理
    @Resource(name = "gesReceiptOrderServiceImpl")
    private IGesReceiptOrderService gesReceiptOrderService;
    public IGoodsAppMarkService getGoodsAppMarkService() {
        return goodsAppMarkService;
    }

    public void setGoodsAppMarkService(IGoodsAppMarkService goodsAppMarkService) {
        this.goodsAppMarkService = goodsAppMarkService;
    }

    @Resource(name = "gesPaymentOrderServiceImpl")
    private IGesPaymentOrderService gesPaymentOrderService;
    // OA消息
    @Resource(name = "gesMessageServiceImpl")
    private IGesMessageService gesMessageService;

    public IGesMessageService getGesMessageService() {
        return gesMessageService;
    }

    public void setGesMessageService(IGesMessageService gesMessageService) {
        this.gesMessageService = gesMessageService;
    }

    /**
     * 物料单位
     */
    @Resource(name = "matterUnitServiceImpl")
    private IMatterUnitService matterUnitService;

    // 城市管理
    @Resource(name = "gesCityServiceImpl")
    private IGesCityService gesCityService;

    // erp同步接口
    @Resource(name = "erpBaseDataServiceImpl")
    private IERPBaseDataService erpBaseDataService;
    // 基础数据
    @Resource(name = "gesErpCodeServiceImpl")
    private IGesErpCodeService gesErpCodeService;
    // 物料详情
    @Resource(name = "gesPoDetailServiceImpl")
    private IGesPoDetailService gesPoDetailService;

    @Resource(name = "webLabelServiceImpl")
    private IWebLabelService webLabelService;

    @Resource(name = "authenticationServiceImpl")
    private IAuthenticationService authenticationService;

    @Resource(name = "userInfoServiceImpl")
    private IUserInfoService userInfoService;

    @Resource(name = "userRoleServiceImpl")
    private IUserRoleService userRoleService;

    @Resource(name = "userBuildingItemServiceImpl")
    private IUserBuildingItemService userBuildingItemService;

    public IUserBuildingItemService getUserBuildingItemService() {
        return userBuildingItemService;
    }

    public void setUserBuildingItemService(IUserBuildingItemService userBuildingItemService) {
        this.userBuildingItemService = userBuildingItemService;
    }

    public IUserRoleService getUserRoleService() {
        return userRoleService;
    }

    public void setUserRoleService(IUserRoleService userRoleService) {
        this.userRoleService = userRoleService;
    }

    @Resource(name = "gesOrderPayMoneyServiceImpl")
    private IGesOrderPayMoneyService gesOrderPayMoneyService;

    @Resource(name = "gesCustomerServiceImpl")
    private IGesCustomerService gesCustomerService;

    @Resource(name = "gesErpSynchLogServiceImpl")
    private IGesErpSynchLogService gesErpSynchLogService;

    @Resource(name = "webArticleServiceImpl")
    private IWebArticleService webArticleService;

    // 点赞
    @Resource(name = "webSupportItemServiceImpl")
    private IWebSupportItemService webSupportItemService;
    // 收藏
    @Resource(name = "webCollectionItemServiceImpl")
    private IWebCollectionItemService webCollectionItemService;
    // 虚拟现实
    @Resource(name = "gesShopGoodsItemServiceImpl")
    private IGesShopGoodsItemService gesShopGoodsItemService;
    // 推荐位
    @Resource(name = "webRecommendInfoServiceImpl")
    private IWebRecommendInfoService webRecommendInfoService;
    @Resource(name = "webRecommendPositionServiceImpl")
    private IWebRecommendPositionService webRecommendPositionService;

    
    public IGesAppointmentService getGesAppointmentService() {
        return gesAppointmentService;
    }

    public void setGesAppointmentService(IGesAppointmentService gesAppointmentService) {
        this.gesAppointmentService = gesAppointmentService;
    }

    public IWebRecommendInfoService getWebRecommendInfoService() {
        return webRecommendInfoService;
    }

    public void setWebRecommendInfoService(IWebRecommendInfoService webRecommendInfoService) {
        this.webRecommendInfoService = webRecommendInfoService;
    }

    public IWebRecommendPositionService getWebRecommendPositionService() {
        return webRecommendPositionService;
    }

    public void setWebRecommendPositionService(IWebRecommendPositionService webRecommendPositionService) {
        this.webRecommendPositionService = webRecommendPositionService;
    }

    public IWebArticleService getWebArticleService() {
        return webArticleService;
    }

    public void setWebArticleService(IWebArticleService webArticleService) {
        this.webArticleService = webArticleService;
    }

    @Resource(name = "gesSoMatterItemServiceImpl")
    private IGesSoMatterItemService gesSoMatterItemService;

    public IGesReceiptOrderService getGesReceiptOrderService() {
        return gesReceiptOrderService;
    }
    
    public IWebDesignerService getWebDesignerServiceImpl() {
        return webDesignerServiceImpl;
    }

    public void setWebDesignerServiceImpl(IWebDesignerService webDesignerServiceImpl) {
        this.webDesignerServiceImpl = webDesignerServiceImpl;
    }

    public IWebContrastDetailService getWebContrastDetailServiceImpl() {
        return webContrastDetailServiceImpl;
    }

    public void setWebContrastDetailServiceImpl(
            IWebContrastDetailService webContrastDetailServiceImpl) {
        this.webContrastDetailServiceImpl = webContrastDetailServiceImpl;
    }

    public void setGesReceiptOrderService(IGesReceiptOrderService gesReceiptOrderService) {
        this.gesReceiptOrderService = gesReceiptOrderService;
    }

    public IGesPaymentOrderService getGesPaymentOrderService() {
        return gesPaymentOrderService;
    }

    public void setGesPaymentOrderService(IGesPaymentOrderService gesPaymentOrderService) {
        this.gesPaymentOrderService = gesPaymentOrderService;
    }

    public IAuthenticationService getAuthenticationService() {
        return authenticationService;
    }

    public void setAuthenticationService(IAuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    public IUserInfoService getUserInfoService() {
        return userInfoService;
    }

    public void setUserInfoService(IUserInfoService userInfoService) {
        this.userInfoService = userInfoService;
    }

    public IUserService getUserService() {
        return userService;
    }

    public void setUserService(IUserService userService) {
        this.userService = userService;
    }

    public IValidateService getValidateService() {
        return validateService;
    }

    public void setValidateService(IValidateService validateService) {
        this.validateService = validateService;
    }

    @Resource(name = "userServiceImpl")
    private IUserService userService;
    @Resource(name = "validateServiceImpl")
    private IValidateService validateService;

    @Resource(name = "webCommentItemServiceImpl")
    private IWebCommentItemService webCommentItemService;

    public IWebCommentItemService getWebCommentItemService() {
        return webCommentItemService;
    }

    public void setWebCommentItemService(IWebCommentItemService webCommentItemService) {
        this.webCommentItemService = webCommentItemService;
    }

    @Resource(name = "smsValidationServiceImpl")
    private ISmsValidationService smsValidationService;

    public ISmsValidationService getSmsValidationService() {
        return smsValidationService;
    }

    public void setSmsValidationService(ISmsValidationService smsValidationService) {
        this.smsValidationService = smsValidationService;
    }
    @Resource(name="emailValidationServiceImpl")
    private IEmailValidationService emailValidationService;

    public IEmailValidationService getEmailValidationService() {
        return emailValidationService;
    }

    public void setEmailValidationService(IEmailValidationService emailValidationService) {
        this.emailValidationService = emailValidationService;
    }

    public IMatterAlbumService getMatterAlbumService() {
        return matterAlbumService;
    }

    public void setMatterAlbumService(IMatterAlbumService matterAlbumService) {
        this.matterAlbumService = matterAlbumService;
    }

    public IMatterSpecService getMatterSpecService() {
        return matterSpecService;
    }

    public void setMatterSpecService(IMatterSpecService matterSpecService) {
        this.matterSpecService = matterSpecService;
    }

    public IGoodsRoomService getGoodsRoomService() {
        return goodsRoomService;
    }

    public void setGoodsRoomService(IGoodsRoomService goodsRoomService) {
        this.goodsRoomService = goodsRoomService;
    }

    public IGoodsService getGoodsService() {
        return goodsService;
    }

    public void setGoodsService(IGoodsService goodsService) {
        this.goodsService = goodsService;
    }

    public IGoodsDiyItemService getGoodsDiyItemService() {
        return goodsDiyItemService;
    }

    public void setGoodsDiyItemService(IGoodsDiyItemService goodsDiyItemService) {
        this.goodsDiyItemService = goodsDiyItemService;
    }

    public IGoodsPriceDetailService getGoodsPriceDetailService() {
        return goodsPriceDetailService;
    }

    public void setGoodsPriceDetailService(IGoodsPriceDetailService goodsPriceDetailService) {
        this.goodsPriceDetailService = goodsPriceDetailService;
    }

    public IGoodsDiyMatterService getGoodsDiyMatterService() {
        return goodsDiyMatterService;
    }

    public void setGoodsDiyMatterService(IGoodsDiyMatterService goodsDiyMatterService) {
        this.goodsDiyMatterService = goodsDiyMatterService;
    }

    public IGoodsMatterService getGoodsMatterService() {
        return goodsMatterService;
    }

    public void setGoodsMatterService(IGoodsMatterService goodsMatterService) {
        this.goodsMatterService = goodsMatterService;
    }

    public IGoodsMarkService getGoodsMarkService() {
        return goodsMarkService;
    }

    public void setGoodsMarkService(IGoodsMarkService goodsMarkService) {
        this.goodsMarkService = goodsMarkService;
    }

    public IDictionaryService getDictionaryService() {
        return dictionaryService;
    }

    public void setDictionaryService(IDictionaryService dictionaryService) {
        this.dictionaryService = dictionaryService;
    }

    public IGesShopService getGesShopServiceImpl() {
        return gesShopServiceImpl;
    }

    public void setGesShopServiceImpl(IGesShopService gesShopServiceImpl) {
        this.gesShopServiceImpl = gesShopServiceImpl;
    }

    public IMatterService getMatterService() {
        return matterService;
    }

    public void setMatterService(IMatterService matterService) {
        this.matterService = matterService;
    }

    public IWebLabelService getWebLabelService() {
        return webLabelService;
    }

    public void setWebLabelService(IWebLabelService webLabelService) {
        this.webLabelService = webLabelService;
    }

    public IGesCityOperatorService getGesCityOperatorService() {
        return gesCityOperatorService;
    }

    public void setGesCityOperatorService(IGesCityOperatorService gesCityOperatorService) {
        this.gesCityOperatorService = gesCityOperatorService;
    }

    public IBrandService getBrandService() {
        return brandService;
    }

    public void setBrandService(IBrandService brandService) {
        this.brandService = brandService;
    }

    public IMaterialsCategoryService getMaterialsCategoryService() {
        return materialsCategoryService;
    }

    public void setMaterialsCategoryService(IMaterialsCategoryService materialsCategoryService) {
        this.materialsCategoryService = materialsCategoryService;
    }

    public IGesMenuService getGesMenuService() {
        return gesMenuService;
    }

    public void setGesMenuService(IGesMenuService gesMenuService) {
        this.gesMenuService = gesMenuService;
    }

    public IDeptService getDeptService() {
        return deptService;
    }

    public void setDeptService(IDeptService deptService) {
        this.deptService = deptService;
    }

    public IGesBuildingService getGesBuildingService() {
        return gesBuildingService;
    }

    public void setGesBuildingService(IGesBuildingService gesBuildingService) {
        this.gesBuildingService = gesBuildingService;
    }

    public IPictureService getPictureService() {
        return pictureService;
    }

    public void setPictureService(IPictureService pictureService) {
        this.pictureService = pictureService;
    }

    public IWebContrastService getWebContrastService() {
        return webContrastService;
    }

    public void setWebContrastService(IWebContrastService webContrastService) {
        this.webContrastService = webContrastService;
    }

    public IGesAreaService getGesAreaService() {
        return gesAreaService;
    }

    public void setGesAreaService(IGesAreaService gesAreaService) {
        this.gesAreaService = gesAreaService;
    }

    public IWebAdbiceService getWebAdbiceService() {
        return webAdbiceService;
    }

    public void setWebAdbiceService(IWebAdbiceService webAdbiceService) {
        this.webAdbiceService = webAdbiceService;
    }

    public IGesStoreService getGesStoreService() {
        return gesStoreService;
    }

    public void setGesStoreService(IGesStoreService gesStoreService) {
        this.gesStoreService = gesStoreService;
    }

    public IGesStoreLocationService getGesStoreLocationService() {
        return gesStoreLocationService;
    }

    public void setGesStoreLocationService(IGesStoreLocationService gesStoreLocationService) {
        this.gesStoreLocationService = gesStoreLocationService;
    }

    public IGesStoreInventoryService getGesStoreInventoryService() {
        return gesStoreInventoryService;
    }

    public void setGesStoreInventoryService(IGesStoreInventoryService gesStoreInventoryService) {
        this.gesStoreInventoryService = gesStoreInventoryService;
    }

    public IGesPoMainService getGesPoMainService() {
        return gesPoMainService;
    }

    public void setGesPoMainService(IGesPoMainService gesPoMainService) {
        this.gesPoMainService = gesPoMainService;
    }

    public IGesRdRecordService getGesRdRecordService() {
        return gesRdRecordService;
    }

    public void setGesRdRecordService(IGesRdRecordService gesRdRecordService) {
        this.gesRdRecordService = gesRdRecordService;
    }

    public IERPBaseDataService getErpBaseDataService() {
        return erpBaseDataService;
    }

    public void setErpBaseDataService(IERPBaseDataService erpBaseDataService) {
        this.erpBaseDataService = erpBaseDataService;
    }

    public IGesErpCodeService getGesErpCodeService() {
        return gesErpCodeService;
    }

    public void setGesErpCodeService(IGesErpCodeService gesErpCodeService) {
        this.gesErpCodeService = gesErpCodeService;
    }

    public IGesPoDetailService getGesPoDetailService() {
        return gesPoDetailService;
    }

    public void setGesPoDetailService(IGesPoDetailService gesPoDetailService) {
        this.gesPoDetailService = gesPoDetailService;
    }

    public IGesRdRecordsService getGesRdRecordsService() {
        return gesRdRecordsService;
    }

    public void setGesRdRecordsService(IGesRdRecordsService gesRdRecordsService) {
        this.gesRdRecordsService = gesRdRecordsService;
    }

    public IMatterUnitService getMatterUnitService() {
        return matterUnitService;
    }

    public void setMatterUnitService(IMatterUnitService matterUnitService) {
        this.matterUnitService = matterUnitService;
    }

    public IGesOrderPayMoneyService getGesOrderPayMoneyService() {
        return gesOrderPayMoneyService;
    }

    public void setGesOrderPayMoneyService(IGesOrderPayMoneyService gesOrderPayMoneyService) {
        this.gesOrderPayMoneyService = gesOrderPayMoneyService;
    }

    public IGesSoMatterItemService getGesSoMatterItemService() {
        return gesSoMatterItemService;
    }

    public void setGesSoMatterItemService(IGesSoMatterItemService gesSoMatterItemService) {
        this.gesSoMatterItemService = gesSoMatterItemService;
    }

    protected ErrorResult getError(Exception ex) {
        ErrorResult error = new ErrorResult();
        if (ex instanceof ErrorCodeException) {
            ErrorCodeException ece = (ErrorCodeException) ex;
            error.setRet(ece.getErrorCode());
            error.setMsg(ece.getErrorMessage());
        } else if (ex instanceof GenericException) {
            GenericException ge = (GenericException) ex;
            error.setRet(String.valueOf(SECode.s_100010.getCode()));
            error.setMsg(ge.getErrorMessage().getMessage());
        } else {
            error.setRet(String.valueOf(SECode.s_100010.getCode()));
            error.setMsg(SECode.s_100010.getMessage());
        }

        error.setVersion("4.0.0");

        return error;
    }

    public IGesOrderService getGesOrderService() {
        return gesOrderService;
    }

    public void setGesOrderService(IGesOrderService gesOrderService) {
        this.gesOrderService = gesOrderService;
    }

    public IGesCityService getGesCityService() {
        return gesCityService;
    }

    public void setGesCityService(IGesCityService gesCityService) {
        this.gesCityService = gesCityService;
    }

    public IGesCustomerService getGesCustomerService() {
        return gesCustomerService;
    }

    public void setGesCustomerService(IGesCustomerService gesCustomerService) {
        this.gesCustomerService = gesCustomerService;
    }

    public IWebEncyclopediaLabelItemService getWebEncyclopediaLabelItemService() {
        return webEncyclopediaLabelItemService;
    }

    public void setWebEncyclopediaLabelItemService(IWebEncyclopediaLabelItemService webEncyclopediaLabelItemService) {
        this.webEncyclopediaLabelItemService = webEncyclopediaLabelItemService;
    }

    public IWebTopicArticleItemService getWebTopicArticleItemService() {
        return webTopicArticleItemService;
    }

    public void setWebTopicArticleItemService(IWebTopicArticleItemService webTopicArticleItemService) {
        this.webTopicArticleItemService = webTopicArticleItemService;
    }

    public IWebArticleGoodsService getWebArticleGoodsService() {
        return webArticleGoodsService;
    }

    public void setWebArticleGoodsService(IWebArticleGoodsService webArticleGoodsService) {
        this.webArticleGoodsService = webArticleGoodsService;
    }

    public IGesErpSynchLogService getGesErpSynchLogService() {
        return gesErpSynchLogService;
    }

    public void setGesErpSynchLogService(IGesErpSynchLogService gesErpSynchLogService) {
        this.gesErpSynchLogService = gesErpSynchLogService;
    }

    public IGesCustomerMessageService getGesCustomerMessageService() {
        return gesCustomerMessageService;
    }

    public void setGesCustomerMessageService(IGesCustomerMessageService gesCustomerMessageService) {
        this.gesCustomerMessageService = gesCustomerMessageService;
    }

    public IGesCustomerMessageLogService getGesCustomerMessageLogService() {
        return gesCustomerMessageLogService;
    }

    public void setGesCustomerMessageLogService(IGesCustomerMessageLogService gesCustomerMessageLogService) {
        this.gesCustomerMessageLogService = gesCustomerMessageLogService;
    }

    public IModellingService getModellingService() {
        return modellingService;
    }

    public void setModellingService(IModellingService modellingService) {
        this.modellingService = modellingService;
    }

    public IModellingMatterItemService getModellingMatterItemService() {
        return modellingMatterItemService;
    }

    public void setModellingMatterItemService(IModellingMatterItemService modellingMatterItemService) {
        this.modellingMatterItemService = modellingMatterItemService;
    }

    public IWebSupportItemService getWebSupportItemService() {
        return webSupportItemService;
    }

    public void setWebSupportItemService(IWebSupportItemService webSupportItemService) {
        this.webSupportItemService = webSupportItemService;
    }

    public IWebCollectionItemService getWebCollectionItemService() {
        return webCollectionItemService;
    }

    public void setWebCollectionItemService(IWebCollectionItemService webCollectionItemService) {
        this.webCollectionItemService = webCollectionItemService;
    }

    public IGesShopGoodsItemService getGesShopGoodsItemService() {
        return gesShopGoodsItemService;
    }

    public void setGesShopGoodsItemService(IGesShopGoodsItemService gesShopGoodsItemService) {
        this.gesShopGoodsItemService = gesShopGoodsItemService;
    }

    @Resource(name = "multiplePaymentServiceImpl")
    private IMultiplePaymentService multiplePaymentService;

    public IMultiplePaymentService getMultiplePaymentService() {
        return multiplePaymentService;
    }

    public void setMultiplePaymentService(IMultiplePaymentService multiplePaymentService) {
        this.multiplePaymentService = multiplePaymentService;
    }

    @Resource(name = "ownerLoanServiceImpl")
    private IOwnerLoanService ownerLoanService;

    public IOwnerLoanService getOwnerLoanService() {
        return ownerLoanService;
    }

	public void setOwnerLoanService(IOwnerLoanService ownerLoanService) {
		this.ownerLoanService = ownerLoanService;
	}
    
	@Resource(name="loanDictServiceImpl")
    private ILoanDictService loanDictService;

	public ILoanDictService getLoanDictService() {
		return loanDictService;
	}

	public void setLoanDictService(ILoanDictService loanDictService) {
		this.loanDictService = loanDictService;
	}
	
	@Resource(name="orderGjbPayServiceImpl")
	private IOrderGjbPayService orderGjbPayService;

	public IOrderGjbPayService getOrderGjbPayService() {
		return orderGjbPayService;
	}

	public void setOrderGjbPayService(IOrderGjbPayService orderGjbPayService) {
		this.orderGjbPayService = orderGjbPayService;
	}
	
	
	@Resource(name="roleServiceImpl")
	private IRoleService roleService;

    public IRoleService getRoleService() {
        return roleService;
    }

    public void setRoleService(IRoleService roleService) {
        this.roleService = roleService;
    }

    public IGesMenuRoleItemService getGesMenuRoleItemService() {
        return gesMenuRoleItemService;
    }

    public void setGesMenuRoleItemService(
            IGesMenuRoleItemService gesMenuRoleItemService) {
        this.gesMenuRoleItemService = gesMenuRoleItemService;
    }

    public IBuildingSaleConfigService getBuildingSaleConfigService() {
        return buildingSaleConfigService;
    }

    public void setBuildingSaleConfigService(
            IBuildingSaleConfigService buildingSaleConfigService) {
        this.buildingSaleConfigService = buildingSaleConfigService;
    }

    public IBuildingInfoService getBuildingInfoService() {
        return buildingInfoService;
    }

    public void setBuildingInfoService(IBuildingInfoService buildingInfoService) {
        this.buildingInfoService = buildingInfoService;
    }

    public IBuildingInfoGoodsService getBuildingInfoGoodsService() {
        return buildingInfoGoodsService;
    }

    public void setBuildingInfoGoodsService(
            IBuildingInfoGoodsService buildingInfoGoodsService) {
        this.buildingInfoGoodsService = buildingInfoGoodsService;
    }
    
    
  //练习
    @Resource(name="xgGoujiaServiceImpl")
    private XgGoujiaService xgGoujiaService;

	public XgGoujiaService getXgGoujiaService() {
		return xgGoujiaService;
	}

	public void setXgGoujiaService(XgGoujiaService xgGoujiaService) {
		this.xgGoujiaService = xgGoujiaService;
	}

    
  

}
