/**
 * Copyright 2014-2015 goujia.com
 * All rights reserved.
 * 
 * @project
 * @author guojianbin
 * @version 3.0
 * @date 2015-09-26
 */
package com.gjw.dto.diy;

import java.io.Serializable;
import java.util.List;

import com.gjw.entity.goods.GoodsDiyMatter;

/**
 * DIY清单数据传输对象
 * @author guojianbin
 *
 */
public class GoodsDiyMatterDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * DIY增加项列表
	 */
	private List<GoodsDiyMatter> addList;
	
	/**
	 * DIY减少项列表
	 */
	private List<GoodsDiyMatter> reduceList;
	
	/**
	 * DIY替换项列表(替换前)
	 */
	private List<GoodsDiyMatter> replaceToList;
	
	/**
	 * DIY替换项列表(替换后)
	 */
	private List<GoodsDiyMatter> replaceFromList;
	
	public List<GoodsDiyMatter> getAddList() {
		return addList;
	}
	
	public void setAddList(List<GoodsDiyMatter> addList) {
		this.addList = addList;
	}
	
	public List<GoodsDiyMatter> getReduceList() {
		return reduceList;
	}
	
	public void setReduceList(List<GoodsDiyMatter> reduceList) {
		this.reduceList = reduceList;
	}
	
	public List<GoodsDiyMatter> getReplaceToList() {
		return replaceToList;
	}
	
	public void setReplaceToList(List<GoodsDiyMatter> replaceToList) {
		this.replaceToList = replaceToList;
	}
	
	public List<GoodsDiyMatter> getReplaceFromList() {
		return replaceFromList;
	}
	
	public void setReplaceFromList(List<GoodsDiyMatter> replaceFromList) {
		this.replaceFromList = replaceFromList;
	}

}
