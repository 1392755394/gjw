/**
 * Copyright 2014-2015 goujia.com
 * All rights reserved.
 * 
 * @project
 * @author guojianbin
 * @version 3.0
 * @date 2015-09-19
 */
package com.gjw.dto.diy;

import java.io.Serializable;
import java.util.List;

import com.gjw.common.constants.GoodsDiyConstant;
import com.gjw.entity.goods.Goods;

/**
 * DIY方案数据传输对象
 * @author guojianbin
 *
 */
public class GoodsDiyDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * DIY方案ID
	 */
	private Long diyId;

	/**
	 * DIY方案的关联产品包的ID
	 */
    private Long goodsId;
    
    /**
     * 产品包名称
     */
    private String name;
	
	/**
	 * DIY方案名称
	 */
	private String diyName;
    
    /**
     * 楼盘名称
     */
    private String buildingName;
    
    /**
     * 风格名称
     */
    private String styleName;
    
    /**
     * 户型名称
     */
    private String houseTypeName;
    
    /**
     * 面积
     */
    private Double floorArea;
    
    /**
     * 是否标准DIY方案：'y'|'n' '是'|'否'
     */
    private String isStandardDiy;
	
    /**
     * 是否后端：'y'|'n' '是'|'否'
     */
    private String isBackend;
	
    /**
     * 用户ID
     */
    private Long userId;
	
    /**
     * 是否编辑：0:否、1：编辑标准DIY、2：编辑普通DIY
     */
    private Integer isModify;

    /**
     * 是否DIY
     */
    private Long isDiy;

	/**
	 * 房间列表
	 */
	private List<GoodsRoomDTO> roomList;
	
	public Long getDiyId() {
		return diyId;
	}

	public void setDiyId(Long diyId) {
		this.diyId = diyId;
	}

	public Long getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Long goodsId) {
		this.goodsId = goodsId;
	}

	public String getDiyName() {
		return diyName;
	}

	public void setDiyName(String diyName) {
		this.diyName = diyName;
	}

	public List<GoodsRoomDTO> getRoomList() {
		return roomList;
	}

	public void setRoomList(List<GoodsRoomDTO> roomList) {
		this.roomList = roomList;
	}

	public String getIsBackend() {
		return isBackend;
	}

	public void setIsBackend(String isBackend) {
		this.isBackend = isBackend;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Integer getIsModify() {
		return isModify;
	}

	public void setIsModify(Integer isModify) {
		this.isModify = isModify;
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getStyleName() {
        return styleName;
    }

    public void setStyleName(String styleName) {
        this.styleName = styleName;
    }

    public String getHouseTypeName() {
        return houseTypeName;
    }

    public void setHouseTypeName(String houseTypeName) {
        this.houseTypeName = houseTypeName;
    }

    public Double getFloorArea() {
        return floorArea;
    }

    public void setFloorArea(Double floorArea) {
        this.floorArea = floorArea;
    }

    public String getIsStandardDiy() {
        return isStandardDiy;
    }

    public void setIsStandardDiy(String isStandardDiy) {
        this.isStandardDiy = isStandardDiy;
    }

    public Long getIsDiy() {
        return isDiy;
    }

    public void setIsDiy(Long isDiy) {
        this.isDiy = isDiy;
    }

    public void copyFromEntity(Goods goods) {
        this.name = goods.getName();
        this.buildingName = goods.getHouse().getBuilding().getName();
        this.styleName = goods.getStyle().getText();
        this.houseTypeName = goods.getHouseType().getText();
        this.floorArea = goods.getHouse().getFloorArea();
        // 编码转换：产品包：1030201->0、标准DIY方案：1030202->1、用户DIY方案：1030203->2
        this.isDiy = goods.getDiyType().getId() - GoodsDiyConstant.IS_DIY_GOODS;
    }

}
